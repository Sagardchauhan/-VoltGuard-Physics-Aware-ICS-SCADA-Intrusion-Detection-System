# Component interfaces (schema version 1)

Every component exchanges JSON objects. The machine-readable contract is `message_schema.json`; the reference validators are in `voltguard/schemas.py`. The transport (subprocess pipes vs. local IPC) is chosen in Phase 7 and is not part of this document.

```
C++ parser --ParsedCommand--> Python physics --SimulationResult--> Rust decision --DecisionResult--> logger / dashboard
```

## General rules

- All messages are untrusted input to their receiver. Validate exact key sets, types, ranges and finiteness; reject unknown fields.
- `command_id` (`[A-Za-z0-9_.-]{1,64}`) is carried unchanged through every stage for traceability.
- Numbers must be finite (no NaN/Infinity). Booleans are not accepted as integers.
- **Fail closed:** a missing, invalid, timed-out or contradictory message is never treated as "safe". It results in `REJECT` or `BLOCK`.
- Packet data is never used to build shell commands or file paths.

## ParsedCommand (parser -> physics)

| Field | Type / range | Used by |
|---|---|---|
| command_id | string, pattern above | all |
| protocol | exactly `"Modbus/TCP"` | all |
| transaction_id | integer 0..65535 | all |
| unit_id | integer 0..255 | all |
| function_code | 3, 6 or 16 | all |
| register_address | integer 0..65535 | all |
| register_value | integer 0..65535 | FC 6 only |
| quantity | integer 1..125 (FC 3), 1..123 (FC 16) | FC 3, 16 |
| register_values | list of `quantity` integers 0..65535 | FC 16 only |

Fields not listed for a function code must be absent. `register_address + quantity - 1` must not exceed 65535. Any other function code is unsupported and is rejected by the parser (it never reaches the physics engine).

```json
{"command_id": "TEST-001", "protocol": "Modbus/TCP", "transaction_id": 1,
 "unit_id": 1, "function_code": 6, "register_address": 100, "register_value": 60}
```

## SimulationResult (physics -> decision)

| Field | Notes |
|---|---|
| command_id, simulation_status, pressure_unit, configured_min_pressure, configured_max_pressure, violations | required |
| simulation_status | `SUCCESS`, `INVALID_INPUT`, `ERROR`, `TIMEOUT` |
| predicted_pressure, predicted_flow, flow_unit | required when `SUCCESS`; forbidden otherwise |
| error | required (non-empty) when not `SUCCESS`; forbidden when `SUCCESS` |
| violations | list of `{type, limit, predicted}`; must be empty when not `SUCCESS` |

Violation types: `PRESSURE_HIGH`, `PRESSURE_LOW`, `FLOW_HIGH`, `FLOW_LOW`. A `_HIGH` violation requires `predicted > limit`; a `_LOW` violation requires `predicted < limit`. Contradictory violations are rejected. `configured_min_pressure` must be less than `configured_max_pressure`.

```json
{"command_id": "TEST-001", "simulation_status": "SUCCESS", "pressure_unit": "kPa",
 "configured_min_pressure": 20.0, "configured_max_pressure": 100.0, "violations": [],
 "predicted_pressure": 75.0, "predicted_flow": 30.0, "flow_unit": "L/s"}
```

All values are illustrative simulation outputs, not sensor measurements.

## DecisionResult (decision -> logger / dashboard)

| Field | Notes |
|---|---|
| command_id, decision, reason | required; `reason` non-empty, at most 512 characters |
| decision | `ALLOW` (policy satisfied), `BLOCK` (predicted physical violation), `REJECT` (malformed, unsupported or unprocessable input) |
| predicted_pressure, configured_max_pressure | optional, finite numbers |

```json
{"command_id": "TEST-002", "decision": "BLOCK",
 "reason": "Predicted pressure exceeds configured maximum",
 "predicted_pressure": 120.0, "configured_max_pressure": 100.0}
```

## Versioning

This is schema version 1. The safety configuration (`config/safety_limits.json`) carries its own `schema_version`. Message schemas will gain an explicit version field if the IPC envelope in Phase 7 needs one.

## Mock traffic file (traffic generator -> parser tests)

`python -m traffic_generator.generate_traffic` writes `{"format_version": 1, "messages": [...]}`. Each message holds `command_id` (`TG-0001`...), `scenario`, `description`, `intent`, `parse_expected` (`PARSE_OK` or `PARSE_REJECT`), `frame_hex`, `frame_length`, and either `expected_fields` (the ParsedCommand fields the parser must produce) or `reject_reason`.

`parse_expected` is a protocol-level fact the parser must reproduce (Phase 4). `intent` is the physical outcome expected from the Phase 5 simulation model with the default settings (`NORMAL`, `BOUNDARY_SAFE`, `UNSAFE`, `INVALID_VALUE`, `READ_ONLY`, ...). Since Phase 5 it is pinned by tests against the invented prototype model; it is not a real-world safety claim and never overrides a parser or decision result. The generator writes files only and never opens a network connection.

Register map of the mock pipeline (`voltguard/register_map.py`, invented, not a real PLC): register 100 = pump speed (percent, valid 0..100), register 101 = valve position (percent, valid 0..100).

## Parser CLI (`voltguard_parser_cli`)

The C++ parser is exposed as a line-oriented filter: one request per stdin line, one JSON object per stdout line, in order. It reads stdin only and never opens files, sockets or subprocesses. (Phase 7 decides how the application drives it.)

Input line: `<command_id> [<frame as hex>]`. Blank lines and lines starting with `#` are ignored. A line with only a command id is an empty frame. Lines longer than 4096 bytes are rejected without parsing; memory per line is bounded.

Output:

```json
{"command_id":"T1","status":"OK","command":{"command_id":"T1","protocol":"Modbus/TCP","transaction_id":1,"unit_id":1,"function_code":6,"register_address":100,"register_value":60}}
{"command_id":"T2","status":"REJECTED","error_code":"UNSUPPORTED_FUNCTION_CODE","error":"unsupported function code"}
{"command_id":null,"status":"REJECTED","error_code":"INVALID_INPUT","error":"invalid command id"}
```

`command` conforms to the ParsedCommand schema above. `command_id` is `null` when the id itself was invalid; untrusted text is never echoed.

| error_code | error | Meaning |
|---|---|---|
| FRAME_TOO_LARGE | frame too large | more than 260 bytes (checked first) |
| FRAME_TOO_SHORT | frame shorter than MBAP header | fewer than 7 bytes |
| INVALID_PROTOCOL_ID | invalid protocol id | MBAP protocol id is not 0 |
| LENGTH_MISMATCH | length field mismatch | MBAP length does not equal the bytes that follow it |
| MISSING_FUNCTION_CODE | missing function code | header only |
| UNSUPPORTED_FUNCTION_CODE | unsupported function code | anything other than 3, 6, 16 |
| INVALID_PDU_LENGTH | invalid PDU length for function code | wrong PDU size for the function |
| INVALID_QUANTITY | invalid quantity | FC3 not 1..125, FC16 not 1..123 |
| BYTE_COUNT_MISMATCH | byte count mismatch | FC16 byte count is not 2 x quantity |
| REGISTER_RANGE_OVERFLOW | register range exceeds address space | address + quantity - 1 > 65535 |
| INVALID_INPUT | (varies) | the text line itself was unusable (bad id, bad hex, extra tokens, too long) |

The `error` strings for protocol errors are identical to the fixture's `reject_reason` values and are asserted by tests. A rejected request is never forwarded to the physics engine.

## Pipeline (`voltguard/pipeline.py`, Phase 7)

`Pipeline.process_frame(command_id, frame_bytes)` -> `PipelineResult`. It never raises for bad input or failed components. The parser child is started from a fixed argument list (`shell=False`) and receives only `<validated id> <hex digits>` lines. Timeouts come from `config/safety_limits.json` (`timeouts_ms.parser`, `timeouts_ms.simulation`).

| Field | Meaning |
|---|---|
| `command_id` | The caller's id, unchanged; `null` only if the id itself was invalid |
| `stage` | `SIMULATED`: parsed, and a SimulationResult exists (check its `simulation_status`; a failed or violating simulation is still `SIMULATED`). `PARSE_REJECTED`: the parser rejected the frame, the simulator was not called. `COMPONENT_FAILURE`: a component failed, no usable result |
| `parsed_command`, `simulation` | ParsedCommand / SimulationResult objects, or `null` |
| `error_code`, `error` | Set for `PARSE_REJECTED` (the parser's code and text) and `COMPONENT_FAILURE` |
| `timings_ms` | `parse` (includes the process round trip), `simulate`, `total` |

`COMPONENT_FAILURE` codes: `INVALID_COMMAND_ID`, `INVALID_FRAME`, `PARSER_UNAVAILABLE` (cannot start), `PARSER_TIMEOUT`, `PARSER_CRASHED`, `PARSER_BAD_OUTPUT` (not JSON, too long, unknown status, missing fields), `PARSER_ID_MISMATCH`, `PARSER_SCHEMA_ERROR` (reply violates ParsedCommand, or inner id differs), `SIMULATOR_ERROR`. Frames over 1000 bytes are `PARSE_REJECTED` / `FRAME_TOO_LARGE` without being sent.

Rules for consumers (Phase 10): only `SIMULATED` with `simulation_status == "SUCCESS"` can ever lead to ALLOW, and only if the policy is satisfied. `PARSE_REJECTED` maps to REJECT; `COMPONENT_FAILURE` and any non-SUCCESS simulation fail closed. A pipeline result is not itself a decision.

## Dashboard worker protocol (`python -m voltguard.worker`, Phase 8)

The Qt dashboard starts the worker as a child process (`QProcess`, fixed argument list, no shell) and exchanges **one JSON object per line** over stdin/stdout, so the GUI thread never runs parser or simulation code. stdout carries protocol lines only; diagnostics go to `logs/`. Requests longer than 64 KB, non-JSON lines and unknown ops get an `error` reply; the worker survives them.

| Direction | Message |
|---|---|
| worker -> GUI, once at start | `{"type":"ready","version","config":{pressure,flow,pump_speed,valve_position:{min,max,unit},timeouts_ms,description},"config_path","parser_available","parser_path","decision_engine":{available,path,error},"event_log":{enabled,path,ok,error},"notice"}` or `{"type":"fatal","error"}` (exit 2: invalid safety configuration, fail closed) |
| GUI -> worker | `{"op":"scenarios"}` -> `{"type":"scenarios","scenarios":[{name,description,intent,frame_hex}]}` |
| GUI -> worker | `{"op":"process","command_id":ID,"frame_hex":HEX}` -> `{"type":"result","timestamp_utc",<PipelineResult fields above>}` |
| GUI -> worker | `{"op":"shutdown"}` -> worker exits 0 |
| GUI -> worker | `{"op":"process", ..., "source":TEXT}` (optional `source`, default `manual`); the result gains `"logged": true|false|null` (stored / NOT stored / logging off) |
| GUI -> worker | `{"op":"events","limit":N,"severity":S}` -> `{"type":"events","total":n,"events":[{id,timestamp_utc,command_id,source,stage,severity,sim_status,function_code,register_address,predicted_pressure,predicted_flow,violations,error_code,error}]}` newest first; `{"op":"verify_log"}` -> `{"type":"log_verification","ok","message"}` |
| GUI -> worker | process replies also carry `"decision":{command_id,decision:ALLOW|BLOCK|REJECT,reason,source:"engine"|"fail_closed",error_code:null|CODE,[predicted_pressure,configured_max_pressure]}` (Phase 11; always present). The worker takes `--decision-engine PATH` (default: `$VOLTGUARD_DECISION_ENGINE` or `decision_engine/target/{release,debug}`); without a working engine every result is REJECT (`DECISION_ENGINE_UNAVAILABLE`). Events replies include `decision`, `decision_reason`, `decision_source`. |
| GUI -> worker | `{"op":"export","format":"csv"|"json"|"pdf","path":P,"severity":S?,"overwrite":bool?}` -> `{"type":"export","ok":true,"path","format","rows","total","truncated","verified","message"}` or `{"type":"export","ok":false,"error"}` (Phase 15; never overwrites unless `overwrite` is true; the dashboard allows `overwrite` only after its save dialog confirmed). |
| worker -> GUI | `{"type":"error","command_id":ID|null,"error":TEXT}` for any invalid request |

`frame_hex` must be an even number of hex digits, at most 4000 characters (the pipeline itself rejects frames over 1000 bytes). The dashboard validates this before sending and again treats the worker as untrusted: every `result` is checked field by field (`CommandRecord::fromJson`); a reply that fails validation, does not match a pending request, exceeds 2 MB per line, or does not arrive within the request timeout (10 s) puts the client in the `Failed` state, kills the worker, and every pending command is shown as a `COMPONENT_FAILURE` row. The dashboard displays the decision exactly as received and validates it strictly: the `decision` object must exist, match the command id, be ALLOW/BLOCK/REJECT with a non-empty reason (<= 512), source `engine` (no error code) or `fail_closed` (REJECT with an error code), and ALLOW/BLOCK are accepted only for a SIMULATED result with simulation status SUCCESS. A reply that fails any check is shown as a failure row (REJECT, fail_closed). Nothing is forwarded to any device.
