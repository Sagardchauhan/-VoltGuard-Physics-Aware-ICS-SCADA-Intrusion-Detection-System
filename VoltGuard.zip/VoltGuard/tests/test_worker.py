"""Phase 8 tests: the JSON-lines worker that the Qt dashboard talks to."""

import json
import subprocess
import sys
from datetime import datetime
from pathlib import Path

import pytest

from voltguard.pipeline import STAGES, find_parser_cli
from voltguard.worker import MAX_FRAME_HEX_CHARS, MAX_REQUEST_BYTES

ROOT = Path(__file__).resolve().parent.parent
CLI = find_parser_cli()
needs_cpp = pytest.mark.skipif(CLI is None, reason="voltguard_parser_cli not built (these tests did NOT run)")
VALID = "00010000000601060064003c"


class Worker:
    def __init__(self, tmp_path, *extra):
        self.proc = subprocess.Popen(
            [sys.executable, "-m", "voltguard.worker", "--log-dir", str(tmp_path), *extra], cwd=ROOT,
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        self.lines = []

    def read(self):
        line = self.proc.stdout.readline()
        assert line, "worker closed stdout: " + self.proc.stderr.read().decode(errors="replace")
        self.lines.append(line)
        return json.loads(line)

    def send(self, obj):
        raw = obj if isinstance(obj, bytes) else json.dumps(obj).encode()
        self.proc.stdin.write(raw + b"\n")
        self.proc.stdin.flush()

    def ask(self, obj):
        self.send(obj)
        return self.read()

    def close(self):
        try:
            self.proc.stdin.close()
        except OSError:
            pass
        try:
            self.proc.wait(timeout=10)
        except subprocess.TimeoutExpired:
            self.proc.kill()
            self.proc.wait()
        self.proc.stdout.close(), self.proc.stderr.close()


@pytest.fixture
def worker(tmp_path):
    w = Worker(tmp_path, *(["--parser-cli", str(CLI)] if CLI else []))
    ready = w.read()
    assert ready["type"] == "ready", ready
    w.ready = ready
    yield w
    w.close()


def test_ready_message_describes_configuration_and_status(worker):
    r = worker.ready
    assert r["version"] and "SIMULATED" in r["notice"]
    assert set(r["decision_engine"]) == {"available", "path", "error"}
    assert r["config"]["pressure"] == {"min": 20.0, "max": 100.0, "unit": "kPa"}
    assert r["config"]["flow"]["unit"] == "L/s" and set(r["config"]["timeouts_ms"]) == {"parser", "simulation", "decision"}
    assert r["parser_available"] is bool(CLI)


@needs_cpp
def test_scenarios_op_lists_every_generator_scenario(worker):
    reply = worker.ask({"op": "scenarios"})
    assert reply["type"] == "scenarios" and len(reply["scenarios"]) >= 27
    names = {s["name"] for s in reply["scenarios"]}
    assert {"normal_pump_60", "unsafe_pump_100", "malformed_empty"} <= names
    assert all(set(s) == {"name", "description", "intent", "frame_hex"} for s in reply["scenarios"])


@needs_cpp
def test_process_returns_a_pipeline_result_with_timestamp(worker):
    reply = worker.ask({"op": "process", "command_id": "UI-0001", "frame_hex": VALID})
    assert reply["type"] == "result" and reply["command_id"] == "UI-0001" and reply["stage"] == "SIMULATED"
    assert reply["parsed_command"]["register_value"] == 60 and reply["simulation"]["simulation_status"] == "SUCCESS"
    assert set(reply["timings_ms"]) == {"parse", "simulate", "total"}
    ts = datetime.fromisoformat(reply["timestamp_utc"])
    assert ts.tzinfo is not None


@needs_cpp
def test_every_scenario_produces_a_valid_stage(worker):
    for s in worker.ask({"op": "scenarios"})["scenarios"]:
        reply = worker.ask({"op": "process", "command_id": "S-" + s["name"][:40].replace(" ", "_"), "frame_hex": s["frame_hex"]})
        assert reply["type"] == "result" and reply["stage"] in STAGES and reply["stage"] != "COMPONENT_FAILURE", s["name"]


@needs_cpp
def test_malformed_frame_is_a_parse_rejection_not_an_error(worker):
    reply = worker.ask({"op": "process", "command_id": "M1", "frame_hex": "0001"})
    assert reply["type"] == "result" and reply["stage"] == "PARSE_REJECTED" and reply["error_code"] == "FRAME_TOO_SHORT"
    assert worker.ask({"op": "process", "command_id": "M2", "frame_hex": ""})["error_code"] == "FRAME_TOO_SHORT"
    big = worker.ask({"op": "process", "command_id": "M3", "frame_hex": "00" * 1500})
    assert big["stage"] == "PARSE_REJECTED" and big["error_code"] == "FRAME_TOO_LARGE"


@pytest.mark.parametrize("request_obj,fragment", [
    (b"{not json", "not valid JSON"), (b"[1,2]", "JSON object"), (b"5", "JSON object"), (b"null", "JSON object"),
    ({}, "unknown or missing op"), ({"op": "launch_missiles"}, "unknown or missing op"), ({"op": 5}, "unknown or missing op"),
    ({"op": "process"}, "command_id"), ({"op": "process", "command_id": "bad id", "frame_hex": VALID}, "command_id"),
    ({"op": "process", "command_id": "x;y", "frame_hex": VALID}, "command_id"),
    ({"op": "process", "command_id": 5, "frame_hex": VALID}, "command_id"),
    ({"op": "process", "command_id": "A1"}, "frame_hex must be a string"),
    ({"op": "process", "command_id": "A1", "frame_hex": 12}, "frame_hex must be a string"),
    ({"op": "process", "command_id": "A1", "frame_hex": "abc"}, "even number"),
    ({"op": "process", "command_id": "A1", "frame_hex": "zz"}, "even number"),
    ({"op": "process", "command_id": "A1", "frame_hex": "00 00"}, "even number"),
    ({"op": "process", "command_id": "A1", "frame_hex": "0x00"}, "even number"),
    ({"op": "process", "command_id": "A1", "frame_hex": "00" * (MAX_FRAME_HEX_CHARS // 2 + 1)}, "longer than"),
])
def test_invalid_requests_get_an_error_reply_and_the_worker_survives(worker, request_obj, fragment):
    reply = worker.ask(request_obj)
    assert reply["type"] == "error" and fragment in reply["error"]
    assert reply["command_id"] in (None, "A1")
    follow = worker.ask({"op": "scenarios"})  # still alive and in sync
    assert follow["type"] == "scenarios"


def test_error_replies_never_echo_untrusted_ids(worker):
    reply = worker.ask({"op": "process", "command_id": "<script>alert(1)</script>", "frame_hex": VALID})
    assert reply["command_id"] is None and "script" not in json.dumps(reply)


def test_overlong_request_line_is_rejected_and_discarded(worker):
    worker.send(b'{"op":"process","command_id":"A1","frame_hex":"' + b"0" * (MAX_REQUEST_BYTES * 3) + b'"}')
    reply = worker.read()
    assert reply["type"] == "error" and "longer than" in reply["error"]
    assert worker.ask({"op": "scenarios"})["type"] == "scenarios"  # the tail of the long line was not misread


def test_binary_garbage_cannot_crash_the_worker(worker):
    for blob in (b"\xff\xfe\x00\x01", b"\x00" * 100, bytes(range(256))):
        assert worker.ask(blob.replace(b"\n", b"?"))["type"] == "error"
    assert worker.ask({"op": "scenarios"})["type"] == "scenarios"


@needs_cpp
def test_stdout_contains_only_json_protocol_lines(worker):
    worker.ask({"op": "scenarios"})
    worker.ask(b"{garbage")
    worker.ask({"op": "process", "command_id": "A1", "frame_hex": VALID})
    for line in worker.lines:
        assert isinstance(json.loads(line), dict) and "type" in json.loads(line) and line.endswith(b"\n")


@needs_cpp
def test_many_sequential_requests_keep_ids_in_order(worker):
    for i in range(300):
        reply = worker.ask({"op": "process", "command_id": f"Q{i}", "frame_hex": VALID})
        assert reply["command_id"] == f"Q{i}" and reply["stage"] == "SIMULATED"


def test_shutdown_op_exits_cleanly(tmp_path):
    w = Worker(tmp_path)
    assert w.read()["type"] == "ready"
    w.send({"op": "shutdown"})
    assert w.proc.wait(timeout=10) == 0
    w.close()


def test_stdin_eof_exits_cleanly(tmp_path):
    w = Worker(tmp_path)
    w.read()
    w.proc.stdin.close()
    assert w.proc.wait(timeout=10) == 0
    w.close()


def test_invalid_configuration_is_fatal_and_fails_closed(tmp_path):
    bad = tmp_path / "bad.json"
    bad.write_text(json.dumps({"schema_version": 1}))
    w = Worker(tmp_path, "--config", str(bad))
    msg = w.read()
    assert msg["type"] == "fatal" and "invalid safety configuration" in msg["error"]
    assert w.proc.wait(timeout=10) == 2
    w.close()


def test_missing_parser_is_reported_and_results_fail_closed(tmp_path):
    w = Worker(tmp_path, "--parser-cli", str(tmp_path / "does_not_exist"))
    ready = w.read()
    assert ready["type"] == "ready" and ready["parser_available"] is False
    reply = w.ask({"op": "process", "command_id": "P1", "frame_hex": VALID})
    assert reply["stage"] == "COMPONENT_FAILURE" and reply["error_code"] == "PARSER_UNAVAILABLE"
    assert reply["simulation"] is None and reply["parsed_command"] is None
    w.close()
