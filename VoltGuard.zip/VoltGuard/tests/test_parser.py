"""Phase 4 tests: the C++ parser CLI against the Phase 3 fixture and the Phase 2 schemas.

These tests run the compiled `voltguard_parser_cli`. Build it first:
    cmake -S . -B build && cmake --build build
or point VOLTGUARD_PARSER_CLI at the executable. If it cannot be found the tests are
SKIPPED with a loud reason, which is not the same as passing.
"""

import json
import os
import random
import struct
import subprocess
import sys
from pathlib import Path

import pytest

from traffic_generator import generate_traffic as gt
from voltguard.schemas import ParsedCommand

ROOT = Path(__file__).resolve().parent.parent
FIXTURE = ROOT / "tests" / "fixtures" / "mock_traffic.json"


def find_cli():
    env = os.environ.get("VOLTGUARD_PARSER_CLI")
    candidates = [Path(env)] if env else []
    exe = "voltguard_parser_cli.exe" if sys.platform == "win32" else "voltguard_parser_cli"
    for sub in ("", "Release", "Debug"):
        candidates.append(ROOT / "build" / "packet_interceptor" / sub / exe)
    return next((c for c in candidates if c.is_file()), None)


CLI = find_cli()
pytestmark = pytest.mark.skipif(CLI is None, reason="voltguard_parser_cli not built: run cmake --build build "
                                                    "(these tests did NOT run)")


def run_cli(text: str | bytes, timeout=30):
    data = text.encode() if isinstance(text, str) else text
    proc = subprocess.run([str(CLI)], input=data, capture_output=True, timeout=timeout)
    return proc


def run_lines(lines):
    proc = run_cli("\n".join(lines) + "\n")
    assert proc.returncode == 0, proc.stderr
    return [json.loads(line) for line in proc.stdout.decode().splitlines()]


# ------------------------------------------------------------------ fixture conformance

@pytest.fixture(scope="module")
def fixture_messages():
    return json.loads(FIXTURE.read_text(encoding="utf-8"))["messages"]


@pytest.fixture(scope="module")
def fixture_outputs(fixture_messages):
    return run_lines([f"{m['command_id']} {m['frame_hex']}" for m in fixture_messages])


def test_one_output_per_input_in_order(fixture_messages, fixture_outputs):
    assert [o["command_id"] for o in fixture_outputs] == [m["command_id"] for m in fixture_messages]


def test_parse_outcome_matches_fixture(fixture_messages, fixture_outputs):
    for message, out in zip(fixture_messages, fixture_outputs):
        if message["parse_expected"] == "PARSE_OK":
            assert out["status"] == "OK", f"{message['scenario']}: {out}"
        else:
            assert out["status"] == "REJECTED", f"{message['scenario']} was accepted: {out}"
            assert out["error"] == message["reject_reason"], message["scenario"]


def test_parsed_fields_match_fixture(fixture_messages, fixture_outputs):
    checked = 0
    for message, out in zip(fixture_messages, fixture_outputs):
        if message["parse_expected"] != "PARSE_OK":
            continue
        expected = {"command_id": message["command_id"], "protocol": "Modbus/TCP", **message["expected_fields"]}
        assert out["command"] == expected, message["scenario"]
        checked += 1
    assert checked >= 10


def test_parser_output_satisfies_phase2_schema(fixture_messages, fixture_outputs):
    for message, out in zip(fixture_messages, fixture_outputs):
        if out["status"] == "OK":
            parsed = ParsedCommand.from_dict(out["command"])
            assert parsed.to_dict() == out["command"]


def test_rejections_carry_stable_error_codes(fixture_messages, fixture_outputs):
    codes = {o["error_code"] for o in fixture_outputs if o["status"] == "REJECTED"}
    assert {"UNSUPPORTED_FUNCTION_CODE", "FRAME_TOO_SHORT", "LENGTH_MISMATCH", "INVALID_PROTOCOL_ID",
            "INVALID_PDU_LENGTH", "BYTE_COUNT_MISMATCH", "INVALID_QUANTITY", "FRAME_TOO_LARGE"} <= codes


def test_multiple_sequential_messages_stream():
    records = gt.generate_stream(1000, seed=11)
    outs = run_lines([f"{r['command_id']} {r['frame_hex']}" for r in records])
    assert len(outs) == 1000
    for record, out in zip(records, outs):
        assert out["status"] == "OK"
        assert out["command"]["register_value"] == record["expected_fields"]["register_value"]
        assert out["command"]["register_address"] == record["expected_fields"]["register_address"]


# ------------------------------------------------------------------ independent reference parser

def reference_parse(frame: bytes):
    """Second implementation written from the Modbus/TCP spec; returns (ok, error_text, fields)."""
    if len(frame) > 260:
        return False, "frame too large", None
    if len(frame) < 7:
        return False, "frame shorter than MBAP header", None
    tid, proto, length, unit = struct.unpack(">HHHB", frame[:7])
    if proto != 0:
        return False, "invalid protocol id", None
    if length != len(frame) - 6:
        return False, "length field mismatch", None
    if len(frame) == 7:
        return False, "missing function code", None
    pdu = frame[7:]
    fc = pdu[0]
    fields = {"transaction_id": tid, "unit_id": unit, "function_code": fc}
    if fc == 3 or fc == 6:
        if len(pdu) != 5:
            return False, "invalid PDU length for function code", None
        addr, val = struct.unpack(">HH", pdu[1:5])
        fields["register_address"] = addr
        if fc == 3:
            if not 1 <= val <= 125:
                return False, "invalid quantity", None
            fields["quantity"] = val
            span = val
        else:
            fields["register_value"] = val
            span = 1
    elif fc == 16:
        if len(pdu) < 6:
            return False, "invalid PDU length for function code", None
        addr, qty, bc = struct.unpack(">HHB", pdu[1:6])
        if not 1 <= qty <= 123:
            return False, "invalid quantity", None
        if bc != qty * 2:
            return False, "byte count mismatch", None
        if len(pdu) != 6 + bc:
            return False, "invalid PDU length for function code", None
        fields.update(register_address=addr, quantity=qty,
                      register_values=list(struct.unpack(f">{qty}H", pdu[6:])))
        span = qty
    else:
        return False, "unsupported function code", None
    if fields["register_address"] + span - 1 > 0xFFFF:
        return False, "register range exceeds address space", None
    return True, None, fields


def mutate(rng: random.Random, frame: bytes) -> bytes:
    b = bytearray(frame)
    for _ in range(rng.randint(0, 3)):
        kind = rng.randint(0, 3)
        if kind == 0 and b:
            b[rng.randrange(len(b))] = rng.randrange(256)
        elif kind == 1 and b:
            del b[rng.randrange(len(b)):]
        elif kind == 2:
            b.extend(rng.randbytes(rng.randint(1, 5)))
        elif kind == 3 and len(b) >= 6:
            b[4:6] = struct.pack(">H", len(b) - 6 + rng.choice((0, 0, 0, 1, -1)) & 0xFFFF)  # often fix the length field
    return bytes(b)


def test_cpp_parser_agrees_with_independent_reference_parser(fixture_messages):
    rng = random.Random(2026)
    seeds = [bytes.fromhex(m["frame_hex"]) for m in fixture_messages]
    frames = list(seeds) + [mutate(rng, rng.choice(seeds)) for _ in range(6000)]
    outs = run_lines([f"D{i} {f.hex()}" for i, f in enumerate(frames)])
    assert len(outs) == len(frames)
    accepted = 0
    for frame, out in zip(frames, outs):
        ok, error, fields = reference_parse(frame)
        if ok:
            accepted += 1
            assert out["status"] == "OK", f"{frame.hex()}: {out}"
            command = {k: v for k, v in out["command"].items() if k not in ("command_id", "protocol")}
            assert command == fields, frame.hex()
        else:
            assert out["status"] == "REJECTED", f"C++ accepted {frame.hex()} but reference says: {error}"
            assert out["error"] == error, frame.hex()
    assert 500 < accepted < len(frames)  # the sweep exercised both outcomes


# ------------------------------------------------------------------ CLI robustness / input hardening

def test_bad_lines_do_not_stop_processing():
    outs = run_lines(["G1 00010000000601060064003c", "B;1 00", "G2 zz", "G3 00010000000601060064003c", "G4"])
    assert [o["status"] for o in outs] == ["OK", "REJECTED", "REJECTED", "OK", "REJECTED"]
    assert outs[1]["command_id"] is None
    assert outs[2]["error"] == "frame is not valid hex"


def test_blank_comment_and_crlf_lines():
    proc = run_cli("# comment\r\n\r\nC1 00010000000601060064003c\r\n   \r\n")
    outs = [json.loads(line) for line in proc.stdout.decode().splitlines()]
    assert proc.returncode == 0 and len(outs) == 1 and outs[0]["status"] == "OK"


def test_no_trailing_newline_still_processed():
    proc = run_cli("C1 00010000000601060064003c")
    assert json.loads(proc.stdout)["status"] == "OK"


def test_empty_stdin_is_fine():
    proc = run_cli("")
    assert proc.returncode == 0 and proc.stdout == b""


def test_binary_garbage_input_cannot_crash_parser():
    rng = random.Random(5)
    garbage = rng.randbytes(200_000)
    proc = run_cli(garbage)
    assert proc.returncode == 0
    lines = proc.stdout.decode().splitlines()
    assert lines  # random bytes contain newlines, so some output is expected
    for line in lines:
        assert json.loads(line)["status"] in ("OK", "REJECTED")  # every output line is valid JSON


def test_garbage_never_echoed_into_output():
    proc = run_cli(b"\x01\x02evil\xff;rm -rf / 00\n")
    out = json.loads(proc.stdout)
    assert out["command_id"] is None and b"evil" not in proc.stdout and b"rm" not in proc.stdout


def test_huge_line_is_rejected_with_bounded_behaviour():
    proc = run_cli("A" * 5_000_000 + "\nG1 00010000000601060064003c\n")
    lines = [json.loads(line) for line in proc.stdout.decode().splitlines()]
    assert proc.returncode == 0 and len(lines) == 2
    assert lines[0]["error"] == "input line too long" and lines[0]["command_id"] is None
    assert lines[1]["status"] == "OK"  # the next line is processed normally


def test_command_id_with_shell_metacharacters_is_rejected():
    for bad in ("x;touch", "$(id)", "`id`", "a|b", "../etc/passwd", "a&b"):
        out = run_lines([f"{bad} 00010000000601060064003c"])[0]
        assert out["status"] == "REJECTED" and out["command_id"] is None


def test_max_length_command_id_accepted():
    out = run_lines([f"{'x' * 64} 00010000000601060064003c"])[0]
    assert out["status"] == "OK"
    assert run_lines([f"{'x' * 65} 00010000000601060064003c"])[0]["status"] == "REJECTED"


def test_oversized_frame_in_hex_is_frame_too_large():
    out = run_lines(["BIG " + "00" * 261])[0]
    assert out["error_code"] == "FRAME_TOO_LARGE"


def test_help_and_bad_arguments():
    ok = subprocess.run([str(CLI), "--help"], capture_output=True, timeout=10)
    assert ok.returncode == 0 and b"usage" in ok.stdout
    bad = subprocess.run([str(CLI), "--unknown"], capture_output=True, timeout=10)
    assert bad.returncode == 2


def test_parser_is_deterministic_across_runs(fixture_messages):
    lines = [f"{m['command_id']} {m['frame_hex']}" for m in fixture_messages]
    assert run_cli("\n".join(lines) + "\n").stdout == run_cli("\n".join(lines) + "\n").stdout


# ------------------------------------------------------------------ round trip and third-party dissector (Phase 6)

from scapy.contrib.modbus import (ModbusADURequest, ModbusPDU03ReadHoldingRegistersRequest,  # noqa: E402
                                  ModbusPDU06WriteSingleRegisterRequest, ModbusPDU10WriteMultipleRegistersRequest)


def random_valid_request(rng: random.Random, i: int):
    """Returns (ground-truth ParsedCommand fields, frame bytes built by Scapy). Edge values are over-sampled."""
    fc = rng.choice((3, 6, 16))
    tid, unit = rng.choice((0, 65535, rng.randrange(65536))), rng.choice((0, 255, rng.randrange(256)))
    truth = {"command_id": f"R{i}", "protocol": "Modbus/TCP", "transaction_id": tid, "unit_id": unit, "function_code": fc}
    adu = ModbusADURequest(transId=tid, unitId=unit)
    if fc == 6:
        addr, value = rng.choice((0, 65535, rng.randrange(65536))), rng.choice((0, 65535, rng.randrange(65536)))
        truth.update(register_address=addr, register_value=value)
        pdu = ModbusPDU06WriteSingleRegisterRequest(registerAddr=addr, registerValue=value)
    else:
        qty = rng.choice((1, 125 if fc == 3 else 123, rng.randint(1, 125 if fc == 3 else 123)))
        addr = rng.choice((0, 65536 - qty, rng.randrange(65536 - qty + 1)))
        truth.update(register_address=addr, quantity=qty)
        if fc == 3:
            pdu = ModbusPDU03ReadHoldingRegistersRequest(startAddr=addr, quantity=qty)
        else:
            values = [rng.choice((0, 65535, rng.randrange(65536))) for _ in range(qty)]
            truth["register_values"] = values
            pdu = ModbusPDU10WriteMultipleRegistersRequest(startAddr=addr, quantityRegisters=qty, outputsValue=values)
    return truth, bytes(adu / pdu)


def scapy_dissect(frame: bytes) -> dict:
    """Decode a frame with Scapy's own Modbus dissector into ParsedCommand-style fields."""
    adu = ModbusADURequest(frame)
    pdu = adu.payload
    fields = {"transaction_id": adu.transId, "unit_id": adu.unitId, "function_code": pdu.funcCode}
    if pdu.funcCode == 6:
        fields.update(register_address=pdu.registerAddr, register_value=pdu.registerValue)
    elif pdu.funcCode == 3:
        fields.update(register_address=pdu.startAddr, quantity=pdu.quantity)
    else:
        fields.update(register_address=pdu.startAddr, quantity=pdu.quantityRegisters,
                      register_values=list(pdu.outputsValue))
    return fields


def test_round_trip_random_valid_requests_recover_exact_fields():
    rng = random.Random(77)
    cases = [random_valid_request(rng, i) for i in range(3000)]
    outs = run_lines([f"{t['command_id']} {frame.hex()}" for t, frame in cases])
    seen = {3: 0, 6: 0, 16: 0}
    for (truth, frame), out in zip(cases, outs):
        assert out["status"] == "OK", f"{frame.hex()}: {out}"
        assert out["command"] == truth, frame.hex()
        ParsedCommand.from_dict(out["command"])  # and the Phase 2 contract accepts it
        seen[truth["function_code"]] += 1
    assert all(count > 500 for count in seen.values()), seen


def scapy_can_dissect(frame: bytes) -> bool:
    return hasattr(ModbusADURequest(frame).payload, "funcCode")


def test_cpp_parser_agrees_with_scapy_dissector_on_valid_frames(fixture_messages):
    """Third-party check: Scapy's Modbus dissector and the C++ parser decode the same bytes identically.

    Known Scapy 2.8.0 limitation (found in Phase 6): its dissector returns a raw payload for
    function-16 writes of 101..123 registers although the frames are byte-identical to an
    independent encoder's output. Those frames cannot be cross-checked against Scapy; the test
    asserts the exclusion is exactly that case, and they are verified by the independent
    reference parser and the round-trip test instead.
    """
    rng = random.Random(78)
    frames = [bytes.fromhex(m["frame_hex"]) for m in fixture_messages if m["parse_expected"] == "PARSE_OK"]
    frames += [random_valid_request(rng, i)[1] for i in range(1500)]
    outs = run_lines([f"S{i} {f.hex()}" for i, f in enumerate(frames)])
    compared = excluded = 0
    for frame, out in zip(frames, outs):
        assert out["status"] == "OK", frame.hex()
        if not scapy_can_dissect(frame):
            excluded += 1
            assert frame[7] == 16 and struct.unpack(">H", frame[10:12])[0] >= 101, frame.hex()  # only the known case
            continue
        cpp = {k: v for k, v in out["command"].items() if k not in ("command_id", "protocol")}
        assert cpp == scapy_dissect(frame), frame.hex()
        compared += 1
    assert compared > 1300 and 0 < excluded < 250, (compared, excluded)


def test_scapy_built_frame_with_corrupted_length_is_rejected():
    """Frames Scapy builds correctly must parse; the same frame with each header/length byte damaged must not."""
    rng = random.Random(79)
    for i in range(300):
        _, frame = random_valid_request(rng, i)
        assert run_lines([f"G{i} {frame.hex()}"])[0]["status"] == "OK"
        bad = bytearray(frame)
        bad[rng.choice((2, 3, 4, 5))] ^= rng.randrange(1, 256)  # protocol id or length field
        assert run_lines([f"B{i} {bytes(bad).hex()}"])[0]["status"] == "REJECTED"


def test_every_valid_frame_with_a_byte_removed_or_added_is_rejected():
    rng = random.Random(80)
    for i in range(300):
        _, frame = random_valid_request(rng, i)
        cut = frame[:-1]
        added = frame + b"\x00"
        outs = run_lines([f"C{i} {cut.hex()}", f"A{i} {added.hex()}"])
        assert [o["status"] for o in outs] == ["REJECTED", "REJECTED"], frame.hex()
