"""Fake parser child for fault-injection tests of the pipeline bridge. NOT part of VoltGuard itself.

Speaks the parser line protocol but ignores the frame: it always "parses" a pump write of 50 percent.
The command id prefix selects a misbehaviour.
"""
import json
import sys
import time

OK_COMMAND = {"protocol": "Modbus/TCP", "transaction_id": 1, "unit_id": 1, "function_code": 6,
              "register_address": 100, "register_value": 50}


def out(obj):
    sys.stdout.write(json.dumps(obj) + "\n")
    sys.stdout.flush()


for line in sys.stdin:
    cid = line.split(" ", 1)[0].strip()
    ok = {"command_id": cid, "status": "OK", "command": {"command_id": cid, **OK_COMMAND}}
    if cid.startswith("HANG"):
        time.sleep(120)
    elif cid.startswith("CRASH"):
        sys.exit(3)
    elif cid.startswith("WRONGID"):
        out({**ok, "command_id": "OTHER"})
    elif cid.startswith("INNERID"):
        out({**ok, "command": {**ok["command"], "command_id": "OTHER"}})
    elif cid.startswith("BADJSON"):
        sys.stdout.write("{not json\n")
        sys.stdout.flush()
    elif cid.startswith("NOTDICT"):
        out([1, 2, 3])
    elif cid.startswith("BADSTATUS"):
        out({"command_id": cid, "status": "MAYBE"})
    elif cid.startswith("NOCMD"):
        out({"command_id": cid, "status": "OK"})
    elif cid.startswith("BADSCHEMA"):
        out({**ok, "command": {**ok["command"], "command_id": cid, "register_value": 70000}})
    elif cid.startswith("TOOLONG"):
        sys.stdout.write("x" * 100000 + "\n")
        sys.stdout.flush()
    elif cid.startswith("EXTRA"):
        out(ok)
        out({"command_id": "STRAY", "status": "REJECTED", "error_code": "X", "error": "unsolicited"})
    elif cid.startswith("REJ"):
        out({"command_id": cid, "status": "REJECTED", "error_code": "LENGTH_MISMATCH", "error": "length field mismatch"})
    elif cid.startswith("SLOWOK"):
        time.sleep(0.2)
        out(ok)
    else:
        out(ok)
