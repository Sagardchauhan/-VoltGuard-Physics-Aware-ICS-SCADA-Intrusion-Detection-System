"""Fake decision engine used ONLY by tests to inject engine failures (speaks the engine's JSON-lines protocol).

Usage: python fake_engine.py MODE   (or set VOLTGUARD_FAKE_ENGINE_MODE, used when started through a wrapper by the worker tests)
  hang | crash | garbage | notjson | wrongid | allow_all | block_all | error | badcontract | oversize | echo_reject | slow
"""
import json
import sys
import time

import os

mode = os.environ.get("VOLTGUARD_FAKE_ENGINE_MODE") or (sys.argv[1] if len(sys.argv) > 1 else "hang")   # extra args such as --config are ignored
for line in sys.stdin:
    try:
        req = json.loads(line)
        cid = req.get("command_id")
    except ValueError:
        continue
    if mode == "hang":
        continue
    if mode == "crash":
        sys.exit(3)
    if mode == "slow":
        time.sleep(1.0)
        mode = "echo_reject"
    if mode == "garbage":
        print("this is not json")
    elif mode == "notjson":
        print('{"command_id": ')
    elif mode == "wrongid":
        print(json.dumps({"command_id": "OTHER-ID", "decision": "ALLOW", "reason": "x"}))
    elif mode == "allow_all":
        print(json.dumps({"command_id": cid, "decision": "ALLOW", "reason": "allow everything"}))
    elif mode == "block_all":
        print(json.dumps({"command_id": cid, "decision": "BLOCK", "reason": "block everything"}))
    elif mode == "error":
        print(json.dumps({"type": "error", "error": "no decision possible"}))
    elif mode == "badcontract":
        print(json.dumps({"command_id": cid, "decision": "MAYBE", "reason": "x"}))
    elif mode == "oversize":
        print("x" * 40000)
    elif mode == "echo_reject":
        print(json.dumps({"command_id": cid, "decision": "REJECT", "reason": "fake engine reject"}))
    sys.stdout.flush()
