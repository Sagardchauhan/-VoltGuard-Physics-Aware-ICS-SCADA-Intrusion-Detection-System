"""Fake dashboard worker used ONLY by the Qt dashboard tests to inject worker failures.

Usage: python fake_worker.py MODE
It speaks the same JSON-lines protocol as voltguard.worker but misbehaves on purpose:
  hang        ready, then never answers a "process" request
  crash       ready, then exits with code 3 on the first "process" request
  garbage     ready, then answers "process" with a line that is not JSON, then a result for another id
  badresult   ready, then answers "process" with a result missing required fields
  error       ready, then answers "process" with {"type":"error",...}
  fatal       prints {"type":"fatal"} and exits 2 (no ready)
  silent      prints nothing at all (never ready)
  oversize    ready, then answers "process" with a line larger than 2 MB
  twoscen     ready; answers "scenarios" with two small scenarios; answers "process" with an error
"""

import json
import sys


def out(obj):
    sys.stdout.write(json.dumps(obj) + "\n")
    sys.stdout.flush()


READY = {"type": "ready", "version": "fake", "config": {}, "config_path": "fake.json",
         "parser_available": True, "parser_path": "fake", "decision_engine": "not implemented"}


def main():
    mode = sys.argv[1] if len(sys.argv) > 1 else "hang"
    if mode == "fatal":
        out({"type": "fatal", "error": "fake fatal error"})
        return 2
    if mode == "silent":
        sys.stdin.read()
        return 0
    # "logok": claims a working event log and then never answers export requests (dashboard export-timeout tests)
    out({**READY, "event_log": {"enabled": True, "ok": True, "path": "fake.db", "error": None}} if mode in ("logok", "logerr") else READY)
    for line in sys.stdin:
        try:
            req = json.loads(line)
        except ValueError:
            continue
        op = req.get("op")
        if op == "shutdown":
            return 0
        if op == "scenarios":
            out({"type": "scenarios", "scenarios": [
                {"name": "fake_one", "description": "d1", "intent": "NORMAL", "frame_hex": "00"},
                {"name": "fake_two", "description": "d2", "intent": "NORMAL", "frame_hex": "01"}]})
            continue
        if op == "export" and mode == "logerr":     # an old-style error reply instead of an export reply
            out({"type": "error", "command_id": None, "error": "fake export refusal"})
            continue
        if op != "process":
            continue
        cid = req.get("command_id")
        if mode == "hang":
            continue
        if mode == "crash":
            return 3
        if mode == "garbage":
            sys.stdout.write("this is not json\n")
            out({"type": "result", "command_id": "SOMEONE-ELSE", "stage": "SIMULATED"})
            sys.stdout.flush()
            continue
        if mode == "badresult":
            out({"type": "result", "command_id": cid, "stage": "SIMULATED"})
            continue
        if mode == "error" or mode == "twoscen":
            out({"type": "error", "command_id": cid, "error": "fake worker error"})
            continue
        if mode == "oversize":
            sys.stdout.write("x" * (3 * 1024 * 1024) + "\n")
            sys.stdout.flush()
            continue
    return 0


if __name__ == "__main__":
    sys.exit(main())
