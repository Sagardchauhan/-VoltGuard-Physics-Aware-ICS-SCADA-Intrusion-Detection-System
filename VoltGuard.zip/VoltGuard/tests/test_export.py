"""Phase 15 tests: CSV/JSON export, the optional PDF report, the worker's export op and the export CLI."""

import csv
import json
import os
import sqlite3
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest

from event_logging import export as export_module
from event_logging.event_store import EventStore, UnavailableStore
from event_logging.export import (EXPORT_COLUMNS, ExportError, ReportUnavailable, export_events, neutralise_cell)
from voltguard.config import load_safety_config
from voltguard.worker import handle_request
from tests.test_worker import CLI, Worker

ROOT = Path(__file__).resolve().parent.parent
CONFIG = load_safety_config(ROOT / "config" / "safety_limits.json")
FIXTURE = [json.loads(line) for line in (ROOT / "tests" / "fixtures" / "pipeline_results.jsonl").read_text().splitlines()]
INTENT_DECISION = {"NORMAL": "ALLOW", "BOUNDARY_SAFE": "ALLOW", "READ_ONLY": "ALLOW", "UNSAFE": "BLOCK"}

try:
    import reportlab  # noqa: F401
    import pypdf
    HAVE_PDF = True
except ImportError:
    HAVE_PDF = False
needs_pdf = pytest.mark.skipif(not HAVE_PDF, reason="reportlab/pypdf not installed (this test did NOT run)")


def decision_for(entry):
    result = entry["result"]
    return {"command_id": result["command_id"], "decision": INTENT_DECISION.get(entry["intent"], "REJECT"),
            "reason": f"test decision for {entry['scenario']}", "source": "engine", "error_code": None}


def fill(store, sources=None):
    for i, entry in enumerate(FIXTURE):
        source = sources[i] if sources else entry["scenario"]
        assert store.record(entry["result"], source, "0001", f"2026-11-03T10:00:{i:02d}.000+00:00", decision_for(entry))


@pytest.fixture
def store(tmp_path):
    s = EventStore(tmp_path / "events.db")
    fill(s)
    yield s
    s.close()


def read_csv(path):
    with open(path, newline="", encoding="utf-8") as handle:
        return list(csv.reader(handle))


# ------------------------------------------------------------------ CSV and JSON content

def test_csv_has_every_event_oldest_first_with_the_documented_columns(store, tmp_path):
    result = export_events(store, tmp_path / "out.csv", "csv")
    rows = read_csv(result.path)
    assert tuple(rows[0]) == EXPORT_COLUMNS and len(rows) == 1 + len(FIXTURE)
    table = [dict(zip(rows[0], r)) for r in rows[1:]]
    assert [int(r["id"]) for r in table] == list(range(1, len(FIXTURE) + 1))
    for entry, row in zip(FIXTURE, table):
        assert row["command_id"] == entry["result"]["command_id"] and row["source"] == entry["scenario"]
        assert row["decision"] == decision_for(entry)["decision"]
        sim = entry["result"]["simulation"]
        if sim and sim.get("predicted_pressure") is not None:
            assert float(row["predicted_pressure"]) == pytest.approx(sim["predicted_pressure"])
    assert result.rows == len(FIXTURE) and result.verified and not result.truncated


def test_json_export_carries_the_notice_the_integrity_result_and_every_row(store, tmp_path):
    result = export_events(store, tmp_path / "out.json", "json")
    doc = json.loads(result.path.read_text(encoding="utf-8"))
    assert doc["format_version"] == 1 and "SIMULATED" in doc["notice"] and "Nothing was forwarded" in doc["notice"]
    assert doc["integrity"]["verified"] is True and "tamper-evidence only" in doc["integrity"]["note"]
    assert doc["rows_exported"] == doc["total_matching_rows"] == len(FIXTURE) and doc["truncated"] is False
    assert [e["id"] for e in doc["events"]] == list(range(1, len(FIXTURE) + 1))
    assert all(set(e) == set(EXPORT_COLUMNS) for e in doc["events"])
    tally = {}
    for e in doc["events"]:
        tally[e["decision"]] = tally.get(e["decision"], 0) + 1
    assert tally == {"ALLOW": 6, "BLOCK": 5, "REJECT": 16}


@pytest.mark.parametrize("fmt", ["csv", "json"])
def test_truncation_is_reported_never_silent(store, tmp_path, fmt):
    result = export_events(store, tmp_path / f"out.{fmt}", fmt, max_rows=5)
    assert (result.rows, result.total_matching, result.truncated) == (5, len(FIXTURE), True)
    if fmt == "json":
        doc = json.loads(result.path.read_text())
        assert doc["truncated"] is True and doc["rows_exported"] == 5 and doc["total_matching_rows"] == len(FIXTURE)
    else:
        assert len(read_csv(result.path)) == 1 + 5


def test_severity_filter_and_unknown_severity(store, tmp_path):
    result = export_events(store, tmp_path / "v.json", "json", severity="LIMIT_VIOLATION")
    doc = json.loads(result.path.read_text())
    assert doc["filter"] == {"severity": "LIMIT_VIOLATION"} and doc["rows_exported"] == 5
    assert {e["severity"] for e in doc["events"]} == {"LIMIT_VIOLATION"}
    with pytest.raises(ExportError):
        export_events(store, tmp_path / "x.json", "json", severity="NOPE")
    assert not (tmp_path / "x.json").exists()


def test_an_empty_log_exports_a_valid_header_only_file(tmp_path):
    s = EventStore(tmp_path / "empty.db")
    export_events(s, tmp_path / "e.csv", "csv")
    assert read_csv(tmp_path / "e.csv") == [list(EXPORT_COLUMNS)]
    export_events(s, tmp_path / "e.json", "json")
    assert json.loads((tmp_path / "e.json").read_text())["events"] == []
    s.close()


# ------------------------------------------------------------------ hostile content

HOSTILE_SOURCES = ["=HYPERLINK(\"http://evil\",\"x\")", "+1+1", "-2+3", "@SUM(A1:A9)", "\t=1", "\r=1", "plain, with \"quotes\" and ; semicolon",
                   "line\nbreak", "unicode é中文", "'; DROP TABLE events; --", "<b>bold</b> & <script>"]


def test_text_that_a_spreadsheet_would_execute_is_neutralised_in_csv(tmp_path):
    s = EventStore(tmp_path / "h.db")
    sources = HOSTILE_SOURCES + ["x"] * (len(FIXTURE) - len(HOSTILE_SOURCES))
    fill(s, sources)
    rows = read_csv(export_events(s, tmp_path / "h.csv", "csv").path)
    stored = [r[EXPORT_COLUMNS.index("source")] for r in rows[1:]]
    for original, got in zip(HOSTILE_SOURCES, stored):
        cleaned = "".join(c if c.isprintable() else "?" for c in original)      # what the store itself keeps
        if cleaned.startswith(("=", "+", "-", "@")):          # the store already turns tabs and CRs into '?'; the exporter still guards them
            assert got == "'" + cleaned, original
        else:
            assert got == cleaned, original
        assert not got.startswith(("=", "+", "-", "@", "\t", "\r"))
    s.close()


def test_numbers_are_never_prefixed_but_text_is():
    assert neutralise_cell(-5.0) == -5.0 and neutralise_cell(None) is None and neutralise_cell(0) == 0
    assert neutralise_cell("=1+1") == "'=1+1" and neutralise_cell("safe") == "safe" and neutralise_cell("") == ""
    assert neutralise_cell("a=b") == "a=b"          # only a LEADING character matters


def test_a_negative_prediction_stays_a_number_in_the_csv(tmp_path):
    s = EventStore(tmp_path / "n.db")
    result = {"command_id": "N-1", "stage": "SIMULATED", "parsed_command": {"function_code": 6, "register_address": 100},
              "simulation": {"simulation_status": "SUCCESS", "predicted_pressure": -5.5, "predicted_flow": -1.25, "violations": []},
              "timings_ms": {}}
    assert s.record(result, "neg", "00", "2026-11-03T10:00:00+00:00", None)
    row = dict(zip(*read_csv(export_events(s, tmp_path / "n.csv", "csv").path)))
    assert row["predicted_pressure"] == "-5.5" and row["predicted_flow"] == "-1.25"
    s.close()


def test_hostile_text_survives_the_json_round_trip_unchanged(tmp_path):
    s = EventStore(tmp_path / "h.db")
    fill(s, HOSTILE_SOURCES + ["x"] * (len(FIXTURE) - len(HOSTILE_SOURCES)))
    doc = json.loads(export_events(s, tmp_path / "h.json", "json").path.read_text())
    got = [e["source"] for e in doc["events"]][:len(HOSTILE_SOURCES)]
    assert got == ["".join(c if c.isprintable() else "?" for c in t) for t in HOSTILE_SOURCES]
    s.close()


# ------------------------------------------------------------------ files: no overwrite, no partial output, refusals

def only(path):
    return sorted(p.name for p in path.iterdir())


def test_an_existing_file_is_never_replaced_unless_asked(store, tmp_path):
    target = tmp_path / "keep.csv"
    target.write_text("precious")
    with pytest.raises(ExportError, match="already exists"):
        export_events(store, target, "csv")
    assert target.read_text() == "precious"
    assert "keep.csv" in only(tmp_path) and not [n for n in only(tmp_path) if n.endswith(".tmp")]
    export_events(store, target, "csv", overwrite=True)
    assert read_csv(target)[0][0] == "id"


def test_a_file_that_appears_during_the_export_is_not_replaced(store, tmp_path, monkeypatch):
    target = tmp_path / "race.json"
    real = export_module.check_target

    def racing(path, fmt, overwrite):
        checked = real(path, fmt, overwrite)
        checked.write_text("someone else's file")          # the name is taken after the check
        return checked

    monkeypatch.setattr(export_module, "check_target", racing)
    with pytest.raises(ExportError, match="already exists"):
        export_events(store, target, "json")
    assert target.read_text() == "someone else's file"
    assert not [n for n in only(tmp_path) if n.endswith(".tmp")]


def test_a_failure_in_the_middle_leaves_no_file_and_no_temporary_file(store, tmp_path, monkeypatch):
    def boom(*a, **k):
        raise OSError("disk full")

    monkeypatch.setattr(export_module.json, "dump", boom)
    before = only(tmp_path)
    with pytest.raises(ExportError, match="disk full"):
        export_events(store, tmp_path / "fail.json", "json")
    assert only(tmp_path) == before


@pytest.mark.parametrize("name, fmt, message", [("out.txt", "csv", "must end in"), ("out.csv", "json", "must end in"),
                                                ("out.csv", "exe", "unknown export format"), ("missing/out.csv", "csv", "does not exist")])
def test_bad_targets_are_refused_before_anything_is_written(store, tmp_path, name, fmt, message):
    before = only(tmp_path)
    with pytest.raises(ExportError, match=message):
        export_events(store, tmp_path / name, fmt)
    assert only(tmp_path) == before


def test_a_folder_or_symlink_target_is_refused(store, tmp_path):
    (tmp_path / "d.csv").mkdir()
    with pytest.raises(ExportError, match="the target is a folder"):
        export_events(store, tmp_path / "d.csv", "csv", overwrite=True)
    if sys.platform != "win32":
        victim = tmp_path / "victim.csv"
        victim.write_text("do not touch")
        (tmp_path / "link.csv").symlink_to(victim)
        with pytest.raises(ExportError, match="symbolic link"):
            export_events(store, tmp_path / "link.csv", "csv", overwrite=True)
        assert victim.read_text() == "do not touch"


# ------------------------------------------------------------------ integrity

def tamper(db_path):
    con = sqlite3.connect(db_path)
    con.execute("UPDATE events SET severity='WITHIN_LIMITS' WHERE id=5")
    con.commit()
    con.close()


def test_a_tampered_log_is_still_exported_but_labelled_failed(tmp_path):
    s = EventStore(tmp_path / "t.db")
    fill(s)
    tamper(tmp_path / "t.db")
    result = export_events(s, tmp_path / "t.json", "json")
    assert result.verified is False and "row 5" in result.verify_message
    doc = json.loads(result.path.read_text())
    assert doc["integrity"]["verified"] is False and doc["rows_exported"] == len(FIXTURE)
    s.close()


def test_an_unavailable_store_refuses_to_export(tmp_path):
    with pytest.raises(ExportError, match="cannot read the event log"):
        export_events(UnavailableStore("disk gone"), tmp_path / "u.csv", "csv")
    assert only(tmp_path) == []


# ------------------------------------------------------------------ PDF

def pdf_text(path):
    return "\n".join(page.extract_text() for page in pypdf.PdfReader(str(path)).pages)


@needs_pdf
def test_the_pdf_states_the_facts_and_the_limitations(store, tmp_path):
    result = export_events(store, tmp_path / "r.pdf", "pdf", safety_config=CONFIG)
    data = result.path.read_bytes()
    assert data.startswith(b"%PDF") and len(data) > 1500
    text = pdf_text(result.path)
    for needle in ("VoltGuard event report", "SIMULATED", "VERIFIED", "tamper-evidence only", "Configured limits", "pump_speed", "ALLOW", "BLOCK",
                   "REJECT", "Limitations:", "not a compliance or audit document"):
        assert needle in text, needle
    assert "FAILED" not in text


@needs_pdf
def test_a_failed_integrity_check_is_printed_in_the_pdf(tmp_path):
    s = EventStore(tmp_path / "t.db")
    fill(s)
    tamper(tmp_path / "t.db")
    text = pdf_text(export_events(s, tmp_path / "r.pdf", "pdf").path)
    assert "FAILED" in text and "row 5" in text
    s.close()


@needs_pdf
def test_markup_in_logged_text_is_printed_literally_not_interpreted(tmp_path):
    s = EventStore(tmp_path / "m.db")
    nasty = ["<b>bold</b> & <script>alert(1)</script>", "</para><para>", "&lt;amp&gt;", "<font color='red'>x</font>"]
    fill(s, nasty + ["x"] * (len(FIXTURE) - len(nasty)))
    text = pdf_text(export_events(s, tmp_path / "m.pdf", "pdf").path)
    assert "<b>bold</b>" in text and "<script>" in text and "</para><para>" in text and "&lt;amp&gt;" in text
    s.close()


@needs_pdf
def test_a_large_log_gives_a_truncated_pdf_that_says_so(tmp_path):
    s = EventStore(tmp_path / "big.db")
    for i in range(300):
        s.record(FIXTURE[i % len(FIXTURE)]["result"], "bulk", "00", f"2026-11-03T10:00:00.{i:03d}+00:00", decision_for(FIXTURE[i % len(FIXTURE)]))
    text = pdf_text(export_events(s, tmp_path / "big.pdf", "pdf", max_rows=250).path)
    assert "TRUNCATED" in text and "250 of 300" in text
    s.close()


def test_without_reportlab_the_pdf_is_refused_cleanly_and_other_formats_still_work(store, tmp_path, monkeypatch):
    for name in [m for m in sys.modules if m == "reportlab" or m.startswith("reportlab.")] + ["reportlab", "reportlab.lib", "reportlab.platypus"]:
        monkeypatch.setitem(sys.modules, name, None)       # a cached submodule would otherwise still import
    with pytest.raises(ReportUnavailable):
        export_events(store, tmp_path / "r.pdf", "pdf")
    assert only(tmp_path) == ["events.db"]
    export_events(store, tmp_path / "r.csv", "csv")


# ------------------------------------------------------------------ the worker's export op

def stub_pipeline():
    return SimpleNamespace(config=CONFIG)


def ask(store, **fields):
    return handle_request(stub_pipeline(), [], {"op": "export", **fields}, store)


@pytest.mark.parametrize("fmt", ["csv", "json"] + (["pdf"] if HAVE_PDF else []))
def test_the_worker_exports_and_reports_what_it_did(store, tmp_path, fmt):
    reply = ask(store, format=fmt, path=str(tmp_path / f"w.{fmt}"))
    assert reply["type"] == "export" and reply["ok"] is True
    assert (reply["rows"], reply["total"], reply["truncated"], reply["verified"]) == (len(FIXTURE), len(FIXTURE), False, True)
    assert Path(reply["path"]).is_file()


def test_the_worker_refuses_bad_export_requests_with_ok_false(store, tmp_path):
    good = str(tmp_path / "w.csv")
    bad = [dict(format="csv", path=123), dict(format="csv", path=""), dict(format="csv", path="a\x00.csv"), dict(format="csv", path="x" * 5000),
           dict(format=5, path=good), dict(format="exe", path=good), dict(format="csv", path=good, overwrite="yes"),
           dict(format="csv", path=good, severity=5), dict(format="csv", path=good, severity="NOPE"),
           dict(format="csv", path=str(tmp_path / "nodir" / "w.csv")), dict(path=good), dict(format="csv")]
    for request in bad:
        reply = ask(store, **request)
        assert reply["type"] == "export" and reply["ok"] is False and reply["error"], request
    assert only(tmp_path) == ["events.db"] or only(tmp_path) == ["events.db", "events.db-journal"]
    assert ask(None, format="csv", path=good)["ok"] is False
    assert ask(UnavailableStore("x"), format="csv", path=good)["ok"] is False


def test_the_worker_never_overwrites_unless_told_to(store, tmp_path):
    path = str(tmp_path / "w.json")
    assert ask(store, format="json", path=path)["ok"] is True
    again = ask(store, format="json", path=path)
    assert again["ok"] is False and "already exists" in again["error"]
    assert ask(store, format="json", path=path, overwrite=True)["ok"] is True


def test_a_real_worker_process_exports_the_log_it_wrote(tmp_path):
    cli_args = ["--parser-cli", str(CLI)] if CLI else []
    w = Worker(tmp_path, *cli_args)
    try:
        assert w.read()["type"] == "ready"
        if CLI:
            for i, frame in enumerate(("00010000000601060064003c", "000700000006010600640064", "0001")):
                assert w.ask({"op": "process", "command_id": f"X-{i}", "frame_hex": frame})["logged"] is True
        out = tmp_path / "from_worker.json"
        reply = w.ask({"op": "export", "format": "json", "path": str(out)})
        assert reply["ok"] is True and reply["verified"] is True and reply["rows"] == (3 if CLI else 0)
        doc = json.loads(out.read_text())
        assert doc["rows_exported"] == reply["rows"]
        assert w.ask({"op": "export", "format": "json", "path": str(out)})["ok"] is False        # no overwrite
    finally:
        w.close()


# ------------------------------------------------------------------ command line

def run_cli(*args):
    import subprocess
    return subprocess.run([sys.executable, "-m", "event_logging.export", *map(str, args)], cwd=ROOT, capture_output=True, text=True, timeout=60)


def test_cli_exports_and_refuses(store, tmp_path):
    db = tmp_path / "events.db"
    ok = run_cli("--db", db, "--format", "csv", "--out", tmp_path / "c.csv")
    assert ok.returncode == 0 and f"wrote {len(FIXTURE)} of {len(FIXTURE)}" in ok.stdout and "integrity: verified" in ok.stdout
    again = run_cli("--db", db, "--format", "csv", "--out", tmp_path / "c.csv")
    assert again.returncode == 2 and "already exists" in again.stderr
    assert run_cli("--db", db, "--format", "csv", "--out", tmp_path / "c.csv", "--force").returncode == 0
    missing = run_cli("--db", tmp_path / "nope.db", "--format", "csv", "--out", tmp_path / "d.csv")
    assert missing.returncode == 2 and not (tmp_path / "nope.db").exists() and not (tmp_path / "d.csv").exists()
    assert run_cli("--db", db, "--format", "csv", "--out", tmp_path / "d.csv", "--max-rows", "0").returncode == 2


def test_cli_exit_code_reports_a_failed_integrity_check(tmp_path):
    s = EventStore(tmp_path / "t.db")
    fill(s)
    s.close()
    tamper(tmp_path / "t.db")
    result = run_cli("--db", tmp_path / "t.db", "--format", "json", "--out", tmp_path / "t.json")
    assert result.returncode == 4 and "integrity: FAILED" in result.stdout and (tmp_path / "t.json").is_file()
