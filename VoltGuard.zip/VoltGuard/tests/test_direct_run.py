"""Entry-point modules must also work when started as a plain file, e.g. with an editor's Run button (Phase 18 follow-up).

`python voltguard/main.py` puts voltguard/ (not the project root) on sys.path, which used to fail with
"ModuleNotFoundError: No module named 'voltguard'". These tests start each file the way an editor does, from a
different working directory and without PYTHONPATH.
"""

import os
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
ENTRY_FILES = ["voltguard/main.py", "voltguard/pipeline.py", "voltguard/worker.py", "traffic_generator/generate_traffic.py",
               "event_logging/export.py", "physics_engine/simulator.py"]


def run_file(relative, tmp_path, *args):
    env = {k: v for k, v in os.environ.items() if k != "PYTHONPATH"}
    return subprocess.run([sys.executable, str(ROOT / relative), *args], cwd=tmp_path, env=env, capture_output=True, text=True, timeout=60)


@pytest.mark.parametrize("relative", ENTRY_FILES)
def test_the_file_starts_when_run_directly_from_another_folder(relative, tmp_path):
    proc = run_file(relative, tmp_path, "--help")
    assert proc.returncode == 0, proc.stderr[-400:]
    assert "usage" in proc.stdout.lower()
    assert "ModuleNotFoundError" not in proc.stderr


def test_main_runs_to_completion_when_started_as_a_file(tmp_path):
    proc = run_file("voltguard/main.py", tmp_path)
    assert proc.returncode == 0, proc.stderr[-400:]
    assert "Configuration loaded" in proc.stderr + proc.stdout


def test_the_traffic_generator_writes_a_file_when_started_directly(tmp_path):
    out = tmp_path / "traffic.json"
    proc = run_file("traffic_generator/generate_traffic.py", tmp_path, "--output", str(out))
    assert proc.returncode == 0, proc.stderr[-400:]
    assert out.is_file() and out.stat().st_size > 1000
