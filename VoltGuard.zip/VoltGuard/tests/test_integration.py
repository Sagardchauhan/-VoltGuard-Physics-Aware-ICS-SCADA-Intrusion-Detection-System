"""Phase 7 tests: parser -> simulation pipeline (integration, fault injection, end-to-end)."""

import json
import random
import subprocess
import sys
import threading
import time
from pathlib import Path

import pytest

from physics_engine.simulator import DEFAULT_STATE, PipelineState, simulate_command
from test_physics import EXPECTED_INVALID, EXPECTED_VIOLATIONS
from traffic_generator import generate_traffic as gt
from voltguard import pipeline as pl
from voltguard.config import load_safety_config
from voltguard.pipeline import (STAGE_COMPONENT_FAILURE, STAGE_PARSE_REJECTED, STAGE_SIMULATED, STAGES, Pipeline,
                                find_parser_cli)
from voltguard.schemas import ParsedCommand, SimulationResult

ROOT = Path(__file__).resolve().parent.parent
FIXTURE = ROOT / "tests" / "fixtures" / "mock_traffic.json"
FAKE = ROOT / "tests" / "fixtures" / "fake_parser.py"
CLI = find_parser_cli()
needs_cpp = pytest.mark.skipif(CLI is None, reason="voltguard_parser_cli not built (these tests did NOT run)")
VALID_FRAME = bytes.fromhex("00010000000601060064003c")


@pytest.fixture(scope="module")
def config():
    return load_safety_config(ROOT / "config" / "safety_limits.json")


@pytest.fixture(scope="module")
def messages():
    return json.loads(FIXTURE.read_text(encoding="utf-8"))["messages"]


@pytest.fixture
def fake(config):
    """Pipeline whose parser is the fault-injecting fake; short parser timeout."""
    with Pipeline(config, parser_argv=[sys.executable, "-I", str(FAKE)], parser_timeout_ms=400) as p:
        yield p


@pytest.fixture
def real(config):
    with Pipeline(config, parser_argv=[str(CLI)]) as p:
        yield p


def assert_failed_closed(result, code):
    assert result.stage == STAGE_COMPONENT_FAILURE and result.error_code == code, result
    assert result.simulation is None and result.parsed_command is None
    assert result.error


# ------------------------------------------------------------------ end to end with the real C++ parser

@needs_cpp
def test_every_fixture_message_flows_end_to_end(real, messages, config):
    for m in messages:
        r = real.process_frame(m["command_id"], bytes.fromhex(m["frame_hex"]))
        assert r.command_id == m["command_id"] and r.stage in STAGES
        if m["parse_expected"] == "PARSE_OK":
            assert r.stage == STAGE_SIMULATED, (m["scenario"], r)
            expected = simulate_command(ParsedCommand.from_dict({"command_id": m["command_id"], "protocol": "Modbus/TCP",
                                                                  **m["expected_fields"]}), config)
            assert r.simulation == expected, m["scenario"]  # the bridge adds nothing and loses nothing
        else:
            assert r.stage == STAGE_PARSE_REJECTED, (m["scenario"], r)
            assert r.error == m["reject_reason"] and r.simulation is None and r.parsed_command is None


@needs_cpp
def test_end_to_end_outcomes_match_pinned_physics_expectations(real, messages):
    seen = set()
    for m in messages:
        if m["parse_expected"] != "PARSE_OK":
            continue
        r = real.process_frame(m["command_id"], bytes.fromhex(m["frame_hex"]))
        name = m["scenario"]
        seen.add(name)
        if name in EXPECTED_INVALID:
            assert r.simulation.simulation_status == "INVALID_INPUT", name
        else:
            assert r.simulation.simulation_status == "SUCCESS", name
            assert [v.type for v in r.simulation.violations] == EXPECTED_VIOLATIONS[name], name
    assert seen == set(EXPECTED_VIOLATIONS) | EXPECTED_INVALID


@needs_cpp
def test_parser_output_matches_simulator_input_schema(real, messages):
    """Audit: parser output validates as ParsedCommand and the simulator consumed it without schema errors."""
    checked = 0
    for m in messages:
        if m["parse_expected"] != "PARSE_OK":
            continue
        r = real.process_frame(m["command_id"], bytes.fromhex(m["frame_hex"]))
        assert ParsedCommand.from_dict(r.parsed_command.to_dict()) == r.parsed_command
        assert SimulationResult.from_dict(r.simulation.to_dict()) == r.simulation
        assert r.parsed_command.command_id == r.simulation.command_id == m["command_id"]
        checked += 1
    assert checked >= 12


@needs_cpp
def test_command_ids_stay_associated_with_results_in_order(real):
    records = gt.generate_stream(500, seed=21)
    results = real.process_many([(r["command_id"], bytes.fromhex(r["frame_hex"])) for r in records])
    assert [r.command_id for r in results] == [r["command_id"] for r in records]
    for record, r in zip(records, results):
        assert r.stage == STAGE_SIMULATED
        assert r.parsed_command.register_value == record["expected_fields"]["register_value"]
        assert r.simulation.command_id == record["command_id"]


@needs_cpp
def test_single_parser_process_is_reused_across_requests(real):
    real.process_frame("A1", VALID_FRAME)
    pid = real.parser.pid
    for i in range(200):
        assert real.process_frame(f"A{i + 2}", VALID_FRAME).stage == STAGE_SIMULATED
    assert real.parser.pid == pid and real.parser.starts == 1


@needs_cpp
def test_malformed_traffic_never_crashes_the_application(real):
    rng = random.Random(404)
    base = [bytes.fromhex(m["frame_hex"]) for m in json.loads(FIXTURE.read_text())["messages"]]
    counts = {s: 0 for s in STAGES}
    for i in range(3000):
        frame = bytearray(rng.choice(base))
        for _ in range(rng.randint(0, 4)):
            if frame and rng.random() < 0.6:
                frame[rng.randrange(len(frame))] = rng.randrange(256)
            elif frame and rng.random() < 0.5:
                del frame[rng.randrange(len(frame)):]
            else:
                frame.extend(rng.randbytes(rng.randint(1, 8)))
        r = real.process_frame(f"M{i}", bytes(frame))
        counts[r.stage] += 1
        assert r.command_id == f"M{i}"
    assert counts[STAGE_COMPONENT_FAILURE] == 0, counts   # the real parser never misbehaves
    assert counts[STAGE_PARSE_REJECTED] > 500 and counts[STAGE_SIMULATED] > 100, counts
    assert real.parser.starts == 1                        # and was never restarted


@needs_cpp
def test_rejected_frames_never_reach_the_simulator(config, messages):
    calls = []

    def spy_solver(model, pump, valve):
        calls.append((pump, valve))
        from physics_engine.pipeline_model import solve_operating_point
        return solve_operating_point(model, pump, valve)

    with Pipeline(config, parser_argv=[str(CLI)], solver=spy_solver) as p:
        for m in messages:
            if m["parse_expected"] == "PARSE_REJECT":
                p.process_frame(m["command_id"], bytes.fromhex(m["frame_hex"]))
    assert calls == []


@needs_cpp
def test_current_pipeline_state_is_used_and_never_modified(config):
    state = PipelineState(pump_speed=90, valve_position=15)
    with Pipeline(config, parser_argv=[str(CLI)], state=state) as p:
        r = p.process_frame("S1", VALID_FRAME)   # pump := 60, valve stays at the state's 15
        assert state == PipelineState(90, 15)
        assert r.simulation.predicted_pressure > 0
    with Pipeline(config, parser_argv=[str(CLI)]) as p2:
        assert p2.process_frame("S1", VALID_FRAME).simulation != r.simulation  # different state -> different prediction


@needs_cpp
def test_results_are_deterministic(config):
    a = Pipeline(config, parser_argv=[str(CLI)])
    b = Pipeline(config, parser_argv=[str(CLI)])
    try:
        for i, rec in enumerate(gt.generate_scenarios()):
            ra = a.process_frame(rec["command_id"], bytes.fromhex(rec["frame_hex"])).to_dict()
            rb = b.process_frame(rec["command_id"], bytes.fromhex(rec["frame_hex"])).to_dict()
            ra.pop("timings_ms"), rb.pop("timings_ms")
            assert ra == rb
    finally:
        a.close(), b.close()


@needs_cpp
def test_timings_are_recorded(real):
    r = real.process_frame("T1", VALID_FRAME)
    assert r.parse_ms > 0 and r.simulate_ms >= 0 and r.total_ms >= r.parse_ms + r.simulate_ms - 0.01
    assert set(r.to_dict()["timings_ms"]) == {"parse", "simulate", "total"}
    json.dumps(r.to_dict())  # serialisable


@needs_cpp
def test_concurrent_callers_get_their_own_results(real):
    errors = []

    def worker(n):
        for i in range(60):
            cid = f"W{n}-{i}"
            r = real.process_frame(cid, VALID_FRAME)
            if r.command_id != cid or r.stage != STAGE_SIMULATED or r.parsed_command.command_id != cid:
                errors.append((cid, r))

    threads = [threading.Thread(target=worker, args=(n,)) for n in range(6)]
    [t.start() for t in threads], [t.join(30) for t in threads]
    assert errors == [] and real.parser.starts == 1


# ------------------------------------------------------------------ caller input validation (no parser needed)

@pytest.mark.parametrize("bad", ["", "a b", "x" * 65, "a;b", "id\n", "../x", None, 5, b"id"])
def test_invalid_command_id_is_a_recorded_failure(fake, bad):
    r = fake.process_frame(bad, VALID_FRAME)
    assert r.stage == STAGE_COMPONENT_FAILURE and r.error_code == "INVALID_COMMAND_ID" and r.command_id is None
    assert fake.parser.starts == 0  # nothing was sent to a child


@pytest.mark.parametrize("bad", ["0001", None, 5, [1, 2], bytearray(b"ok")[0]])
def test_non_bytes_frame_is_a_recorded_failure(fake, bad):
    r = fake.process_frame("F1", bad)
    assert_failed_closed(r, "INVALID_FRAME")
    assert fake.parser.starts == 0


def test_oversized_frame_rejected_before_reaching_the_parser(fake):
    r = fake.process_frame("BIG1", bytes(pl.MAX_FRAME_BYTES + 1))
    assert r.stage == STAGE_PARSE_REJECTED and r.error == "frame too large" and r.simulation is None
    assert fake.parser.starts == 0


def test_bytearray_frames_are_accepted(fake):
    assert fake.process_frame("OK1", bytearray(VALID_FRAME)).stage == STAGE_SIMULATED


# ------------------------------------------------------------------ fault injection with the fake parser

def test_fake_parser_happy_path_flows_through_simulation(fake):
    r = fake.process_frame("OK1", VALID_FRAME)
    assert r.stage == STAGE_SIMULATED and r.simulation.simulation_status == "SUCCESS"
    assert r.parsed_command.register_value == 50 and r.command_id == "OK1"


def test_valid_rejection_reply_becomes_parse_rejected(fake):
    r = fake.process_frame("REJ1", VALID_FRAME)
    assert r.stage == STAGE_PARSE_REJECTED and r.error_code == "LENGTH_MISMATCH" and r.simulation is None


def test_parser_timeout_fails_closed_within_bounded_time_and_recovers(fake):
    fake.process_frame("OK1", VALID_FRAME)
    pid = fake.parser.pid
    t0 = time.perf_counter()
    r = fake.process_frame("HANG1", VALID_FRAME)
    elapsed = time.perf_counter() - t0
    assert_failed_closed(r, "PARSER_TIMEOUT")
    assert 0.35 < elapsed < 3.0, elapsed
    assert fake.parser.pid is None                       # the hung child was killed
    after = fake.process_frame("OK2", VALID_FRAME)       # next request restarts a fresh child
    assert after.stage == STAGE_SIMULATED and fake.parser.pid != pid


def test_slow_but_in_time_parser_still_works(config):
    with Pipeline(config, parser_argv=[sys.executable, "-I", str(FAKE)], parser_timeout_ms=3000) as p:
        assert p.process_frame("SLOWOK1", VALID_FRAME).stage == STAGE_SIMULATED


def test_parser_crash_fails_closed_and_recovers(fake):
    r = fake.process_frame("CRASH1", VALID_FRAME)
    assert_failed_closed(r, "PARSER_CRASHED")
    assert fake.process_frame("OK1", VALID_FRAME).stage == STAGE_SIMULATED


def test_parser_dying_between_requests_is_detected(fake):
    fake.process_frame("OK1", VALID_FRAME)
    fake.parser._proc.kill()
    fake.parser._proc.wait()
    assert fake.process_frame("OK2", VALID_FRAME).stage == STAGE_SIMULATED  # restarted transparently


@pytest.mark.parametrize("prefix,code", [
    ("WRONGID", "PARSER_ID_MISMATCH"), ("BADJSON", "PARSER_BAD_OUTPUT"), ("NOTDICT", "PARSER_BAD_OUTPUT"),
    ("BADSTATUS", "PARSER_BAD_OUTPUT"), ("NOCMD", "PARSER_BAD_OUTPUT"), ("TOOLONG", "PARSER_BAD_OUTPUT"),
    ("BADSCHEMA", "PARSER_SCHEMA_ERROR"), ("INNERID", "PARSER_SCHEMA_ERROR"),
])
def test_misbehaving_parser_output_fails_closed_then_recovers(fake, prefix, code):
    r = fake.process_frame(f"{prefix}1", VALID_FRAME)
    assert_failed_closed(r, code)
    assert fake.process_frame("OK1", VALID_FRAME).stage == STAGE_SIMULATED


def test_unsolicited_extra_output_cannot_desynchronise_later_requests(fake):
    first = fake.process_frame("EXTRA1", VALID_FRAME)
    assert first.stage == STAGE_SIMULATED
    for i in range(5):
        r = fake.process_frame(f"OK{i}", VALID_FRAME)
        assert r.stage == STAGE_SIMULATED and r.command_id == f"OK{i}" and r.parsed_command.command_id == f"OK{i}"


def test_missing_parser_executable_is_a_recorded_failure(config):
    with Pipeline(config, parser_argv=["/nonexistent/voltguard_parser_cli"]) as p:
        assert_failed_closed(p.process_frame("N1", VALID_FRAME), "PARSER_UNAVAILABLE")
        assert_failed_closed(p.process_frame("N2", VALID_FRAME), "PARSER_UNAVAILABLE")  # repeated attempts also fail cleanly


def test_unbuilt_default_parser_is_a_recorded_failure(config, monkeypatch):
    monkeypatch.setattr(pl, "find_parser_cli", lambda: None)
    with Pipeline(config) as p:
        assert_failed_closed(p.process_frame("N1", VALID_FRAME), "PARSER_UNAVAILABLE")


def test_failure_results_never_look_like_a_safe_prediction(fake):
    for prefix in ("HANG", "CRASH", "WRONGID", "BADJSON", "BADSCHEMA"):
        r = fake.process_frame(f"{prefix}9", VALID_FRAME)
        d = r.to_dict()
        assert d["stage"] == STAGE_COMPONENT_FAILURE and d["simulation"] is None and d["parsed_command"] is None


# ------------------------------------------------------------------ simulator faults and timeouts

def test_simulator_exception_is_reported_as_simulation_error_not_a_crash(config):
    def boom(model, pump, valve):
        raise RuntimeError("solver exploded")

    with Pipeline(config, parser_argv=[sys.executable, "-I", str(FAKE)], solver=boom) as p:
        r = p.process_frame("E1", VALID_FRAME)
        assert r.stage == STAGE_SIMULATED and r.simulation.simulation_status == "ERROR"
        assert r.simulation.predicted_pressure is None and r.simulation.violations == ()


def test_simulator_timeout_fails_closed_quickly(config):
    release = threading.Event()

    def stuck(model, pump, valve):
        release.wait(30)
        raise RuntimeError("released")

    with Pipeline(config, parser_argv=[sys.executable, "-I", str(FAKE)], solver=stuck, simulation_timeout_ms=150) as p:
        t0 = time.perf_counter()
        r = p.process_frame("T1", VALID_FRAME)
        elapsed = time.perf_counter() - t0
        release.set()
    assert r.stage == STAGE_SIMULATED and r.simulation.simulation_status == "TIMEOUT"
    assert r.simulation.predicted_pressure is None and r.simulation.violations == () and r.simulation.error
    assert 0.14 < elapsed < 3.0, elapsed
    SimulationResult.from_dict(r.simulation.to_dict())  # still a valid contract message


def test_timeouts_default_from_configuration(config):
    with Pipeline(config, parser_argv=[sys.executable, "-I", str(FAKE)]) as p:
        assert p.parser_timeout_s == config.timeouts_ms["parser"] / 1000.0
        assert p.simulation_timeout_s == config.timeouts_ms["simulation"] / 1000.0


# ------------------------------------------------------------------ process-launch safety

def test_parser_is_launched_without_a_shell_from_a_fixed_argument_list(config, monkeypatch):
    seen = []
    real_popen = subprocess.Popen

    def spy(args, *a, **kw):
        seen.append((args, kw))
        return real_popen(args, *a, **kw)

    monkeypatch.setattr(subprocess, "Popen", spy)
    with Pipeline(config, parser_argv=[sys.executable, "-I", str(FAKE)]) as p:
        p.process_frame("SAFE1;touch_x", VALID_FRAME)   # invalid id, never launched
        p.process_frame("OK1", VALID_FRAME)
    assert len(seen) == 1
    args, kw = seen[0]
    assert isinstance(args, list) and kw.get("shell") is False
    assert all("OK1" not in a and "SAFE1" not in a for a in args)  # packet-derived data is never in argv


def test_packet_data_only_reaches_the_child_as_validated_id_and_hex(config, tmp_path):
    log = tmp_path / "stdin.log"
    script = tmp_path / "spy_parser.py"
    script.write_text("import sys, json\nfor line in sys.stdin:\n"
                      f"    open({str(log)!r}, 'a').write(line)\n"
                      "    cid = line.split(' ', 1)[0]\n"
                      "    print(json.dumps({'command_id': cid, 'status': 'REJECTED', 'error_code': 'X', 'error': 'x'}), flush=True)\n",
                      encoding="utf-8")
    with Pipeline(config, parser_argv=[sys.executable, "-I", str(script)]) as p:
        p.process_frame("ID-1", b"$(rm -rf /)`id`;\n\x00\xff")
    line = log.read_text()
    assert line.count("\n") == 1 and line.startswith("ID-1 ")
    assert set(line.split(" ", 1)[1].strip()) <= set("0123456789abcdef")


# ------------------------------------------------------------------ command line

@needs_cpp
def test_cli_processes_fixture_and_writes_json(tmp_path, capsys):
    out = tmp_path / "results.json"
    assert pl.main(["--input", str(FIXTURE), "--output", str(out)]) == 0
    text = capsys.readouterr().out
    assert "SIMULATED" in text and "PARSE_REJECTED" in text and "no allow/block decision" in text
    results = json.loads(out.read_text())["results"]
    assert len(results) == len(json.loads(FIXTURE.read_text())["messages"])
    assert {r["stage"] for r in results} == {STAGE_SIMULATED, STAGE_PARSE_REJECTED}


def test_cli_setup_errors_exit_2(tmp_path, capsys):
    assert pl.main(["--input", str(tmp_path / "missing.json")]) == 2
    bad = tmp_path / "bad.json"
    bad.write_text('{"format_version": 9, "messages": []}')
    assert pl.main(["--input", str(bad)]) == 2
    assert pl.main(["--input", str(FIXTURE), "--parser-cli", str(tmp_path / "nope")]) == 2


@pytest.mark.skipif(sys.platform == "win32", reason="uses a #! launcher script")
def test_cli_reports_component_failure_with_exit_1(tmp_path, capsys):
    traffic = tmp_path / "t.json"
    traffic.write_text(json.dumps({"format_version": 1, "messages": [
        {"command_id": "HANG1", "frame_hex": VALID_FRAME.hex(), "scenario": "hanging_parser"},
        {"command_id": "OK1", "frame_hex": VALID_FRAME.hex(), "scenario": "after_recovery"}]}))
    launcher = tmp_path / "fake_parser_cli"
    launcher.write_text(f"#!{sys.executable}\nimport runpy\nrunpy.run_path({str(FAKE)!r}, run_name='__main__')\n")
    launcher.chmod(0o755)
    out = tmp_path / "r.json"
    assert pl.main(["--input", str(traffic), "--parser-cli", str(launcher), "--output", str(out)]) == 1
    text = capsys.readouterr().out
    assert "COMPONENT_FAILURE" in text and "PARSER_TIMEOUT" in text and "1 component failure" in text
    results = json.loads(out.read_text())["results"]
    assert [r["stage"] for r in results] == [STAGE_COMPONENT_FAILURE, STAGE_SIMULATED]  # processing continued
