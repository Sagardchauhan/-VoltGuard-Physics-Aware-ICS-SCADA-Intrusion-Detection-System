"""Phase 5 tests: simplified pump/valve/pipeline physics engine and simulator."""

import copy
import json
import math
from dataclasses import FrozenInstanceError
from pathlib import Path

import pytest

from physics_engine import simulator as sim
from physics_engine.pipeline_model import (DEFAULT_MODEL, ModelError, OperatingPoint, PipelineModel,
                                           closed_form_operating_point, solve_operating_point)
from physics_engine.safety_limits import evaluate_limits
from physics_engine.simulator import (DEFAULT_STATE, PipelineState, simulate_command, simulate_settings)
from traffic_generator import generate_traffic as gt
from traffic_generator import scenarios as sc
from voltguard.config import load_safety_config, parse_safety_config
from voltguard.schemas import ParsedCommand, SimulationResult, Violation

ROOT = Path(__file__).resolve().parent.parent
CONFIG_PATH = ROOT / "config" / "safety_limits.json"


@pytest.fixture(scope="module")
def config():
    return load_safety_config(CONFIG_PATH)


def config_with(**limits):
    data = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    for key, (lo, hi) in limits.items():
        data["limits"][key] = {"min": lo, "max": hi}
    return parse_safety_config(data)


def cmd(fc, address, command_id="T-1", **kw):
    """Build a ParsedCommand directly (bypassing from_dict) so malformed combinations can be tried."""
    return ParsedCommand(command_id=command_id, transaction_id=1, unit_id=1, function_code=fc,
                         register_address=address, **kw)


def assert_contract(result):
    """Every result must satisfy the Phase 2 SimulationResult contract."""
    assert SimulationResult.from_dict(result.to_dict()) == result


# ------------------------------------------------------------------ model parameters

def test_default_model_parameters_are_valid():
    assert DEFAULT_MODEL.shutoff_pressure_kpa > 0 and DEFAULT_MODEL.pump_curve_coeff > 0


@pytest.mark.parametrize("field", ["shutoff_pressure_kpa", "pump_curve_coeff", "pipe_resistance", "valve_resistance"])
@pytest.mark.parametrize("bad", [0, -1.0, float("nan"), float("inf"), "1", True, None])
def test_bad_model_parameters_rejected(field, bad):
    with pytest.raises(ModelError):
        PipelineModel(**{field: bad})


def test_back_pressure_may_be_zero_but_not_negative():
    PipelineModel(static_back_pressure_kpa=0.0)
    with pytest.raises(ModelError):
        PipelineModel(static_back_pressure_kpa=-0.1)


# ------------------------------------------------------------------ physics core

GRID = [0, 5, 10, 20, 30, 40, 50, 60, 70, 80, 90, 95, 100]


def test_solver_matches_closed_form_over_grid():
    for pump in GRID + [33.3, 0.001, 99.999]:
        for valve in GRID + [0.001, 12.5, 99.999]:
            numeric = solve_operating_point(DEFAULT_MODEL, pump, valve)
            exact = closed_form_operating_point(DEFAULT_MODEL, pump, valve)
            assert numeric.flow_lps == pytest.approx(exact.flow_lps, abs=1e-7), (pump, valve)
            assert numeric.pressure_kpa == pytest.approx(exact.pressure_kpa, abs=1e-6), (pump, valve)


def test_operating_point_lies_on_both_curves():
    m = DEFAULT_MODEL
    for pump in (30, 60, 100):
        for valve in (20, 50, 100):
            p = solve_operating_point(m, pump, valve)
            s, v = pump / 100, valve / 100
            pump_side = m.shutoff_pressure_kpa * s * s - m.pump_curve_coeff * p.flow_lps ** 2
            system_side = m.static_back_pressure_kpa + (m.pipe_resistance + m.valve_resistance / v ** 2) * p.flow_lps ** 2
            assert pump_side == pytest.approx(p.pressure_kpa, abs=1e-6)
            assert system_side == pytest.approx(p.pressure_kpa, abs=1e-6)


def test_closed_valve_gives_zero_flow_and_deadhead_pressure():
    p = solve_operating_point(DEFAULT_MODEL, 50, 0)
    assert p.flow_lps == 0.0
    assert p.pressure_kpa == pytest.approx(DEFAULT_MODEL.shutoff_pressure_kpa * 0.25)


def test_stopped_pump_gives_zero_flow_and_zero_pressure():
    p = solve_operating_point(DEFAULT_MODEL, 0, 100)
    assert (p.flow_lps, p.pressure_kpa) == (0.0, 0.0)


def test_pump_too_slow_to_overcome_back_pressure_gives_no_flow():
    # 10 % speed: dead-head 1.6 kPa < 10 kPa back pressure
    p = solve_operating_point(DEFAULT_MODEL, 10, 100)
    assert p.flow_lps == 0.0 and p.pressure_kpa == pytest.approx(1.6)


def test_flow_and_pressure_rise_with_pump_speed():
    for valve in (20, 60, 100):
        points = [solve_operating_point(DEFAULT_MODEL, pump, valve) for pump in range(0, 101, 5)]
        assert all(b.flow_lps >= a.flow_lps - 1e-9 for a, b in zip(points, points[1:]))
        assert all(b.pressure_kpa >= a.pressure_kpa - 1e-9 for a, b in zip(points, points[1:]))


def test_closing_valve_raises_pressure_and_lowers_flow():
    for pump in (40, 70, 100):
        points = [solve_operating_point(DEFAULT_MODEL, pump, valve) for valve in range(100, -1, -5)]  # closing
        assert all(b.flow_lps <= a.flow_lps + 1e-9 for a, b in zip(points, points[1:]))
        assert all(b.pressure_kpa >= a.pressure_kpa - 1e-9 for a, b in zip(points, points[1:]))


@pytest.mark.parametrize("bad", [-0.0001, 100.0001, float("nan"), float("inf"), "5", True, None])
def test_core_rejects_bad_inputs(bad):
    with pytest.raises(ModelError):
        solve_operating_point(DEFAULT_MODEL, bad, 50)
    with pytest.raises(ModelError):
        solve_operating_point(DEFAULT_MODEL, 50, bad)


def test_extreme_tiny_valve_opening_is_numerically_stable():
    p = solve_operating_point(DEFAULT_MODEL, 100, 1e-9)
    assert math.isfinite(p.pressure_kpa) and 0 <= p.flow_lps < 1e-6
    assert p.pressure_kpa == pytest.approx(DEFAULT_MODEL.shutoff_pressure_kpa, rel=1e-6)


# ------------------------------------------------------------------ limit evaluation

def test_limits_are_inclusive(config):
    assert evaluate_limits(100.0, 50.0, config) == ()
    assert evaluate_limits(20.0, 5.0, config) == ()
    assert [v.type for v in evaluate_limits(100.0001, 5.0, config)] == ["PRESSURE_HIGH"]
    assert [v.type for v in evaluate_limits(19.9999, 5.0, config)] == ["PRESSURE_LOW"]
    assert [v.type for v in evaluate_limits(50.0, 50.0001, config)] == ["FLOW_HIGH"]
    assert [v.type for v in evaluate_limits(50.0, 4.9999, config)] == ["FLOW_LOW"]


def test_limit_evaluation_reports_all_violations_in_fixed_order(config):
    assert [v.type for v in evaluate_limits(150.0, 60.0, config)] == ["PRESSURE_HIGH", "FLOW_HIGH"]
    assert [v.type for v in evaluate_limits(0.0, 0.0, config)] == ["PRESSURE_LOW", "FLOW_LOW"]
    assert evaluate_limits(150.0, 60.0, config)[0] == Violation("PRESSURE_HIGH", 100.0, 150.0)


# ------------------------------------------------------------------ simulate_settings: required scenarios

def test_normal_operation(config):
    r = simulate_settings("N-1", 60, 70, config)
    assert r.simulation_status == "SUCCESS" and r.violations == ()
    assert r.pressure_unit == "kPa" and r.flow_unit == "L/s"
    assert (r.configured_min_pressure, r.configured_max_pressure) == (20.0, 100.0)
    assert 20 <= r.predicted_pressure <= 100 and 5 <= r.predicted_flow <= 50
    assert_contract(r)


def test_upper_pressure_limit_violation(config):
    r = simulate_settings("H-1", 100, 20, config)
    assert r.simulation_status == "SUCCESS"
    assert [v.type for v in r.violations] == ["PRESSURE_HIGH"]
    assert r.violations[0].limit == 100.0 and r.violations[0].predicted == r.predicted_pressure > 100.0
    assert_contract(r)


def test_lower_pressure_limit_violation(config):
    r = simulate_settings("L-1", 40, 60, config)
    assert [v.type for v in r.violations] == ["PRESSURE_LOW"]
    assert r.predicted_pressure < 20.0
    assert_contract(r)


def test_low_flow_violation_with_valve_closed(config):
    r = simulate_settings("F-1", 50, 0, config)
    assert r.predicted_flow == 0.0 and [v.type for v in r.violations] == ["FLOW_LOW"]


def test_flow_high_violation_with_widened_model(config):
    strong = PipelineModel(shutoff_pressure_kpa=400.0)
    r = simulate_settings("F-2", 100, 100, config_with(pressure=(0.0, 1000.0)), model=strong)
    assert "FLOW_HIGH" in [v.type for v in r.violations]


@pytest.mark.parametrize("bad", [-1, -0.0001, 100.0001, 250, float("nan"), float("inf"), float("-inf"),
                                 "50", True, [50], {"v": 1}])
def test_invalid_pump_input(config, bad):
    r = simulate_settings("I-1", bad, 50, config)
    assert r.simulation_status == "INVALID_INPUT" and "pump_speed" in r.error
    assert r.predicted_pressure is None and r.predicted_flow is None and r.violations == ()
    assert_contract(r)


@pytest.mark.parametrize("bad", [-1, 100.0001, 1000, float("nan"), float("inf"), "50", False, [1]])
def test_invalid_valve_position(config, bad):
    r = simulate_settings("I-2", 50, bad, config)
    assert r.simulation_status == "INVALID_INPUT" and "valve_position" in r.error
    assert_contract(r)


def test_missing_values(config):
    for pump, valve, name in ((None, 50, "pump_speed"), (50, None, "valve_position"), (None, None, "pump_speed")):
        r = simulate_settings("M-1", pump, valve, config)
        assert r.simulation_status == "INVALID_INPUT" and name in r.error and "missing" in r.error
        assert_contract(r)


def test_boundary_input_values_accepted(config):
    for pump, valve in ((0, 0), (0, 100), (100, 0), (100, 100), (0.0, 0.0), (100.0, 100.0)):
        assert simulate_settings("B-1", pump, valve, config).simulation_status == "SUCCESS"


def test_full_speed_full_open_lands_exactly_on_flow_limit(config):
    r = simulate_settings("B-2", 100, 100, config)
    assert r.predicted_flow == 50.0  # exactly the configured maximum
    assert r.violations == ()        # limits are inclusive


def test_prediction_exactly_on_limit_is_allowed_and_a_hair_over_is_not(config):
    base = simulate_settings("B-3", 50, 60, config)
    p = base.predicted_pressure
    at_limit = simulate_settings("B-3", 50, 60, config_with(pressure=(0.0, p)))
    assert at_limit.violations == ()
    just_over = simulate_settings("B-3", 50, 60, config_with(pressure=(0.0, round(p - 0.0001, 4))))
    assert [v.type for v in just_over.violations] == ["PRESSURE_HIGH"]
    at_min = simulate_settings("B-3", 50, 60, config_with(pressure=(p, 200.0)))
    assert at_min.violations == ()
    below_min = simulate_settings("B-3", 50, 60, config_with(pressure=(round(p + 0.0001, 4), 200.0)))
    assert [v.type for v in below_min.violations] == ["PRESSURE_LOW"]


def test_limits_come_from_configuration(config):
    tight = config_with(pressure=(20.0, 30.0))
    assert simulate_settings("C-1", 60, 70, config).violations == ()
    r = simulate_settings("C-1", 60, 70, tight)
    assert [v.type for v in r.violations] == ["PRESSURE_HIGH"] and r.configured_max_pressure == 30.0


def test_percentage_input_ranges_follow_configuration():
    narrow = config_with(pump_speed=(10.0, 90.0))
    assert simulate_settings("R-1", 95, 50, narrow).simulation_status == "INVALID_INPUT"
    assert simulate_settings("R-1", 5, 50, narrow).simulation_status == "INVALID_INPUT"
    assert simulate_settings("R-1", 50, 50, narrow).simulation_status == "SUCCESS"


# ------------------------------------------------------------------ simulation failure handling

class _Boom(Exception):  # an Exception subclass the simulator does not know about (generic handler)
    pass


@pytest.mark.parametrize("solver", [
    lambda m, p, v: (_ for _ in ()).throw(RuntimeError("solver diverged")),
    lambda m, p, v: (_ for _ in ()).throw(ValueError("bad bracket")),
    lambda m, p, v: (_ for _ in ()).throw(ZeroDivisionError()),
    lambda m, p, v: (_ for _ in ()).throw(_Boom("custom")),
    lambda m, p, v: OperatingPoint(float("nan"), 10.0),
    lambda m, p, v: OperatingPoint(50.0, float("inf")),
    lambda m, p, v: OperatingPoint(-5.0, 10.0),
    lambda m, p, v: OperatingPoint(50.0, -1.0),
    lambda m, p, v: OperatingPoint("50", 1.0),
    lambda m, p, v: OperatingPoint(True, 1.0),
    lambda m, p, v: None,
    lambda m, p, v: object(),
])
def test_solver_failures_fail_closed(config, solver):
    r = simulate_settings("S-1", 50, 60, config, solver=solver)
    assert r.simulation_status == "ERROR"
    assert r.error and r.predicted_pressure is None and r.predicted_flow is None and r.violations == ()
    assert_contract(r)


def test_failure_is_never_reported_as_success_or_safe(config):
    r = simulate_settings("S-2", 50, 60, config, solver=lambda m, p, v: (_ for _ in ()).throw(RuntimeError("x")))
    assert r.simulation_status != "SUCCESS" and r.violations == ()  # no predictions: downstream cannot call it safe


def test_failure_message_does_not_leak_traceback_but_names_cause(config):
    r = simulate_settings("S-3", 50, 60, config, solver=lambda m, p, v: (_ for _ in ()).throw(RuntimeError("diverged")))
    assert "RuntimeError" in r.error and "Traceback" not in r.error


# ------------------------------------------------------------------ command -> settings

def test_fc6_write_pump_applies_to_current_valve(config):
    r = simulate_command(cmd(6, 100, register_value=80), config)
    assert r == simulate_settings("T-1", 80, DEFAULT_STATE.valve_position, config)


def test_fc6_write_valve_applies_to_current_pump(config):
    r = simulate_command(cmd(6, 101, register_value=30), config)
    assert r == simulate_settings("T-1", DEFAULT_STATE.pump_speed, 30, config)


def test_fc16_writes_both_registers(config):
    r = simulate_command(cmd(16, 100, quantity=2, register_values=(70, 40)), config)
    assert r == simulate_settings("T-1", 70, 40, config)


def test_fc16_starting_at_valve_register_with_one_value(config):
    r = simulate_command(cmd(16, 101, quantity=1, register_values=(35,)), config)
    assert r == simulate_settings("T-1", DEFAULT_STATE.pump_speed, 35, config)


def test_fc3_read_changes_nothing(config):
    r = simulate_command(cmd(3, 100, quantity=2), config)
    assert r == simulate_settings("T-1", DEFAULT_STATE.pump_speed, DEFAULT_STATE.valve_position, config)


def test_current_state_is_respected(config):
    state = PipelineState(pump_speed=90, valve_position=15)
    r = simulate_command(cmd(6, 100, register_value=95), config, state=state)
    assert r == simulate_settings("T-1", 95, 15, config)


@pytest.mark.parametrize("command", [
    cmd(6, 102, register_value=5),                                  # unmapped register
    cmd(6, 99, register_value=5),
    cmd(6, 0, register_value=5),
    cmd(16, 100, quantity=3, register_values=(1, 2, 3)),            # spills into unmapped 102
    cmd(16, 101, quantity=2, register_values=(1, 2)),               # 101 ok, 102 unmapped
    cmd(16, 99, quantity=2, register_values=(1, 2)),                # 99 unmapped
    cmd(6, 100, register_value=250),                                # out-of-range value
    cmd(6, 101, register_value=101),
    cmd(16, 100, quantity=2, register_values=(50, 200)),
    cmd(6, 100, register_value=None),                               # missing value
    cmd(16, 100, quantity=2, register_values=None),
    cmd(5, 100, register_value=1),                                  # unsupported function code
    cmd(1, 100, quantity=1),
])
def test_invalid_commands_are_invalid_input(config, command):
    r = simulate_command(command, config)
    assert r.simulation_status == "INVALID_INPUT" and r.error
    assert r.predicted_pressure is None and r.violations == ()
    assert r.command_id == "T-1"
    assert_contract(r)


def test_partial_invalid_multi_write_applies_nothing(config):
    r = simulate_command(cmd(16, 100, quantity=2, register_values=(50, 200)), config)
    assert r.simulation_status == "INVALID_INPUT"  # one bad value rejects the whole command


def test_command_id_is_preserved(config):
    for cid in ("TG-0001", "a.b_c-9", "x" * 64):
        assert simulate_command(cmd(6, 100, command_id=cid, register_value=50), config).command_id == cid
        assert simulate_command(cmd(6, 100, command_id=cid, register_value=500), config).command_id == cid


# ------------------------------------------------------------------ determinism and purity

def test_identical_inputs_give_identical_results(config):
    first = simulate_settings("D-1", 73.3, 41.7, config)
    for _ in range(200):
        assert simulate_settings("D-1", 73.3, 41.7, config) == first
    assert json.dumps(first.to_dict(), sort_keys=True) == json.dumps(
        simulate_settings("D-1", 73.3, 41.7, config).to_dict(), sort_keys=True)


def test_simulation_does_not_mutate_its_inputs(config):
    state = PipelineState(pump_speed=40, valve_position=40)
    command = cmd(16, 100, quantity=2, register_values=(60, 70))
    snapshot = (copy.deepcopy(state), copy.deepcopy(command), copy.deepcopy(config))
    simulate_command(command, config, state=state)
    assert (state, command, config) == snapshot
    with pytest.raises(FrozenInstanceError):
        state.pump_speed = 1


def test_predictions_are_rounded_and_clean(config):
    r = simulate_settings("D-2", 33.333, 66.666, config)
    for value in (r.predicted_pressure, r.predicted_flow):
        assert round(value, sim.ROUND_DIGITS) == value
    zero = simulate_settings("D-3", 0, 50, config)
    assert str(zero.predicted_pressure) == "0.0" and str(zero.predicted_flow) == "0.0"  # never "-0.0"


# ------------------------------------------------------------------ the Phase 3 scenarios, verified against the model

EXPECTED_VIOLATIONS = {
    "normal_pump_60": [], "normal_pump_45": [], "normal_valve_70": [],
    "unsafe_multi_pump_100_valve_20": ["PRESSURE_HIGH"],
    "unsafe_valve_closed": ["FLOW_LOW"],
    "unsafe_pump_stop": ["PRESSURE_LOW", "FLOW_LOW"],
    "unsafe_pump_40_low_pressure": ["PRESSURE_LOW"],
    "unsafe_pump_100": ["PRESSURE_HIGH"],
    "boundary_full_speed_full_open": [],
    "read_pump_registers": [],
    "write_multiple_pump_valve": [],
}
EXPECTED_INVALID = {"out_of_range_pump_250", "unmapped_register_write"}


def scenario_results(config):
    out = {}
    for record in gt.generate_scenarios():
        if record["parse_expected"] != sc.PARSE_OK:
            continue
        command = ParsedCommand.from_dict({"command_id": record["command_id"], "protocol": "Modbus/TCP",
                                           **record["expected_fields"]})
        out[record["scenario"]] = (record, simulate_command(command, config))
    return out


def test_every_parseable_scenario_has_a_pinned_expectation(config):
    assert set(scenario_results(config)) == set(EXPECTED_VIOLATIONS) | EXPECTED_INVALID


def test_scenario_violations_match_pinned_expectations(config):
    for name, (record, result) in scenario_results(config).items():
        if name in EXPECTED_INVALID:
            assert result.simulation_status == "INVALID_INPUT", name
        else:
            assert result.simulation_status == "SUCCESS", name
            assert [v.type for v in result.violations] == EXPECTED_VIOLATIONS[name], name
        assert_contract(result)


def test_scenario_intent_labels_agree_with_the_model(config):
    """The generator's intent labels were corrected in Phase 5; they must now agree with the simulation."""
    for name, (record, result) in scenario_results(config).items():
        intent = record["intent"]
        if intent in (sc.INTENT_NORMAL, sc.INTENT_BOUNDARY, sc.INTENT_READ):
            assert result.simulation_status == "SUCCESS" and result.violations == (), name
        elif intent == sc.INTENT_UNSAFE:
            assert result.simulation_status == "SUCCESS" and result.violations, name
        elif intent == sc.INTENT_INVALID_VALUE:
            assert result.simulation_status == "INVALID_INPUT", name
        else:
            pytest.fail(f"{name}: unexpected intent {intent}")


def test_random_stream_commands_all_simulate_without_error(config):
    for record in gt.generate_stream(500, seed=3):
        command = ParsedCommand.from_dict({"command_id": record["command_id"], "protocol": "Modbus/TCP",
                                           **record["expected_fields"]})
        result = simulate_command(command, config)
        assert result.simulation_status == "SUCCESS"
        assert_contract(result)


# ------------------------------------------------------------------ CLI

def test_cli_success_and_violation_output(capsys):
    assert sim.main(["--pump", "60", "--valve", "70", "--id", "CLI-9"]) == 0
    out = json.loads(capsys.readouterr().out)
    assert out["command_id"] == "CLI-9" and out["simulation_status"] == "SUCCESS"


def test_cli_invalid_input_and_bad_config(capsys, tmp_path):
    assert sim.main(["--pump", "250", "--valve", "70"]) == 1
    assert json.loads(capsys.readouterr().out)["simulation_status"] == "INVALID_INPUT"
    assert sim.main(["--pump", "50", "--valve", "50", "--config", str(tmp_path / "missing.json")]) == 2
