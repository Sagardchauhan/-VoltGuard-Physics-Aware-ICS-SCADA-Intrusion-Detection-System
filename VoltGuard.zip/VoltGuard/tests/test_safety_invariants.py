"""Phase 12 tests: system-level safety and failure behaviour.

Unit tests for each component already exist. These tests check the *whole chain* (parser -> physics ->
decision engine -> event log) against one invariant:

    ALLOW is only ever produced when every component worked AND an independent check agrees the command
    is a well-formed, supported request whose simulated outcome is inside the configured limits.

Everything runs on simulated traffic. Tests that need the built parser CLI or the Rust engine are skipped
visibly (and the report generator fails on skips), never silently passed.
"""

import json
import os
import random
import struct
import subprocess
import sys
import time
from pathlib import Path

import pytest

from physics_engine.pipeline_model import OperatingPoint, solve_operating_point
from physics_engine.safety_limits import evaluate_limits
from traffic_generator.generate_traffic import generate_scenarios
from voltguard.config import load_safety_config
from voltguard.decision_bridge import Decider, find_decision_engine
from voltguard.pipeline import Pipeline, find_parser_cli
from voltguard.worker import handle_request
from tests.test_worker import Worker

ROOT = Path(__file__).resolve().parent.parent
CONFIG_PATH = ROOT / "config" / "safety_limits.json"
CONFIG = load_safety_config(CONFIG_PATH)
CLI = find_parser_cli()
ENGINE = find_decision_engine()
FAKE_PARSER = ROOT / "tests" / "fixtures" / "fake_parser.py"
FAKE_ENGINE = ROOT / "tests" / "fixtures" / "fake_engine.py"
needs_real = pytest.mark.skipif(CLI is None or ENGINE is None, reason="parser CLI or decision engine not built (these tests did NOT run)")
SAFE_WRITE = "00010000000601060064003c"      # pump 60 %: within limits
UNSAFE_WRITE = "000700000006010600640064"    # pump 100 %: pressure too high


# ------------------------------------------------------------------ independent oracle

def oracle_conditions_for_allow(frame: bytes) -> str | None:
    """Return None if `frame` could legitimately be ALLOWED, otherwise the reason it must not be.

    Written separately from the C++ parser and the Rust engine (plain struct, no shared code). These are
    necessary conditions for ALLOW, so a violation here proves a wrongly allowed command.
    """
    if len(frame) < 8 or len(frame) > 260:
        return "frame length outside 8..260"
    tid, pid, length, unit, fc = struct.unpack(">HHHBB", frame[:8])
    if pid != 0:
        return "protocol id is not 0"
    if length != len(frame) - 6:
        return "MBAP length field does not match the frame"
    pdu = frame[7:]
    if fc == 3:
        if len(pdu) != 5:
            return "FC3 request must be 5 bytes"
        addr, qty = struct.unpack(">HH", pdu[1:5])
        if not 1 <= qty <= 125 or addr + qty > 65536:
            return "FC3 quantity or address range invalid"
        return None
    if fc == 6:
        if len(pdu) != 5:
            return "FC6 request must be 5 bytes"
        addr, value = struct.unpack(">HH", pdu[1:5])
        if addr not in (100, 101):
            return "FC6 targets a register that is not the pump or the valve"
        if not 0 <= value <= 100:
            return "FC6 value outside 0..100"
        return None
    if fc == 16:
        if len(pdu) < 6:
            return "FC16 request too short"
        addr, qty, count = struct.unpack(">HHB", pdu[1:6])
        if qty < 1 or qty > 123 or count != qty * 2 or len(pdu) != 6 + count:
            return "FC16 byte count or quantity inconsistent"
        values = struct.unpack(f">{qty}H", pdu[6:])
        for i, v in enumerate(values):
            if addr + i not in (100, 101):
                return "FC16 writes a register that is not the pump or the valve"
            if not 0 <= v <= 100:
                return "FC16 value outside 0..100"
        return None
    return "function code is not 3, 6 or 16"


def assert_allow_is_justified(frame: bytes, decision: dict, result: dict) -> None:
    if decision["decision"] != "ALLOW":
        return
    why = oracle_conditions_for_allow(frame)
    assert why is None, f"ALLOW for a frame the oracle refuses ({why}): {frame.hex()}"
    assert result["stage"] == "SIMULATED" and result["simulation"]["simulation_status"] == "SUCCESS"
    assert decision["source"] == "engine" and decision["error_code"] is None
    parsed = result["parsed_command"]
    if parsed["function_code"] != 3:      # writes: the predicted state must be inside the limits (checked here again)
        sim = result["simulation"]
        assert not evaluate_limits(sim["predicted_pressure"], sim["predicted_flow"], CONFIG), frame.hex()


# ------------------------------------------------------------------ 1. mutation fuzz through the real chain

def mutate(rng: random.Random, frame: bytes) -> bytes:
    data = bytearray(frame)
    kind = rng.randrange(9)
    if kind == 0 and data:                                   # flip bits
        for _ in range(rng.randint(1, 3)):
            data[rng.randrange(len(data))] ^= 1 << rng.randrange(8)
    elif kind == 1 and data:                                 # replace a byte
        data[rng.randrange(len(data))] = rng.randrange(256)
    elif kind == 2 and len(data) > 1:                        # truncate
        del data[rng.randrange(1, len(data)):]
    elif kind == 3:                                          # extend
        data += bytes(rng.randrange(256) for _ in range(rng.randint(1, 20)))
    elif kind == 4 and len(data) >= 6:                       # change the length field
        data[4:6] = struct.pack(">H", rng.choice([0, 1, 2, 6, 7, 255, 256, 65535, rng.randrange(65536)]))
    elif kind == 5 and len(data) >= 8:                       # change the function code
        data[7] = rng.choice([0, 1, 2, 4, 5, 15, 17, 23, 43, 0x83, 0x86, 0xFF, rng.randrange(256)])
    elif kind == 6 and len(data) >= 10:                      # change the register address
        data[8:10] = struct.pack(">H", rng.choice([0, 99, 100, 101, 102, 65535, rng.randrange(65536)]))
    elif kind == 7 and len(data) >= 12:                      # change the value / quantity
        data[10:12] = struct.pack(">H", rng.choice([0, 1, 100, 101, 255, 256, 65535, rng.randrange(65536)]))
    else:                                                    # completely random frame
        data = bytearray(rng.randrange(256) for _ in range(rng.randint(0, 40)))
    return bytes(data)


@pytest.fixture(scope="module")
def real_chain():
    pipe = Pipeline(CONFIG, parser_argv=[str(CLI)])
    decider = Decider(CONFIG, engine_argv("real"))
    assert decider.available
    yield pipe, decider
    pipe.close()
    decider.close()


@needs_real
def test_mutated_frames_are_never_allowed_unless_an_independent_oracle_agrees(real_chain):
    pipe, decider = real_chain
    rng = random.Random(12012)
    seeds = [bytes.fromhex(s["frame_hex"]) for s in generate_scenarios()]
    seeds += [bytes.fromhex(SAFE_WRITE), bytes.fromhex(UNSAFE_WRITE)]
    tally = {"ALLOW": 0, "BLOCK": 0, "REJECT": 0}
    for i in range(1500):
        frame = mutate(rng, rng.choice(seeds))
        result = pipe.process_frame(f"F-{i}", frame).to_dict()
        decision = decider.decide(result)
        tally[decision["decision"]] += 1
        assert decision["command_id"] == f"F-{i}"
        assert_allow_is_justified(frame, decision, result)
    # The fuzz is only meaningful if it reached every outcome; otherwise it proves nothing.
    assert tally["ALLOW"] >= 20 and tally["BLOCK"] >= 20 and tally["REJECT"] >= 500, tally


@needs_real
def test_random_binary_garbage_is_never_allowed(real_chain):
    pipe, decider = real_chain
    rng = random.Random(77)
    for i in range(500):
        frame = bytes(rng.randrange(256) for _ in range(rng.randint(0, 300)))
        result = pipe.process_frame(f"G-{i}", frame).to_dict()
        decision = decider.decide(result)
        assert_allow_is_justified(frame, decision, result)
        assert decision["decision"] != "BLOCK" or result["stage"] == "SIMULATED"


@needs_real
def test_every_value_of_both_writable_registers_matches_the_independent_limit_check(real_chain):
    """Exhaustive: pump and valve 0..100 each (and just outside): the decision equals the physics + limits."""
    pipe, decider = real_chain
    n = 0
    for reg, other_default in ((100, None), (101, None)):
        for value in list(range(0, 102)) + [255, 1000, 65535]:
            frame = struct.pack(">HHHBBHH", n + 1, 0, 6, 1, 6, reg, value)
            result = pipe.process_frame(f"X-{n}", frame).to_dict()
            decision = decider.decide(result)
            n += 1
            assert_allow_is_justified(frame, decision, result)
            if value > 100:
                assert decision["decision"] == "REJECT", (reg, value)
            elif result["stage"] == "SIMULATED" and result["simulation"]["simulation_status"] == "SUCCESS":
                sim = result["simulation"]
                inside = not evaluate_limits(sim["predicted_pressure"], sim["predicted_flow"], CONFIG)
                assert decision["decision"] == ("ALLOW" if inside else "BLOCK"), (reg, value, sim)


# ------------------------------------------------------------------ 2. fault matrix

SOLVERS = {
    "ok": solve_operating_point,
    "raises": lambda model, pump, valve: (_ for _ in ()).throw(RuntimeError("solver exploded")),
    "nan": lambda model, pump, valve: OperatingPoint(float("nan"), float("nan")),
    "inf": lambda model, pump, valve: OperatingPoint(float("inf"), 10.0),
    "negative": lambda model, pump, valve: OperatingPoint(-5.0, -1.0),
    "string": lambda model, pump, valve: OperatingPoint("50", "10"),
    "none": lambda model, pump, valve: None,
}
PARSER_IDS = {"ok": "", "hang": "HANG", "crash": "CRASH", "wrongid": "WRONGID", "innerid": "INNERID", "badjson": "BADJSON",
              "notdict": "NOTDICT", "badstatus": "BADSTATUS", "nocmd": "NOCMD", "badschema": "BADSCHEMA", "toolong": "TOOLONG",
              "extra": "EXTRA", "rejected": "REJ"}
ENGINES = ["real", "missing", "hang", "crash", "garbage", "notjson", "wrongid", "allow_all", "block_all", "error", "badcontract",
           "oversize", "echo_reject", "slow"]


def engine_argv(name: str):
    if name == "real":
        return [str(ENGINE), "--config", str(CONFIG_PATH)] if ENGINE else None
    if name == "missing":
        return None
    return [sys.executable, "-I", str(FAKE_ENGINE), name]


def solver_is_healthy(name: str) -> bool:
    return name == "ok"


@pytest.mark.parametrize("engine", ENGINES)
def test_fault_matrix_allow_requires_every_component_to_work(engine):
    """Parser faults x solver faults x one engine mode: ALLOW only if parser, solver and engine are all sound.
    ("extra" sends a correct reply followed by a stray line, so that request is sound; the stray line is the next request's problem.)

    The fake parser always reports a safe pump write of 50 %, so an ALLOW is legitimate exactly when the
    parser reply is good, the solver is good and the engine says ALLOW (real or the fake that says ALLOW).
    """
    if engine == "real" and ENGINE is None:
        pytest.skip("decision engine not built (this test did NOT run)")
    engine_can_allow = engine in ("real", "allow_all")
    decider = Decider(CONFIG, engine_argv(engine), timeout_s=0.5)
    allowed = []
    try:
        full = engine in ("real", "allow_all")      # the two engines that can ALLOW get the full matrix; the others a reduced one
        for solver_name, solver in SOLVERS.items():
            if not full and solver_name not in ("ok", "raises", "nan"):
                continue
            for parser_name, prefix in PARSER_IDS.items():
                if not full and parser_name not in ("ok", "crash", "badschema", "rejected"):
                    continue
                with Pipeline(CONFIG, parser_argv=[sys.executable, "-I", str(FAKE_PARSER)], solver=solver,
                              parser_timeout_ms=300, simulation_timeout_ms=300) as pipe:
                    command_id = f"{prefix}M-{solver_name}-{parser_name}"
                    result = pipe.process_frame(command_id, bytes.fromhex(SAFE_WRITE)).to_dict()
                    decision = decider.decide(result)
                expected_allow = parser_name in ("ok", "extra") and solver_is_healthy(solver_name) and engine_can_allow
                got = decision["decision"] == "ALLOW"
                assert got == expected_allow, (engine, solver_name, parser_name, decision, result["stage"])
                if got:
                    allowed.append((solver_name, parser_name))
                assert decision["command_id"] in (command_id, None)
                assert decision["decision"] in ("ALLOW", "BLOCK", "REJECT")
        assert bool(allowed) == engine_can_allow          # the healthy path must still work (otherwise the matrix proves nothing)
    finally:
        decider.close()


@needs_real
@pytest.mark.parametrize("engine", [e for e in ENGINES if e != "real"])
def test_an_unsafe_command_is_never_allowed_whatever_the_engine_does(engine, tmp_path):
    """Real parser and physics, a command that violates the limits, a faulty or lying decision engine."""
    with Pipeline(CONFIG, parser_argv=[str(CLI)]) as pipe:
        decider = Decider(CONFIG, engine_argv(engine), timeout_s=0.5)
        try:
            for frame_hex in (UNSAFE_WRITE, "000700000006010600640000", "00070000000601060064ffff"):
                result = pipe.process_frame("U-1", bytes.fromhex(frame_hex)).to_dict()
                if frame_hex != "00070000000601060064ffff":      # premise: the command really does leave the limits
                    assert result["simulation"]["violations"], frame_hex
                assert decider.decide(result)["decision"] != "ALLOW", (engine, frame_hex)
        finally:
            decider.close()


# ------------------------------------------------------------------ 3. event log failures vs ALLOW

class FailingStore:
    """An event store whose writes fail in a configurable pattern."""

    def __init__(self, fail_calls):
        self.calls, self.fail_calls = 0, fail_calls

    def record(self, *args, **kwargs):
        self.calls += 1
        return self.calls not in self.fail_calls


@needs_real
@pytest.mark.parametrize("fail_calls, expect", [((), "ALLOW"), ((1,), "REJECT"), ((1, 2), "REJECT"), ((2,), "ALLOW")])
def test_an_allow_needs_its_event_to_be_stored_first(fail_calls, expect, real_chain):
    pipe, decider = real_chain
    store = FailingStore(set(fail_calls))
    reply = handle_request(pipe, [], {"op": "process", "command_id": "L-1", "frame_hex": SAFE_WRITE}, store, decider)
    assert reply["decision"]["decision"] == expect
    if expect == "REJECT":
        assert reply["decision"]["error_code"] == "EVENT_LOG_UNAVAILABLE"
        assert reply["logged"] in (True, False)


@needs_real
def test_an_event_store_that_raises_or_returns_junk_cannot_produce_an_unlogged_allow(real_chain):
    pipe, decider = real_chain

    class Raises:
        def record(self, *a, **k):
            raise OSError("disk full")

    class Junk:
        def record(self, *a, **k):
            return "yes"

    for store in (Raises(), Junk()):
        reply = handle_request(pipe, [], {"op": "process", "command_id": "L-2", "frame_hex": SAFE_WRITE}, store, decider)
        assert reply["decision"]["decision"] == "REJECT", reply["decision"]
        assert reply["decision"]["error_code"] == "EVENT_LOG_UNAVAILABLE" and reply["logged"] is False


# ------------------------------------------------------------------ 4. configuration failures stop the system

def corrupt_variants():
    good = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))

    def with_(path, value):
        c = json.loads(json.dumps(good))
        d = c
        for key in path[:-1]:
            d = d[key]
        d[path[-1]] = value
        return json.dumps(c)

    def without(*path):
        c = json.loads(json.dumps(good))
        d = c
        for key in path[:-1]:
            d = d[key]
        del d[path[-1]]
        return json.dumps(c)

    return {
        "empty_file": "",
        "not_json": "{not json",
        "json_array": "[1,2,3]",
        "json_null": "null",
        "truncated": json.dumps(good)[:40],
        "missing_pressure": without("limits", "pressure"),
        "missing_timeouts": without("timeouts_ms"),
        "min_above_max": with_(["limits", "pressure", "min"], 500),
        "nan_limit": with_(["limits", "pressure", "max"], float("nan")),
        "infinite_limit": with_(["limits", "flow", "max"], float("inf")),
        "string_limit": with_(["limits", "pressure", "max"], "100"),
        "boolean_limit": with_(["limits", "pressure", "max"], True),
        "negative_timeout": with_(["timeouts_ms", "decision"], -1),
        "zero_timeout": with_(["timeouts_ms", "parser"], 0),
        "huge_timeout": with_(["timeouts_ms", "simulation"], 10 ** 9),
        "wrong_schema": with_(["schema_version"], 99),
        "pump_over_100": with_(["limits", "pump_speed", "max"], 250),
    }


@pytest.mark.parametrize("name", sorted(corrupt_variants()))
def test_a_corrupt_configuration_stops_the_worker_before_it_can_decide_anything(name, tmp_path):
    cfg = tmp_path / "bad.json"
    cfg.write_text(corrupt_variants()[name], encoding="utf-8")
    proc = subprocess.run([sys.executable, "-m", "voltguard.worker", "--config", str(cfg), "--log-dir", str(tmp_path)],
                          cwd=ROOT, input=json.dumps({"op": "process", "command_id": "C-1", "frame_hex": SAFE_WRITE}) + "\n",
                          capture_output=True, text=True, timeout=30)
    assert proc.returncode == 2, (name, proc.stdout, proc.stderr)
    lines = [json.loads(l) for l in proc.stdout.splitlines() if l.strip()]
    assert [m["type"] for m in lines] == ["fatal"], (name, lines)
    assert "ALLOW" not in proc.stdout


def test_a_missing_configuration_file_stops_the_worker(tmp_path):
    proc = subprocess.run([sys.executable, "-m", "voltguard.worker", "--config", str(tmp_path / "nope.json"), "--log-dir", str(tmp_path)],
                          cwd=ROOT, input="", capture_output=True, text=True, timeout=30)
    assert proc.returncode == 2 and json.loads(proc.stdout.splitlines()[0])["type"] == "fatal"


@needs_real
def test_limits_in_a_different_configuration_change_the_decision_not_just_the_label(tmp_path):
    """Tighten the pressure limit: the same command that was ALLOWed under the shipped limits is now BLOCKed."""
    cfg = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    cfg["limits"]["pressure"]["max"] = 30.0
    tight = tmp_path / "tight.json"
    tight.write_text(json.dumps(cfg), encoding="utf-8")
    results = {}
    for label, path in (("shipped", CONFIG_PATH), ("tight", tight)):
        config = load_safety_config(path)
        with Pipeline(config, parser_argv=[str(CLI)]) as pipe:
            decider = Decider(config, [str(ENGINE), "--config", str(path)])
            try:
                results[label] = decider.decide(pipe.process_frame("T-1", bytes.fromhex(SAFE_WRITE)).to_dict())["decision"]
            finally:
                decider.close()
    assert results == {"shipped": "ALLOW", "tight": "BLOCK"}, results


# ------------------------------------------------------------------ 5. hostile input at the worker boundary

@needs_real
def test_the_worker_survives_hostile_lines_and_keeps_ids_matched(tmp_path):
    w = Worker(tmp_path, "--parser-cli", str(CLI), "--no-event-log")
    try:
        assert w.read()["type"] == "ready"
        hostile = [b"\xff\xfe\x00garbage", b"{", b"[]", b'"string"', b"null", b"123", b'{"op":null}', b'{"op":"process"}',
                   b'{"op":"process","command_id":"A B","frame_hex":"00"}', b'{"op":"process","command_id":"H-1","frame_hex":"zz"}',
                   b'{"op":"process","command_id":"H-2","frame_hex":"' + b"00" * 3000 + b'"}', b'{"op":"' + b"x" * 5000 + b'"}',
                   b'{"op":"process","command_id":"H-3","frame_hex":"' + SAFE_WRITE.encode() + b'","source":{"a":1}}',
                   b'{"op":"process","command_id":"H-4","frame_hex":"' + SAFE_WRITE.encode() + b'","source":"\\u0000;rm -rf /"}']
        for line in hostile:
            reply = w.ask(line)
            assert reply["type"] in ("error", "result"), reply
            if reply["type"] == "result":
                assert reply["decision"]["decision"] in ("ALLOW", "BLOCK", "REJECT")
        # still healthy afterwards, and replies belong to the right request
        for i in range(20):
            reply = w.ask({"op": "process", "command_id": f"OK-{i}", "frame_hex": SAFE_WRITE if i % 2 else UNSAFE_WRITE})
            assert reply["command_id"] == f"OK-{i}"
            assert reply["decision"]["decision"] == ("ALLOW" if i % 2 else "BLOCK"), reply["decision"]
    finally:
        w.close()
    assert w.proc.returncode == 0


@needs_real
def test_closing_stdin_in_the_middle_of_a_session_ends_the_worker_cleanly(tmp_path):
    w = Worker(tmp_path, "--parser-cli", str(CLI), "--no-event-log")
    try:
        assert w.read()["type"] == "ready"
        w.send({"op": "process", "command_id": "E-1", "frame_hex": SAFE_WRITE})
        w.proc.stdin.write(b'{"op":"process","command_id":"E-2","frame_h')      # cut off mid-line, no newline
        w.proc.stdin.flush()
        w.proc.stdin.close()
        assert w.read()["command_id"] == "E-1"
        assert w.proc.wait(timeout=15) == 0
    finally:
        w.close()


def test_a_hung_decision_engine_costs_a_bounded_time_per_command():
    decider = Decider(CONFIG, [sys.executable, "-I", str(FAKE_ENGINE), "hang"], timeout_s=0.3)
    sim = {"command_id": "S-1", "stage": "SIMULATED", "parsed_command": {"command_id": "S-1", "function_code": 6, "register_address": 100, "register_value": 60},
           "simulation": {"command_id": "S-1", "simulation_status": "SUCCESS", "predicted_pressure": 50.0, "predicted_flow": 20.0}}
    try:
        times = []
        for _ in range(4):
            start = time.monotonic()
            assert decider.decide(sim)["decision"] == "REJECT"
            times.append(time.monotonic() - start)
        assert max(times) < 3.0, times       # generous: 0.3 s timeout plus restart on a loaded machine
    finally:
        decider.close()
