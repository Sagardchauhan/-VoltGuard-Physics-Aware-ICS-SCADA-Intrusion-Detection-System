"""Phase 16 tests: the whole system as separate processes, the way the dashboard uses it.

mock traffic file -> worker process (C++ parser child + physics + Rust engine child + SQLite log) -> export.
Also: restarts on the same database, kill -9 of the worker, killed child processes, orphaned children.
Everything is simulated traffic. Tests need the built parser CLI and decision engine (visible skip otherwise);
the process-killing tests need Linux (/proc) and are skipped visibly elsewhere.
"""

import json
import os
import signal
import subprocess
import sys
import time
from pathlib import Path

import pytest

from event_logging.event_store import EventStore
from event_logging.export import export_events
from voltguard.decision_bridge import find_decision_engine
from voltguard.pipeline import find_parser_cli
from tests.test_safety_invariants import oracle_conditions_for_allow

ROOT = Path(__file__).resolve().parent.parent
CLI, ENGINE = find_parser_cli(), find_decision_engine()
needs_real = pytest.mark.skipif(CLI is None or ENGINE is None, reason="parser CLI or decision engine not built (these tests did NOT run)")
needs_proc = pytest.mark.skipif(not Path("/proc/self/stat").exists(), reason="needs /proc (Linux); these tests did NOT run")
INTENT_DECISION = {"NORMAL": "ALLOW", "BOUNDARY_SAFE": "ALLOW", "READ_ONLY": "ALLOW", "UNSAFE": "BLOCK"}
SAFE = "00010000000601060064003c"


class Session:
    """The real worker process, driven over its JSON-lines protocol."""

    def __init__(self, tmp_path: Path, db: Path):
        self.db = db
        self.proc = subprocess.Popen([sys.executable, "-m", "voltguard.worker", "--log-dir", str(tmp_path), "--event-db", str(db),
                                      "--parser-cli", str(CLI), "--decision-engine", str(ENGINE)], cwd=ROOT,
                                     stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
        ready = self.read()
        assert ready["type"] == "ready" and ready["decision_engine"]["available"] and ready["event_log"]["ok"], ready

    def read(self):
        line = self.proc.stdout.readline()
        assert line, "worker closed its output"
        return json.loads(line)

    def send(self, obj):
        self.proc.stdin.write((json.dumps(obj) + "\n").encode())
        self.proc.stdin.flush()

    def process(self, command_id, frame_hex, source="e2e"):
        self.send({"op": "process", "command_id": command_id, "frame_hex": frame_hex, "source": source})
        return self.read()

    def children(self):
        return children_of(self.proc.pid)

    def close(self):
        try:
            self.proc.stdin.close()
        except OSError:
            pass
        try:
            self.proc.wait(timeout=15)
        except subprocess.TimeoutExpired:
            self.proc.kill()
            self.proc.wait()
        self.proc.stdout.close()


def children_of(pid):
    """(pid, command line) of the direct children of `pid`, read from /proc."""
    found = []
    for entry in os.listdir("/proc"):
        if not entry.isdigit():
            continue
        try:
            stat = Path(f"/proc/{entry}/stat").read_text()
            ppid = int(stat.rsplit(")", 1)[1].split()[1])
            if ppid == pid:
                found.append((int(entry), Path(f"/proc/{entry}/cmdline").read_bytes().replace(b"\0", b" ").decode(errors="replace")))
        except (OSError, ValueError, IndexError):
            continue
    return found


def child_pid(session, name):
    for pid, cmd in session.children():
        if name in cmd:
            return pid
    raise AssertionError(f"no child process named {name}: {session.children()}")


def alive(pid):
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    try:    # a zombie counts as dead
        return Path(f"/proc/{pid}/stat").read_text().rsplit(")", 1)[1].split()[0] != "Z"
    except OSError:
        return False


def generate(tmp_path, *args):
    out = tmp_path / "traffic.json"
    subprocess.run([sys.executable, "-m", "traffic_generator.generate_traffic", "--output", str(out), *map(str, args)], cwd=ROOT, check=True,
                   capture_output=True, timeout=120)
    return json.loads(out.read_text())["messages"]


# ------------------------------------------------------------------ generator -> worker -> log -> export

@needs_real
def test_generated_scenarios_flow_through_every_component_to_the_export(tmp_path):
    messages = generate(tmp_path)
    assert len(messages) == 27
    s = Session(tmp_path, tmp_path / "e.db")
    try:
        replies = [s.process(m["command_id"], m["frame_hex"], m["scenario"]) for m in messages]
    finally:
        s.close()
    for m, r in zip(messages, replies):
        assert r["command_id"] == m["command_id"] and r["logged"] is True
        assert r["decision"]["decision"] == INTENT_DECISION.get(m["intent"], "REJECT"), (m["scenario"], r["decision"])
        assert r["decision"]["source"] == "engine"

    store = EventStore(tmp_path / "e.db")
    result = export_events(store, tmp_path / "out.json", "json")
    export_events(store, tmp_path / "out.csv", "csv")
    store.close()
    assert result.verified and result.rows == 27
    events = json.loads((tmp_path / "out.json").read_text())["events"]
    for m, r, e in zip(messages, replies, events):       # log, reply and traffic file agree row by row
        assert (e["command_id"], e["source"], e["decision"], e["frame_hex"]) == (m["command_id"], m["scenario"], r["decision"]["decision"], m["frame_hex"])
        assert e["stage"] == r["stage"]
    tally = {}
    for e in events:
        tally[e["decision"]] = tally.get(e["decision"], 0) + 1
    assert tally == {"ALLOW": 6, "BLOCK": 5, "REJECT": 16}


@needs_real
def test_a_random_command_stream_never_produces_an_unjustified_allow_end_to_end(tmp_path):
    messages = generate(tmp_path, "--stream", 250, "--seed", 16)
    assert len(messages) == 250
    s = Session(tmp_path, tmp_path / "e.db")
    try:
        replies = [s.process(m["command_id"], m["frame_hex"], "stream") for m in messages]
    finally:
        s.close()
    seen = {"ALLOW": 0, "BLOCK": 0, "REJECT": 0}
    for m, r in zip(messages, replies):
        seen[r["decision"]["decision"]] += 1
        if r["decision"]["decision"] == "ALLOW":
            assert oracle_conditions_for_allow(bytes.fromhex(m["frame_hex"])) is None, m
    assert seen["ALLOW"] > 10 and seen["BLOCK"] > 10, seen          # the stream reaches both outcomes
    store = EventStore(tmp_path / "e.db")
    assert store.verify() == (True, "250 row(s) verified")
    assert store.count() == 250
    store.close()


@needs_real
def test_the_pipeline_cli_output_gives_the_same_decisions_through_the_engine_cli(tmp_path):
    traffic = tmp_path / "t.json"
    subprocess.run([sys.executable, "-m", "traffic_generator.generate_traffic", "--output", str(traffic)], cwd=ROOT, check=True, capture_output=True)
    results = tmp_path / "r.json"
    subprocess.run([sys.executable, "-m", "voltguard.pipeline", "--input", str(traffic), "--parser-cli", str(CLI), "--output", str(results)],
                   cwd=ROOT, check=True, capture_output=True, timeout=120)
    doc = json.loads(results.read_text())
    items = doc if isinstance(doc, list) else doc.get("results", doc)
    lines = "\n".join(json.dumps(r, separators=(",", ":")) for r in items) + "\n"
    out = subprocess.run([str(ENGINE), "--config", str(ROOT / "config" / "safety_limits.json")], input=lines, capture_output=True, text=True, timeout=60)
    decisions = [json.loads(l)["decision"] for l in out.stdout.splitlines()]
    assert len(decisions) == 27
    assert {d: decisions.count(d) for d in set(decisions)} == {"ALLOW": 6, "BLOCK": 5, "REJECT": 16}


# ------------------------------------------------------------------ restarts and crashes

@needs_real
def test_two_sessions_on_one_database_continue_one_verified_chain(tmp_path):
    db = tmp_path / "e.db"
    for session_no in range(2):
        s = Session(tmp_path, db)
        try:
            for i in range(10):
                assert s.process(f"S{session_no}-{i}", SAFE)["logged"] is True
        finally:
            s.close()
    store = EventStore(db)
    assert store.verify() == (True, "20 row(s) verified")
    ids = [r["command_id"] for r in reversed(store.query(limit=100))]
    assert ids == [f"S{n}-{i}" for n in range(2) for i in range(10)]
    store.close()


@needs_real
@needs_proc
@pytest.mark.parametrize("released_before_kill", [1, 7, 23])
def test_killing_the_worker_never_loses_an_allow_that_was_released(tmp_path, released_before_kill):
    """kill -9 while a burst of requests is in flight: every ALLOW the client received is already in the log."""
    db = tmp_path / "e.db"
    s = Session(tmp_path, db)
    try:
        for i in range(60):
            s.send({"op": "process", "command_id": f"K-{i}", "frame_hex": SAFE, "source": "burst"})
        replies = [s.read() for _ in range(released_before_kill)]
        os.kill(s.proc.pid, signal.SIGKILL)
        s.proc.wait(timeout=15)
    finally:
        s.close()
    assert all(r["decision"]["decision"] == "ALLOW" and r["logged"] is True for r in replies)
    store = EventStore(db)
    stored = {r["command_id"]: r for r in store.query(limit=1000)}
    for r in replies:
        assert r["command_id"] in stored and stored[r["command_id"]]["decision"] == "ALLOW", r["command_id"]
    ok, message = store.verify()
    assert ok, message                      # a kill in the middle of a write leaves a consistent chain
    store.close()


UNSAFE = "000700000006010600640064"
MIN_BURST, MAX_BURST = 240, 4000


@needs_real
@needs_proc
@pytest.mark.parametrize("victim", ["voltguard_parser_cli", "voltguard_decision_engine"])
def test_a_child_killed_between_commands_is_replaced_and_nothing_unsafe_is_allowed(tmp_path, victim):
    """A component that died while idle is restarted before the next command. The new process is healthy, so a
    safe command may legitimately be ALLOWed; what must hold is that the old process is really gone, a new one
    serves the commands, an unsafe command is still BLOCKed and every command is logged."""
    s = Session(tmp_path, tmp_path / "e.db")
    try:
        assert s.process("R-0", SAFE)["decision"]["decision"] == "ALLOW"
        old = child_pid(s, victim)
        os.kill(old, signal.SIGKILL)
        deadline = time.monotonic() + 5
        while alive(old) and time.monotonic() < deadline:
            time.sleep(0.05)
        assert not alive(old)
        replies = [s.process("R-1", UNSAFE), s.process("R-2", SAFE), s.process("R-3", UNSAFE)]
        # A component that died while idle is noticed and replaced BEFORE the next command, so no command is lost to it:
        # the unsafe command is a normal BLOCK from the new process, not a collateral refusal, and the safe one is ALLOWed.
        assert [r["decision"]["decision"] for r in replies] == ["BLOCK", "ALLOW", "BLOCK"], [r["decision"] for r in replies]
        assert all(r["decision"]["source"] == "engine" for r in replies)
        new = child_pid(s, victim)
        assert new != old and alive(new)                      # a replacement process is serving
        assert all(r["logged"] is True for r in replies)
    finally:
        s.close()
    store = EventStore(tmp_path / "e.db")
    assert store.verify()[0] and store.count() == 4
    store.close()


@needs_real
@needs_proc
def test_both_children_killed_at_once_is_still_fail_closed_and_recovers(tmp_path):
    """Parser and engine die together while idle. Nothing unsafe may be allowed, both are replaced by new
    processes, and every command is still logged on one verified chain."""
    s = Session(tmp_path, tmp_path / "e.db")
    try:
        assert s.process("B-0", SAFE)["decision"]["decision"] == "ALLOW"
        old = [child_pid(s, "voltguard_parser_cli"), child_pid(s, "voltguard_decision_engine")]
        for pid in old:
            os.kill(pid, signal.SIGKILL)
        deadline = time.monotonic() + 5
        while any(alive(pid) for pid in old) and time.monotonic() < deadline:
            time.sleep(0.05)
        assert not any(alive(pid) for pid in old)
        replies = [s.process("B-1", UNSAFE), s.process("B-2", SAFE), s.process("B-3", UNSAFE)]
        decisions = [r["decision"]["decision"] for r in replies]
        assert decisions[0] != "ALLOW" and decisions[2] != "ALLOW", decisions      # unsafe is never allowed
        assert decisions == ["BLOCK", "ALLOW", "BLOCK"], decisions                  # and both components came back
        new = [child_pid(s, "voltguard_parser_cli"), child_pid(s, "voltguard_decision_engine")]
        assert all(alive(pid) for pid in new) and not set(new) & set(old)
        assert all(r["logged"] is True for r in replies)
    finally:
        s.close()
    store = EventStore(tmp_path / "e.db")
    assert store.verify()[0] and store.count() == 4
    store.close()


@needs_real
@needs_proc
def test_children_killed_repeatedly_during_a_burst_never_cause_an_unsafe_allow(tmp_path):
    """A background thread SIGKILLs the parser and the decision engine every ~5 ms while alternating safe and
    unsafe commands are processed (at least 240, and on until a fail-closed refusal has been seen, bounded). Every
    reply must belong to its request, be logged, and no unsafe command may ever be ALLOWed.

    A child that dies while idle is replaced before the next command, so a kill only causes a refusal when it lands
    in the middle of a request. With a fast engine that is rare, so a fixed command count made this test flaky (it
    failed about 1 run in 13 with the release build). Running until a refusal is observed removes the dependence on
    luck, and the run still fails if no kill ever lands mid-request within the bound."""
    import threading

    s = Session(tmp_path, tmp_path / "e.db")
    stop = threading.Event()
    kills = []

    def killer():
        while not stop.is_set():
            for name in ("voltguard_parser_cli", "voltguard_decision_engine"):
                try:
                    pid = child_pid(s, name)
                    os.kill(pid, signal.SIGKILL)
                    kills.append(pid)
                except (AssertionError, ProcessLookupError):
                    pass
            time.sleep(0.005)

    thread = threading.Thread(target=killer, daemon=True)
    try:
        thread.start()
        replies = []
        refused = False
        for i in range(MAX_BURST):
            frame = UNSAFE if i % 2 else SAFE
            reply = s.process(f"X-{i}", frame, "burst")
            replies.append((frame, reply))
            refused = refused or reply["decision"]["source"] == "fail_closed" or reply["stage"] == "COMPONENT_FAILURE"
            if i + 1 >= MIN_BURST and refused:
                break
    finally:
        stop.set()
        thread.join(timeout=5)
        s.close()
    assert len(kills) >= 5, kills
    for i, (frame, r) in enumerate(replies):
        assert r["command_id"] == f"X-{i}" and r["logged"] is True
        assert r["decision"]["decision"] in ("ALLOW", "BLOCK", "REJECT")
        if frame == UNSAFE:
            assert r["decision"]["decision"] != "ALLOW", r["decision"]
    refusals = [r for _, r in replies if r["decision"]["source"] == "fail_closed" or r["stage"] == "COMPONENT_FAILURE"]
    assert refusals, f"{len(kills)} kills produced no fail-closed refusal: the test did not reach the failure path"
    assert any(r["decision"]["decision"] == "ALLOW" for frame, r in replies if frame == SAFE)     # the system also kept working
    store = EventStore(tmp_path / "e.db")
    assert store.verify()[0] and store.count() == len(replies)
    store.close()


@needs_real
@needs_proc
def test_closing_the_worker_leaves_no_orphaned_children(tmp_path):
    s = Session(tmp_path, tmp_path / "e.db")
    s.process("C-0", SAFE)
    pids = [pid for pid, _ in s.children()]
    assert len(pids) >= 2, s.children()                  # the parser and the decision engine
    s.close()
    deadline = time.monotonic() + 10
    while time.monotonic() < deadline and any(alive(p) for p in pids):
        time.sleep(0.1)
    assert not [p for p in pids if alive(p)], "child processes survived the worker"


@needs_real
@needs_proc
def test_a_killed_worker_does_not_leave_children_running_forever(tmp_path):
    """kill -9 of the worker: the pipes close, so the children see end of input and exit by themselves."""
    s = Session(tmp_path, tmp_path / "e.db")
    s.process("O-0", SAFE)
    pids = [pid for pid, _ in s.children()]
    os.kill(s.proc.pid, signal.SIGKILL)
    s.proc.wait(timeout=15)
    deadline = time.monotonic() + 15
    while time.monotonic() < deadline and any(alive(p) for p in pids):
        time.sleep(0.1)
    leftovers = [p for p in pids if alive(p)]
    for p in leftovers:        # do not leave stray processes behind even when the assertion fails
        os.kill(p, signal.SIGKILL)
    s.close()
    assert not leftovers, "children outlived a killed worker"
