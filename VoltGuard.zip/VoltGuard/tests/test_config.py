"""Phase 1 tests: safety configuration loading and validation."""

import copy
import json
from pathlib import Path

import pytest

from voltguard.config import ConfigError, MAX_CONFIG_BYTES, load_safety_config, parse_safety_config

PROJECT_ROOT = Path(__file__).resolve().parent.parent
SHIPPED_CONFIG = PROJECT_ROOT / "config" / "safety_limits.json"


@pytest.fixture
def valid_data():
    return json.loads(SHIPPED_CONFIG.read_text(encoding="utf-8"))


def write_json(tmp_path, data, name="cfg.json"):
    path = tmp_path / name
    path.write_text(json.dumps(data), encoding="utf-8")
    return path


def test_shipped_config_loads():
    config = load_safety_config(SHIPPED_CONFIG)
    assert config.pressure.unit == "kPa"
    assert config.pressure.minimum < config.pressure.maximum
    assert config.timeouts_ms["simulation"] > 0


def test_limit_contains_is_inclusive_at_boundaries():
    config = load_safety_config(SHIPPED_CONFIG)
    assert config.pressure.contains(config.pressure.minimum)
    assert config.pressure.contains(config.pressure.maximum)
    assert not config.pressure.contains(config.pressure.maximum + 0.001)
    assert not config.pressure.contains(config.pressure.minimum - 0.001)


def test_loading_is_deterministic():
    assert load_safety_config(SHIPPED_CONFIG) == load_safety_config(SHIPPED_CONFIG)


def test_missing_file_raises(tmp_path):
    with pytest.raises(ConfigError, match="cannot read"):
        load_safety_config(tmp_path / "nope.json")


def test_invalid_json_raises(tmp_path):
    path = tmp_path / "bad.json"
    path.write_text("{not json", encoding="utf-8")
    with pytest.raises(ConfigError, match="not valid JSON"):
        load_safety_config(path)


def test_non_utf8_file_raises(tmp_path):
    path = tmp_path / "bin.json"
    path.write_bytes(b"\xff\xfe\x00\x80")
    with pytest.raises(ConfigError):
        load_safety_config(path)


def test_oversized_file_raises(tmp_path):
    path = tmp_path / "big.json"
    path.write_text(" " * (MAX_CONFIG_BYTES + 1), encoding="utf-8")
    with pytest.raises(ConfigError, match="too large"):
        load_safety_config(path)


@pytest.mark.parametrize("root", [[], "text", 5, None])
def test_non_object_root_raises(root):
    with pytest.raises(ConfigError):
        parse_safety_config(root)


def test_wrong_schema_version_raises(valid_data):
    valid_data["schema_version"] = 99
    with pytest.raises(ConfigError, match="schema_version"):
        parse_safety_config(valid_data)


def test_missing_limit_raises(valid_data):
    del valid_data["limits"]["pressure"]
    with pytest.raises(ConfigError, match="limits.pressure is missing"):
        parse_safety_config(valid_data)


def test_missing_min_raises(valid_data):
    del valid_data["limits"]["flow"]["min"]
    with pytest.raises(ConfigError, match="limits.flow.min is missing"):
        parse_safety_config(valid_data)


def test_min_not_less_than_max_raises(valid_data):
    valid_data["limits"]["pressure"] = {"min": 100.0, "max": 100.0}
    with pytest.raises(ConfigError, match="must be less than max"):
        parse_safety_config(valid_data)


@pytest.mark.parametrize("bad", ["100", True, None, [1]])
def test_non_numeric_limit_raises(valid_data, bad):
    valid_data["limits"]["pressure"]["max"] = bad
    with pytest.raises(ConfigError, match="must be a number"):
        parse_safety_config(valid_data)


@pytest.mark.parametrize("bad", [float("nan"), float("inf"), float("-inf")])
def test_non_finite_limit_raises(valid_data, bad):
    # json.dumps writes NaN/Infinity, which Python's json.loads accepts; we must reject them.
    valid_data["limits"]["pressure"]["max"] = bad
    path_data = json.loads(json.dumps(valid_data))
    with pytest.raises(ConfigError, match="finite"):
        parse_safety_config(path_data)


def test_percentage_limit_out_of_range_raises(valid_data):
    valid_data["limits"]["valve_position"]["max"] = 150.0
    with pytest.raises(ConfigError, match="0..100"):
        parse_safety_config(valid_data)


def test_missing_unit_raises(valid_data):
    valid_data["units"]["pressure"] = ""
    with pytest.raises(ConfigError, match="units.pressure"):
        parse_safety_config(valid_data)


@pytest.mark.parametrize("bad", [0, -5, 60_001, 1.5, "100", True])
def test_bad_timeout_raises(valid_data, bad):
    valid_data["timeouts_ms"]["decision"] = bad
    with pytest.raises(ConfigError, match="timeouts_ms.decision"):
        parse_safety_config(valid_data)


def test_missing_timeout_raises(valid_data):
    del valid_data["timeouts_ms"]["parser"]
    with pytest.raises(ConfigError, match="timeouts_ms.parser is missing"):
        parse_safety_config(valid_data)


def test_parse_does_not_mutate_input(valid_data):
    snapshot = copy.deepcopy(valid_data)
    parse_safety_config(valid_data)
    assert valid_data == snapshot
