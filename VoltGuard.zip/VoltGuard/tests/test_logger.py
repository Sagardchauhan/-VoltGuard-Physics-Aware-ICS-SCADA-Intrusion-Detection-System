"""Phase 1 tests: application logger."""

import logging

from voltguard.app_logging import LOG_FILE_NAME, setup_logger


def _close(logger):
    for handler in list(logger.handlers):
        logger.removeHandler(handler)
        handler.close()


def test_logger_writes_to_file(tmp_path):
    logger = setup_logger("vg_test_file", log_dir=tmp_path, console=False)
    logger.info("hello phase one")
    for handler in logger.handlers:
        handler.flush()
    content = (tmp_path / LOG_FILE_NAME).read_text(encoding="utf-8")
    assert "hello phase one" in content
    assert "INFO" in content
    _close(logger)


def test_repeated_setup_does_not_duplicate_handlers(tmp_path):
    setup_logger("vg_test_dup", log_dir=tmp_path, console=False)
    logger = setup_logger("vg_test_dup", log_dir=tmp_path, console=False)
    assert len(logger.handlers) == 1
    logger.warning("only once")
    for handler in logger.handlers:
        handler.flush()
    content = (tmp_path / LOG_FILE_NAME).read_text(encoding="utf-8")
    assert content.count("only once") == 1
    _close(logger)


def test_log_dir_is_created(tmp_path):
    target = tmp_path / "nested" / "logs"
    logger = setup_logger("vg_test_mkdir", log_dir=target, console=False)
    assert target.is_dir()
    _close(logger)


def test_level_is_respected(tmp_path):
    logger = setup_logger("vg_test_level", log_dir=tmp_path, level=logging.ERROR, console=False)
    logger.info("hidden")
    logger.error("visible")
    for handler in logger.handlers:
        handler.flush()
    content = (tmp_path / LOG_FILE_NAME).read_text(encoding="utf-8")
    assert "hidden" not in content
    assert "visible" in content
    _close(logger)
