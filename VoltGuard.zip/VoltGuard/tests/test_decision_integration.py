"""Phase 11 tests: decisions inside the dashboard worker (decision engine + event log, fail closed)."""

import json
import os
import stat
import sys
from pathlib import Path

import pytest

from event_logging.event_store import EventStore
from tests.test_decision_bridge import EXPECTED, ENGINE, fixture
from tests.test_worker import CLI, Worker, needs_cpp

ROOT = Path(__file__).resolve().parent.parent
FAKE = ROOT / "tests" / "fixtures" / "fake_engine.py"
needs_all = pytest.mark.skipif(CLI is None or ENGINE is None,
                               reason="parser CLI or decision engine not built (these tests did NOT run)")
VALID = "00010000000601060064003c"        # pump 60 %: within limits
UNSAFE = "000700000006010600640064"       # pump 100 %: pressure too high


def start(tmp_path, *extra):
    base = ["--parser-cli", str(CLI)] if CLI else []
    w = Worker(tmp_path, *base, *extra)
    ready = w.read()
    assert ready["type"] == "ready", ready
    return w, ready


def scenarios():
    from traffic_generator.generate_traffic import generate_scenarios
    return generate_scenarios()


def fake_engine_wrapper(tmp_path):
    """An executable that runs fake_engine.py (the mode comes from VOLTGUARD_FAKE_ENGINE_MODE)."""
    if sys.platform == "win32":
        path = tmp_path / "fake_engine.cmd"
        path.write_text(f'@"{sys.executable}" "{FAKE}" %*\r\n')
    else:
        path = tmp_path / "fake_engine.sh"
        path.write_text(f'#!/bin/sh\nexec "{sys.executable}" "{FAKE}" "$@"\n')
        path.chmod(path.stat().st_mode | stat.S_IXUSR)
    return path


# ----------------------------------------------------------------------------- real engine in the worker

@needs_all
def test_every_scenario_gets_its_designed_decision_through_the_worker(tmp_path):
    w, ready = start(tmp_path)
    try:
        assert ready["decision_engine"]["available"] is True and ready["decision_engine"]["error"] is None
        tally = {"ALLOW": 0, "BLOCK": 0, "REJECT": 0}
        for i, row in enumerate(scenarios()):
            r = w.ask({"op": "process", "command_id": f"D-{i:03d}", "frame_hex": row["frame_hex"], "source": row["scenario"]})
            d = r["decision"]
            assert d["decision"] == EXPECTED[row["intent"]], (row["scenario"], d)
            assert d["source"] == "engine" and d["error_code"] is None and d["command_id"] == r["command_id"]
            assert r["logged"] is True
            tally[d["decision"]] += 1
        assert tally == {"ALLOW": 6, "BLOCK": 5, "REJECT": 16}
        stored = w.ask({"op": "events", "limit": 100})["events"]
        assert len(stored) == 27
        by_cmd = {e["command_id"]: e for e in stored}
        for i, row in enumerate(scenarios()):
            e = by_cmd[f"D-{i:03d}"]
            assert e["decision"] == EXPECTED[row["intent"]] and e["decision_source"] == "engine" and e["decision_reason"]
        assert w.ask({"op": "verify_log"})["ok"] is True
    finally:
        w.close()


@needs_all
def test_a_blocked_command_is_logged_with_both_severity_and_decision(tmp_path):
    w, _ = start(tmp_path)
    try:
        r = w.ask({"op": "process", "command_id": "B-1", "frame_hex": UNSAFE, "source": "unsafe"})
        assert r["decision"]["decision"] == "BLOCK" and "pressure" in r["decision"]["reason"]
        assert r["decision"]["predicted_pressure"] > r["decision"]["configured_max_pressure"]
        e = w.ask({"op": "events", "limit": 1})["events"][0]
        assert (e["severity"], e["decision"]) == ("LIMIT_VIOLATION", "BLOCK")
    finally:
        w.close()


# ----------------------------------------------------------------------------- engine missing or failing

@needs_cpp
def test_without_a_decision_engine_every_command_is_rejected(tmp_path):
    w, ready = start(tmp_path, "--decision-engine", str(tmp_path / "does-not-exist"))
    try:
        assert ready["decision_engine"]["available"] is False and ready["decision_engine"]["error"]
        for i, row in enumerate(scenarios()):
            r = w.ask({"op": "process", "command_id": f"M-{i:03d}", "frame_hex": row["frame_hex"], "source": row["scenario"]})
            assert r["decision"]["decision"] == "REJECT", row["scenario"]
            assert (r["decision"]["source"], r["decision"]["error_code"]) == ("fail_closed", "DECISION_ENGINE_UNAVAILABLE")
            assert r["logged"] is True                      # the refusal is still recorded
        stored = w.ask({"op": "events", "limit": 100})["events"]
        assert {e["decision"] for e in stored} == {"REJECT"} and {e["decision_source"] for e in stored} == {"fail_closed"}
    finally:
        w.close()


@needs_cpp
@pytest.mark.parametrize("mode, code", [("hang", "DECISION_TIMEOUT"), ("crash", "DECISION_ENGINE_CRASHED"),
                                        ("garbage", "DECISION_BAD_OUTPUT"), ("wrongid", "DECISION_ID_MISMATCH"),
                                        ("allow_all", None)])
def test_a_faulty_engine_can_never_make_the_worker_allow_an_unsafe_command(tmp_path, monkeypatch, mode, code):
    monkeypatch.setenv("VOLTGUARD_FAKE_ENGINE_MODE", mode)
    w, ready = start(tmp_path, "--decision-engine", str(fake_engine_wrapper(tmp_path)))
    try:
        r = w.ask({"op": "process", "command_id": "F-1", "frame_hex": UNSAFE, "source": "unsafe"})
        assert r["decision"]["decision"] == "REJECT" and r["decision"]["source"] == "fail_closed"
        if code:
            assert r["decision"]["error_code"] == code
        else:       # an engine that allows everything is stopped by the Python second check
            assert r["decision"]["error_code"] == "DECISION_INCONSISTENT"
        r2 = w.ask({"op": "process", "command_id": "F-2", "frame_hex": "0001", "source": "malformed"})    # worker still alive
        assert r2["stage"] == "PARSE_REJECTED" and r2["decision"]["decision"] != "ALLOW"
    finally:
        w.close()


@needs_cpp
def test_handle_request_without_a_decider_fails_closed(tmp_path):
    from voltguard.config import load_safety_config
    from voltguard.pipeline import Pipeline
    from voltguard.worker import handle_request
    pipeline = Pipeline(load_safety_config(ROOT / "config" / "safety_limits.json"), parser_argv=[str(CLI)])
    try:
        reply = handle_request(pipeline, [], {"op": "process", "command_id": "N-1", "frame_hex": VALID})
        assert reply["decision"]["decision"] == "REJECT" and reply["decision"]["source"] == "fail_closed"
    finally:
        pipeline.close()


# ----------------------------------------------------------------------------- log before allow

@needs_all
def test_an_unusable_event_log_turns_allow_into_reject_but_leaves_block_alone(tmp_path):
    blocker = tmp_path / "file"
    blocker.write_text("x")
    w, ready = start(tmp_path, "--event-db", str(blocker / "events.db"))
    try:
        assert ready["event_log"]["ok"] is False
        allowed = w.ask({"op": "process", "command_id": "L-1", "frame_hex": VALID, "source": "normal"})
        assert allowed["decision"]["decision"] == "REJECT"
        assert (allowed["decision"]["source"], allowed["decision"]["error_code"]) == ("fail_closed", "EVENT_LOG_UNAVAILABLE")
        assert allowed["logged"] is False
        blocked = w.ask({"op": "process", "command_id": "L-2", "frame_hex": UNSAFE, "source": "unsafe"})
        assert blocked["decision"]["decision"] == "BLOCK" and blocked["decision"]["source"] == "engine"      # already not forwarded
        assert blocked["logged"] is False
    finally:
        w.close()


@needs_all
def test_with_logging_deliberately_off_an_allow_stays_an_allow(tmp_path):
    w, _ = start(tmp_path, "--no-event-log")
    try:
        r = w.ask({"op": "process", "command_id": "O-1", "frame_hex": VALID})
        assert r["decision"]["decision"] == "ALLOW" and r["logged"] is None
    finally:
        w.close()


@needs_all
def test_the_allow_is_stored_before_it_is_released(tmp_path):
    """When a reply says ALLOW, the matching row already exists (checked by reading the file independently)."""
    w, _ = start(tmp_path)
    try:
        r = w.ask({"op": "process", "command_id": "A-1", "frame_hex": VALID, "source": "normal"})
        assert r["decision"]["decision"] == "ALLOW" and r["logged"] is True
        db = EventStore(tmp_path / "events.db")
        row = db.query(command_id="A-1")[0]
        db.close()
        assert (row["decision"], row["decision_source"]) == ("ALLOW", "engine")
    finally:
        w.close()
