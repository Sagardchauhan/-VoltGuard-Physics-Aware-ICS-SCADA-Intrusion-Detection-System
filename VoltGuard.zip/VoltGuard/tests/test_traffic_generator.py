"""Phase 3 tests: mock Modbus/TCP traffic generator."""

import json
import socket
import struct
from pathlib import Path

import pytest

from traffic_generator import generate_traffic as gt
from traffic_generator.scenarios import (INTENT_MALFORMED, INTENT_UNSAFE, PARSE_OK, PARSE_REJECT,
                                         SCENARIOS, SCENARIOS_BY_NAME)

FIXTURE = Path(__file__).resolve().parent / "fixtures" / "mock_traffic.json"


def reference_frame(tid, unit, pdu: bytes) -> bytes:
    """Independent, hand-rolled MBAP encoder used to cross-check Scapy's output."""
    return struct.pack(">HHHB", tid, 0, len(pdu) + 1, unit) + pdu


def test_scenario_names_unique_and_nonempty():
    assert len(SCENARIOS) >= 20
    assert len({s.name for s in SCENARIOS}) == len(SCENARIOS)


def test_scenarios_cover_required_categories():
    intents = {s.intent for s in SCENARIOS}
    assert {"NORMAL", INTENT_UNSAFE, INTENT_MALFORMED, "UNSUPPORTED", "READ_ONLY"} <= intents
    assert any(s.parse_expected == PARSE_REJECT for s in SCENARIOS)
    assert any(s.parse_expected == PARSE_OK for s in SCENARIOS)


def test_every_scenario_builds_bytes():
    for s in SCENARIOS:
        assert isinstance(gt.build_frame(s), bytes)


def test_scapy_fc6_matches_reference_encoding():
    frame = gt.build_frame(SCENARIOS_BY_NAME["normal_pump_60"])
    assert frame == reference_frame(1, 1, struct.pack(">BHH", 6, 100, 60))
    assert frame.hex() == "00010000000601060064003c"


def test_scapy_fc3_matches_reference_encoding():
    frame = gt.build_frame(SCENARIOS_BY_NAME["read_pump_registers"])
    assert frame == reference_frame(9, 1, struct.pack(">BHH", 3, 100, 2))


def test_scapy_fc16_matches_reference_encoding():
    frame = gt.build_frame(SCENARIOS_BY_NAME["write_multiple_pump_valve"])
    assert frame == reference_frame(10, 1, struct.pack(">BHHBHH", 16, 100, 2, 4, 55, 65))


def test_well_formed_frames_have_consistent_length_field():
    for s in SCENARIOS:
        if s.parse_expected != PARSE_OK:
            continue
        frame = gt.build_frame(s)
        tid, proto, length, unit = struct.unpack(">HHHB", frame[:7])
        assert proto == 0 and length == len(frame) - 6 and tid == s.transaction_id and unit == s.unit_id


def test_malformed_frames_really_are_malformed():
    """Independent check: each malformed frame violates at least one MBAP rule or is oversized/short."""
    for s in SCENARIOS:
        if s.intent != INTENT_MALFORMED:
            continue
        frame = gt.build_frame(s)
        if len(frame) < 8 or len(frame) > 260:
            continue
        _, proto, length, _ = struct.unpack(">HHHB", frame[:7])
        fc = frame[7]
        pdu_len = len(frame) - 7  # bytes after unit id
        problems = [proto != 0, length != len(frame) - 6]
        if fc == 6:
            problems.append(pdu_len != 5)
        if fc == 3:
            addr, qty = struct.unpack(">HH", frame[8:12])
            problems.append(not 1 <= qty <= 125)
            problems.append(addr + qty - 1 > 0xFFFF)
        if fc == 16 and len(frame) >= 13:
            qty = struct.unpack(">H", frame[10:12])[0]
            problems.append(frame[12] != qty * 2 or pdu_len != 6 + qty * 2)
        assert any(problems), f"{s.name} does not look malformed"


def test_unsupported_scenarios_are_otherwise_valid_frames():
    for name in ("unsupported_fc01_read_coils", "unsupported_fc05_write_coil"):
        frame = gt.build_frame(SCENARIOS_BY_NAME[name])
        _, proto, length, _ = struct.unpack(">HHHB", frame[:7])
        assert proto == 0 and length == len(frame) - 6
        assert frame[7] in (1, 5)


def test_oversized_scenario_exceeds_adu_limit():
    assert len(gt.build_frame(SCENARIOS_BY_NAME["malformed_oversized"])) > 260


def test_empty_frame_scenario():
    assert gt.build_frame(SCENARIOS_BY_NAME["malformed_empty"]) == b""


def test_records_have_expected_fields_only_when_parseable():
    records = gt.generate_scenarios()
    assert len(records) == len(SCENARIOS)
    for r in records:
        assert r["frame_length"] == len(bytes.fromhex(r["frame_hex"]))
        assert ("expected_fields" in r) == (r["parse_expected"] == PARSE_OK)
        assert ("reject_reason" in r) == (r["parse_expected"] == PARSE_REJECT)


def test_command_ids_unique_and_valid():
    from voltguard.schemas import COMMAND_ID_PATTERN
    ids = [r["command_id"] for r in gt.generate_scenarios()]
    assert len(set(ids)) == len(ids)
    assert all(COMMAND_ID_PATTERN.fullmatch(i) for i in ids)


def test_expected_fields_pass_phase2_validator():
    """Parseable scenarios must be expressible as a valid ParsedCommand (contract consistency)."""
    from voltguard.schemas import ParsedCommand
    for r in gt.generate_scenarios():
        if r["parse_expected"] != PARSE_OK:
            continue
        ParsedCommand.from_dict({"command_id": r["command_id"], "protocol": "Modbus/TCP", **r["expected_fields"]})


def test_generation_is_deterministic():
    assert gt.generate_scenarios() == gt.generate_scenarios()


def test_select_scenarios_by_name_and_unknown_name():
    records = gt.generate_scenarios(["normal_pump_60"])
    assert [r["scenario"] for r in records] == ["normal_pump_60"]
    with pytest.raises(ValueError, match="unknown scenario"):
        gt.generate_scenarios(["no_such_scenario"])


def test_stream_is_reproducible_and_seed_sensitive():
    a, b, c = gt.generate_stream(50, 7), gt.generate_stream(50, 7), gt.generate_stream(50, 8)
    assert a == b
    assert a != c


def test_stream_values_within_percent_range():
    for r in gt.generate_stream(200, 1):
        f = r["expected_fields"]
        assert f["function_code"] == 6 and f["register_address"] in (100, 101)
        assert 0 <= f["register_value"] <= 100


@pytest.mark.parametrize("count", [0, -1, gt.MAX_STREAM_LENGTH + 1, "5", 2.5, True, None])
def test_stream_rejects_bad_count(count):
    with pytest.raises(ValueError, match="count"):
        gt.generate_stream(count, 0)


def test_generation_never_touches_the_network(monkeypatch):
    def refuse(*a, **k):
        raise AssertionError("traffic generator attempted to open a socket")
    monkeypatch.setattr(socket, "socket", refuse)
    monkeypatch.setattr(socket, "create_connection", refuse)
    gt.generate_scenarios()
    gt.generate_stream(10, 0)


def test_cli_writes_file(tmp_path, capsys):
    out = tmp_path / "t.json"
    assert gt.main(["--output", str(out)]) == 0
    doc = json.loads(out.read_text(encoding="utf-8"))
    assert doc["format_version"] == gt.FORMAT_VERSION
    assert len(doc["messages"]) == len(SCENARIOS)


def test_cli_stream_and_bad_count(tmp_path):
    out = tmp_path / "s.json"
    assert gt.main(["--stream", "5", "--seed", "3", "--output", str(out)]) == 0
    assert len(json.loads(out.read_text())["messages"]) == 5
    assert gt.main(["--stream", "0", "--output", str(tmp_path / "x.json")]) == 2
    assert not (tmp_path / "x.json").exists()


def test_committed_fixture_is_in_sync_with_generator():
    """tests/fixtures/mock_traffic.json is consumed by the C++ parser tests (Phase 4); keep it current.
    Regenerate with: python -m traffic_generator.generate_traffic --output tests/fixtures/mock_traffic.json"""
    assert FIXTURE.exists(), "fixture missing; regenerate it"
    doc = json.loads(FIXTURE.read_text(encoding="utf-8"))
    assert doc["messages"] == gt.generate_scenarios()
