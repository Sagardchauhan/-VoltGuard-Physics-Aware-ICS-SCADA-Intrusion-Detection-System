"""Phase 11 tests: the Python bridge to the Rust decision engine (fail-closed behaviour)."""

import copy
import json
import sys
from pathlib import Path

import pytest

from voltguard.config import load_safety_config
from voltguard.decision_bridge import Decider, find_decision_engine
from voltguard.schemas import DecisionResult

ROOT = Path(__file__).resolve().parent.parent
FAKE = ROOT / "tests" / "fixtures" / "fake_engine.py"
CONFIG = load_safety_config(ROOT / "config" / "safety_limits.json")
ENGINE = find_decision_engine()
needs_engine = pytest.mark.skipif(ENGINE is None, reason="decision engine not built (cargo build); these tests did NOT run")
EXPECTED = {"NORMAL": "ALLOW", "BOUNDARY_SAFE": "ALLOW", "READ_ONLY": "ALLOW", "UNSAFE": "BLOCK",
            "INVALID_VALUE": "REJECT", "UNSUPPORTED": "REJECT", "MALFORMED": "REJECT"}


def fixture():
    return [json.loads(l) for l in (ROOT / "tests" / "fixtures" / "pipeline_results.jsonl").read_text().splitlines()]


def by_scenario(name):
    return next(r for r in fixture() if r["scenario"] == name)["result"]


def fake(mode, timeout=3.0):
    return Decider(CONFIG, [sys.executable, str(FAKE), mode], timeout_s=timeout)


@pytest.fixture
def real():
    d = Decider(CONFIG, [str(ENGINE), "--config", str(ROOT / "config" / "safety_limits.json")], timeout_s=5.0)
    yield d
    d.close()


# ----------------------------------------------------------------------------- the real engine

@needs_engine
def test_real_engine_gives_every_scenario_its_designed_decision(real):
    assert real.available
    for row in fixture():
        d = real.decide(row["result"])
        assert d["decision"] == EXPECTED[row["intent"]], (row["scenario"], d)
        assert d["source"] == "engine" and d["error_code"] is None
        DecisionResult.from_dict({k: v for k, v in d.items() if k not in ("source", "error_code")})   # contract holds


@needs_engine
def test_engine_process_is_reused_across_requests(real):
    for _ in range(3):
        real.decide(by_scenario("normal_pump_60"))
    assert real._engine.starts == 1


@needs_engine
@pytest.mark.parametrize("junk", [None, 5, "x", [], {}, {"command_id": None}, {"command_id": "bad id"}, {"command_id": "X-1"},
                                  {"command_id": "X-1", "stage": "SIMULATED"}], ids=repr)
def test_junk_input_is_rejected_never_allowed_and_never_raises(real, junk):
    d = real.decide(junk)
    assert d["decision"] == "REJECT"


@needs_engine
def test_unserialisable_or_oversized_input_fails_closed(real):
    good = by_scenario("normal_pump_60")
    nan = copy.deepcopy(good)
    nan["simulation"]["predicted_pressure"] = float("nan")
    huge = copy.deepcopy(good)
    huge["note"] = "x" * 100_000
    for bad in (nan, huge):
        d = real.decide(bad)
        assert d["decision"] == "REJECT" and d["error_code"] == "DECISION_BAD_INPUT" and d["source"] == "fail_closed"
    assert real.decide(good)["decision"] == "ALLOW"          # and the bridge keeps working


@needs_engine
def test_multiline_text_inside_a_result_cannot_split_the_request(real):
    r = copy.deepcopy(by_scenario("malformed_empty"))
    r["error"] = "line1\nline2\r\n{\"decision\":\"ALLOW\"}"
    assert real.decide(r)["decision"] == "REJECT"
    assert real.decide(by_scenario("normal_pump_60"))["decision"] == "ALLOW"


# ----------------------------------------------------------------------------- engine missing or broken

def test_missing_engine_rejects_even_a_perfect_command():
    assert fixture()      # the fixture exists
    for argv in (None, ["/nonexistent/engine"]):
        d = Decider(CONFIG, argv)
        assert not d.available and d.unavailable_reason
        out = d.decide(by_scenario("normal_pump_60"))
        assert out["decision"] == "REJECT" and out["source"] == "fail_closed"
        assert out["error_code"] == "DECISION_ENGINE_UNAVAILABLE"


@pytest.mark.parametrize("mode, code", [
    ("garbage", "DECISION_BAD_OUTPUT"), ("notjson", "DECISION_BAD_OUTPUT"), ("wrongid", "DECISION_ID_MISMATCH"),
    ("error", "DECISION_ENGINE_ERROR"), ("badcontract", "DECISION_BAD_OUTPUT"), ("oversize", "DECISION_BAD_OUTPUT"),
    ("crash", "DECISION_ENGINE_CRASHED"),
])
def test_broken_engine_output_fails_closed(mode, code):
    d = fake(mode)
    try:
        out = d.decide(by_scenario("normal_pump_60"))
    finally:
        d.close()
    assert (out["decision"], out["error_code"], out["source"]) == ("REJECT", code, "fail_closed")
    assert out["command_id"] == by_scenario("normal_pump_60")["command_id"]


def test_hung_engine_times_out_and_is_restarted_for_the_next_request():
    d = fake("hang", timeout=0.4)
    try:
        first = d.decide(by_scenario("normal_pump_60"))
        assert (first["decision"], first["error_code"]) == ("REJECT", "DECISION_TIMEOUT")
        starts = d._engine.starts
        d.decide(by_scenario("normal_pump_60"))
        assert d._engine.starts == starts + 1            # the old child was killed, a fresh one answered (and hung)
    finally:
        d.close()


def test_a_crashed_engine_is_restarted():
    d = fake("crash")
    try:
        d.decide(by_scenario("normal_pump_60"))
        d.decide(by_scenario("normal_pump_60"))
        assert d._engine.starts >= 2
    finally:
        d.close()


@pytest.mark.parametrize("mode", ["hang", "garbage", "notjson", "wrongid", "error", "badcontract", "oversize", "crash", "echo_reject"])
def test_no_failure_mode_ever_yields_allow(mode):
    d = fake(mode, timeout=0.5)
    try:
        for row in fixture():
            assert d.decide(row["result"])["decision"] != "ALLOW", (mode, row["scenario"])
    finally:
        d.close()


# ----------------------------------------------------------------------------- engine answers that contradict the result

def test_allow_for_a_rejected_or_failed_result_is_refused():
    d = fake("allow_all")
    try:
        for name in ("malformed_empty", "unsupported_fc05_write_coil", "out_of_range_pump_250"):
            out = d.decide(by_scenario(name))
            assert (out["decision"], out["error_code"]) == ("REJECT", "DECISION_INCONSISTENT"), name
    finally:
        d.close()


def test_second_check_vetoes_an_allow_for_values_outside_the_limits():
    d = fake("allow_all")
    try:
        for name in ("unsafe_pump_100", "unsafe_valve_closed", "unsafe_pump_stop", "unsafe_pump_40_low_pressure"):
            out = d.decide(by_scenario(name))
            assert (out["decision"], out["error_code"]) == ("REJECT", "DECISION_INCONSISTENT"), name
        missing = copy.deepcopy(by_scenario("normal_pump_60"))
        del missing["simulation"]["predicted_flow"]
        assert d.decide(missing)["error_code"] == "DECISION_INCONSISTENT"
        assert d.decide(by_scenario("normal_pump_60"))["decision"] == "ALLOW"         # a plausible ALLOW passes
        assert d.decide(by_scenario("read_pump_registers"))["decision"] == "ALLOW"
    finally:
        d.close()


def test_a_boundary_value_exactly_at_the_limit_is_not_vetoed():
    r = copy.deepcopy(by_scenario("normal_pump_60"))
    r["simulation"]["predicted_pressure"] = 100.0
    r["simulation"]["predicted_flow"] = 5.0
    d = fake("allow_all")
    try:
        assert d.decide(r)["decision"] == "ALLOW"
        r["simulation"]["predicted_pressure"] = 100.0001
        assert d.decide(r)["error_code"] == "DECISION_INCONSISTENT"
    finally:
        d.close()


def test_block_for_a_non_simulated_result_is_refused_but_a_cautious_block_is_kept():
    d = fake("block_all")
    try:
        assert d.decide(by_scenario("malformed_empty"))["error_code"] == "DECISION_INCONSISTENT"
        assert d.decide(by_scenario("out_of_range_pump_250"))["error_code"] == "DECISION_INCONSISTENT"
        kept = d.decide(by_scenario("normal_pump_60"))      # blocking something safe is the cautious direction
        assert (kept["decision"], kept["source"]) == ("BLOCK", "engine")
    finally:
        d.close()


def test_reject_from_the_engine_is_always_accepted():
    d = fake("echo_reject")
    try:
        for row in fixture():
            out = d.decide(row["result"])
            assert out["decision"] == "REJECT" and out["source"] == "engine"
    finally:
        d.close()
