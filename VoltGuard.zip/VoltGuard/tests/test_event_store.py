"""Phase 9 tests: persistent event log (SQLite) and its integration with the dashboard worker."""

import json
import math
import sqlite3
import sys

import pytest

import event_logging.event_store as es
from event_logging.event_store import (GENESIS, MAX_FRAME_HEX, MAX_TEXT, SEVERITIES, EventStore, EventStoreError,
                                       UnavailableStore, build_row, classify)
from tests.test_worker import CLI, VALID, Worker, needs_cpp

TS = "2026-10-31T12:00:00.000+00:00"


def sim(status="SUCCESS", violations=(), pressure=55.0, flow=20.0):
    d = {"simulation_status": status, "violations": list(violations), "configured_min_pressure": 20.0,
         "configured_max_pressure": 100.0, "pressure_unit": "kPa"}
    if status == "SUCCESS":
        d.update(predicted_pressure=pressure, predicted_flow=flow, flow_unit="L/s")
    else:
        d["error"] = "x"
    return d


def result(stage="SIMULATED", simulation=None, cid="C-1", **kw):
    parsed = {"function_code": 6, "register_address": 100, "register_value": 60} if stage == "SIMULATED" else None
    r = {"command_id": cid, "stage": stage, "parsed_command": parsed,
         "simulation": simulation if stage == "SIMULATED" else None,
         "error_code": None if stage == "SIMULATED" else "E", "error": None if stage == "SIMULATED" else "bad",
         "timings_ms": {"parse": 1.0, "simulate": 2.0, "total": 3.0}}
    r.update(kw)
    return r


VIOL = [{"type": "PRESSURE_HIGH", "limit": 100.0, "predicted": 145.0}]


@pytest.fixture
def store(tmp_path):
    s = EventStore(tmp_path / "events.db")
    yield s
    s.close()


# ----------------------------------------------------------------------------- classification

@pytest.mark.parametrize("res, expected", [
    (result(simulation=sim()), "WITHIN_LIMITS"),
    (result(simulation=sim(violations=VIOL, pressure=145.0)), "LIMIT_VIOLATION"),
    (result(simulation=sim("INVALID_INPUT")), "REJECTED"),
    (result(simulation=sim("ERROR")), "SIMULATION_FAILURE"),
    (result(simulation=sim("TIMEOUT")), "SIMULATION_FAILURE"),
    (result("PARSE_REJECTED"), "REJECTED"),
    (result("COMPONENT_FAILURE"), "COMPONENT_FAILURE"),
    ({"stage": "SIMULATED", "simulation": None}, "COMPONENT_FAILURE"),   # inconsistent shape fails closed
    ({"stage": "SOMETHING_NEW"}, "COMPONENT_FAILURE"),
    ({}, "COMPONENT_FAILURE"),
], ids=["ok", "violation", "invalid_input", "sim_error", "sim_timeout", "parse_rejected", "component_failure",
        "missing_simulation", "unknown_stage", "empty"])
def test_classify(res, expected):
    assert classify(res) == expected
    assert expected in SEVERITIES


def test_unknown_stage_is_stored_as_component_failure(store):
    assert store.record({"stage": "SOMETHING_NEW", "command_id": "A"}, "t", "00", TS)
    row = store.query()[0]
    assert row["stage"] == "COMPONENT_FAILURE" and row["severity"] == "COMPONENT_FAILURE"


# ----------------------------------------------------------------------------- storage and queries

def test_record_and_query_roundtrip(store):
    assert store.record(result(simulation=sim(violations=VIOL, pressure=145.0), cid="V-1"), "unsafe_pump_100", "00aa", TS)
    row = store.query()[0]
    assert (row["command_id"], row["source"], row["severity"], row["stage"]) == ("V-1", "unsafe_pump_100", "LIMIT_VIOLATION", "SIMULATED")
    assert (row["function_code"], row["register_address"], row["predicted_pressure"]) == (6, 100, 145.0)
    assert json.loads(row["violations"]) == [{"type": "PRESSURE_HIGH", "limit": 100.0, "predicted": 145.0}]
    assert row["frame_hex"] == "00aa" and row["timestamp_utc"] == TS
    assert json.loads(row["timings_json"])["total"] == 3.0
    assert json.loads(row["simulation_json"])["simulation_status"] == "SUCCESS"


def test_parse_rejection_row_has_no_prediction_columns(store):
    store.record(result("PARSE_REJECTED", cid="R-1"), "malformed", "", TS)
    row = store.query()[0]
    assert row["predicted_pressure"] is None and row["sim_status"] is None and row["parsed_json"] is None
    assert row["error_code"] == "E" and row["frame_hex"] == ""


def test_query_is_newest_first_and_filters_work(store):
    for i, res in enumerate([result(simulation=sim(), cid="A"), result(simulation=sim(violations=VIOL), cid="B"),
                             result("PARSE_REJECTED", cid="C"), result(simulation=sim(violations=VIOL), cid="D")]):
        store.record(res, f"s{i}", "00", TS)
    assert [r["command_id"] for r in store.query()] == ["D", "C", "B", "A"]
    assert [r["command_id"] for r in store.query(limit=2)] == ["D", "C"]
    assert [r["command_id"] for r in store.query(severity="LIMIT_VIOLATION")] == ["D", "B"]
    assert [r["command_id"] for r in store.query(command_id="C")] == ["C"]
    assert store.query(command_id="nope") == []
    assert store.count() == 4


@pytest.mark.parametrize("kwargs", [{"limit": 0}, {"limit": -1}, {"limit": True}, {"limit": "5"}, {"severity": "ALLOW"},
                                    {"severity": "x' OR '1'='1"}])
def test_query_rejects_invalid_arguments(store, kwargs):
    with pytest.raises(ValueError):
        store.query(**kwargs)


def test_query_limit_is_clamped(store, monkeypatch):
    fill(store, 5)
    monkeypatch.setattr(es, "MAX_QUERY_LIMIT", 2)
    assert len(store.query(limit=10**9)) == 2


# ----------------------------------------------------------------------------- hostile content

INJECTIONS = ["'; DROP TABLE events; --", "\" OR 1=1 --", "x'); DELETE FROM events; --", "\x00\x1b[31mred\r\n"]


@pytest.mark.parametrize("text", INJECTIONS)
def test_hostile_text_is_stored_as_data_and_never_executed(store, text):
    store.record(result(simulation=sim(), cid="SAFE-1"), "ok", "00", TS)
    assert store.record(result("PARSE_REJECTED", cid=text, error=text), text, "00", TS)
    assert store.count() == 2            # nothing dropped or deleted
    rows = store.query()
    cleaned = "".join(c if c.isprintable() else "?" for c in text)
    assert rows[0]["source"] == cleaned and rows[0]["command_id"] == cleaned[:64]
    assert store.query(command_id=cleaned[:64])   # a hostile filter value is just a value
    assert store.query(command_id="x' OR '1'='1") == []     # and never widens the query
    assert store.verify()[0]


def test_long_and_control_character_fields_are_capped_and_cleaned(store):
    store.record(result("COMPONENT_FAILURE", error="e\x00\n" * 5000, error_code="C" * 500), "s" * 1000, "ab" * 10000, TS)
    row = store.query()[0]
    assert len(row["error"]) == MAX_TEXT and "\x00" not in row["error"] and "\n" not in row["error"]
    assert len(row["error_code"]) == 60 and len(row["source"]) == 120 and len(row["frame_hex"]) == MAX_FRAME_HEX


def test_huge_json_payload_is_replaced_by_a_marker(store):
    big = sim()
    big["note"] = "x" * 100_000
    store.record(result(simulation=big), "s", "00", TS)
    marker = json.loads(store.query()[0]["simulation_json"])
    assert marker["truncated"] is True and marker["original_length"] > 100_000


def test_non_numeric_prediction_is_not_stored_as_a_number(store):
    r = result(simulation=sim())
    r["simulation"]["predicted_pressure"] = "55"
    assert build_row(r, "s", "00", TS)["predicted_pressure"] is None
    r["simulation"]["predicted_pressure"] = True
    assert build_row(r, "s", "00", TS)["predicted_pressure"] is None


# ----------------------------------------------------------------------------- tamper evidence

def fill(store, n=5):
    for i in range(n):
        store.record(result(simulation=sim(), cid=f"K-{i}"), "s", "00", TS)


def raw(store, sql, args=()):
    db = sqlite3.connect(str(store.path))
    db.execute(sql, args)
    db.commit()
    db.close()


def test_empty_and_fresh_logs_verify(store):
    assert store.verify() == (True, "0 row(s) verified")
    fill(store, 3)
    assert store.verify() == (True, "3 row(s) verified")
    assert store.query(limit=10)[-1]["prev_hash"] == GENESIS


@pytest.mark.parametrize("sql, args, bad_row", [
    ("UPDATE events SET severity='WITHIN_LIMITS', error='edited' WHERE id=3", (), 3),
    ("UPDATE events SET frame_hex='ff' WHERE id=2", (), 2),
    ("UPDATE events SET predicted_pressure=1.0 WHERE id=4", (), 4),
    ("UPDATE events SET timestamp_utc='2000-01-01' WHERE id=1", (), 1),
    ("DELETE FROM events WHERE id=3", (), 4),            # removal shows up as a broken chain at the next row
    ("UPDATE events SET row_hash=? WHERE id=5", ("0" * 64,), 5),
], ids=["severity", "frame", "pressure", "timestamp", "deleted_middle", "forged_hash"])
def test_verify_detects_edits_and_deletions(store, sql, args, bad_row):
    fill(store)
    raw(store, sql, args)
    ok, message = store.verify()
    assert not ok and f"row {bad_row}:" in message


@pytest.mark.parametrize("column", es._HASHED)
def test_every_stored_field_is_covered_by_the_hash(store, column):
    fill(store, 3)
    raw(store, f"UPDATE events SET {column}='tampered' WHERE id=2")     # column names come from the module's constant list
    ok, message = store.verify()
    assert not ok and "row 2:" in message


def test_deletion_is_reported_as_a_broken_chain(store):
    fill(store, 4)
    raw(store, "DELETE FROM events WHERE id=2")
    ok, message = store.verify()
    assert not ok and message.startswith("row 3:") and "chain broken" in message


def test_swapping_two_rows_is_detected(store):
    fill(store, 3)
    raw(store, "UPDATE events SET id=99 WHERE id=1")
    raw(store, "UPDATE events SET id=1 WHERE id=2")
    raw(store, "UPDATE events SET id=2 WHERE id=99")
    assert not store.verify()[0]


def test_documented_limit_tail_truncation_is_not_detected(store):
    """Honest limitation: removing the newest rows leaves a valid chain (see docs/event_logging.md)."""
    fill(store, 4)
    raw(store, "DELETE FROM events WHERE id>2")
    assert store.verify()[0]


def test_chain_continues_across_reopen(tmp_path):
    path = tmp_path / "e.db"
    a = EventStore(path)
    fill(a, 2)
    a.close()
    b = EventStore(path)
    fill(b, 2)
    assert b.count() == 4 and b.verify() == (True, "4 row(s) verified")
    b.close()


# ----------------------------------------------------------------------------- failure behaviour

def test_record_never_raises_and_reports_failure_after_close(store):
    store.close()
    assert store.record(result(simulation=sim()), "s", "00", TS) is False
    assert store.last_error


def test_unserialisable_result_is_reported_and_leaves_no_partial_row(store):
    bad = result(simulation=sim())
    bad["simulation"]["predicted_pressure"] = math.inf
    bad["simulation"]["extra"] = math.nan     # not valid JSON: must not be stored half-way
    assert store.record(bad, "s", "00", TS) is False
    assert store.count() == 0 and store.last_error
    assert store.record(result(simulation=sim()), "s", "00", TS) is True   # the store keeps working
    assert store.verify()[0]


def test_unopenable_path_raises_event_store_error(tmp_path):
    blocker = tmp_path / "file"
    blocker.write_text("x")
    with pytest.raises(EventStoreError):
        EventStore(blocker / "events.db")


def test_foreign_or_future_schema_is_refused(tmp_path):
    path = tmp_path / "e.db"
    EventStore(path).close()
    db = sqlite3.connect(str(path))
    db.execute("UPDATE meta SET value='99' WHERE key='schema_version'")
    db.commit()
    db.close()
    with pytest.raises(EventStoreError):
        EventStore(path)


def test_unavailable_store_reports_instead_of_hiding():
    u = UnavailableStore("disk full")
    assert u.record({}, "s", "00", TS) is False
    assert u.verify() == (False, "disk full")
    with pytest.raises(EventStoreError):
        u.query()


# ----------------------------------------------------------------------------- worker integration

def start(tmp_path, *extra):
    w = Worker(tmp_path, *(["--parser-cli", str(CLI)] if CLI else []), *extra)
    ready = w.read()
    assert ready["type"] == "ready", ready
    return w, ready


@needs_cpp
def test_worker_logs_every_command_and_serves_history(tmp_path):
    w, ready = start(tmp_path)
    try:
        assert ready["event_log"]["ok"] is True and ready["event_log"]["path"].endswith("events.db")
        r1 = w.ask({"op": "process", "command_id": "W-1", "frame_hex": VALID, "source": "normal_pump_60"})
        r2 = w.ask({"op": "process", "command_id": "W-2", "frame_hex": "000700000006010600640064", "source": "unsafe_pump_100"})
        r3 = w.ask({"op": "process", "command_id": "W-3", "frame_hex": "0001"})        # malformed, default source
        assert (r1["logged"], r2["logged"], r3["logged"]) == (True, True, True)
        ev = w.ask({"op": "events", "limit": 10})
        assert ev["type"] == "events" and ev["total"] == 3
        assert [(e["command_id"], e["severity"], e["source"]) for e in ev["events"]] == [
            ("W-3", "REJECTED", "manual"), ("W-2", "LIMIT_VIOLATION", "unsafe_pump_100"), ("W-1", "WITHIN_LIMITS", "normal_pump_60")]
        assert "frame_hex" not in ev["events"][0]
        only = w.ask({"op": "events", "severity": "LIMIT_VIOLATION"})
        assert [e["command_id"] for e in only["events"]] == ["W-2"]
        assert w.ask({"op": "verify_log"}) == {"type": "log_verification", "ok": True, "message": "3 row(s) verified"}
    finally:
        w.close()
    db = EventStore(tmp_path / "events.db")           # persisted after the worker exited
    assert db.count() == 3 and db.verify()[0]
    db.close()


@needs_cpp
@pytest.mark.parametrize("request_", [
    {"op": "events", "limit": 0}, {"op": "events", "limit": "10"}, {"op": "events", "limit": True},
    {"op": "events", "severity": "ALLOW"}, {"op": "process", "command_id": "S-1", "frame_hex": VALID, "source": 5},
], ids=["limit0", "limit_str", "limit_bool", "bad_severity", "bad_source"])
def test_worker_rejects_bad_event_requests(tmp_path, request_):
    w, _ = start(tmp_path)
    try:
        reply = w.ask(request_)
        assert reply["type"] == "error" and "internal error" not in reply["error"]     # a clean refusal, not a caught crash
        assert any(word in reply["error"] for word in ("limit", "severity", "source"))
        assert w.ask({"op": "events"})["total"] == 0          # nothing was logged for the refused request
    finally:
        w.close()


def test_worker_with_logging_disabled_says_so(tmp_path):
    w, ready = start(tmp_path, "--no-event-log")
    try:
        assert ready["event_log"]["enabled"] is False and ready["event_log"]["ok"] is False
        assert w.ask({"op": "events"})["type"] == "error"
        assert w.ask({"op": "verify_log"})["type"] == "error"
        if CLI:
            assert w.ask({"op": "process", "command_id": "N-1", "frame_hex": VALID})["logged"] is None
        assert not (tmp_path / "events.db").exists()
    finally:
        w.close()


@needs_cpp
def test_worker_keeps_processing_but_flags_an_unusable_event_log(tmp_path):
    blocker = tmp_path / "file"
    blocker.write_text("x")
    w, ready = start(tmp_path, "--event-db", str(blocker / "events.db"))
    try:
        assert ready["event_log"]["enabled"] is True and ready["event_log"]["ok"] is False and ready["event_log"]["error"]
        r = w.ask({"op": "process", "command_id": "U-1", "frame_hex": VALID})
        assert r["stage"] == "SIMULATED" and r["logged"] is False        # processed, but visibly NOT logged
        assert w.ask({"op": "verify_log"})["ok"] is False
        assert w.ask({"op": "events"})["type"] == "error"
    finally:
        w.close()


# ----------------------------------------------------------------------------- schema v2 (Phase 11): decisions and migration

DECISION = {"command_id": "C-1", "decision": "BLOCK", "reason": "predicted pressure 145 exceeds maximum 100",
            "source": "engine", "error_code": None}

V1_SCHEMA = """
CREATE TABLE meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE events (
    id INTEGER PRIMARY KEY AUTOINCREMENT, timestamp_utc TEXT NOT NULL, command_id TEXT, source TEXT NOT NULL,
    stage TEXT NOT NULL, severity TEXT NOT NULL, sim_status TEXT, function_code INTEGER, register_address INTEGER,
    predicted_pressure REAL, predicted_flow REAL, violations TEXT NOT NULL, error_code TEXT, error TEXT,
    frame_hex TEXT NOT NULL, parsed_json TEXT, simulation_json TEXT, timings_json TEXT NOT NULL,
    prev_hash TEXT NOT NULL, row_hash TEXT NOT NULL);
"""


def make_v1_database(path, rows=3):
    """A database exactly as Phase 9 wrote it (v1 schema, v1 hash), built independently of the current code."""
    import hashlib
    fields = es._HASHED_V1
    db = sqlite3.connect(str(path))
    db.executescript(V1_SCHEMA)
    db.execute("INSERT INTO meta VALUES('schema_version','1')")
    prev = GENESIS
    for i in range(rows):
        row = es.build_row(result(simulation=sim(), cid=f"OLD-{i}"), "old", "00", TS)
        digest = hashlib.sha256((prev + json.dumps([row[k] for k in fields], separators=(",", ":"), allow_nan=False)).encode()).hexdigest()
        db.execute(f"INSERT INTO events ({', '.join(fields)}, prev_hash, row_hash) VALUES ({', '.join('?' * len(fields))}, ?, ?)",
                   [row[k] for k in fields] + [prev, digest])
        prev = digest
    db.commit()
    db.close()


def test_decision_is_stored_and_covered_by_the_hash(store):
    assert store.record(result(simulation=sim(violations=VIOL, pressure=145.0)), "s", "00", TS, DECISION)
    row = store.query()[0]
    assert (row["decision"], row["decision_source"], row["decision_reason"]) == ("BLOCK", "engine", DECISION["reason"])
    assert row["hash_version"] == 2
    raw(store, "UPDATE events SET decision='ALLOW' WHERE id=1")        # flipping BLOCK to ALLOW must be noticed
    ok, message = store.verify()
    assert not ok and "row 1:" in message


def test_rows_without_a_decision_store_nulls_and_invalid_values_are_dropped(store):
    store.record(result(simulation=sim()), "s", "00", TS)
    store.record(result(simulation=sim()), "s", "00", TS, {"decision": "MAYBE", "source": "nobody", "reason": "x"})
    for row in store.query():
        assert row["decision"] is None and row["decision_source"] is None


def test_a_v1_database_is_migrated_and_still_verifies(tmp_path):
    path = tmp_path / "old.db"
    make_v1_database(path, 3)
    s = EventStore(path)
    try:
        assert s.count() == 3 and s.verify() == (True, "3 row(s) verified")
        assert all(r["hash_version"] == 1 and r["decision"] is None for r in s.query(limit=10))
        assert s.record(result(simulation=sim(), cid="NEW-1"), "new", "00", TS, DECISION)
        assert s.verify() == (True, "4 row(s) verified")
        versions = {r["command_id"]: r["hash_version"] for r in s.query(limit=10)}
        assert versions == {"OLD-0": 1, "OLD-1": 1, "OLD-2": 1, "NEW-1": 2}
    finally:
        s.close()
    db = sqlite3.connect(str(path))
    assert db.execute("SELECT value FROM meta WHERE key='schema_version'").fetchone()[0] == "2"
    db.close()
    again = EventStore(path)                       # reopening a migrated database works and keeps the chain
    assert again.verify()[0]
    again.close()


@pytest.mark.parametrize("sql, bad_row", [
    ("UPDATE events SET error='edited' WHERE id=2", 2),                      # old content is still protected
    ("UPDATE events SET decision='ALLOW' WHERE id=2", 2),                    # a decision cannot be attached to an old row
    ("UPDATE events SET decision_source='engine' WHERE id=1", 1),
    ("UPDATE events SET hash_version=2 WHERE id=1", 1),                      # relabelling a row to dodge its hash
    ("UPDATE events SET hash_version=7 WHERE id=3", 3),
])
def test_migrated_rows_cannot_be_altered_or_given_decisions(tmp_path, sql, bad_row):
    path = tmp_path / "old.db"
    make_v1_database(path, 3)
    s = EventStore(path)
    raw(s, sql)
    ok, message = s.verify()
    s.close()
    assert not ok and f"row {bad_row}:" in message


def test_downgrading_a_new_row_to_hash_version_1_is_detected(store):
    store.record(result(simulation=sim()), "s", "00", TS, DECISION)
    raw(store, "UPDATE events SET hash_version=1 WHERE id=1")
    assert not store.verify()[0]
