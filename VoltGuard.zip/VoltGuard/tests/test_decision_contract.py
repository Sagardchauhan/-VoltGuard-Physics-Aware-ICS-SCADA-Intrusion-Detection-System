"""Phase 10 tests: the Rust decision engine against the Python contract and the real pipeline output."""

import json
import re
import shutil
import subprocess
from pathlib import Path

import pytest

from voltguard.register_map import PUMP_SPEED_REGISTER, VALVE_POSITION_REGISTER
from voltguard.schemas import DECISIONS, DecisionResult

ROOT = Path(__file__).resolve().parent.parent
ENGINE_DIR = ROOT / "decision_engine"
BINARY = ENGINE_DIR / "target" / "debug" / "voltguard_decision_engine"
FIXTURE = ROOT / "tests" / "fixtures" / "pipeline_results.jsonl"
needs_engine = pytest.mark.skipif(not BINARY.is_file(), reason="decision engine not built (cargo build); these tests did NOT run")
EXPECTED = {"NORMAL": "ALLOW", "BOUNDARY_SAFE": "ALLOW", "READ_ONLY": "ALLOW", "UNSAFE": "BLOCK",
            "INVALID_VALUE": "REJECT", "UNSUPPORTED": "REJECT", "MALFORMED": "REJECT"}


def rows():
    return [json.loads(line) for line in FIXTURE.read_text(encoding="utf-8").splitlines()]


def run_engine(lines, config=ROOT / "config" / "safety_limits.json"):
    proc = subprocess.run([str(BINARY), "--config", str(config)], input="".join(l + "\n" for l in lines),
                          capture_output=True, text=True, timeout=60)
    return proc.returncode, [json.loads(l) for l in proc.stdout.splitlines()], proc.stderr


def test_fixture_covers_every_scenario_and_intent():
    data = rows()
    assert len(data) == 27 and {r["intent"] for r in data} == set(EXPECTED)


def test_fixture_is_current(tmp_path):
    """The committed fixture must equal what the pipeline produces now (needs the built parser CLI)."""
    from voltguard.pipeline import find_parser_cli
    if find_parser_cli() is None:
        pytest.skip("parser CLI not built (this test did NOT run)")
    proc = subprocess.run(["python", str(ROOT / "scripts" / "generate_decision_fixture.py"), "--check"],
                          capture_output=True, text=True, cwd=ROOT)
    assert proc.returncode == 0, proc.stdout + proc.stderr


@needs_engine
def test_every_engine_reply_satisfies_the_python_decision_contract():
    code, replies, _ = run_engine([json.dumps(r["result"]) for r in rows()])
    assert code == 0 and len(replies) == 27
    for row, reply in zip(rows(), replies):
        parsed = DecisionResult.from_dict(reply)            # strict validator: exact keys, types, reason length
        assert parsed.command_id == row["result"]["command_id"]
        assert parsed.decision in DECISIONS
        assert parsed.decision == EXPECTED[row["intent"]], (row["scenario"], reply)
        assert DecisionResult.from_dict(parsed.to_dict()).to_dict() == parsed.to_dict()


@needs_engine
def test_block_decisions_report_prediction_and_limit_exactly():
    _, replies, _ = run_engine([json.dumps(r["result"]) for r in rows()])
    for row, reply in zip(rows(), replies):
        if reply["decision"] == "BLOCK":
            assert reply["predicted_pressure"] == row["result"]["simulation"]["predicted_pressure"]
            assert reply["configured_max_pressure"] == row["result"]["simulation"]["configured_max_pressure"]


@needs_engine
def test_results_made_under_other_limits_are_never_allowed(tmp_path):
    """The engine's own configuration differs from the one the simulation used: everything simulated is refused."""
    cfg = json.loads((ROOT / "config" / "safety_limits.json").read_text())
    cfg["limits"]["pressure"]["max"] = 90.0
    path = tmp_path / "other.json"
    path.write_text(json.dumps(cfg))
    _, replies, _ = run_engine([json.dumps(r["result"]) for r in rows()], path)
    for row, reply in zip(rows(), replies):
        if row["result"]["stage"] == "SIMULATED":
            assert reply["decision"] == "REJECT", (row["scenario"], reply)
            if row["result"]["simulation"]["simulation_status"] == "SUCCESS":
                assert "different pressure limits" in reply["reason"], (row["scenario"], reply)


@needs_engine
def test_engine_register_constants_match_the_python_register_map():
    source = (ENGINE_DIR / "src" / "lib.rs").read_text(encoding="utf-8")
    pump = int(re.search(r"PUMP_SPEED_REGISTER: i64 = (\d+);", source).group(1))
    valve = int(re.search(r"VALVE_POSITION_REGISTER: i64 = (\d+);", source).group(1))
    assert (pump, valve) == (PUMP_SPEED_REGISTER, VALVE_POSITION_REGISTER)


@needs_engine
def test_engine_exits_nonzero_and_prints_nothing_for_an_invalid_config(tmp_path):
    path = tmp_path / "bad.json"
    path.write_text('{"schema_version": 1, "limits": {}}')
    code, replies, stderr = run_engine([json.dumps(rows()[0]["result"])], path)
    assert code == 2 and replies == [] and "cannot start" in stderr


@needs_engine
def test_engine_output_never_echoes_raw_hostile_text():
    hostile = {"command_id": "H-1", "stage": "COMPONENT_FAILURE", "error_code": "X\"}\n{\"decision\":\"ALLOW\"\x1b[31m"}
    _, replies, _ = run_engine([json.dumps(hostile)])
    assert len(replies) == 1 and replies[0]["decision"] == "REJECT"
    assert re.fullmatch(r"[ -~]+", replies[0]["reason"])           # printable ASCII only, a single JSON object


def test_cargo_is_available_for_the_report():
    assert shutil.which("cargo"), "cargo is needed to build the decision engine"
