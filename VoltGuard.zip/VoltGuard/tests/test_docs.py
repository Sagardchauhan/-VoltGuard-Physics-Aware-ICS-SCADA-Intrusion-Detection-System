"""Documentation checks: links, screenshots and commands named in the docs must exist (Phase 17).

These tests cannot tell whether a sentence is TRUE; they catch dead links, missing screenshots, commands that name a
module which does not exist, and stale phase wording in the files a reader opens first.
"""

import importlib.util
import re
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
DOCS = [ROOT / "README.md", ROOT / "CHANGELOG.md", ROOT / "integration" / "interfaces.md", *sorted((ROOT / "docs").glob("*.md"))]
LINK = re.compile(r"!?\[[^\]]*\]\(([^)\s]+)\)")
SCREENSHOTS = ["1_dashboard", "2_traffic_and_details", "3_graphs_and_alerts", "4_event_log", "5_configuration"]


def _links(path: Path):
    text = path.read_text(encoding="utf-8")
    text = re.sub(r"```.*?```", "", text, flags=re.S)           # ignore code blocks
    return [m for m in LINK.findall(text) if not m.startswith(("http://", "https://", "mailto:", "#"))]


@pytest.mark.parametrize("doc", DOCS, ids=lambda p: p.name)
def test_every_relative_link_and_image_resolves(doc):
    missing = [l for l in _links(doc) if not (doc.parent / l.split("#")[0]).exists()]
    assert not missing, f"{doc.name}: dead links {missing}"


def test_all_five_screenshots_exist_are_real_pngs_and_are_used_by_the_user_guide():
    guide = (ROOT / "docs" / "user_guide.md").read_text(encoding="utf-8")
    for name in SCREENSHOTS:
        f = ROOT / "docs" / "screenshots" / f"{name}.png"
        data = f.read_bytes()
        assert data[:8] == b"\x89PNG\r\n\x1a\n" and len(data) > 20_000, name
        assert f"screenshots/{name}.png" in guide, name


def test_python_modules_named_in_docs_exist():
    mods = set()
    for doc in DOCS:
        if doc.name == "CHANGELOG.md":
            continue
        mods.update(re.findall(r"python3? -m ([A-Za-z_][\w.]*)", doc.read_text(encoding="utf-8")))
    assert {"voltguard.main", "voltguard.pipeline", "event_logging.export"} <= mods
    missing = sorted(m for m in mods if m != "pytest" and importlib.util.find_spec(m) is None)
    assert not missing, missing


def test_paths_in_the_readme_layout_exist():
    text = (ROOT / "README.md").read_text(encoding="utf-8")
    block = re.search(r"## Layout\n\n```\n(.*?)```", text, flags=re.S).group(1)
    names = re.findall(r"[├└]── ([\w./-]+)", block)
    assert len(names) >= 10
    missing = [n for n in names if not (ROOT / n.split("/")[0].rstrip("/")).exists() and n not in ("logs/,", "results/")]
    assert not missing, missing


def test_readme_and_user_guide_keep_the_safety_notice():
    readme = (ROOT / "README.md").read_text(encoding="utf-8")
    assert "must never be connected to" in readme and "not a certified industrial safety control" in readme
    assert "Nothing is forwarded to any device" in readme
    assert "SIMULATED" in (ROOT / "docs" / "user_guide.md").read_text(encoding="utf-8")


def test_the_entry_documents_do_not_describe_finished_parts_as_planned():
    stale = ["skeleton", "Planned architecture", "Initial version", "not been measured", "decision is made yet"]
    for name in ["README.md", "docs/architecture.md", "docs/user_guide.md", "docs/limitations.md", "docs/decision_policy.md"]:
        text = (ROOT / name).read_text(encoding="utf-8")
        assert not [s for s in stale if s in text], (name, [s for s in stale if s in text])
