"""Phase 14 tests: the benchmark script's arithmetic and structure. They do NOT assert any speed, because a
timing threshold would make the suite depend on how busy the machine is; speed is reported by the script."""

import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
import benchmark  # noqa: E402

from voltguard.decision_bridge import find_decision_engine  # noqa: E402
from voltguard.pipeline import find_parser_cli  # noqa: E402

needs_built = pytest.mark.skipif(find_parser_cli() is None or find_decision_engine() is None,
                                 reason="parser CLI or decision engine not built (this test did NOT run)")


def test_percentiles_use_the_nearest_rank_method():
    data = [float(i) for i in range(1, 101)]          # 1..100
    assert benchmark.percentile(data, 50) == 50.0
    assert benchmark.percentile(data, 95) == 95.0
    assert benchmark.percentile(data, 99) == 99.0
    assert benchmark.percentile(data, 100) == 100.0
    assert benchmark.percentile([7.0], 99) == 7.0
    assert benchmark.percentile([1.0, 2.0, 3.0, 4.0], 50) == 2.0       # ceil(0.5 * 4) = 2nd value
    assert benchmark.percentile([1.0, 2.0, 3.0, 4.0, 5.0], 99) == 5.0  # ceil(0.99 * 5) = 5th value
    assert benchmark.percentile([float(i) for i in range(1, 21)], 95) == 19.0   # no float rounding error at 95 % of 20


@pytest.mark.parametrize("bad", [0, -5, 101, 99.5])
def test_percentile_rejects_nonsense(bad):
    with pytest.raises(ValueError):
        benchmark.percentile([1.0, 2.0], bad)
    with pytest.raises(ValueError):
        benchmark.percentile([], 50)


def test_summary_statistics_are_consistent():
    s = benchmark.summarise([5.0, 1.0, 3.0, 2.0, 4.0])
    assert (s["n"], s["min"], s["max"], s["mean"], s["p50"]) == (5, 1.0, 5.0, 3.0, 3.0)
    assert s["min"] <= s["p50"] <= s["p95"] <= s["p99"] <= s["max"]


@needs_built
@pytest.mark.parametrize("target, expect_pass", [(1e9, True), (1e-6, False)])
def test_a_short_run_produces_complete_results_and_an_honest_verdict(tmp_path, capsys, target, expect_pass):
    out = tmp_path / "res.json"
    assert benchmark.main(["--iterations", "20", "--worker-iterations", "20", "--warmup", "2", "--target-ms", str(target),
                           "--out", str(out)]) == 0
    res = json.loads(out.read_text())
    assert len(res["in_process"]) == 4 and res["worker"]["round_trip_ms"]["n"] == 20
    for wl in res["in_process"]:
        stages = wl["stages_ms"]
        assert wl["iterations"] == 20 and stages["handle"]["n"] == 20
        for name in ("parse", "decide", "log"):
            assert stages[name]["n"] == 20
            assert stages[name]["mean"] <= stages["handle"]["mean"] + 1e-9     # a part cannot take longer than the whole
        for s in stages.values():
            assert 0.0 <= s["min"] <= s["p50"] <= s["p99"] <= s["max"]
    assert [v["pass"] for v in res["verdicts"]] == [expect_pass] * 4
    text = capsys.readouterr().out
    assert ("PASS" in text) == expect_pass and ("FAIL" in text) != expect_pass


def test_too_few_iterations_are_refused():
    with pytest.raises(SystemExit):
        benchmark.main(["--iterations", "5"])
