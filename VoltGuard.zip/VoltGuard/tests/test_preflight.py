"""Tests for scripts/preflight.py, the pre-demo readiness check (Phase 18).

A readiness check that always says READY is worse than none, so most of these tests make a component misbehave and
require the check to say NOT READY.
"""

import importlib.util
import os
import stat
import sys
from pathlib import Path

import pytest

from voltguard.decision_bridge import find_decision_engine
from voltguard.pipeline import find_parser_cli

ROOT = Path(__file__).resolve().parent.parent
FIXTURES = Path(__file__).resolve().parent / "fixtures"
needs_real = pytest.mark.skipif(find_parser_cli() is None or find_decision_engine() is None,
                                reason="needs the built parser CLI and decision engine")
needs_posix = pytest.mark.skipif(sys.platform == "win32", reason="uses a shell wrapper for the fake engine")


@pytest.fixture()
def preflight():
    spec = importlib.util.spec_from_file_location("preflight_under_test", ROOT / "scripts" / "preflight.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def run(preflight, capsys, *args):
    code = preflight.main(list(args))
    return code, capsys.readouterr().out


def fake_engine(tmp_path, mode):
    wrapper = tmp_path / f"engine_{mode}.sh"
    wrapper.write_text(f'#!/bin/sh\nexec "{sys.executable}" "{FIXTURES / "fake_engine.py"}" {mode} "$@"\n')
    wrapper.chmod(wrapper.stat().st_mode | stat.S_IXUSR)
    return wrapper


@needs_real
def test_a_working_installation_is_ready_and_the_real_event_log_is_untouched(preflight, capsys):
    db = ROOT / "logs" / "events.db"
    before = (db.stat().st_size, db.stat().st_mtime_ns) if db.exists() else None
    code, out = run(preflight, capsys, "--no-dashboard")
    assert code == 0, out
    for needle in ("safe write: ALLOW", "unsafe write: BLOCK", "malformed frame: REJECT", "3 events stored, hash chain verifies", "READY: 0 failure(s)"):
        assert needle in out, (needle, out)
    assert "FAIL" not in out
    after = (db.stat().st_size, db.stat().st_mtime_ns) if db.exists() else None
    assert before == after


@needs_real
@needs_posix
@pytest.mark.parametrize("mode", ["allow_all", "block_all", "crash", "hang", "garbage"])
def test_a_misbehaving_decision_engine_makes_the_check_fail(preflight, capsys, monkeypatch, tmp_path, mode):
    """allow_all would release the unsafe write if nothing vetoed it; the others break the decisions or the protocol."""
    monkeypatch.setattr("voltguard.decision_bridge.find_decision_engine", lambda: fake_engine(tmp_path, mode))
    code, out = run(preflight, capsys, "--no-dashboard")
    assert code == 1, out
    assert "NOT READY" in out and "FAIL" in out
    assert "unsafe write: ALLOW" not in out


@needs_real
def test_a_missing_parser_fails_and_skips_the_end_to_end_run(preflight, capsys, monkeypatch):
    monkeypatch.setattr("voltguard.pipeline.find_parser_cli", lambda: None)
    code, out = run(preflight, capsys, "--no-dashboard")
    assert code == 1
    assert "FAIL  C++ parser not built" in out and "FAIL  end-to-end check skipped" in out
    assert "NOT READY: 2 failure(s)" in out


@needs_real
def test_a_missing_decision_engine_fails_and_says_why(preflight, capsys, monkeypatch):
    monkeypatch.setattr("voltguard.decision_bridge.find_decision_engine", lambda: None)
    code, out = run(preflight, capsys, "--no-dashboard")
    assert code == 1
    assert "FAIL  Rust decision engine not built" in out and "REJECTED" in out and "FAIL  end-to-end check skipped" in out
    assert "NOT READY: 2 failure(s)" in out


@needs_real
def test_a_missing_dashboard_fails_unless_explicitly_allowed(preflight, capsys, monkeypatch):
    monkeypatch.setattr(preflight, "find_dashboard", lambda: None)
    code, out = run(preflight, capsys)
    assert code == 1 and "dashboard not built" in out and "FAIL  dashboard" in out
    code, out = run(preflight, capsys, "--no-dashboard")
    assert code == 0 and "WARN  dashboard not built" in out


def test_a_missing_python_package_is_reported(preflight, capsys, monkeypatch):
    real = importlib.util.find_spec
    monkeypatch.setattr(importlib.util, "find_spec", lambda name, *a, **k: None if name == "scipy" else real(name, *a, **k))
    report = preflight.Report()
    preflight.check_python_packages(report)
    out = capsys.readouterr().out
    assert report.failures == 1 and "scipy" in out and "FAIL" in out


@pytest.mark.parametrize("reply,passes", [
    ({"decision": {"decision": "ALLOW", "source": "engine"}, "logged": True}, True),
    ({"decision": {"decision": "ALLOW", "source": "engine"}, "logged": False}, False),
    ({"decision": {"decision": "ALLOW", "source": "engine"}}, False),
    ({"decision": {"decision": "ALLOW", "source": "engine"}, "logged": "yes"}, False),
    ({"decision": {"decision": "REJECT", "source": "fail_closed"}, "logged": True}, False),
    ({"decision": "ALLOW", "logged": True}, False),
    ({"logged": True}, False),
    ({}, False),
])
def test_a_reply_passes_only_with_the_wanted_decision_and_a_confirmed_log_write(preflight, reply, passes):
    ok, text = preflight.judge_reply("x", "ALLOW", reply)
    assert ok is passes, text


@pytest.mark.parametrize("verified,count,passes", [(True, 3, True), (False, 3, False), (True, 2, False), (True, 4, False), (None, 3, False), (1, 3, False)])
def test_the_stored_log_passes_only_when_verified_and_complete(preflight, verified, count, passes):
    assert preflight.judge_log(verified, count, 3)[0] is passes


@needs_real
def test_a_worker_that_cannot_be_started_is_reported_not_raised(preflight, capsys, monkeypatch):
    def refuse(*a, **k):
        raise OSError("cannot start")
    monkeypatch.setattr(preflight.subprocess, "Popen", refuse)
    code, out = run(preflight, capsys, "--no-dashboard")
    assert code == 1
    assert "FAIL  end-to-end run failed: OSError" in out and "NOT READY" in out


@needs_real
@pytest.mark.skipif(sys.platform == "win32", reason="headless run uses the Qt offscreen platform on Linux")
def test_the_dashboard_event_db_option_gives_a_fresh_log_and_leaves_the_default_one_alone(tmp_path):
    """scripts/demo.sh relies on `--event-db`: a headless run of all 27 scenarios must land in exactly that file."""
    import sqlite3
    import subprocess
    exe = ROOT / "build" / "dashboard" / "voltguard_dashboard"
    if not exe.is_file():
        pytest.skip("dashboard not built")
    default_db = ROOT / "logs" / "events.db"
    before = (default_db.stat().st_size, default_db.stat().st_mtime_ns) if default_db.exists() else None
    db = tmp_path / "fresh.db"
    env = {**os.environ, "QT_QPA_PLATFORM": "offscreen"}
    proc = subprocess.run([str(exe), "--screenshot-dir", str(tmp_path / "shots"), "--event-db", str(db)], cwd=ROOT, env=env,
                          capture_output=True, text=True, timeout=120)
    assert proc.returncode == 0, proc.stderr[-500:]
    assert len(list((tmp_path / "shots").glob("*.png"))) == 5
    con = sqlite3.connect(db)
    try:
        assert con.execute("select count(*) from events").fetchone()[0] == 27
    finally:
        con.close()
    after = (default_db.stat().st_size, default_db.stat().st_mtime_ns) if default_db.exists() else None
    assert before == after
