"""Phase 1 tests: application entry point."""

import json
import logging
from pathlib import Path

import pytest

from voltguard.main import DEFAULT_CONFIG, main

LOGGER_NAME = "voltguard"


@pytest.fixture(autouse=True)
def _release_log_handlers():
    yield
    logger = logging.getLogger(LOGGER_NAME)
    for handler in list(logger.handlers):
        logger.removeHandler(handler)
        handler.close()


def test_main_succeeds_with_shipped_config(tmp_path):
    assert main(["--config", str(DEFAULT_CONFIG), "--log-dir", str(tmp_path)]) == 0
    log_text = (tmp_path / "voltguard.log").read_text(encoding="utf-8")
    assert "Configuration loaded" in log_text
    assert "fail closed" in log_text  # the decision engine status must say what happens without it
    assert "C++ packet parser" in log_text


def test_main_fails_closed_on_missing_config(tmp_path):
    assert main(["--config", str(tmp_path / "missing.json"), "--log-dir", str(tmp_path)]) == 2
    log_text = (tmp_path / "voltguard.log").read_text(encoding="utf-8")
    assert "refusing to start" in log_text


def test_main_fails_closed_on_invalid_config(tmp_path):
    bad = tmp_path / "bad.json"
    bad.write_text(json.dumps({"schema_version": 1}), encoding="utf-8")
    assert main(["--config", str(bad), "--log-dir", str(tmp_path)]) == 2


def test_version_flag_exits_zero(capsys):
    with pytest.raises(SystemExit) as exc:
        main(["--version"])
    assert exc.value.code == 0
    assert "VoltGuard" in capsys.readouterr().out
