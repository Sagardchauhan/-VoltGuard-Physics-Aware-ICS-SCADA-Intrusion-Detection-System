"""Phase 2 tests: message contracts and their validators."""

import copy
import json
from pathlib import Path

import pytest

from voltguard import schemas
from voltguard.schemas import (DecisionResult, ParsedCommand, SchemaError, SimulationResult, Violation)

SCHEMA_FILE = Path(__file__).resolve().parent.parent / "integration" / "message_schema.json"


def cmd6(**over):
    d = {"command_id": "TEST-001", "protocol": "Modbus/TCP", "transaction_id": 1, "unit_id": 1,
         "function_code": 6, "register_address": 100, "register_value": 60}
    d.update(over)
    return d


def cmd3(**over):
    d = {"command_id": "TEST-003", "protocol": "Modbus/TCP", "transaction_id": 3, "unit_id": 1,
         "function_code": 3, "register_address": 0, "quantity": 2}
    d.update(over)
    return d


def cmd16(**over):
    d = {"command_id": "TEST-016", "protocol": "Modbus/TCP", "transaction_id": 4, "unit_id": 1,
         "function_code": 16, "register_address": 10, "quantity": 2, "register_values": [5, 6]}
    d.update(over)
    return d


def sim_ok(**over):
    d = {"command_id": "TEST-001", "simulation_status": "SUCCESS", "pressure_unit": "kPa",
         "configured_min_pressure": 20.0, "configured_max_pressure": 100.0, "violations": [],
         "predicted_pressure": 75.0, "predicted_flow": 30.0, "flow_unit": "L/s"}
    d.update(over)
    return d


def sim_fail(**over):
    d = {"command_id": "TEST-001", "simulation_status": "ERROR", "pressure_unit": "kPa",
         "configured_min_pressure": 20.0, "configured_max_pressure": 100.0, "violations": [],
         "error": "solver failed"}
    d.update(over)
    return d


# ------------------------------------------------------------------ ParsedCommand

@pytest.mark.parametrize("make", [cmd3, cmd6, cmd16])
def test_valid_commands_round_trip(make):
    data = make()
    assert ParsedCommand.from_dict(data).to_dict() == data


def test_fc6_fields():
    c = ParsedCommand.from_dict(cmd6())
    assert (c.function_code, c.register_address, c.register_value, c.quantity) == (6, 100, 60, None)


def test_fc16_values_become_tuple():
    assert ParsedCommand.from_dict(cmd16()).register_values == (5, 6)


@pytest.mark.parametrize("bad", [[], "x", 5, None])
def test_command_must_be_object(bad):
    with pytest.raises(SchemaError):
        ParsedCommand.from_dict(bad)


@pytest.mark.parametrize("fc", [0, 1, 2, 4, 5, 15, 17, 43, 255])
def test_unsupported_function_code(fc):
    with pytest.raises(SchemaError, match="unsupported function_code"):
        ParsedCommand.from_dict(cmd6(function_code=fc))


@pytest.mark.parametrize("fc", [-1, 256, "6", 6.0, True, None])
def test_invalid_function_code_type_or_range(fc):
    with pytest.raises(SchemaError):
        ParsedCommand.from_dict(cmd6(function_code=fc))


def test_missing_function_code():
    d = cmd6()
    del d["function_code"]
    with pytest.raises(SchemaError, match="function_code"):
        ParsedCommand.from_dict(d)


@pytest.mark.parametrize("field", ["command_id", "protocol", "transaction_id", "unit_id",
                                   "register_address", "register_value"])
def test_missing_required_field(field):
    d = cmd6()
    del d[field]
    with pytest.raises(SchemaError, match=field):
        ParsedCommand.from_dict(d)


def test_unknown_field_rejected():
    with pytest.raises(SchemaError, match="unknown"):
        ParsedCommand.from_dict(cmd6(extra=1))


def test_field_for_other_function_code_rejected():
    with pytest.raises(SchemaError, match="unknown"):
        ParsedCommand.from_dict(cmd6(quantity=1))
    with pytest.raises(SchemaError, match="unknown"):
        ParsedCommand.from_dict(cmd3(register_value=1))


@pytest.mark.parametrize("cid", ["", "a b", "x" * 65, "a;rm -rf /", "../etc", "id\n", 5, None])
def test_bad_command_id(cid):
    with pytest.raises(SchemaError, match="command_id"):
        ParsedCommand.from_dict(cmd6(command_id=cid))


def test_command_id_boundary_length():
    ParsedCommand.from_dict(cmd6(command_id="x" * 64))


def test_wrong_protocol():
    with pytest.raises(SchemaError, match="protocol"):
        ParsedCommand.from_dict(cmd6(protocol="DNP3"))


@pytest.mark.parametrize("field,value", [
    ("transaction_id", -1), ("transaction_id", 65536), ("unit_id", 256), ("unit_id", -1),
    ("register_address", 65536), ("register_address", -1), ("register_value", 65536),
    ("register_value", -1), ("register_value", 1.5), ("register_value", "60"),
    ("register_value", True), ("register_value", None)])
def test_out_of_range_or_wrong_type(field, value):
    with pytest.raises(SchemaError):
        ParsedCommand.from_dict(cmd6(**{field: value}))


def test_boundary_values_accepted():
    ParsedCommand.from_dict(cmd6(transaction_id=0, unit_id=0, register_address=0, register_value=0))
    ParsedCommand.from_dict(cmd6(transaction_id=65535, unit_id=255, register_address=65535,
                                 register_value=65535))


@pytest.mark.parametrize("qty,ok", [(0, False), (1, True), (125, True), (126, False)])
def test_fc3_quantity_limits(qty, ok):
    if ok:
        ParsedCommand.from_dict(cmd3(quantity=qty))
    else:
        with pytest.raises(SchemaError):
            ParsedCommand.from_dict(cmd3(quantity=qty))


@pytest.mark.parametrize("qty,ok", [(1, True), (123, True), (124, False)])
def test_fc16_quantity_limits(qty, ok):
    d = cmd16(quantity=qty, register_values=[1] * qty)
    if ok:
        ParsedCommand.from_dict(d)
    else:
        with pytest.raises(SchemaError):
            ParsedCommand.from_dict(d)


def test_fc16_length_mismatch():
    with pytest.raises(SchemaError, match="length equals quantity"):
        ParsedCommand.from_dict(cmd16(quantity=3))


@pytest.mark.parametrize("values", ["ab", (1, 2), None, [1, "x"], [1, 70000], [1, True]])
def test_fc16_bad_values(values):
    with pytest.raises(SchemaError):
        ParsedCommand.from_dict(cmd16(register_values=values))


def test_register_range_overflow():
    with pytest.raises(SchemaError, match="address space"):
        ParsedCommand.from_dict(cmd3(register_address=65535, quantity=2))
    ParsedCommand.from_dict(cmd3(register_address=65535, quantity=1))


def test_command_parse_does_not_mutate_input():
    d = cmd16()
    snapshot = copy.deepcopy(d)
    ParsedCommand.from_dict(d)
    assert d == snapshot


# ------------------------------------------------------------------ SimulationResult

def test_valid_success_result_round_trip():
    d = sim_ok()
    assert SimulationResult.from_dict(d).to_dict() == d


def test_valid_failure_result_round_trip():
    d = sim_fail()
    assert SimulationResult.from_dict(d).to_dict() == d


@pytest.mark.parametrize("status", ["INVALID_INPUT", "ERROR", "TIMEOUT"])
def test_all_failure_statuses_accepted(status):
    SimulationResult.from_dict(sim_fail(simulation_status=status))


def test_result_with_violations_round_trip():
    d = sim_ok(predicted_pressure=120.0,
               violations=[{"type": "PRESSURE_HIGH", "limit": 100.0, "predicted": 120.0}])
    result = SimulationResult.from_dict(d)
    assert result.violations == (Violation("PRESSURE_HIGH", 100.0, 120.0),)
    assert result.to_dict() == d


def test_unknown_status():
    with pytest.raises(SchemaError, match="simulation_status"):
        SimulationResult.from_dict(sim_ok(simulation_status="OK"))


@pytest.mark.parametrize("field", ["predicted_pressure", "predicted_flow", "flow_unit"])
def test_success_requires_predictions(field):
    d = sim_ok()
    del d[field]
    with pytest.raises(SchemaError, match="SUCCESS requires"):
        SimulationResult.from_dict(d)


def test_success_with_null_prediction_rejected():
    with pytest.raises(SchemaError, match="SUCCESS requires"):
        SimulationResult.from_dict(sim_ok(predicted_pressure=None))


def test_success_must_not_carry_error():
    with pytest.raises(SchemaError, match="must not carry an error"):
        SimulationResult.from_dict(sim_ok(error="oops"))


def test_failure_requires_error():
    d = sim_fail()
    del d["error"]
    with pytest.raises(SchemaError, match="requires an error"):
        SimulationResult.from_dict(d)


def test_failure_must_not_carry_predictions():
    with pytest.raises(SchemaError, match="must not carry predictions"):
        SimulationResult.from_dict(sim_fail(predicted_pressure=50.0))


def test_failure_must_not_carry_violations():
    v = [{"type": "PRESSURE_HIGH", "limit": 100.0, "predicted": 120.0}]
    with pytest.raises(SchemaError, match="must not carry predictions"):
        SimulationResult.from_dict(sim_fail(violations=v))


@pytest.mark.parametrize("bad", [float("nan"), float("inf"), float("-inf"), "75", True])
def test_non_finite_or_non_numeric_prediction(bad):
    with pytest.raises(SchemaError):
        SimulationResult.from_dict(sim_ok(predicted_pressure=bad))


def test_min_pressure_must_be_below_max():
    with pytest.raises(SchemaError, match="less than"):
        SimulationResult.from_dict(sim_ok(configured_min_pressure=100.0))


def test_contradictory_violation_rejected():
    for v in ({"type": "PRESSURE_HIGH", "limit": 100.0, "predicted": 90.0},
              {"type": "PRESSURE_HIGH", "limit": 100.0, "predicted": 100.0},
              {"type": "FLOW_LOW", "limit": 5.0, "predicted": 6.0}):
        with pytest.raises(SchemaError):
            SimulationResult.from_dict(sim_ok(violations=[v]))


def test_unknown_violation_type_and_fields():
    with pytest.raises(SchemaError):
        SimulationResult.from_dict(sim_ok(violations=[{"type": "TEMP_HIGH", "limit": 1, "predicted": 2}]))
    with pytest.raises(SchemaError, match="unknown"):
        SimulationResult.from_dict(sim_ok(violations=[
            {"type": "PRESSURE_HIGH", "limit": 1, "predicted": 2, "x": 1}]))


def test_violations_must_be_list():
    with pytest.raises(SchemaError, match="violations must be a list"):
        SimulationResult.from_dict(sim_ok(violations="none"))


def test_result_unknown_field():
    with pytest.raises(SchemaError, match="unknown"):
        SimulationResult.from_dict(sim_ok(safe=True))


def test_result_missing_violations_field():
    d = sim_ok()
    del d["violations"]
    with pytest.raises(SchemaError, match="violations"):
        SimulationResult.from_dict(d)


# ------------------------------------------------------------------ DecisionResult

def test_decision_round_trip_minimal():
    d = {"command_id": "TEST-001", "decision": "ALLOW",
         "reason": "All configured simulated safety constraints satisfied"}
    assert DecisionResult.from_dict(d).to_dict() == d


def test_decision_round_trip_full():
    d = {"command_id": "TEST-001", "decision": "BLOCK",
         "reason": "Predicted pressure exceeds configured maximum",
         "predicted_pressure": 120.0, "configured_max_pressure": 100.0}
    assert DecisionResult.from_dict(d).to_dict() == d


@pytest.mark.parametrize("decision", ["allow", "DENY", "", None, 1, "UNKNOWN"])
def test_unknown_decision_rejected(decision):
    with pytest.raises(SchemaError, match="decision"):
        DecisionResult.from_dict({"command_id": "T", "decision": decision, "reason": "r"})


@pytest.mark.parametrize("reason", ["", "   ", None, 5, "x" * 513])
def test_bad_reason_rejected(reason):
    with pytest.raises(SchemaError, match="reason"):
        DecisionResult.from_dict({"command_id": "T", "decision": "BLOCK", "reason": reason})


def test_decision_unknown_and_missing_fields():
    with pytest.raises(SchemaError, match="unknown"):
        DecisionResult.from_dict({"command_id": "T", "decision": "ALLOW", "reason": "r", "x": 1})
    with pytest.raises(SchemaError, match="missing"):
        DecisionResult.from_dict({"command_id": "T", "decision": "ALLOW"})


def test_decision_non_finite_pressure_rejected():
    with pytest.raises(SchemaError, match="finite"):
        DecisionResult.from_dict({"command_id": "T", "decision": "BLOCK", "reason": "r",
                                  "predicted_pressure": float("nan")})


def test_all_decision_values_accepted():
    for decision in schemas.DECISIONS:
        DecisionResult.from_dict({"command_id": "T", "decision": decision, "reason": "r"})


# ------------------------------------------------------------------ JSON schema file in sync

@pytest.fixture(scope="module")
def schema_defs():
    return json.loads(SCHEMA_FILE.read_text(encoding="utf-8"))["$defs"]


def test_schema_enums_match_python(schema_defs):
    assert tuple(schema_defs["ParsedCommand"]["properties"]["function_code"]["enum"]) == \
        schemas.SUPPORTED_FUNCTION_CODES
    assert tuple(schema_defs["SimulationResult"]["properties"]["simulation_status"]["enum"]) == \
        schemas.SIMULATION_STATUSES
    assert tuple(schema_defs["Violation"]["properties"]["type"]["enum"]) == schemas.VIOLATION_TYPES
    assert tuple(schema_defs["DecisionResult"]["properties"]["decision"]["enum"]) == schemas.DECISIONS
    assert schema_defs["ParsedCommand"]["properties"]["protocol"]["const"] == schemas.PROTOCOL
    assert schema_defs["commandId"]["pattern"] == schemas.COMMAND_ID_PATTERN.pattern


def test_schema_required_fields_match_python(schema_defs):
    assert set(schema_defs["ParsedCommand"]["required"]) == \
        {"command_id", "protocol", "transaction_id", "unit_id", "function_code", "register_address"}
    assert set(schema_defs["SimulationResult"]["required"]) == \
        {"command_id", "simulation_status", "pressure_unit", "configured_min_pressure",
         "configured_max_pressure", "violations"}
    assert set(schema_defs["DecisionResult"]["required"]) == {"command_id", "decision", "reason"}


def test_schema_properties_match_dataclass_fields(schema_defs):
    assert set(schema_defs["ParsedCommand"]["properties"]) == set(cmd16()) | {"register_value"}
    assert set(schema_defs["DecisionResult"]["properties"]) == \
        {"command_id", "decision", "reason", "predicted_pressure", "configured_max_pressure"}
    assert set(schema_defs["SimulationResult"]["properties"]) == set(sim_ok()) | {"error"}
