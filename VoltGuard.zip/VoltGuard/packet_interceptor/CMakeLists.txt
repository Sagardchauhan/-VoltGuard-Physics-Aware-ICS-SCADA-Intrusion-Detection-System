add_library(voltguard_parser STATIC src/parser.cpp src/wire_format.cpp)
target_include_directories(voltguard_parser PUBLIC include)

add_executable(voltguard_parser_cli src/main.cpp)
target_link_libraries(voltguard_parser_cli PRIVATE voltguard_parser)

add_executable(parser_tests tests/parser_tests.cpp)
target_link_libraries(parser_tests PRIVATE voltguard_parser)

foreach(target voltguard_parser voltguard_parser_cli parser_tests)
  if(MSVC)
    target_compile_options(${target} PRIVATE /W4)
  else()
    target_compile_options(${target} PRIVATE -Wall -Wextra -Wpedantic)
  endif()
endforeach()

# Optional: build with -DVOLTGUARD_SANITIZE=ON (GCC/Clang) to run tests under ASan + UBSan.
option(VOLTGUARD_SANITIZE "Build C++ targets with AddressSanitizer and UBSan" OFF)
if(VOLTGUARD_SANITIZE AND NOT MSVC)
  foreach(target voltguard_parser voltguard_parser_cli parser_tests)
    target_compile_options(${target} PRIVATE -fsanitize=address,undefined -fno-omit-frame-pointer)
    target_link_options(${target} PRIVATE -fsanitize=address,undefined)
  endforeach()
endif()

add_test(NAME parser_unit_tests COMMAND parser_tests)
