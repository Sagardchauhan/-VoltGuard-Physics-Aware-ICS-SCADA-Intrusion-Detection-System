// Unit tests for the VoltGuard Modbus/TCP parser and wire format. Framework-free so it builds anywhere.
#include <cstdint>
#include <cstdio>
#include <string>
#include <vector>

#include "parser.h"
#include "wire_format.h"

using namespace voltguard;

namespace {

int g_checks = 0;
int g_failures = 0;

#define CHECK(cond)                                                              \
    do {                                                                         \
        ++g_checks;                                                              \
        if (!(cond)) {                                                           \
            ++g_failures;                                                        \
            std::fprintf(stderr, "FAIL %s:%d: %s\n", __FILE__, __LINE__, #cond); \
        }                                                                        \
    } while (0)

std::vector<std::uint8_t> bytes(const std::string& hex) {
    std::vector<std::uint8_t> out;
    if (!decode_hex(hex, out)) {
        std::fprintf(stderr, "test bug: bad hex literal '%s'\n", hex.c_str());
        ++g_failures;
    }
    return out;
}

ParseResult parse_hex(const std::string& hex) {
    const auto b = bytes(hex);
    return parse_frame(b.data(), b.size());
}

ErrorCode error_of(const std::string& hex) { return parse_hex(hex).error; }

// ---- supported messages

void test_valid_fc6() {
    const auto r = parse_hex("00010000000601060064003c");
    CHECK(r.ok());
    CHECK(r.command.transaction_id == 1);
    CHECK(r.command.unit_id == 1);
    CHECK(r.command.function_code == 6);
    CHECK(r.command.register_address == 100);
    CHECK(r.command.has_register_value && r.command.register_value == 60);
    CHECK(!r.command.has_quantity && r.command.register_values.empty());
}

void test_valid_fc3() {
    const auto r = parse_hex("000900000006010300640002");
    CHECK(r.ok());
    CHECK(r.command.function_code == 3 && r.command.register_address == 100);
    CHECK(r.command.has_quantity && r.command.quantity == 2);
    CHECK(!r.command.has_register_value);
}

void test_valid_fc16() {
    const auto r = parse_hex("000a0000000b0110006400020400370041");
    CHECK(r.ok());
    CHECK(r.command.function_code == 16 && r.command.quantity == 2);
    CHECK(r.command.register_values.size() == 2);
    CHECK(r.command.register_values[0] == 55 && r.command.register_values[1] == 65);
}

void test_field_extremes() {
    const auto r2 = parse_hex("ffff0000000601" "06" "ffff" "ffff");
    CHECK(r2.ok());
    CHECK(r2.command.transaction_id == 0xFFFF && r2.command.register_address == 0xFFFF);
    CHECK(r2.command.register_value == 0xFFFF);
    const auto r3 = parse_hex("00000000000600" "06" "0000" "0000");
    CHECK(r3.ok() && r3.command.unit_id == 0 && r3.command.register_value == 0);
}

// ---- rejection of malformed / unsupported input

void test_size_limits() {
    CHECK(parse_frame(nullptr, 0).error == ErrorCode::FrameTooShort);
    CHECK(error_of("") == ErrorCode::FrameTooShort);
    CHECK(error_of("000d000000") == ErrorCode::FrameTooShort);
    CHECK(error_of("000d00000006") == ErrorCode::FrameTooShort);  // 6 bytes: still short of the 7-byte header
    std::vector<std::uint8_t> big(kMaxAduSize + 1, 0);
    CHECK(parse_frame(big.data(), big.size()).error == ErrorCode::FrameTooLarge);
    CHECK(parse_frame(nullptr, kMaxAduSize + 1).error == ErrorCode::FrameTooLarge);  // size checked before dereference
    CHECK(parse_frame(nullptr, 10).error == ErrorCode::FrameTooShort);               // null pointer with nonzero size is safe
}

void test_header_validation() {
    CHECK(error_of("00110001000601060064003c") == ErrorCode::InvalidProtocolId);
    CHECK(error_of("0011ffff000601060064003c") == ErrorCode::InvalidProtocolId);
    CHECK(error_of("000f0000000501060064003c") == ErrorCode::LengthMismatch);
    CHECK(error_of("00100000ffff01060064003c") == ErrorCode::LengthMismatch);
    CHECK(error_of("000e00000006010600") == ErrorCode::LengthMismatch);
    CHECK(error_of("00010000000101") == ErrorCode::MissingFunctionCode);
    CHECK(error_of("00010000000001") == ErrorCode::LengthMismatch);  // length 0 never valid
}

void test_unsupported_function_codes() {
    CHECK(error_of("000b0000000601010000000a") == ErrorCode::UnsupportedFunctionCode);
    CHECK(error_of("000c000000060105000aff00") == ErrorCode::UnsupportedFunctionCode);
    for (int fc = 0; fc < 256; ++fc) {
        if (fc == 3 || fc == 6 || fc == 16) continue;
        char buf[64];
        std::snprintf(buf, sizeof buf, "00010000000601%02x00640001", fc);
        CHECK(error_of(buf) == ErrorCode::UnsupportedFunctionCode);
    }
    // Modbus exception-response function codes are not requests and are unsupported.
    CHECK(error_of("0001000000030186" "02") == ErrorCode::UnsupportedFunctionCode);
}

void test_pdu_validation() {
    CHECK(error_of("00120000000401060064") == ErrorCode::InvalidPduLength);              // FC6 too short
    CHECK(error_of("00120000000701060064003c00") == ErrorCode::InvalidPduLength);        // FC6 too long
    CHECK(error_of("0001000000050103006400") == ErrorCode::InvalidPduLength);            // FC3 too short
    CHECK(error_of("00010000000401100064") == ErrorCode::InvalidPduLength);              // FC16 header incomplete
    // FC16 with bytecount matching quantity but a trailing extra byte
    CHECK(error_of("00130000000a01100064000102003c00") == ErrorCode::InvalidPduLength);
    // FC16 data truncated: claims 2 registers (4 bytes), supplies 2
    CHECK(error_of("00130000000901100064000204003c") == ErrorCode::InvalidPduLength);
}

void test_quantity_and_bytecount() {
    CHECK(error_of("001400000006010300640000") == ErrorCode::InvalidQuantity);
    CHECK(error_of("00150000000601030064007e") == ErrorCode::InvalidQuantity);   // 126
    CHECK(parse_hex("00150000000601030064007d").ok());                           // 125 boundary
    CHECK(error_of("00160000000901100064000002" "0000") == ErrorCode::InvalidQuantity);  // FC16 qty 0
    CHECK(error_of("00130000000901100064000202003c") == ErrorCode::ByteCountMismatch);
    CHECK(error_of("00130000000901100064000201003c") == ErrorCode::ByteCountMismatch);
    // FC16 qty 123 is the largest that fits (259-byte frame); qty 124 is rejected on quantity
    // before the (absent) data is examined. A real 124-register frame would exceed 260 bytes.
    std::string ok = "0017" "0000" "00fd" "01" "10" "0000" "007b" "f6";
    for (int i = 0; i < 123; ++i) ok += "0001";
    CHECK(parse_hex(ok).ok());
    CHECK(parse_hex(ok).command.register_values.size() == 123);
    CHECK(error_of("0017" "0000" "0007" "01" "10" "0000" "007c" "f8") == ErrorCode::InvalidQuantity);
}

void test_register_range_overflow() {
    CHECK(error_of("0001000000060103ffff0002") == ErrorCode::RegisterRangeOverflow);
    CHECK(parse_hex("0001000000060103ffff0001").ok());
    CHECK(parse_hex("0001000000060106ffff0001").ok());  // FC6 at the last address is valid
    CHECK(parse_hex("0001" "0000" "000b" "01" "10" "fffe" "0002" "04" "0001" "0002").ok());
    CHECK(error_of("0001" "0000" "000b" "01" "10" "ffff" "0002" "04" "0001" "0002") == ErrorCode::RegisterRangeOverflow);
}

// ---- robustness

void test_every_truncation_of_valid_frames_is_safe() {
    const char* frames[] = {"00010000000601060064003c", "000900000006010300640002", "000a000000" "0b0110006400020400370041"};
    for (const char* hex : frames) {
        const auto full = bytes(hex);
        for (std::size_t n = 0; n < full.size(); ++n) {
            const auto r = parse_frame(full.data(), n);  // a strict prefix must never parse as OK
            CHECK(!r.ok());
        }
        CHECK(parse_frame(full.data(), full.size()).ok());
    }
}

void test_every_single_byte_corruption_is_safe() {
    const auto base = bytes("000a000000" "0b0110006400020400370041");
    int ok_count = 0;
    for (std::size_t i = 0; i < base.size(); ++i) {
        for (int v = 0; v < 256; ++v) {
            auto b = base;
            b[i] = static_cast<std::uint8_t>(v);
            if (parse_frame(b.data(), b.size()).ok()) ++ok_count;  // must not crash; some mutations stay valid
        }
    }
    CHECK(ok_count > 0);
}

void test_deterministic_random_input_never_crashes() {
    std::uint32_t state = 12345;
    auto next = [&state]() {
        state = state * 1664525u + 1013904223u;
        return static_cast<std::uint8_t>(state >> 24);
    };
    int accepted = 0;
    for (int i = 0; i < 200000; ++i) {
        const std::size_t len = next() % 300;
        std::vector<std::uint8_t> b(len);
        for (auto& x : b) x = next();
        if (len >= 8 && (next() & 1)) {  // bias half of the inputs towards a plausible header
            b[2] = b[3] = 0;
            b[4] = 0;
            b[5] = static_cast<std::uint8_t>(len - 6);
            b[7] = static_cast<std::uint8_t>((next() & 1) ? 6 : (next() & 1) ? 3 : 16);
        }
        if (parse_frame(b.data(), b.size()).ok()) ++accepted;
    }
    CHECK(accepted >= 0);
    std::printf("random sweep: 200000 inputs, %d accepted\n", accepted);
}

void test_repeated_and_sequential_parsing_is_stateless() {
    const auto a = bytes("00010000000601060064003c");
    const auto b = bytes("00020000000601060065" "0001");
    for (int i = 0; i < 1000; ++i) {
        const auto ra = parse_frame(a.data(), a.size());
        const auto rb = parse_frame(b.data(), b.size());
        CHECK(ra.ok() && ra.command.register_value == 60 && ra.command.transaction_id == 1);
        CHECK(rb.ok() && rb.command.register_value == 1 && rb.command.register_address == 101);
        CHECK(!parse_hex("00").ok());  // a failure in between changes nothing
    }
}

// ---- wire format

void test_command_id_validation() {
    CHECK(is_valid_command_id("TEST-001"));
    CHECK(is_valid_command_id(std::string(64, 'a')));
    CHECK(!is_valid_command_id(""));
    CHECK(!is_valid_command_id(std::string(65, 'a')));
    CHECK(!is_valid_command_id("a b"));
    CHECK(!is_valid_command_id("a;b"));
    CHECK(!is_valid_command_id("../x"));
    CHECK(!is_valid_command_id(std::string("a\0b", 3)));
    CHECK(!is_valid_command_id("a\n"));
}

void test_hex_decoding() {
    std::vector<std::uint8_t> out;
    CHECK(decode_hex("", out) && out.empty());
    CHECK(decode_hex("00fFaB", out) && out.size() == 3 && out[1] == 0xff && out[2] == 0xab);
    CHECK(!decode_hex("0", out));
    CHECK(!decode_hex("zz", out));
    CHECK(!decode_hex("0x00", out));
    CHECK(!decode_hex("00 00", out));
    CHECK(out.empty());
}

void test_process_line_ok_output() {
    const std::string out = process_line("TEST-001 00010000000601060064003c");
    CHECK(out ==
          "{\"command_id\":\"TEST-001\",\"status\":\"OK\",\"command\":{\"command_id\":\"TEST-001\","
          "\"protocol\":\"Modbus/TCP\",\"transaction_id\":1,\"unit_id\":1,\"function_code\":6,"
          "\"register_address\":100,\"register_value\":60}}");
}

void test_process_line_fc16_output() {
    const std::string out = process_line("X 000a000000" "0b0110006400020400370041");
    CHECK(out.find("\"register_values\":[55,65]") != std::string::npos);
    CHECK(out.find("\"quantity\":2") != std::string::npos);
}

void test_process_line_rejections() {
    CHECK(process_line("T1 000b0000000601010000000a") ==
          "{\"command_id\":\"T1\",\"status\":\"REJECTED\",\"error_code\":\"UNSUPPORTED_FUNCTION_CODE\","
          "\"error\":\"unsupported function code\"}");
    CHECK(process_line("T2").find("FRAME_TOO_SHORT") != std::string::npos);
    CHECK(process_line("bad;id 00").find("\"command_id\":null") != std::string::npos);
    CHECK(process_line("bad id 00").find("extra tokens") != std::string::npos);  // "bad" is a valid id; rest is not one hex token
    CHECK(process_line("T3 abc").find("INVALID_INPUT") != std::string::npos);
    CHECK(process_line("T4 zz").find("not valid hex") != std::string::npos);
    CHECK(process_line("T5 00 00").find("extra tokens") != std::string::npos);
    CHECK(process_line(std::string(kMaxLineLength + 1, 'a')).find("too long") != std::string::npos);
}

void test_process_line_ignores_blank_and_comments_and_handles_crlf() {
    CHECK(process_line("").empty());
    CHECK(process_line("   \t ").empty());
    CHECK(process_line("# comment").empty());
    CHECK(process_line("T1 00010000000601060064003c\r\n").find("\"status\":\"OK\"") != std::string::npos);
    CHECK(process_line("  T1   00010000000601060064003c  ").find("\"status\":\"OK\"") != std::string::npos);
}

void test_untrusted_text_is_not_echoed() {
    const std::string out = process_line("<script>\"evil\\ T1");
    CHECK(out.find("script") == std::string::npos);
    CHECK(out.find("evil") == std::string::npos);
    const std::string binary = process_line(std::string("\x01\x02\xff T", 6));
    CHECK(binary.find("\"command_id\":null") != std::string::npos);
}

}  // namespace

int main() {
    test_valid_fc6();
    test_valid_fc3();
    test_valid_fc16();
    test_field_extremes();
    test_size_limits();
    test_header_validation();
    test_unsupported_function_codes();
    test_pdu_validation();
    test_quantity_and_bytecount();
    test_register_range_overflow();
    test_every_truncation_of_valid_frames_is_safe();
    test_every_single_byte_corruption_is_safe();
    test_deterministic_random_input_never_crashes();
    test_repeated_and_sequential_parsing_is_stateless();
    test_command_id_validation();
    test_hex_decoding();
    test_process_line_ok_output();
    test_process_line_fc16_output();
    test_process_line_rejections();
    test_process_line_ignores_blank_and_comments_and_handles_crlf();
    test_untrusted_text_is_not_echoed();

    std::printf("%d checks, %d failures\n", g_checks, g_failures);
    return g_failures == 0 ? 0 : 1;
}
