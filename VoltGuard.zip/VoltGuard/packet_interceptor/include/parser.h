// Modbus/TCP frame parser for VoltGuard.
//
// Pure protocol parsing: bytes in, structured result out. No I/O, no security
// decisions, no allocation proportional to untrusted length fields (frame size is
// capped before anything is read). Every malformed input yields an error code;
// nothing here throws for bad data.
#pragma once

#include <cstddef>
#include <cstdint>
#include <vector>

namespace voltguard {

constexpr std::size_t kMbapHeaderSize = 7;   // transaction(2) protocol(2) length(2) unit(1)
constexpr std::size_t kMaxAduSize = 260;     // Modbus/TCP maximum ADU size
constexpr std::uint8_t kFcReadHoldingRegisters = 3;
constexpr std::uint8_t kFcWriteSingleRegister = 6;
constexpr std::uint8_t kFcWriteMultipleRegisters = 16;
constexpr std::uint16_t kMaxReadQuantity = 125;
constexpr std::uint16_t kMaxWriteQuantity = 123;

enum class ErrorCode {
    None = 0,
    FrameTooLarge,
    FrameTooShort,
    InvalidProtocolId,
    LengthMismatch,
    MissingFunctionCode,
    UnsupportedFunctionCode,
    InvalidPduLength,
    InvalidQuantity,
    ByteCountMismatch,
    RegisterRangeOverflow,
};

// Stable machine-readable name, e.g. "UNSUPPORTED_FUNCTION_CODE".
const char* error_code_name(ErrorCode code);
// Human-readable reason; these strings are part of the test contract (fixture reject_reason).
const char* error_message(ErrorCode code);

struct ParsedCommand {
    std::uint16_t transaction_id = 0;
    std::uint8_t unit_id = 0;
    std::uint8_t function_code = 0;
    std::uint16_t register_address = 0;
    bool has_register_value = false;           // FC 6
    std::uint16_t register_value = 0;
    bool has_quantity = false;                 // FC 3, 16
    std::uint16_t quantity = 0;
    std::vector<std::uint16_t> register_values;  // FC 16
};

struct ParseResult {
    ErrorCode error = ErrorCode::None;
    ParsedCommand command;  // meaningful only when ok()
    bool ok() const { return error == ErrorCode::None; }
};

// Parses one complete Modbus/TCP request ADU. `data` may be null only when size is 0.
ParseResult parse_frame(const std::uint8_t* data, std::size_t size);

}  // namespace voltguard
