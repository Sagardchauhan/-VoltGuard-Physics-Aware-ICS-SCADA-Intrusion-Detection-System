// Text wire format for the parser command-line tool (hex in, JSON lines out).
//
// Input, one request per line:      <command_id> [<frame as hex>]
//   - blank lines and lines starting with '#' are ignored
//   - a line with only a command id is an empty frame (rejected by the parser)
// Output, one JSON object per processed line, in order:
//   {"command_id":"X","status":"OK","command":{...ParsedCommand schema...}}
//   {"command_id":"X","status":"REJECTED","error_code":"...","error":"..."}
// Input that cannot even be split into id + hex is reported with "command_id":null;
// untrusted text is never echoed back.
#pragma once

#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

#include "parser.h"

namespace voltguard {

constexpr std::size_t kMaxLineLength = 4096;  // longer lines are rejected without being parsed

bool is_valid_command_id(const std::string& id);
// Accepts upper/lower-case hex with an even number of digits. Returns false on any other input.
bool decode_hex(const std::string& text, std::vector<std::uint8_t>& out);

std::string render_ok(const std::string& command_id, const ParsedCommand& cmd);
std::string render_rejected(const std::string& command_id, ErrorCode code);
// For input that failed before a parser error code exists. command_id may be empty (-> null).
std::string render_input_error(const std::string& command_id, const std::string& message);

// Processes one input line. Returns an empty string when the line is ignorable.
std::string process_line(const std::string& line);

}  // namespace voltguard
