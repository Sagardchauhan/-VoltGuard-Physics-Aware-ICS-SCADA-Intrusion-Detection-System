#include "wire_format.h"

#include <cstddef>

namespace voltguard {

namespace {

bool is_id_char(char c) {
    return (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') ||
           c == '_' || c == '.' || c == '-';
}

int hex_value(char c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}

bool is_space(char c) { return c == ' ' || c == '\t'; }

// Only fixed, trusted text and validated command ids are rendered, so escaping is a
// defensive measure rather than the primary protection.
std::string json_string(const std::string& s) {
    std::string out = "\"";
    for (char c : s) {
        const unsigned char u = static_cast<unsigned char>(c);
        if (c == '"') out += "\\\"";
        else if (c == '\\') out += "\\\\";
        else if (u < 0x20 || u == 0x7f) out += '?';
        else out += c;
    }
    out += '"';
    return out;
}

std::string id_or_null(const std::string& id) { return id.empty() ? "null" : json_string(id); }

}  // namespace

bool is_valid_command_id(const std::string& id) {
    if (id.empty() || id.size() > 64) return false;
    for (char c : id) {
        if (!is_id_char(c)) return false;
    }
    return true;
}

bool decode_hex(const std::string& text, std::vector<std::uint8_t>& out) {
    out.clear();
    if (text.size() % 2 != 0) return false;
    out.reserve(text.size() / 2);
    for (std::size_t i = 0; i < text.size(); i += 2) {
        const int hi = hex_value(text[i]);
        const int lo = hex_value(text[i + 1]);
        if (hi < 0 || lo < 0) {
            out.clear();
            return false;
        }
        out.push_back(static_cast<std::uint8_t>((hi << 4) | lo));
    }
    return true;
}

std::string render_ok(const std::string& command_id, const ParsedCommand& c) {
    std::string out = "{\"command_id\":" + json_string(command_id) + ",\"status\":\"OK\",\"command\":{";
    out += "\"command_id\":" + json_string(command_id);
    out += ",\"protocol\":\"Modbus/TCP\"";
    out += ",\"transaction_id\":" + std::to_string(c.transaction_id);
    out += ",\"unit_id\":" + std::to_string(c.unit_id);
    out += ",\"function_code\":" + std::to_string(c.function_code);
    out += ",\"register_address\":" + std::to_string(c.register_address);
    if (c.has_register_value) out += ",\"register_value\":" + std::to_string(c.register_value);
    if (c.has_quantity) out += ",\"quantity\":" + std::to_string(c.quantity);
    if (!c.register_values.empty()) {
        out += ",\"register_values\":[";
        for (std::size_t i = 0; i < c.register_values.size(); ++i) {
            if (i) out += ',';
            out += std::to_string(c.register_values[i]);
        }
        out += ']';
    }
    out += "}}";
    return out;
}

std::string render_rejected(const std::string& command_id, ErrorCode code) {
    return "{\"command_id\":" + id_or_null(command_id) + ",\"status\":\"REJECTED\",\"error_code\":" +
           json_string(error_code_name(code)) + ",\"error\":" + json_string(error_message(code)) + "}";
}

std::string render_input_error(const std::string& command_id, const std::string& message) {
    return "{\"command_id\":" + id_or_null(command_id) +
           ",\"status\":\"REJECTED\",\"error_code\":\"INVALID_INPUT\",\"error\":" + json_string(message) + "}";
}

std::string process_line(const std::string& raw) {
    if (raw.size() > kMaxLineLength) return render_input_error("", "input line too long");

    // Trim trailing CR/LF/whitespace and leading whitespace.
    std::size_t begin = 0, end = raw.size();
    while (begin < end && is_space(raw[begin])) ++begin;
    while (end > begin && (is_space(raw[end - 1]) || raw[end - 1] == '\r' || raw[end - 1] == '\n')) --end;
    const std::string line = raw.substr(begin, end - begin);

    if (line.empty() || line[0] == '#') return "";

    std::size_t split = 0;
    while (split < line.size() && !is_space(line[split])) ++split;
    const std::string id = line.substr(0, split);
    if (!is_valid_command_id(id)) return render_input_error("", "invalid command id");

    std::size_t hex_begin = split;
    while (hex_begin < line.size() && is_space(line[hex_begin])) ++hex_begin;
    const std::string hex = line.substr(hex_begin);
    for (char c : hex) {
        if (is_space(c)) return render_input_error(id, "unexpected extra tokens");
    }

    std::vector<std::uint8_t> frame;
    if (!decode_hex(hex, frame)) return render_input_error(id, "frame is not valid hex");

    const ParseResult result = parse_frame(frame.data(), frame.size());
    return result.ok() ? render_ok(id, result.command) : render_rejected(id, result.error);
}

}  // namespace voltguard
