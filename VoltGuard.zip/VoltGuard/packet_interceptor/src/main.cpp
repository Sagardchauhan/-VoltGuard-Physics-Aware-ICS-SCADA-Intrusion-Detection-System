// voltguard_parser_cli: reads "<command_id> <hex frame>" lines on stdin, writes one JSON line per request.
// See wire_format.h for the format. Reads only from stdin; never opens files, sockets or subprocesses.
#include <cstdio>
#include <cstring>
#include <iostream>
#include <string>

#include "wire_format.h"

namespace {

enum class ReadStatus { Line, Overflow, Eof };

// Reads one line while keeping memory bounded: bytes beyond the limit are discarded.
ReadStatus read_bounded_line(std::istream& in, std::string& line) {
    line.clear();
    bool any = false, overflow = false;
    char c;
    while (in.get(c)) {
        any = true;
        if (c == '\n') return overflow ? ReadStatus::Overflow : ReadStatus::Line;
        if (line.size() < voltguard::kMaxLineLength + 1) line.push_back(c);
        else overflow = true;
    }
    if (!any) return ReadStatus::Eof;
    return (overflow || line.size() > voltguard::kMaxLineLength) ? ReadStatus::Overflow : ReadStatus::Line;
}

}  // namespace

int main(int argc, char** argv) {
    if (argc > 1) {
        if (std::strcmp(argv[1], "--help") == 0 || std::strcmp(argv[1], "-h") == 0) {
            std::cout << "usage: voltguard_parser_cli < requests.txt\n"
                         "  input line:  <command_id> [<frame hex>]\n"
                         "  output line: JSON (status OK or REJECTED)\n";
            return 0;
        }
        std::cerr << "voltguard_parser_cli: unexpected argument (see --help)\n";
        return 2;
    }

    std::ios::sync_with_stdio(false);
    std::string line;
    for (;;) {
        const ReadStatus status = read_bounded_line(std::cin, line);
        if (status == ReadStatus::Eof) break;
        const std::string out = (status == ReadStatus::Overflow)
                                    ? voltguard::render_input_error("", "input line too long")
                                    : voltguard::process_line(line);
        if (!out.empty()) std::cout << out << '\n' << std::flush;
    }
    return 0;
}
