#include "parser.h"

namespace voltguard {

namespace {

std::uint16_t be16(const std::uint8_t* p) {
    return static_cast<std::uint16_t>((static_cast<unsigned>(p[0]) << 8) | p[1]);
}

ParseResult fail(ErrorCode code) {
    ParseResult r;
    r.error = code;
    return r;
}

}  // namespace

const char* error_code_name(ErrorCode code) {
    switch (code) {
        case ErrorCode::None: return "NONE";
        case ErrorCode::FrameTooLarge: return "FRAME_TOO_LARGE";
        case ErrorCode::FrameTooShort: return "FRAME_TOO_SHORT";
        case ErrorCode::InvalidProtocolId: return "INVALID_PROTOCOL_ID";
        case ErrorCode::LengthMismatch: return "LENGTH_MISMATCH";
        case ErrorCode::MissingFunctionCode: return "MISSING_FUNCTION_CODE";
        case ErrorCode::UnsupportedFunctionCode: return "UNSUPPORTED_FUNCTION_CODE";
        case ErrorCode::InvalidPduLength: return "INVALID_PDU_LENGTH";
        case ErrorCode::InvalidQuantity: return "INVALID_QUANTITY";
        case ErrorCode::ByteCountMismatch: return "BYTE_COUNT_MISMATCH";
        case ErrorCode::RegisterRangeOverflow: return "REGISTER_RANGE_OVERFLOW";
    }
    return "UNKNOWN";
}

const char* error_message(ErrorCode code) {
    switch (code) {
        case ErrorCode::None: return "no error";
        case ErrorCode::FrameTooLarge: return "frame too large";
        case ErrorCode::FrameTooShort: return "frame shorter than MBAP header";
        case ErrorCode::InvalidProtocolId: return "invalid protocol id";
        case ErrorCode::LengthMismatch: return "length field mismatch";
        case ErrorCode::MissingFunctionCode: return "missing function code";
        case ErrorCode::UnsupportedFunctionCode: return "unsupported function code";
        case ErrorCode::InvalidPduLength: return "invalid PDU length for function code";
        case ErrorCode::InvalidQuantity: return "invalid quantity";
        case ErrorCode::ByteCountMismatch: return "byte count mismatch";
        case ErrorCode::RegisterRangeOverflow: return "register range exceeds address space";
    }
    return "unknown error";
}

ParseResult parse_frame(const std::uint8_t* data, std::size_t size) {
    // Size cap first: nothing below depends on an attacker-controlled length for allocation.
    if (size > kMaxAduSize) return fail(ErrorCode::FrameTooLarge);
    if (size < kMbapHeaderSize || data == nullptr) return fail(ErrorCode::FrameTooShort);

    if (be16(data + 2) != 0) return fail(ErrorCode::InvalidProtocolId);
    // The MBAP length counts the unit id plus the PDU, i.e. every byte after the length field.
    if (static_cast<std::size_t>(be16(data + 4)) != size - 6) return fail(ErrorCode::LengthMismatch);
    if (size == kMbapHeaderSize) return fail(ErrorCode::MissingFunctionCode);

    ParseResult result;
    ParsedCommand& cmd = result.command;
    cmd.transaction_id = be16(data);
    cmd.unit_id = data[6];
    cmd.function_code = data[7];

    const std::uint8_t* pdu = data + 7;  // pdu[0] is the function code
    const std::size_t pdu_len = size - 7;

    // Unsupported function codes are rejected before any PDU layout is assumed.
    switch (cmd.function_code) {
        case kFcReadHoldingRegisters:
            if (pdu_len != 5) return fail(ErrorCode::InvalidPduLength);
            cmd.register_address = be16(pdu + 1);
            cmd.quantity = be16(pdu + 3);
            cmd.has_quantity = true;
            if (cmd.quantity < 1 || cmd.quantity > kMaxReadQuantity) return fail(ErrorCode::InvalidQuantity);
            break;

        case kFcWriteSingleRegister:
            if (pdu_len != 5) return fail(ErrorCode::InvalidPduLength);
            cmd.register_address = be16(pdu + 1);
            cmd.register_value = be16(pdu + 3);
            cmd.has_register_value = true;
            break;

        case kFcWriteMultipleRegisters: {
            if (pdu_len < 6) return fail(ErrorCode::InvalidPduLength);
            cmd.register_address = be16(pdu + 1);
            cmd.quantity = be16(pdu + 3);
            cmd.has_quantity = true;
            if (cmd.quantity < 1 || cmd.quantity > kMaxWriteQuantity) return fail(ErrorCode::InvalidQuantity);
            const std::size_t byte_count = pdu[5];
            if (byte_count != static_cast<std::size_t>(cmd.quantity) * 2) return fail(ErrorCode::ByteCountMismatch);
            if (pdu_len != 6 + byte_count) return fail(ErrorCode::InvalidPduLength);
            cmd.register_values.reserve(cmd.quantity);  // bounded: quantity <= 123 here
            for (std::size_t i = 0; i < cmd.quantity; ++i) cmd.register_values.push_back(be16(pdu + 6 + 2 * i));
            break;
        }

        default:
            return fail(ErrorCode::UnsupportedFunctionCode);
    }

    const std::uint32_t span = cmd.has_quantity ? cmd.quantity : 1u;
    if (static_cast<std::uint32_t>(cmd.register_address) + span - 1 > 0xFFFFu) {
        return fail(ErrorCode::RegisterRangeOverflow);
    }
    return result;
}

}  // namespace voltguard
