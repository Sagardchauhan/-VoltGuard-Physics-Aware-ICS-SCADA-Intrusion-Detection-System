cmake_minimum_required(VERSION 3.20)
project(VoltGuard VERSION 0.1.0 LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

enable_testing()

# Phase 4: C++ Modbus/TCP parser library, command-line tool and unit tests.
add_subdirectory(packet_interceptor)

# Phase 8: native Qt 6 dashboard. Skipped (with a warning) if Qt 6 is not installed, so the parser and tests still build.
option(VOLTGUARD_BUILD_DASHBOARD "Build the Qt 6 dashboard" ON)
if(VOLTGUARD_BUILD_DASHBOARD)
  find_package(Qt6 6.4 QUIET COMPONENTS Widgets Test Charts)
  if(Qt6_FOUND)
    add_subdirectory(dashboard)
  else()
    message(WARNING "Qt 6 (Widgets, Test, Charts) not found: the dashboard is NOT built. See docs/installation.md.")
  endif()
endif()
