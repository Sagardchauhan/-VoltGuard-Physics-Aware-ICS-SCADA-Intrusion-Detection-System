"""Mock Modbus/TCP traffic generator (simulation only; never sends to a network)."""
