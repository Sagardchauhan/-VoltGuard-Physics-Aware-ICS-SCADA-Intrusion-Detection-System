"""Mock Modbus/TCP traffic generator.

Builds Modbus/TCP frames as raw bytes and writes them to a JSON file. It NEVER
opens a socket or sends anything to a network: output is a file (or a Python list)
that later phases feed to the parser.

Well-formed frames are built with Scapy's Modbus layer; malformed frames are
hand-written bytes (Scapy would normally refuse to build them).

Usage:
    python -m traffic_generator.generate_traffic --output tests/fixtures/mock_traffic.json
    python -m traffic_generator.generate_traffic --stream 100 --seed 7 --output results/stream.json
"""

from __future__ import annotations

import argparse
import json
import random
import sys
from pathlib import Path
from typing import Any, Iterable, Sequence

from scapy.contrib.modbus import (ModbusADURequest, ModbusPDU03ReadHoldingRegistersRequest,
                                  ModbusPDU06WriteSingleRegisterRequest,
                                  ModbusPDU10WriteMultipleRegistersRequest)

if __name__ == "__main__" and __package__ in (None, ""):
    # Started as a plain file (for example with an editor's Run button) instead of `python -m ...`: Python then puts
    # this file's own folder on sys.path, so the project packages cannot be found. Use the project root instead.
    sys.path[0:1] = [str(Path(__file__).resolve().parent.parent)]

from traffic_generator.scenarios import (INTENT_NORMAL, PARSE_OK, SCENARIOS, Scenario)
from voltguard.register_map import MAX_PERCENT, PUMP_SPEED_REGISTER, VALVE_POSITION_REGISTER

FORMAT_VERSION = 1
MAX_STREAM_LENGTH = 100_000


def build_frame(scenario: Scenario) -> bytes:
    """Return the Modbus/TCP ADU bytes for a scenario."""
    if scenario.raw_hex is not None:
        return bytes.fromhex(scenario.raw_hex)

    adu = ModbusADURequest(transId=scenario.transaction_id, unitId=scenario.unit_id)
    fc = scenario.function_code
    if fc == 6:
        pdu = ModbusPDU06WriteSingleRegisterRequest(
            registerAddr=scenario.register_address, registerValue=scenario.register_value)
    elif fc == 3:
        pdu = ModbusPDU03ReadHoldingRegistersRequest(
            startAddr=scenario.register_address, quantity=scenario.quantity)
    elif fc == 16:
        pdu = ModbusPDU10WriteMultipleRegistersRequest(
            startAddr=scenario.register_address, quantityRegisters=scenario.quantity,
            outputsValue=list(scenario.register_values))
    else:
        raise ValueError(f"scenario '{scenario.name}' has no raw_hex and unsupported function code {fc!r}")
    return bytes(adu / pdu)


def scenario_record(index: int, scenario: Scenario) -> dict[str, Any]:
    frame = build_frame(scenario)
    record: dict[str, Any] = {
        "command_id": f"TG-{index:04d}",
        "scenario": scenario.name,
        "description": scenario.description,
        "intent": scenario.intent,
        "parse_expected": scenario.parse_expected,
        "frame_hex": frame.hex(),
        "frame_length": len(frame),
    }
    if scenario.parse_expected == PARSE_OK:
        record["expected_fields"] = {
            "transaction_id": scenario.transaction_id, "unit_id": scenario.unit_id,
            "function_code": scenario.function_code, "register_address": scenario.register_address,
            **({"register_value": scenario.register_value} if scenario.function_code == 6 else {}),
            **({"quantity": scenario.quantity} if scenario.function_code in (3, 16) else {}),
            **({"register_values": list(scenario.register_values)} if scenario.function_code == 16 else {}),
        }
    else:
        record["reject_reason"] = scenario.reject_reason
    return record


def generate_scenarios(names: Iterable[str] | None = None) -> list[dict[str, Any]]:
    """Records for all (or the named) scenarios, in definition order. Deterministic."""
    selected: Sequence[Scenario] = SCENARIOS
    if names is not None:
        wanted = set(names)
        unknown = wanted - {s.name for s in SCENARIOS}
        if unknown:
            raise ValueError(f"unknown scenario(s): {sorted(unknown)}")
        selected = [s for s in SCENARIOS if s.name in wanted]
    return [scenario_record(i, s) for i, s in enumerate(selected, start=1)]


def generate_stream(count: int, seed: int) -> list[dict[str, Any]]:
    """A seeded, reproducible stream of well-formed pump/valve write commands (values 0..100).

    The same (count, seed) always yields identical bytes. Intent is NORMAL-or-unverified:
    physical safety of each value is decided by the physics model, not by the generator.
    """
    if isinstance(count, bool) or not isinstance(count, int) or not 1 <= count <= MAX_STREAM_LENGTH:
        raise ValueError(f"count must be an integer between 1 and {MAX_STREAM_LENGTH}")
    rng = random.Random(seed)
    records = []
    for i in range(1, count + 1):
        register = rng.choice((PUMP_SPEED_REGISTER, VALVE_POSITION_REGISTER))
        value = rng.randint(0, MAX_PERCENT)
        scenario = Scenario(
            name=f"stream_{i:05d}", description=f"seeded write {value} to register {register}",
            parse_expected=PARSE_OK, intent=INTENT_NORMAL, transaction_id=i % 0x10000,
            function_code=6, register_address=register, register_value=value)
        records.append(scenario_record(i, scenario))
    return records


def write_traffic_file(records: list[dict[str, Any]], path: Path) -> None:
    document = {"format_version": FORMAT_VERSION,
                "note": "Simulated traffic for testing only. Never sent over a network.",
                "messages": records}
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(document, indent=2) + "\n", encoding="utf-8")


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Generate mock Modbus/TCP test traffic into a JSON file.")
    ap.add_argument("--output", type=Path, required=True, help="output JSON file")
    ap.add_argument("--stream", type=int, metavar="N", help="generate N seeded random write commands instead of the fixed scenarios")
    ap.add_argument("--seed", type=int, default=0, help="seed for --stream (default 0)")
    args = ap.parse_args(argv)
    try:
        records = generate_stream(args.stream, args.seed) if args.stream is not None else generate_scenarios()
    except ValueError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    write_traffic_file(records, args.output)
    print(f"wrote {len(records)} message(s) to {args.output}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
