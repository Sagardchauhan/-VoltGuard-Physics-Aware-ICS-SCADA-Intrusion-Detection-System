"""Test scenarios for the mock traffic generator.

Each scenario describes ONE Modbus/TCP frame and the outcome a correct *parser*
must produce. The expected parser outcome (PARSE_OK / PARSE_REJECT) is a
protocol-level fact and is checked in Phase 4.

``intent`` records the physical outcome the scenario is expected to produce for a
well-formed frame. Since Phase 5 these labels have been checked against the
simulation model (default settings: pump 50 %, valve 60 %) and are pinned by
tests/test_physics.py. They describe the INVENTED prototype model only, are not
real-world safety claims, and never override the parser or the decision engine.
Phase 5 corrections: normal_pump_40 became unsafe_pump_40_low_pressure (it predicts
19.58 kPa, just below the 20 kPa minimum) and the redundant single-write
"pump 100 + valve closed" scenario became an FC16 write that really sets both.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from voltguard.register_map import PUMP_SPEED_REGISTER, VALVE_POSITION_REGISTER

PARSE_OK = "PARSE_OK"
PARSE_REJECT = "PARSE_REJECT"

INTENT_NORMAL = "NORMAL"                  # predicted to satisfy all limits
INTENT_BOUNDARY = "BOUNDARY_SAFE"         # predicted exactly at a limit (limits are inclusive): allowed
INTENT_UNSAFE = "UNSAFE"                  # predicted to violate at least one limit
INTENT_INVALID_VALUE = "INVALID_VALUE"    # valid Modbus, but the value is outside the physical input range
INTENT_READ = "READ_ONLY"                 # read request, no state change requested
INTENT_MALFORMED = "MALFORMED"            # must be rejected by the parser
INTENT_UNSUPPORTED = "UNSUPPORTED"        # valid frame, function code not supported


@dataclass(frozen=True)
class Scenario:
    name: str
    description: str
    parse_expected: str
    intent: str
    transaction_id: int = 1
    unit_id: int = 1
    function_code: Optional[int] = None
    register_address: int = 0
    register_value: Optional[int] = None
    quantity: Optional[int] = None
    register_values: tuple[int, ...] = ()
    # Malformed frames are built from raw bytes instead of the Scapy layer.
    raw_hex: Optional[str] = None
    reject_reason: Optional[str] = None


def _write(name, desc, intent, value, reg=PUMP_SPEED_REGISTER, tid=1):
    return Scenario(name, desc, PARSE_OK, intent, transaction_id=tid, function_code=6,
                    register_address=reg, register_value=value)


SCENARIOS: tuple[Scenario, ...] = (
    # ---- well-formed writes: normal and deliberately aggressive
    _write("normal_pump_60", "Pump to 60% (moderate)", INTENT_NORMAL, 60, tid=1),
    _write("normal_pump_45", "Pump to 45% (moderate)", INTENT_NORMAL, 45, tid=2),
    _write("normal_valve_70", "Valve to 70% open", INTENT_NORMAL, 70, VALVE_POSITION_REGISTER, tid=3),
    Scenario("unsafe_multi_pump_100_valve_20", "FC16: pump 100% with valve throttled to 20% (high pressure)",
             PARSE_OK, INTENT_UNSAFE, transaction_id=4, function_code=16, register_address=PUMP_SPEED_REGISTER,
             quantity=2, register_values=(100, 20)),
    _write("unsafe_valve_closed", "Valve to 0% (fully closed) while pump runs: no flow", INTENT_UNSAFE, 0,
           VALVE_POSITION_REGISTER, tid=5),
    _write("unsafe_pump_stop", "Pump to 0%: no pressure, no flow", INTENT_UNSAFE, 0, tid=6),
    _write("unsafe_pump_40_low_pressure", "Pump to 40%: pressure falls just below the configured minimum",
           INTENT_UNSAFE, 40, tid=31),
    _write("unsafe_pump_100", "Pump to exactly 100% (upper end of the valid range): pressure above maximum",
           INTENT_UNSAFE, 100, tid=7),
    _write("out_of_range_pump_250", "Pump value 250 is outside 0..100 percent; valid Modbus, invalid physical input",
           INTENT_INVALID_VALUE, 250, tid=8),
    _write("unmapped_register_write", "Write to register 102, which controls nothing in the pipeline",
           INTENT_INVALID_VALUE, 5, reg=102, tid=32),
    Scenario("boundary_full_speed_full_open", "FC16: pump 100%, valve 100%: flow lands exactly on the 50 L/s maximum",
             PARSE_OK, INTENT_BOUNDARY, transaction_id=33, function_code=16, register_address=PUMP_SPEED_REGISTER,
             quantity=2, register_values=(100, 100)),
    # ---- read and multi-write
    Scenario("read_pump_registers", "Read 2 holding registers from the pump register", PARSE_OK, INTENT_READ,
             transaction_id=9, function_code=3, register_address=PUMP_SPEED_REGISTER, quantity=2),
    Scenario("write_multiple_pump_valve", "FC16: pump 55%, valve 65%", PARSE_OK, INTENT_NORMAL,
             transaction_id=10, function_code=16, register_address=PUMP_SPEED_REGISTER, quantity=2,
             register_values=(55, 65)),
    # ---- valid frames with a function code VoltGuard does not support
    Scenario("unsupported_fc01_read_coils", "FC1 read coils: valid frame, unsupported function",
             PARSE_REJECT, INTENT_UNSUPPORTED, raw_hex="000b0000000601010000000a",
             reject_reason="unsupported function code"),
    Scenario("unsupported_fc05_write_coil", "FC5 write single coil: unsupported",
             PARSE_REJECT, INTENT_UNSUPPORTED, raw_hex="000c000000060105000aff00",
             reject_reason="unsupported function code"),
    # ---- malformed frames
    Scenario("malformed_empty", "Zero-length input", PARSE_REJECT, INTENT_MALFORMED, raw_hex="",
             reject_reason="frame shorter than MBAP header"),
    Scenario("malformed_truncated_header", "Only 5 bytes of the 7-byte MBAP header", PARSE_REJECT,
             INTENT_MALFORMED, raw_hex="000d000000", reject_reason="frame shorter than MBAP header"),
    Scenario("malformed_truncated_pdu", "Header claims 6 bytes of unit+PDU but frame ends early",
             PARSE_REJECT, INTENT_MALFORMED, raw_hex="000e00000006010600", reject_reason="length field mismatch"),
    Scenario("malformed_length_too_small", "Length field smaller than actual bytes", PARSE_REJECT,
             INTENT_MALFORMED, raw_hex="000f0000000501060064003c",
             reject_reason="length field mismatch"),
    Scenario("malformed_length_too_large", "Length field larger than actual bytes", PARSE_REJECT,
             INTENT_MALFORMED, raw_hex="0010000000ff01060064003c", reject_reason="length field mismatch"),
    Scenario("malformed_wrong_protocol_id", "MBAP protocol id 0x0001 (must be 0)", PARSE_REJECT,
             INTENT_MALFORMED, raw_hex="00110001000601060064003c",
             reject_reason="invalid protocol id"),
    Scenario("malformed_fc6_short_pdu", "FC6 PDU missing the register value", PARSE_REJECT,
             INTENT_MALFORMED, raw_hex="00120000000401060064",
             reject_reason="invalid PDU length for function code"),
    Scenario("malformed_fc16_bytecount_mismatch", "FC16 byte count does not match quantity", PARSE_REJECT,
             INTENT_MALFORMED, raw_hex="00130000000901100064000202003c",
             reject_reason="byte count mismatch"),
    Scenario("malformed_fc3_zero_quantity", "FC3 with quantity 0", PARSE_REJECT, INTENT_MALFORMED,
             raw_hex="001400000006010300640000", reject_reason="invalid quantity"),
    Scenario("malformed_fc3_quantity_126", "FC3 with quantity 126 (> 125)", PARSE_REJECT, INTENT_MALFORMED,
             raw_hex="00150000000601030064007e", reject_reason="invalid quantity"),
    Scenario("malformed_fc3_range_overflow", "FC3 at address 65535 with quantity 2 runs past the address space",
             PARSE_REJECT, INTENT_MALFORMED, raw_hex="0017000000060103ffff0002",
             reject_reason="register range exceeds address space"),
    Scenario("malformed_oversized", "Frame larger than the maximum Modbus/TCP ADU (260 bytes)", PARSE_REJECT,
             INTENT_MALFORMED, raw_hex="0016000000ff01" + "00" * 300, reject_reason="frame too large"),
)

SCENARIOS_BY_NAME = {s.name: s for s in SCENARIOS}
assert len(SCENARIOS_BY_NAME) == len(SCENARIOS), "duplicate scenario names"
