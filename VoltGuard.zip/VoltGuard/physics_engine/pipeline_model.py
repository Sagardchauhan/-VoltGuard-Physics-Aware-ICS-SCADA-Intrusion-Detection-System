"""Simplified steady-state model of a pump, a control valve and a pipeline.

THIS IS A TEACHING-LEVEL APPROXIMATION, NOT A VALIDATED FLUID-DYNAMICS MODEL.
All parameter values are invented for the prototype and do not describe any real plant.
See docs/methodology.md for assumptions and limitations.

Variables (units): s = pump speed fraction (0..1), v = valve opening fraction (0..1),
Q = flow (L/s), P = pump discharge pressure (kPa, gauge).

Equations:
    pump curve (affinity-law form):  P_pump(Q, s) = P0 * s^2 - a * Q^2
    system curve (back pressure + quadratic losses):
                                     P_sys(Q, v)  = P_back + (k_pipe + k_valve / v^2) * Q^2
The operating point is where the two curves intersect (Q >= 0). Special cases:
    * valve fully closed (v = 0), or the pump cannot overcome back pressure
      (P0 * s^2 <= P_back): Q = 0 and the discharge pressure is the pump dead-head
      pressure P0 * s^2.
Closed-form solution (used by the tests as an independent oracle):
    Q^2 = (P0 * s^2 - P_back) / (a + R),   R = k_pipe + k_valve / v^2,   P = P_back + R * Q^2

The solver below finds the intersection numerically with scipy.optimize.brentq so the
same code path keeps working if the curves are later replaced by non-algebraic ones.
Steady state only: no transients, water hammer, temperature, compressibility or pipe topology.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, fields

from scipy.optimize import brentq

PRESSURE_UNIT = "kPa"
FLOW_UNIT = "L/s"


class ModelError(ValueError):
    """Raised for invalid model parameters or inputs the model cannot evaluate."""


@dataclass(frozen=True)
class PipelineModel:
    shutoff_pressure_kpa: float = 160.0        # P0: pump dead-head pressure at 100 % speed
    pump_curve_coeff: float = 0.03             # a: pump pressure loss, kPa / (L/s)^2
    static_back_pressure_kpa: float = 10.0     # P_back: static head / downstream pressure
    pipe_resistance: float = 0.02              # k_pipe: kPa / (L/s)^2
    valve_resistance: float = 0.01             # k_valve: kPa / (L/s)^2 at full opening, scaled by 1/v^2

    def __post_init__(self) -> None:
        for f in fields(self):
            value = getattr(self, f.name)
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
                raise ModelError(f"{f.name} must be a finite number")
            if f.name == "static_back_pressure_kpa":
                if value < 0:
                    raise ModelError("static_back_pressure_kpa must be >= 0")
            elif value <= 0:
                raise ModelError(f"{f.name} must be > 0")


DEFAULT_MODEL = PipelineModel()


@dataclass(frozen=True)
class OperatingPoint:
    pressure_kpa: float
    flow_lps: float


def _check_percent(name: str, value: float) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ModelError(f"{name} must be a finite number")
    if not 0.0 <= value <= 100.0:
        raise ModelError(f"{name} must be between 0 and 100 percent")
    return float(value) / 100.0


def solve_operating_point(model: PipelineModel, pump_speed_pct: float, valve_position_pct: float) -> OperatingPoint:
    """Steady-state pressure and flow for the given pump speed and valve position (both in percent)."""
    s = _check_percent("pump_speed", pump_speed_pct)
    v = _check_percent("valve_position", valve_position_pct)

    p0, a, p_back = model.shutoff_pressure_kpa, model.pump_curve_coeff, model.static_back_pressure_kpa
    head = p0 * s * s  # pump dead-head pressure at this speed
    surplus = head - p_back
    if v == 0.0 or surplus <= 0.0:
        return OperatingPoint(pressure_kpa=head, flow_lps=0.0)

    resistance = model.pipe_resistance + model.valve_resistance / (v * v)

    def residual(q: float) -> float:
        return (head - a * q * q) - (p_back + resistance * q * q)

    q_max = math.sqrt(surplus / a)  # residual(q_max) < 0 because resistance > 0; residual(0) = surplus > 0
    # Relative tolerance only (tiny xtol): with a nearly closed valve the root is ~1e-9 L/s and an
    # absolute tolerance of 1e-12 would be a 0.1 % error, giving pressures above the pump dead-head.
    # brentq raises RuntimeError if it fails to converge; the simulator reports that as ERROR.
    flow = brentq(residual, 0.0, q_max, xtol=1e-300, rtol=1e-14, maxiter=500)
    return OperatingPoint(pressure_kpa=p_back + resistance * flow * flow, flow_lps=flow)


def closed_form_operating_point(model: PipelineModel, pump_speed_pct: float, valve_position_pct: float) -> OperatingPoint:
    """Algebraic solution of the same equations (oracle for tests; not used in the simulator path)."""
    s = _check_percent("pump_speed", pump_speed_pct)
    v = _check_percent("valve_position", valve_position_pct)
    head = model.shutoff_pressure_kpa * s * s
    surplus = head - model.static_back_pressure_kpa
    if v == 0.0 or surplus <= 0.0:
        return OperatingPoint(pressure_kpa=head, flow_lps=0.0)
    resistance = model.pipe_resistance + model.valve_resistance / (v * v)
    q2 = surplus / (model.pump_curve_coeff + resistance)
    return OperatingPoint(pressure_kpa=model.static_back_pressure_kpa + resistance * q2, flow_lps=math.sqrt(q2))
