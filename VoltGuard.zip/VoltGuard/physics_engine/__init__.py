"""VoltGuard physics engine: simplified steady-state pump/valve/pipeline model (simulation only)."""
