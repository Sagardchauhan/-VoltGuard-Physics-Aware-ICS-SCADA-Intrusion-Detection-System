"""Command-to-prediction simulator.

Takes a validated ParsedCommand plus the current pipeline settings, works out the pump and
valve settings the command would produce, predicts the steady-state pressure and flow, and
returns a SimulationResult (the Phase 2 contract).

Rules:
  * Pure and deterministic: no hidden state, same inputs -> same result. The simulator never
    updates the "current settings"; the pipeline applies a command's effect only after an ALLOW.
  * Every failure becomes a non-SUCCESS result with an error message and no predictions. A
    failure is never reported as SUCCESS, so downstream code cannot read it as "safe".
  * Writes to registers that are not mapped to a pipeline control are INVALID_INPUT.
  * Reads (FC3) request no state change; the result describes the current settings.

CLI demo:  python -m physics_engine.simulator --pump 80 --valve 30
"""

from __future__ import annotations

import argparse
import json
import math
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

if __name__ == "__main__" and __package__ in (None, ""):
    # Started as a plain file (for example with an editor's Run button) instead of `python -m ...`: Python then puts
    # this file's own folder on sys.path, so the project packages cannot be found. Use the project root instead.
    sys.path[0:1] = [str(Path(__file__).resolve().parent.parent)]

from physics_engine.pipeline_model import (DEFAULT_MODEL, FLOW_UNIT, PRESSURE_UNIT, ModelError, OperatingPoint,
                                           PipelineModel, solve_operating_point)
from physics_engine.safety_limits import evaluate_limits
from voltguard.app_logging import setup_logger
from voltguard.config import SafetyConfig, load_safety_config
from voltguard.register_map import PUMP_SPEED_REGISTER, REGISTER_NAMES, VALVE_POSITION_REGISTER
from voltguard.schemas import (FC_READ_HOLDING, FC_WRITE_MULTIPLE, FC_WRITE_SINGLE, ParsedCommand, SchemaError,
                               SimulationResult)

ROUND_DIGITS = 4  # predictions are rounded so results are stable and limit comparisons are consistent

Solver = Callable[[PipelineModel, float, float], OperatingPoint]


@dataclass(frozen=True)
class PipelineState:
    """Current control settings, in percent."""

    pump_speed: float = 50.0
    valve_position: float = 60.0


DEFAULT_STATE = PipelineState()


class InvalidInput(ValueError):
    """The command or settings cannot be simulated (maps to simulation_status INVALID_INPUT)."""


def _clean(x: float) -> float:
    return round(x, ROUND_DIGITS) + 0.0  # "+ 0.0" turns -0.0 into 0.0


def _valid_setting(name: str, value: object, config: SafetyConfig) -> float:
    if value is None:
        raise InvalidInput(f"{name} is missing")
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise InvalidInput(f"{name} must be a number")
    number = float(value)
    if not math.isfinite(number):
        raise InvalidInput(f"{name} must be finite")
    limit = getattr(config, name)
    if not limit.contains(number):
        raise InvalidInput(f"{name} {number:g} is outside the valid range {limit.minimum:g}..{limit.maximum:g} {limit.unit}")
    return number


def resolve_settings(command: ParsedCommand, state: PipelineState, config: SafetyConfig) -> tuple[float, float]:
    """Pump speed and valve position (percent) that result from applying `command` to `state`."""
    pump, valve = state.pump_speed, state.valve_position
    fc = command.function_code
    if fc == FC_READ_HOLDING:
        return pump, valve
    if fc == FC_WRITE_SINGLE:
        writes = {command.register_address: command.register_value}
    elif fc == FC_WRITE_MULTIPLE:
        values = command.register_values
        if values is None:
            raise InvalidInput("register_values is missing")
        writes = {command.register_address + i: v for i, v in enumerate(values)}
    else:
        raise InvalidInput(f"function code {fc} is not supported by the simulator")

    for address, value in writes.items():
        if address not in REGISTER_NAMES:
            raise InvalidInput(f"register {address} is not mapped to a pipeline control")
        if address == PUMP_SPEED_REGISTER:
            pump = _valid_setting("pump_speed", value, config)
        elif address == VALVE_POSITION_REGISTER:
            valve = _valid_setting("valve_position", value, config)
    return pump, valve


def _failure(command_id: str, status: str, message: str, config: SafetyConfig) -> SimulationResult:
    return SimulationResult(
        command_id=command_id, simulation_status=status, pressure_unit=config.pressure.unit,
        configured_min_pressure=config.pressure.minimum, configured_max_pressure=config.pressure.maximum,
        violations=(), error=message)


def simulate_settings(command_id: str, pump_speed: object, valve_position: object, config: SafetyConfig,
                      model: PipelineModel = DEFAULT_MODEL, solver: Solver = solve_operating_point) -> SimulationResult:
    """Predict the steady state for explicit settings. Missing/invalid/out-of-range values -> INVALID_INPUT."""
    try:
        pump = _valid_setting("pump_speed", pump_speed, config)
        valve = _valid_setting("valve_position", valve_position, config)
    except InvalidInput as exc:
        return _failure(command_id, "INVALID_INPUT", str(exc), config)

    try:
        point = solver(model, pump, valve)
        pressure, flow = point.pressure_kpa, point.flow_lps
        for name, value in (("pressure", pressure), ("flow", flow)):
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
                raise ArithmeticError(f"solver produced a non-finite {name}")
        if flow < 0 or pressure < 0:
            raise ArithmeticError("solver produced a negative pressure or flow")
        pressure, flow = _clean(pressure), _clean(flow)
        result = SimulationResult(
            command_id=command_id, simulation_status="SUCCESS", pressure_unit=config.pressure.unit,
            configured_min_pressure=config.pressure.minimum, configured_max_pressure=config.pressure.maximum,
            violations=evaluate_limits(pressure, flow, config),
            predicted_pressure=pressure, predicted_flow=flow, flow_unit=config.flow.unit)
        SimulationResult.from_dict(result.to_dict())  # never emit a result that breaks the contract
        return result
    except (ModelError, SchemaError, ArithmeticError, ValueError, RuntimeError, OverflowError, TypeError) as exc:
        return _failure(command_id, "ERROR", f"simulation failed: {type(exc).__name__}: {exc}", config)
    except Exception as exc:  # noqa: BLE001 - a crashing solver must still fail closed
        return _failure(command_id, "ERROR", f"simulation failed unexpectedly: {type(exc).__name__}", config)


def simulate_command(command: ParsedCommand, config: SafetyConfig, state: PipelineState = DEFAULT_STATE,
                     model: PipelineModel = DEFAULT_MODEL, solver: Solver = solve_operating_point) -> SimulationResult:
    """Predict the steady state that results from applying `command` to the pipeline in `state`."""
    try:
        pump, valve = resolve_settings(command, state, config)
    except InvalidInput as exc:
        return _failure(command.command_id, "INVALID_INPUT", str(exc), config)
    return simulate_settings(command.command_id, pump, valve, config, model, solver)


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Predict steady-state pressure/flow for a pump speed and valve position (simulation only).")
    ap.add_argument("--pump", type=float, required=True, help="pump speed, percent")
    ap.add_argument("--valve", type=float, required=True, help="valve position, percent")
    ap.add_argument("--id", default="CLI-001", help="command id for the result")
    ap.add_argument("--config", type=Path, default=Path(__file__).resolve().parent.parent / "config" / "safety_limits.json")
    args = ap.parse_args(argv)
    logger = setup_logger("voltguard.physics", console=False)
    try:
        config = load_safety_config(args.config)
    except ValueError as exc:
        logger.error("invalid configuration: %s", exc)
        print(f"error: invalid configuration: {exc}", file=sys.stderr)
        return 2
    result = simulate_settings(args.id, args.pump, args.valve, config)
    print(json.dumps(result.to_dict(), indent=2))
    return 0 if result.simulation_status == "SUCCESS" else 1


if __name__ == "__main__":
    sys.exit(main())
