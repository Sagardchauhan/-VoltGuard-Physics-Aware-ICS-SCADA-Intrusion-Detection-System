"""Comparison of predicted pressure/flow against the configured safety limits.

Limits are inclusive: a value exactly equal to a configured minimum or maximum is NOT a
violation. Only strictly outside values are reported.
"""

from __future__ import annotations

from voltguard.config import SafetyConfig
from voltguard.schemas import Violation


def evaluate_limits(pressure: float, flow: float, config: SafetyConfig) -> tuple[Violation, ...]:
    """Violations in a fixed order: pressure high/low, then flow high/low."""
    found: list[Violation] = []
    if pressure > config.pressure.maximum:
        found.append(Violation("PRESSURE_HIGH", config.pressure.maximum, pressure))
    elif pressure < config.pressure.minimum:
        found.append(Violation("PRESSURE_LOW", config.pressure.minimum, pressure))
    if flow > config.flow.maximum:
        found.append(Violation("FLOW_HIGH", config.flow.maximum, flow))
    elif flow < config.flow.minimum:
        found.append(Violation("FLOW_LOW", config.flow.minimum, flow))
    return tuple(found)
