"""Latency benchmark for the VoltGuard processing chain (simulated traffic only).

Measures, per command, with time.perf_counter on this machine:
  parse     - frame -> C++ parser process -> validated ParsedCommand (includes the pipe round trip)
  simulate  - physics prediction (SciPy), run in a worker thread with a timeout
  decide    - decision engine round trip (Rust process over pipes) plus the Python consistency checks
  log       - one SQLite event insert with the hash chain (commit included)
  handle    - everything the dashboard worker does for one command (handle_request, all of the above)
and, separately, the full round trip through the real worker process (JSON over stdin/stdout).

It reports percentiles and compares the p99 of `handle` with a target. The target (default 10 ms, from the
project plan) is a goal to be MEASURED, not an assumption: the result says PASS or FAIL for this machine only.

    python scripts/benchmark.py [--iterations N] [--worker-iterations N] [--target-ms 10] [--out docs/performance_results.json]
"""

from __future__ import annotations

import argparse
import json
import os
import platform
import statistics
import subprocess
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from event_logging.event_store import EventStore  # noqa: E402
from traffic_generator.generate_traffic import generate_scenarios  # noqa: E402
from voltguard.config import load_safety_config  # noqa: E402
from voltguard.decision_bridge import Decider, find_decision_engine  # noqa: E402
from voltguard.pipeline import Pipeline, find_parser_cli  # noqa: E402

CONFIG_PATH = ROOT / "config" / "safety_limits.json"
VALID_WRITE = "00010000000601060064003c"      # pump 60 %, ALLOW
UNSAFE_WRITE = "000700000006010600640064"     # pump 100 %, BLOCK
MALFORMED = "0001"                            # REJECT at the parser


def percentile(sorted_values: list[float], p: float) -> float:
    """Nearest-rank percentile of an already sorted list."""
    if not sorted_values:
        raise ValueError("no samples")
    if not 0 < p <= 100 or p != int(p):
        raise ValueError("p must be an integer in 1..100")
    rank = max(1, (int(p) * len(sorted_values) + 99) // 100)          # ceil(p * n / 100) in integer arithmetic
    return sorted_values[min(rank, len(sorted_values)) - 1]


def summarise(samples_ms: list[float]) -> dict[str, float]:
    s = sorted(samples_ms)
    return {"n": len(s), "min": s[0], "mean": statistics.fmean(s), "p50": percentile(s, 50), "p95": percentile(s, 95),
            "p99": percentile(s, 99), "max": s[-1]}


def machine_info() -> dict[str, object]:
    cpu = "unknown"
    try:
        for line in Path("/proc/cpuinfo").read_text().splitlines():
            if line.startswith("model name"):
                cpu = line.split(":", 1)[1].strip()
                break
    except OSError:
        cpu = platform.processor() or "unknown"
    load = os.getloadavg() if hasattr(os, "getloadavg") else None
    return {"cpu": cpu, "cpu_count": os.cpu_count(), "python": platform.python_version(), "os": platform.platform(),
            "load_average_at_start": load}


def run_in_process(iterations: int, warmup: int, frames: list[bytes], label: str) -> dict[str, object]:
    cli, engine = find_parser_cli(), find_decision_engine()
    if cli is None or engine is None:
        raise SystemExit("the parser CLI and the decision engine must be built first (see docs/installation.md)")
    config = load_safety_config(CONFIG_PATH)
    from voltguard.worker import handle_request

    stages: dict[str, list[float]] = {k: [] for k in ("parse", "simulate", "decide", "log", "handle")}
    with tempfile.TemporaryDirectory() as tmp, Pipeline(config, parser_argv=[str(cli)]) as pipe:
        decider = Decider(config, [str(engine), "--config", str(CONFIG_PATH)])
        store = EventStore(Path(tmp) / "events.db")
        try:
            # Instrument the two collaborators handle_request calls, without changing what they do.
            real_decide, real_record = decider.decide, store.record

            def timed_decide(result):
                t0 = time.perf_counter()
                out = real_decide(result)
                stages["decide"].append((time.perf_counter() - t0) * 1000)
                return out

            def timed_record(*a, **k):
                t0 = time.perf_counter()
                out = real_record(*a, **k)
                stages["log"].append((time.perf_counter() - t0) * 1000)
                return out

            decider.decide, store.record = timed_decide, timed_record
            real_process = pipe.process_frame

            def timed_process(command_id, frame):
                r = real_process(command_id, frame)
                if r.parse_ms or r.simulate_ms:
                    stages["parse"].append(r.parse_ms)
                    if r.simulation is not None:
                        stages["simulate"].append(r.simulate_ms)
                return r

            pipe.process_frame = timed_process
            for i in range(warmup + iterations):
                frame = frames[i % len(frames)]
                req = {"op": "process", "command_id": f"B-{i}", "frame_hex": frame.hex()}
                t0 = time.perf_counter()
                reply = handle_request(pipe, [], req, store, decider)
                elapsed = (time.perf_counter() - t0) * 1000
                assert reply is not None and reply["type"] == "result" and reply["logged"] is True, reply
                if i == warmup - 1:
                    for v in stages.values():
                        v.clear()
                if i >= warmup:
                    stages["handle"].append(elapsed)
        finally:
            decider.close()
            store.close()
    return {"workload": label, "iterations": iterations, "warmup": warmup,
            "stages_ms": {k: summarise(v) for k, v in stages.items() if v}}


def run_worker_round_trip(iterations: int, warmup: int, frames: list[bytes]) -> dict[str, object]:
    cli = find_parser_cli()
    with tempfile.TemporaryDirectory() as tmp:
        t_start = time.perf_counter()
        proc = subprocess.Popen([sys.executable, "-m", "voltguard.worker", "--log-dir", tmp, "--parser-cli", str(cli)], cwd=ROOT,
                                stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
        try:
            ready = json.loads(proc.stdout.readline())
            assert ready["type"] == "ready", ready
            startup_ms = (time.perf_counter() - t_start) * 1000
            samples = []
            first_ms = None
            for i in range(warmup + iterations):
                req = {"op": "process", "command_id": f"W-{i}", "frame_hex": frames[i % len(frames)].hex()}
                t0 = time.perf_counter()
                proc.stdin.write((json.dumps(req) + "\n").encode())
                proc.stdin.flush()
                reply = json.loads(proc.stdout.readline())
                elapsed = (time.perf_counter() - t0) * 1000
                assert reply["type"] == "result" and reply["command_id"] == f"W-{i}", reply
                if i == 0:
                    first_ms = elapsed
                if i >= warmup:
                    samples.append(elapsed)
        finally:
            try:
                proc.stdin.close()
            except OSError:
                pass
            try:
                proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                proc.kill()
    return {"startup_to_ready_ms": startup_ms, "first_request_ms": first_ms, "iterations": iterations, "round_trip_ms": summarise(samples)}


def render_markdown(results: dict[str, object]) -> str:
    target = results["target_ms"]
    lines = ["| Workload | Stage | n | mean | p50 | p95 | p99 | max |", "|---|---|---|---|---|---|---|---|"]
    for wl in results["in_process"]:
        for stage, s in wl["stages_ms"].items():
            lines.append(f"| {wl['workload']} | {stage} | {s['n']} | {s['mean']:.3f} | {s['p50']:.3f} | {s['p95']:.3f} | {s['p99']:.3f} | {s['max']:.3f} |")
    w = results["worker"]
    s = w["round_trip_ms"]
    lines.append(f"| real worker process | round trip | {s['n']} | {s['mean']:.3f} | {s['p50']:.3f} | {s['p95']:.3f} | {s['p99']:.3f} | {s['max']:.3f} |")
    lines.append("")
    lines.append(f"Worker start to `ready`: {w['startup_to_ready_ms']:.0f} ms; first request after `ready`: {w['first_request_ms']:.2f} ms (one-off). Times are milliseconds.")
    if results.get("background_load"):
        lines.append(f"Measured with {results['background_load']} busy-loop background process(es) on {results['machine']['cpu_count']} CPU(s).")
    lines.append("")
    for v in results["verdicts"]:
        lines.append(f"- {v['workload']}: p99 of `handle` = {v['p99_ms']:.3f} ms against a {target} ms target -> **{'PASS' if v['pass'] else 'FAIL'}**")
    return "\n".join(lines)


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--iterations", type=int, default=1500)
    ap.add_argument("--worker-iterations", type=int, default=500)
    ap.add_argument("--warmup", type=int, default=100)
    ap.add_argument("--target-ms", type=float, default=10.0)
    ap.add_argument("--background-load", type=int, default=0, help="start N busy-loop processes while measuring (stress run)")
    ap.add_argument("--out", type=Path, default=ROOT / "docs" / "performance_results.json")
    args = ap.parse_args(argv)
    if args.iterations < 20 or args.worker_iterations < 20 or args.warmup < 1:
        ap.error("need at least 20 iterations and 1 warm-up")

    burners = [subprocess.Popen([sys.executable, "-c", "while True: pass"]) for _ in range(max(0, args.background_load))]
    try:
        return _run(args)
    finally:
        for b in burners:
            b.kill()
            b.wait()


def _run(args: argparse.Namespace) -> int:
    scenario_frames = [bytes.fromhex(s["frame_hex"]) for s in generate_scenarios()]
    workloads = [("valid write (ALLOW)", [bytes.fromhex(VALID_WRITE)]),
                 ("unsafe write (BLOCK)", [bytes.fromhex(UNSAFE_WRITE)]),
                 ("malformed frame (REJECT)", [bytes.fromhex(MALFORMED)]),
                 ("all 27 scenarios, cycled", scenario_frames)]
    results: dict[str, object] = {"machine": machine_info(), "target_ms": args.target_ms, "background_load": args.background_load, "in_process": []}
    for label, frames in workloads:
        print(f"measuring: {label} ...", file=sys.stderr, flush=True)
        results["in_process"].append(run_in_process(args.iterations, args.warmup, frames, label))
    print("measuring: real worker round trip ...", file=sys.stderr, flush=True)
    results["worker"] = run_worker_round_trip(args.worker_iterations, args.warmup, scenario_frames)
    results["verdicts"] = [{"workload": wl["workload"], "p99_ms": wl["stages_ms"]["handle"]["p99"],
                            "pass": wl["stages_ms"]["handle"]["p99"] <= args.target_ms} for wl in results["in_process"]]
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8")
    print(render_markdown(results))
    return 0


if __name__ == "__main__":
    sys.exit(main())
