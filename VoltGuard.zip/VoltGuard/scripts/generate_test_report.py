"""Run every VoltGuard test suite and write a test report from the ACTUAL results.

    python scripts/generate_test_report.py [--output docs/test_report.md] [--no-sanitizer] [--no-dashboard]

Nothing in the results tables is typed by hand: counts and pass/fail come from pytest's JUnit XML,
ctest and cargo output. Each audit item names the tests that cover it; the item PASSES only if every
named test exists, ran (was not skipped) and passed. Exit code 0 only if everything passed.
All commands are fixed argument lists; no untrusted input reaches a shell.
"""

from __future__ import annotations

import argparse
import os
import datetime
import platform
import re
import shutil
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

# (audit area, item, what is expected, [test function names, all parametrisations must pass])
AUDIT_ITEMS = [
    ("Parser", "Supported messages (FC 3, 6, 16) are parsed correctly",
     "Every field matches the fixture, Scapy-built round trips and Scapy's own dissector",
     ["test_parsed_fields_match_fixture", "test_round_trip_random_valid_requests_recover_exact_fields",
      "test_cpp_parser_agrees_with_scapy_dissector_on_valid_frames", "test_parser_output_satisfies_phase2_schema"]),
    ("Parser", "Valid and invalid payloads",
     "Accept/reject outcome and reason match the fixture and an independent reference parser on 6,000+ mutated frames",
     ["test_parse_outcome_matches_fixture", "test_cpp_parser_agrees_with_independent_reference_parser"]),
    ("Parser", "Message lengths and field validation",
     "Wrong header, length, protocol id, quantity or byte count is rejected with a stable error code",
     ["test_rejections_carry_stable_error_codes", "test_scapy_built_frame_with_corrupted_length_is_rejected",
      "test_every_valid_frame_with_a_byte_removed_or_added_is_rejected"]),
    ("Parser", "Unsupported function codes",
     "Valid frames with function codes other than 3, 6, 16 are rejected as UNSUPPORTED_FUNCTION_CODE",
     ["test_parse_outcome_matches_fixture", "test_rejections_carry_stable_error_codes"]),
    ("Parser", "Error handling and malformed packets do not crash",
     "Garbage, huge lines and bad ids give a rejection, later lines are still processed, nothing untrusted is echoed",
     ["test_bad_lines_do_not_stop_processing", "test_binary_garbage_input_cannot_crash_parser",
      "test_huge_line_is_rejected_with_bounded_behaviour", "test_garbage_never_echoed_into_output",
      "test_command_id_with_shell_metacharacters_is_rejected", "test_empty_stdin_is_fine"]),
    ("Physics", "Safe baseline conditions",
     "Normal commands predict no violation; scenario outcomes match their pinned expectations",
     ["test_normal_operation", "test_scenario_violations_match_pinned_expectations",
      "test_scenario_intent_labels_agree_with_the_model"]),
    ("Physics", "Predicted pressure-limit violations",
     "Upper and lower pressure violations are reported with the configured limit",
     ["test_upper_pressure_limit_violation", "test_lower_pressure_limit_violation", "test_limits_are_inclusive",
      "test_prediction_exactly_on_limit_is_allowed_and_a_hair_over_is_not"]),
    ("Physics", "Invalid and missing inputs",
     "Out-of-range, non-numeric, NaN/inf, missing values and unmapped registers give INVALID_INPUT with no predictions",
     ["test_invalid_pump_input", "test_invalid_valve_position", "test_missing_values",
      "test_invalid_commands_are_invalid_input", "test_partial_invalid_multi_write_applies_nothing"]),
    ("Physics", "Simulation failure fails closed",
     "Solver exceptions and non-finite/negative output give ERROR, never SUCCESS, with no predictions",
     ["test_solver_failures_fail_closed", "test_failure_is_never_reported_as_success_or_safe"]),
    ("Physics", "Deterministic results for deterministic inputs",
     "Identical inputs give identical results; inputs are not mutated",
     ["test_identical_inputs_give_identical_results", "test_simulation_does_not_mutate_its_inputs",
      "test_loading_is_deterministic"]),
    ("Physics", "Numerical correctness of the model",
     "The numeric solver agrees with the closed-form solution and monotonic physical trends hold",
     ["test_solver_matches_closed_form_over_grid", "test_operating_point_lies_on_both_curves",
      "test_flow_and_pressure_rise_with_pump_speed", "test_closing_valve_raises_pressure_and_lowers_flow",
      "test_extreme_tiny_valve_opening_is_numerically_stable"]),
    ("Integration", "Parser output matches the simulation input schema",
     "Every parsed command validates as ParsedCommand, every simulation result as SimulationResult, and end-to-end results equal a direct simulation",
     ["test_every_fixture_message_flows_end_to_end", "test_parser_output_matches_simulator_input_schema",
      "test_end_to_end_outcomes_match_pinned_physics_expectations"]),
    ("Integration", "Simulation results return to the application with the right command id",
     "Ids stay attached through parser and simulator, in order, also with concurrent callers and after unsolicited parser output",
     ["test_command_ids_stay_associated_with_results_in_order", "test_concurrent_callers_get_their_own_results",
      "test_unsolicited_extra_output_cannot_desynchronise_later_requests", "test_misbehaving_parser_output_fails_closed_then_recovers"]),
    ("Integration", "Component failures and timeouts fail closed and recover",
     "Hung, crashed, missing or lying parsers and a hung or crashing simulator give a recorded failure with no prediction; the next request works",
     ["test_parser_timeout_fails_closed_within_bounded_time_and_recovers", "test_parser_crash_fails_closed_and_recovers",
      "test_parser_dying_between_requests_is_detected", "test_missing_parser_executable_is_a_recorded_failure",
      "test_simulator_timeout_fails_closed_quickly", "test_simulator_exception_is_reported_as_simulation_error_not_a_crash",
      "test_failure_results_never_look_like_a_safe_prediction", "test_cli_reports_component_failure_with_exit_1"]),
    ("Integration", "Malformed messages cannot crash the application",
     "3,000 mutated frames, invalid ids, non-bytes and oversized frames produce results, never exceptions or parser restarts",
     ["test_malformed_traffic_never_crashes_the_application", "test_invalid_command_id_is_a_recorded_failure",
      "test_non_bytes_frame_is_a_recorded_failure", "test_oversized_frame_rejected_before_reaching_the_parser",
      "test_rejected_frames_never_reach_the_simulator"]),
    ("Integration", "No shell commands are built from packet data",
     "The parser is started once from a fixed argument list with shell=False; packet data reaches it only as a validated id and hex digits",
     ["test_parser_is_launched_without_a_shell_from_a_fixed_argument_list",
      "test_packet_data_only_reaches_the_child_as_validated_id_and_hex"]),
    ("Contracts", "Message schemas reject invalid messages",
     "ParsedCommand, SimulationResult and DecisionResult validators enforce types, ranges and cross-field rules",
     ["test_valid_commands_round_trip", "test_unsupported_function_code", "test_failure_must_not_carry_predictions",
      "test_contradictory_violation_rejected", "test_unknown_decision_rejected", "test_schema_enums_match_python"]),
]

# Findings recorded while building Phases 4-6 (historical facts, not re-derived by this script).
FINDINGS = [
    ("Phase 2", "Command-id regex accepted a trailing newline (\"id\\n\") because `$` matches before a final newline.",
     "Switched to fullmatch; regression test added."),
    ("Phase 4", "Mutation check: removing the address-range check survived the Python parser tests (no fixture frame near address 65535).",
     "Added scenario malformed_fc3_range_overflow; the mutant is now caught."),
    ("Phase 5", "Scenario labels were wrong: normal_pump_40 predicts 19.58 kPa (below the 20 kPa minimum); \"pump 100 + valve closed\" never closed the valve.",
     "Relabelled/rebuilt scenarios and pinned them by test."),
    ("Phase 5", "Solver tolerance too coarse for a nearly closed valve: predicted 160.018 kPa, above the 160 kPa pump dead-head.",
     "Switched to a relative tolerance; 200,000-point check agrees with the closed form to ~1e-13."),
    ("Phase 7", "First run of the 53 integration tests passed completely, so their strength was unproven. Mutation check on the bridge: 11 deliberate defects (no id check, no stale-output drain, no schema check, timeout without kill, no frame cap, no id validation, ignored simulator timeout, shell=True, rejected frames reaching the simulator, ...).",
     "10 caught. The survivor removed one of two overlapping child-liveness guards; removing both fails 2 tests, so it is defence in depth, not a gap. A CLI test that never exercised exit code 1 was rewritten to use a hanging parser."),
    ("Phase 6", "Scapy 2.8.0 cannot dissect function-16 writes of 101..123 registers (returns a raw payload) although the frames are byte-identical to an independent encoder's.",
     "Third-party cross-check excludes exactly that case (asserted by the test); those frames are covered by the reference parser and round-trip tests."),
]

LIMITATIONS = [
    "Dashboard tests were run headless (Qt offscreen platform) on Linux with Qt 6.4.2 only; rendering on a real display, high-DPI screens and Windows are untested. Screenshots in docs/screenshots come from the offscreen platform. The responsiveness check is a timing test with generous bounds, not a benchmark.",
    "Fault injection uses a fake parser that I wrote; it covers the failure modes I thought of, not every way a real child process can fail. A simulation that exceeds its timeout is abandoned in a daemon thread and cannot be killed.",
    "Event log: hash-chain tamper-evidence only (tail truncation and full recomputation are not detected), unbounded growth, single writer (docs/event_logging.md). Decisions are logged from schema v2 (Phase 11); older rows have none.",
    "The decision engine is a rule-based policy over SIMULATED data from an invented physics model. ALLOW means \"the simulated prediction is within the example limits and every consistency check passed\", not that an action is safe on real equipment. It is wired into the worker and dashboard (Phase 11), but allowed commands are not applied to the simulated plant state and nothing is forwarded anywhere.",
    "Decision-engine mutation checks (scratch copy, 32 mutants) are described in CHANGELOG.md and are not re-run by this script.",
    "The parser is verified against my own generator, an independent reference parser I wrote, and Scapy's dissector (which cannot decode FC16 writes of 101-123 registers). It has not been run against captured third-party Modbus traffic.",
    "C++ has only been compiled with GCC 13 on Linux; MSVC/Windows is untested.",
    "The physics model is an invented steady-state approximation with unvalidated parameters (docs/methodology.md).",
    "The PDF report needs the optional reportlab package (tested with reportlab 5.0.1 and read back with pypdf 6.17.0 only); the PDF layout was not inspected on other viewers. Export of very large logs (more than 100,000 rows) is truncated by design and was only tested with small limits.",
    "scripts/demo.ps1 (Windows demo launcher) was written to mirror scripts/demo.sh and has never been run. The demo guide timings and screenshots come from the Linux development machine.",
    "Documentation tests check links, files and command names, not whether a sentence is true; the docs were checked by hand against the code and the screenshots only on Linux / Qt 6.4.2.",
    "End-to-end process-killing tests run on Linux only (they read /proc); Windows process handling is untested. See docs/integration_testing.md.",
    "Performance numbers (docs/performance.md) come from one run per condition on one 2-CPU virtual machine and are not re-measured by this script; the 10 ms target is met on the idle machine but not under CPU stress.",
    "Mutation-testing results quoted in CHANGELOG.md were obtained on scratch copies during development and are not re-run by this script.",
]


EVENT_LOG_AUDIT = [
    ("Event log", "Every command is persisted and can be queried newest-first with filters", "rows round-trip, survive restart",
     ["test_record_and_query_roundtrip", "test_query_is_newest_first_and_filters_work", "test_chain_continues_across_reopen",
      "test_worker_logs_every_command_and_serves_history"]),
    ("Event log", "Hostile or oversized content is stored as capped data, never executed", "table intact, fields capped",
     ["test_hostile_text_is_stored_as_data_and_never_executed", "test_long_and_control_character_fields_are_capped_and_cleaned",
      "test_huge_json_payload_is_replaced_by_a_marker", "test_query_rejects_invalid_arguments"]),
    ("Event log", "Edits, deletions, swaps and forged hashes are detected by the hash chain", "verify() fails naming the row",
     ["test_verify_detects_edits_and_deletions", "test_every_stored_field_is_covered_by_the_hash",
      "test_deletion_is_reported_as_a_broken_chain", "test_swapping_two_rows_is_detected"]),
    ("Event log", "A logging failure is reported, never silent, and never alters the processing result", "logged=false, result unchanged",
     ["test_record_never_raises_and_reports_failure_after_close", "test_unserialisable_result_is_reported_and_leaves_no_partial_row",
      "test_unavailable_store_reports_instead_of_hiding", "test_worker_keeps_processing_but_flags_an_unusable_event_log",
      "test_unopenable_path_raises_event_store_error", "test_foreign_or_future_schema_is_refused"]),
    ("Event log", "Known limitation is pinned by a test (tail truncation is NOT detected)", "documented, asserted",
     ["test_documented_limit_tail_truncation_is_not_detected"]),
]

RUST_AUDIT = [
    ("Decision engine", "Every real pipeline scenario gets the decision its design intends (6 ALLOW / 5 BLOCK / 16 REJECT)", "library and CLI agree with intent",
     ["every_scenario_gets_the_decision_its_design_intends", "scenario_outcomes_are_not_all_the_same", "cli_decides_every_fixture_line_in_order"]),
    ("Decision engine", "Malformed, contradictory or hostile results are never ALLOWED (table of 60+ cases and 60,000 fuzzed inputs)", "no ALLOW, no panic",
     ["contradictory_or_malformed_results_are_never_allowed", "fuzz_never_panics_and_never_allows_an_implausible_input"]),
    ("Decision engine", "Limits are inclusive; values just outside are blocked", "boundary behaviour",
     ["limits_are_inclusive", "just_outside_limits_is_blocked", "block_decisions_carry_the_predicted_pressure_and_the_limit"]),
    ("Decision engine", "Bad input lines, over-long lines and invalid configuration fail closed", "error lines / exit 2, no decision",
     ["cli_answers_bad_lines_with_errors_and_keeps_going", "cli_survives_an_overlong_line_and_still_answers_the_next_one",
      "cli_refuses_to_start_without_a_valid_configuration", "config_rejects_bad_values", "unusable_command_ids_give_no_decision"]),
    ("Decision engine", "Untrusted text is sanitised and reasons stay within the contract length", "printable ASCII, <= 512",
     ["text_from_the_input_is_sanitised_inside_reasons", "reason_is_never_longer_than_the_contract_allows", "reason_helper_truncates_and_sanitises"]),
    ("Decision engine", "Documented policy choice pinned: reads are not blocked by predicted limits", "read ALLOW even if already outside limits",
     ["reads_are_not_blocked_by_predicted_limits_by_design"]),
]

BRIDGE_AUDIT = [
    ("Decision bridge", "Missing, hung, crashed or garbling engine never yields ALLOW (REJECT, source fail_closed)", "REJECT with error code",
     ["test_missing_engine_rejects_even_a_perfect_command", "test_broken_engine_output_fails_closed", "test_hung_engine_times_out_and_is_restarted_for_the_next_request",
      "test_a_crashed_engine_is_restarted", "test_no_failure_mode_ever_yields_allow", "test_junk_input_is_rejected_never_allowed_and_never_raises",
      "test_unserialisable_or_oversized_input_fails_closed", "test_multiline_text_inside_a_result_cannot_split_the_request"]),
    ("Decision bridge", "Second opinion: ALLOW/BLOCK for non-simulated results refused; ALLOW outside the limits vetoed", "DECISION_INCONSISTENT",
     ["test_allow_for_a_rejected_or_failed_result_is_refused", "test_second_check_vetoes_an_allow_for_values_outside_the_limits",
      "test_a_boundary_value_exactly_at_the_limit_is_not_vetoed", "test_block_for_a_non_simulated_result_is_refused_but_a_cautious_block_is_kept",
      "test_reject_from_the_engine_is_always_accepted"]),
    ("Decision bridge", "Real engine gives every scenario its designed decision through the worker", "6 ALLOW / 5 BLOCK / 16 REJECT",
     ["test_real_engine_gives_every_scenario_its_designed_decision", "test_every_scenario_gets_its_designed_decision_through_the_worker",
      "test_engine_process_is_reused_across_requests", "test_a_blocked_command_is_logged_with_both_severity_and_decision"]),
    ("Decision bridge", "Worker: no engine => all REJECT; faulty engine never allows an unsafe command", "no ALLOW",
     ["test_without_a_decision_engine_every_command_is_rejected", "test_a_faulty_engine_can_never_make_the_worker_allow_an_unsafe_command",
      "test_handle_request_without_a_decider_fails_closed"]),
    ("Decision bridge", "Log-before-allow: an unusable event log turns ALLOW into REJECT; BLOCK/REJECT unaffected", "REJECT EVENT_LOG_UNAVAILABLE",
     ["test_an_unusable_event_log_turns_allow_into_reject_but_leaves_block_alone", "test_with_logging_deliberately_off_an_allow_stays_an_allow",
      "test_the_allow_is_stored_before_it_is_released"]),
    ("Event log", "Schema v2 stores decisions in the hash chain; v1 databases migrate and still verify; relabelling is detected", "verify ok / tamper detected",
     ["test_decision_is_stored_and_covered_by_the_hash", "test_rows_without_a_decision_store_nulls_and_invalid_values_are_dropped",
      "test_a_v1_database_is_migrated_and_still_verifies", "test_migrated_rows_cannot_be_altered_or_given_decisions"]),
]


SAFETY_AUDIT = [
    ("System safety", "Mutated and random frames through the real parser, physics and engine are never ALLOWed unless an independent oracle agrees", "no unjustified ALLOW; all three outcomes reached",
     ["test_mutated_frames_are_never_allowed_unless_an_independent_oracle_agrees", "test_random_binary_garbage_is_never_allowed"]),
    ("System safety", "Every pump and valve value 0..100 (and beyond) gets the decision the limits imply", "ALLOW inside, BLOCK outside, REJECT above 100",
     ["test_every_value_of_both_writable_registers_matches_the_independent_limit_check"]),
    ("System safety", "Fault matrix (13 parser faults x 7 solver faults x engine modes): ALLOW only if every component worked", "no ALLOW with any fault",
     ["test_fault_matrix_allow_requires_every_component_to_work", "test_an_unsafe_command_is_never_allowed_whatever_the_engine_does"]),
    ("System safety", "Event-log failures (failed, raising or junk-returning store) turn ALLOW into REJECT", "REJECT EVENT_LOG_UNAVAILABLE",
     ["test_an_allow_needs_its_event_to_be_stored_first", "test_an_event_store_that_raises_or_returns_junk_cannot_produce_an_unlogged_allow"]),
    ("System safety", "17 corrupt configurations and a missing file stop the worker (exit 2, only a fatal message); limits really change decisions", "exit 2 / BLOCK under tighter limits",
     ["test_a_corrupt_configuration_stops_the_worker_before_it_can_decide_anything", "test_a_missing_configuration_file_stops_the_worker",
      "test_limits_in_a_different_configuration_change_the_decision_not_just_the_label"]),
    ("System safety", "Hostile worker input, mid-line EOF and a hung engine are survived with bounded delay", "errors, no ALLOW, clean exit",
     ["test_the_worker_survives_hostile_lines_and_keeps_ids_matched", "test_closing_stdin_in_the_middle_of_a_session_ends_the_worker_cleanly",
      "test_a_hung_decision_engine_costs_a_bounded_time_per_command"]),
]


BENCH_AUDIT = [
    ("Performance", "Benchmark arithmetic (nearest-rank percentiles, summaries) is correct and the script gives complete results with an honest PASS/FAIL verdict", "no speed asserted",
     ["test_percentiles_use_the_nearest_rank_method", "test_percentile_rejects_nonsense", "test_summary_statistics_are_consistent",
      "test_a_short_run_produces_complete_results_and_an_honest_verdict", "test_too_few_iterations_are_refused"]),
]


EXPORT_AUDIT = [
    ("Export", "CSV and JSON contain every event oldest-first with documented columns; truncation, filters and the integrity result are reported", "27 rows / 6 ALLOW 5 BLOCK 16 REJECT",
     ["test_csv_has_every_event_oldest_first_with_the_documented_columns", "test_json_export_carries_the_notice_the_integrity_result_and_every_row",
      "test_truncation_is_reported_never_silent", "test_severity_filter_and_unknown_severity", "test_an_empty_log_exports_a_valid_header_only_file"]),
    ("Export", "Hostile text cannot become a spreadsheet formula (CSV) or markup (PDF) and survives JSON unchanged", "neutralised / literal",
     ["test_text_that_a_spreadsheet_would_execute_is_neutralised_in_csv", "test_numbers_are_never_prefixed_but_text_is", "test_a_negative_prediction_stays_a_number_in_the_csv",
      "test_hostile_text_survives_the_json_round_trip_unchanged", "test_markup_in_logged_text_is_printed_literally_not_interpreted"]),
    ("Export", "Files are never overwritten by default (also under a race), failures leave no partial file, bad targets are refused", "no data loss",
     ["test_an_existing_file_is_never_replaced_unless_asked", "test_a_file_that_appears_during_the_export_is_not_replaced",
      "test_a_failure_in_the_middle_leaves_no_file_and_no_temporary_file", "test_bad_targets_are_refused_before_anything_is_written",
      "test_a_folder_or_symlink_target_is_refused"]),
    ("Export", "A tampered log is still exported but labelled FAILED; an unavailable log refuses", "verified=false / refusal",
     ["test_a_tampered_log_is_still_exported_but_labelled_failed", "test_an_unavailable_store_refuses_to_export", "test_cli_exit_code_reports_a_failed_integrity_check"]),
    ("Export", "Optional PDF report states the facts and limitations, shows a failed integrity check, is bounded, and is refused cleanly without reportlab", "text found in the PDF",
     ["test_the_pdf_states_the_facts_and_the_limitations", "test_a_failed_integrity_check_is_printed_in_the_pdf", "test_a_large_log_gives_a_truncated_pdf_that_says_so",
      "test_without_reportlab_the_pdf_is_refused_cleanly_and_other_formats_still_work"]),
    ("Export", "Worker export op and CLI validate requests and report what they did", "ok/ok=false replies, exit codes",
     ["test_the_worker_exports_and_reports_what_it_did", "test_the_worker_refuses_bad_export_requests_with_ok_false", "test_the_worker_never_overwrites_unless_told_to",
      "test_a_real_worker_process_exports_the_log_it_wrote", "test_cli_exports_and_refuses"]),
]


E2E_AUDIT = [
    ("Integration", "Generated traffic flows through worker, parser, simulation, engine, log and export; log, replies and traffic file agree row by row", "27 rows, 6/5/16",
     ["test_generated_scenarios_flow_through_every_component_to_the_export", "test_the_pipeline_cli_output_gives_the_same_decisions_through_the_engine_cli"]),
    ("Integration", "A random command stream never yields an unjustified ALLOW end to end", "oracle agrees, 250 verified rows",
     ["test_a_random_command_stream_never_produces_an_unjustified_allow_end_to_end"]),
    ("Integration", "Sessions continue one verified chain; kill -9 of the worker never loses an ALLOW that was released", "chain verifies, allowed rows present",
     ["test_two_sessions_on_one_database_continue_one_verified_chain", "test_killing_the_worker_never_loses_an_allow_that_was_released"]),
    ("Integration", "Killed parser/engine processes are replaced; repeated kills during a burst never cause an unsafe ALLOW", "no unsafe ALLOW, refusals observed",
     ["test_a_child_killed_between_commands_is_replaced_and_nothing_unsafe_is_allowed", "test_children_killed_repeatedly_during_a_burst_never_cause_an_unsafe_allow",
      "test_both_children_killed_at_once_is_still_fail_closed_and_recovers"]),
    ("Integration", "No parser or engine process outlives the worker (normal exit or kill -9)", "no orphans",
     ["test_closing_the_worker_leaves_no_orphaned_children", "test_a_killed_worker_does_not_leave_children_running_forever"]),
]


PREFLIGHT_AUDIT = [
    ("Demo readiness", "The pre-demo check reports READY on a working installation without touching the real event log, and runs a safe, unsafe and malformed command through the real components", "ALLOW / BLOCK / REJECT, 3 events, chain verifies",
     ["test_a_working_installation_is_ready_and_the_real_event_log_is_untouched"]),
    ("Demo readiness", "The pre-demo check says NOT READY when the engine misbehaves (allows everything, blocks everything, crashes, hangs, garbles), or the parser, engine, dashboard or a package is missing, or the worker cannot start", "exit 1, FAIL lines",
     ["test_a_misbehaving_decision_engine_makes_the_check_fail", "test_a_missing_parser_fails_and_skips_the_end_to_end_run", "test_a_missing_decision_engine_fails_and_says_why",
      "test_a_missing_dashboard_fails_unless_explicitly_allowed", "test_a_missing_python_package_is_reported", "test_a_worker_that_cannot_be_started_is_reported_not_raised"]),
    ("Demo readiness", "A reply passes only with the wanted decision AND a confirmed log write; the stored log passes only when verified and complete", "strict judgement",
     ["test_a_reply_passes_only_with_the_wanted_decision_and_a_confirmed_log_write", "test_the_stored_log_passes_only_when_verified_and_complete"]),
    ("Demo readiness", "The dashboard `--event-db` option puts a headless run's 27 events into a fresh file and leaves the default log alone", "27 rows in the given file",
     ["test_the_dashboard_event_db_option_gives_a_fresh_log_and_leaves_the_default_one_alone"]),
]


DIRECT_RUN_AUDIT = [
    ("Usability", "Every entry-point module also starts when run as a plain file (an editor's Run button) from another folder without PYTHONPATH", "6 files start; main.py runs to completion; generator writes its file",
     ["test_the_file_starts_when_run_directly_from_another_folder", "test_main_runs_to_completion_when_started_as_a_file",
      "test_the_traffic_generator_writes_a_file_when_started_directly"]),
]


DOCS_AUDIT = [
    ("Documentation", "Every relative link and image in the README and docs resolves; all five screenshots exist, are PNG files and appear in the user guide", "no dead links",
     ["test_every_relative_link_and_image_resolves", "test_all_five_screenshots_exist_are_real_pngs_and_are_used_by_the_user_guide"]),
    ("Documentation", "Commands and paths named in the docs exist; entry documents keep the safety notice and do not describe finished parts as planned", "modules importable, notice present",
     ["test_python_modules_named_in_docs_exist", "test_paths_in_the_readme_layout_exist", "test_readme_and_user_guide_keep_the_safety_notice",
      "test_the_entry_documents_do_not_describe_finished_parts_as_planned"]),
]


CONTRACT_AUDIT = [
    ("Decision engine", "Rust output satisfies the Python DecisionResult validator and the engine's register map equals the Python one", "contract and register map agree",
     ["test_every_engine_reply_satisfies_the_python_decision_contract", "test_engine_register_constants_match_the_python_register_map",
      "test_block_decisions_report_prediction_and_limit_exactly"]),
    ("Decision engine", "Results produced under different limits are refused; hostile text never forges a decision", "REJECT",
     ["test_results_made_under_other_limits_are_never_allowed", "test_engine_output_never_echoes_raw_hostile_text",
      "test_engine_exits_nonzero_and_prints_nothing_for_an_invalid_config"]),
    ("Decision engine", "The committed pipeline-result fixture matches what the real pipeline produces now", "--check passes",
     ["test_fixture_is_current", "test_fixture_covers_every_scenario_and_intent"]),
]

DASHBOARD_AUDIT = [
    ("Dashboard", "GUI event loop stays responsive while a worker request is pending", "ticker gap < 400 ms",
     ["eventLoopStaysResponsiveWhileAWorkerRequestIsPending"]),
    ("Dashboard", "Hung, crashed, garbled or oversized worker output is shown as a failure, never as a result", "failure records / Failed state",
     ["hangingWorkerTimesOutAndPendingFails", "crashingWorkerFailsPending", "garbageAndUnexpectedIdAreProtocolErrors",
      "oversizedLineFailsTheWorker", "invalidWorkerReplyIsAFailureNotAResult", "crashedWorkerDisablesControlsAndShowsFailure"]),
    ("Dashboard", "Invalid or hostile hex input is refused before anything is sent", "no row, nothing pending",
     ["invalidHexIsRefusedBeforeSending", "controlsAreDisabledUntilTheWorkerIsReady"]),
    ("Dashboard", "Every scenario is classified and shows the decision its design intends (6 ALLOW / 5 BLOCK / 16 REJECT)", "6 ok / 5 violation / 16 rejected; decisions tallied",
     ["runAllScenariosClassifiesEveryResult", "everyCommandShowsTheDecisionItsDesignIntends", "decisionIsShownExactlyAsReceived",
      "modelShowsTheDecisionAndCountsEachKind"]),
    ("Dashboard", "Without a working decision engine the dashboard shows only REJECT (fail closed); failures are never ALLOW", "0 ALLOW, all REJECT",
     ["withoutADecisionEngineEveryCommandIsRejected", "aHungDecisionEngineNeverProducesAnAllow", "aFailureRecordIsAlwaysARejectNeverAnAllow",
      "aFailClosedRejectIsAccepted"]),
    ("Dashboard", "Graphs plot only simulated predictions, show the configured limit lines, keep out-of-limit values visible and stay bounded", "limit lines at the configured values; 6 ALLOW + 5 BLOCK points",
     ["limitLinesAppearOnlyOnceTheLimitsAreKnownAndMatchTheConfiguration", "onlyCommandsWithAPredictionArePlotted",
      "theAxisAlwaysShowsAnOutOfLimitValueBeyondItsLimitLine", "thePlotIsBoundedAndTheSequenceKeepsCounting", "graphsAndAlertsFollowTheRealScenarioResults"]),
    ("Dashboard", "Alerts: BLOCK and fail-closed are critical, rejections warnings, unstored events flagged; the list is bounded; system faults raise alerts", "5 critical / 16 warning for the scenarios",
     ["anOrdinaryAllowRaisesNoAlert", "aBlockIsCriticalAndNamesTheSimulatedViolation", "aFailClosedRejectIsCriticalWithItsCode", "aWorkerFailureRecordIsCritical",
      "aParserRejectionIsOnlyAWarning", "anUnstoredEventAddsAWarningToWhateverElseHappened", "theAlertLogIsBoundedCountsLevelsAndClears",
      "withoutADecisionEngineTheSystemRaisesAlertsAndNothingIsPlottedAsAllowed", "crashedWorkerDisablesControlsAndShowsFailure"]),
    ("Dashboard", "Export buttons write CSV/JSON/PDF through the worker, never overwrite by default, label a tampered log and fail visibly", "files written / FAILED shown",
     ["exportsTheStoredLogAsCsvJsonAndPdfAndNeverOverwritesByDefault", "badExportRequestsAreRefusedBeforeAnythingIsSent", "withoutAnEventLogThereIsNothingToExport",
      "anExportOfATamperedLogIsLabelledAndRaisesACriticalAlert", "aWorkerThatNeverAnswersAnExportEndsInAVisibleFailure",
      "anErrorReplyToAnExportBecomesAnOkFalseExportReplyNotAFailure", "anExportThatIsNeverAnsweredFailsTheWorkerAfterSixTimesTheRequestTimeout"]),
    ("Dashboard", "Malformed worker results are rejected by strict validation", "fromJson returns false",
     ["malformedResultsAreRejected", "parserRejectedMessageMustCarryErrorFields"]),
    ("Dashboard", "Stored events can be loaded and verified; an unusable event log is shown, not hidden", "table rows, NOT STORED shown",
     ["storedEventsCanBeLoadedAndVerified", "unusableEventLogIsReportedNotHidden", "logQueriesTimeOutAgainstAHungWorker",
      "workerFailureClearsAPendingLogQuery", "aTamperedLogFailsVerificationVisibly", "loggedFlagIsParsedAndShown"]),
    ("Dashboard", "Screenshots can be produced for every tab", "5 PNG files", ["screenshotsAreWrittenForEveryTab"]),
]


def run_dashboard(exe: Path, parser: Path, extra_env: dict[str, str]) -> tuple[int, str]:
    """Runs the QtTest binary headless against the real worker; returns (exit code, combined output)."""
    env = dict(os.environ, QT_QPA_PLATFORM="offscreen", VOLTGUARD_ROOT=str(ROOT), VOLTGUARD_PYTHON=sys.executable,
               VOLTGUARD_PARSER_CLI=str(parser), VOLTGUARD_FAKE_WORKER=str(ROOT / "tests" / "fixtures" / "fake_worker.py"),
               VOLTGUARD_FAKE_ENGINE=str(ROOT / "tests" / "fixtures" / "fake_engine.py"), **extra_env)
    try:
        proc = subprocess.run([str(exe)], cwd=ROOT, env=env, capture_output=True, text=True, timeout=300, stdin=subprocess.DEVNULL)
    except subprocess.TimeoutExpired:
        return 124, "timed out after 300 s"
    except OSError as exc:
        return 127, str(exc)
    return proc.returncode, (proc.stdout or "") + (proc.stderr or "")


def summarise_qttest(code: int, out: str) -> tuple[bool, str, dict[str, str]]:
    """(passed, detail, test-name -> worst outcome). Fails on any failure, skip, crash or missing totals."""
    totals = re.findall(r"Totals: (\d+) passed, (\d+) failed, (\d+) skipped", out)
    if not totals:
        return False, f"no QtTest totals (exit {code})", {}
    p = sum(int(a) for a, _, _ in totals)
    f = sum(int(b) for _, b, _ in totals)
    s = sum(int(c) for _, _, c in totals)
    outcomes: dict[str, str] = {}
    for line in out.splitlines():
        m = re.match(r"(PASS|FAIL!|SKIP)\s*: \w+::(\w+)\(", line)
        if m:
            name, res = m.group(2), {"PASS": "passed", "FAIL!": "failed", "SKIP": "skipped"}[m.group(1)]
            if outcomes.get(name) not in ("failed", "skipped"):
                outcomes[name] = res
    return code == 0 and f == 0 and s == 0 and p > 0, f"{p} passed, {f} failed, {s} skipped (exit {code})", outcomes


def run(cmd: list[str], cwd: Path = ROOT, timeout: int = 900) -> tuple[int, str]:
    try:
        proc = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=timeout)
    except FileNotFoundError:
        return 127, f"command not found: {cmd[0]}"
    except subprocess.TimeoutExpired:
        return 124, f"timed out after {timeout}s: {' '.join(cmd)}"
    return proc.returncode, (proc.stdout or "") + (proc.stderr or "")


def version(cmd: list[str]) -> str:
    code, out = run(cmd, timeout=30)
    return out.strip().splitlines()[0] if code == 0 and out.strip() else "not available"


def parse_junit(path: Path):
    """name-prefix -> list of (full id, outcome). Outcome is passed / failed / skipped."""
    by_name: dict[str, list[tuple[str, str]]] = defaultdict(list)
    totals = {"passed": 0, "failed": 0, "skipped": 0}
    failed_ids: list[str] = []
    for case in ET.parse(path).getroot().iter("testcase"):
        full = f"{case.get('classname', '')}.{case.get('name', '')}"
        base = (case.get("name") or "").split("[")[0]
        if case.find("failure") is not None or case.find("error") is not None:
            outcome = "failed"
            failed_ids.append(full)
        elif case.find("skipped") is not None:
            outcome = "skipped"
        else:
            outcome = "passed"
        totals[outcome] += 1
        by_name[base].append((full, outcome))
    return by_name, totals, failed_ids


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--output", type=Path, default=ROOT / "docs" / "test_report.md")
    ap.add_argument("--no-sanitizer", action="store_true", help="skip the ASan/UBSan C++ build")
    ap.add_argument("--no-dashboard", action="store_true", help="skip the Qt dashboard suite")
    args = ap.parse_args(argv)

    steps: list[tuple[str, str, str]] = []  # (suite, result, detail)
    ok = True

    def record(suite: str, passed: bool, detail: str) -> None:
        nonlocal ok
        ok = ok and passed
        steps.append((suite, "PASS" if passed else "FAIL", detail))

    # ---- C++ build + ctest (the parser CLI must exist before the Python parser tests run)
    build = ROOT / "build"
    cpp_detail, cpp_pass = "", False
    if shutil.which("cmake"):
        code1, out1 = run(["cmake", "-S", str(ROOT), "-B", str(build)])
        code2, out2 = run(["cmake", "--build", str(build)]) if code1 == 0 else (1, "")
        code3, out3 = run(["ctest", "--test-dir", str(build), "--output-on-failure"]) if code2 == 0 else (1, "")
        cpp_pass = code1 == code2 == code3 == 0
        m = re.search(r"(\d+)% tests passed, (\d+) tests failed out of (\d+)", out3)
        checks = run([str(build / "packet_interceptor" / "parser_tests")])[1] if cpp_pass else ""
        c = re.search(r"(\d+) checks, (\d+) failures", checks)
        cpp_detail = (f"ctest: {m.group(3)} test(s), {m.group(2)} failed" if m else "ctest did not run") + \
                     (f"; parser_tests: {c.group(1)} checks, {c.group(2)} failures" if c else "")
        if c and c.group(2) != "0":
            cpp_pass = False
    else:
        cpp_detail = "cmake not found"
    record("C++ build + unit tests (GCC/Clang, default build)", cpp_pass, cpp_detail)

    # ---- Qt dashboard (QtTest, headless, real worker)
    dash_outcomes: dict[str, str] = {}
    dash_exe = build / "dashboard" / "dashboard_tests"
    dashboard_expected = not args.no_dashboard
    if dashboard_expected:
        if dash_exe.is_file():
            dcode, dout = run_dashboard(dash_exe, build / "packet_interceptor" / "voltguard_parser_cli", {})
            dpass, ddetail, dash_outcomes = summarise_qttest(dcode, dout)
            record("Qt dashboard (QtTest, offscreen, real parser + worker)", dpass, ddetail)
        else:
            record("Qt dashboard (QtTest, offscreen, real parser + worker)", False,
                   "dashboard_tests was not built (is Qt 6 installed? see docs/installation.md)")

    # ---- optional sanitizer build
    if not args.no_sanitizer and shutil.which("cmake"):
        san = Path(tempfile.mkdtemp(prefix="vg-san-"))
        c1, _ = run(["cmake", "-S", str(ROOT), "-B", str(san), "-DVOLTGUARD_SANITIZE=ON", "-DCMAKE_BUILD_TYPE=Debug"])
        c2, _ = run(["cmake", "--build", str(san)]) if c1 == 0 else (1, "")
        c3, out = run([str(san / "packet_interceptor" / "parser_tests")]) if c2 == 0 else (1, "build failed")
        m = re.search(r"(\d+) checks, (\d+) failures", out)
        record("C++ unit tests under AddressSanitizer + UBSan", c1 == c2 == c3 == 0 and bool(m) and m.group(2) == "0",
               f"{m.group(1)} checks, {m.group(2)} failures, no sanitizer reports" if m else out.strip()[:200])
        if dashboard_expected and (san / "dashboard" / "dashboard_tests").is_file():
            sc, so = run_dashboard(san / "dashboard" / "dashboard_tests", san / "packet_interceptor" / "voltguard_parser_cli",
                                   {"ASAN_OPTIONS": "detect_leaks=0"})
            spass, sdetail, _ = summarise_qttest(sc, so)
            bad = bool(re.search(r"runtime error|ERROR: AddressSanitizer", so))
            record("Qt dashboard tests under AddressSanitizer + UBSan (leak detection off)", spass and not bad,
                   sdetail + ("; SANITIZER REPORT FOUND" if bad else "; no sanitizer reports"))
        elif dashboard_expected:
            record("Qt dashboard tests under AddressSanitizer + UBSan", False, "dashboard_tests not built in the sanitizer tree")
        shutil.rmtree(san, ignore_errors=True)

    # ---- Rust: build (the Python contract tests use the binary), then test
    rust_outcomes: dict[str, str] = {}
    rust_manifest = ROOT / "decision_engine" / "Cargo.toml"
    if shutil.which("cargo"):
        bcode, bout = run(["cargo", "build", "--manifest-path", str(rust_manifest)])
        tcode, tout = run(["cargo", "test", "--manifest-path", str(rust_manifest)]) if bcode == 0 else (1, bout)
        results = re.findall(r"test result: \w+\. (\d+) passed; (\d+) failed", tout)
        rp, rf = sum(int(a) for a, _ in results), sum(int(b) for _, b in results)
        for name, res in re.findall(r"^test (\S+) \.\.\. (ok|FAILED)", tout, re.M):
            rust_outcomes[name.split("::")[-1]] = "passed" if res == "ok" else "failed"
        record("Rust decision engine (cargo build + cargo test: unit, integration, CLI, fuzz)",
               bcode == 0 and tcode == 0 and bool(results) and rf == 0 and rp > 0,
               f"{rp} passed, {rf} failed" if results else "no result line")
    else:
        record("Rust decision engine", False, "cargo not found")

    # ---- pytest
    junit = Path(tempfile.mkdtemp(prefix="vg-junit-")) / "pytest.xml"
    code, out = run([sys.executable, "-m", "pytest", "-q", f"--junitxml={junit}", "-p", "no:cacheprovider"])
    by_name, totals, failed_ids = ({}, {"passed": 0, "failed": 0, "skipped": 0}, [])
    if junit.exists():
        by_name, totals, failed_ids = parse_junit(junit)
    record("Python (pytest, whole project)",
           code == 0 and totals["failed"] == 0 and totals["skipped"] == 0 and totals["passed"] > 0,
           f"{totals['passed']} passed, {totals['failed']} failed, {totals['skipped']} skipped")

    # ---- audit items
    audit_rows = []
    for area, item, expected, names in AUDIT_ITEMS + EVENT_LOG_AUDIT + CONTRACT_AUDIT + BRIDGE_AUDIT + SAFETY_AUDIT + BENCH_AUDIT + EXPORT_AUDIT + E2E_AUDIT + DOCS_AUDIT + PREFLIGHT_AUDIT + DIRECT_RUN_AUDIT:
        passed_n = total_n = 0
        problems = []
        for name in names:
            cases = by_name.get(name, [])
            if not cases:
                problems.append(f"{name}: NOT FOUND")
            for full, outcome in cases:
                total_n += 1
                if outcome == "passed":
                    passed_n += 1
                else:
                    problems.append(f"{full}: {outcome.upper()}")
        item_ok = not problems and total_n > 0
        ok = ok and item_ok
        audit_rows.append((area, item, expected, names, passed_n, total_n, item_ok, problems))

    dash_rows = []
    if dashboard_expected:
        for area, item, expected, names in DASHBOARD_AUDIT:
            problems = [f"{n}: {dash_outcomes.get(n, 'NOT FOUND').upper()}" for n in names if dash_outcomes.get(n) != "passed"]
            item_ok = not problems
            ok = ok and item_ok
            dash_rows.append((area, item, expected, names, len(names) - len(problems), len(names), item_ok, problems))
    audit_rows += dash_rows
    for area, item, expected, names in RUST_AUDIT:
        problems = [f"{n}: {rust_outcomes.get(n, 'NOT FOUND').upper()}" for n in names if rust_outcomes.get(n) != "passed"]
        ok = ok and not problems
        audit_rows.append((area, item, expected, names, len(names) - len(problems), len(names), not problems, problems))

    methodology_ok = (ROOT / "docs" / "methodology.md").is_file()
    ok = ok and methodology_ok

    # ---- write the report
    env = [("Date (UTC)", datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M")),
           ("OS", platform.platform()), ("Python", platform.python_version()),
           ("C++ compiler", version(["c++", "--version"])), ("CMake", version(["cmake", "--version"])),
           ("Rust", version(["rustc", "--version"])), ("Scapy", version([sys.executable, "-c", "import scapy;print(scapy.__version__)"])),
           ("SciPy", version([sys.executable, "-c", "import scipy;print(scipy.__version__)"]))]
    lines = ["# VoltGuard test report (generated)", "",
             "Generated by `scripts/generate_test_report.py`. Every count below was produced by running the suites in this environment; nothing was typed by hand except the findings and limitations sections, which are labelled.",
             "", f"**Overall result: {'ALL PASSED' if ok else 'FAILURES PRESENT'}**", "", "## Environment", "",
             "| Item | Value |", "|---|---|"] + [f"| {k} | {v} |" for k, v in env]
    lines += ["", "## Suites", "", "| Suite | Result | Detail |", "|---|---|---|"] + [f"| {s} | {r} | {d} |" for s, r, d in steps]
    lines += ["", "## Audit items (parser, physics, integration, dashboard, event log)", "",
              "An item passes only if every listed test exists, ran and passed (parametrised cases are counted individually).", "",
              "| Area | Audit item | Expected | Tests (cases passed/run) | Result |", "|---|---|---|---|---|"]
    for area, item, expected, names, p, t, item_ok, problems in audit_rows:
        lines.append(f"| {area} | {item} | {expected} | {len(names)} tests ({p}/{t} cases) | {'PASS' if item_ok else 'FAIL: ' + '; '.join(problems)} |")
    lines.append(f"| Physics | Mathematical assumptions and model limitations documented | `docs/methodology.md` exists | file check | {'PASS' if methodology_ok else 'FAIL'} |")
    lines += ["", "## Failed tests", ""]
    lines += [f"- `{f}`" for f in failed_ids] if failed_ids else ["None in this run."]
    lines += ["", "## Findings during development and corrective actions", "",
              "*(Historical record of defects found by the tests or by review; maintained by hand.)*", "",
              "| Phase | Finding | Corrective action |", "|---|---|---|"] + [f"| {a} | {b} | {c} |" for a, b, c in FINDINGS]
    lines += ["", "## Remaining limitations", ""] + [f"- {x}" for x in LIMITATIONS] + [""]
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text("\n".join(lines), encoding="utf-8")
    print("\n".join(f"{r:4} {s}: {d}" for s, r, d in steps))
    print(f"audit items passed: {sum(1 for r in audit_rows if r[6])}/{len(audit_rows)}")
    print(f"report written to {args.output}")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
