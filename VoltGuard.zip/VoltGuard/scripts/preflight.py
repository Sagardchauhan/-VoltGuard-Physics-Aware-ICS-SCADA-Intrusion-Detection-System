"""Pre-demo readiness check for VoltGuard (simulated traffic only).

Run it before a demo or a hand-in:  python scripts/preflight.py

It checks the things that make a demo fail and then sends three commands through the REAL worker, parser and
decision engine into a TEMPORARY event database (your logs/events.db is never touched):
a safe write must be ALLOWed, an unsafe write BLOCKed, a malformed frame REJECTed, every event logged,
and the hash chain must verify. Exit code 0 only if nothing FAILed; WARN lines do not fail the check.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

SAFE = "00010000000601060064003c"      # pump speed 60 %
UNSAFE = "000700000006010600640064"    # pump speed 100 %
MALFORMED = "0001"
READY_TIMEOUT_S = 20
REPLY_TIMEOUT_S = 10


class Report:
    def __init__(self) -> None:
        self.failures = 0
        self.warnings = 0

    def ok(self, text: str) -> None:
        print(f"OK    {text}")

    def warn(self, text: str) -> None:
        self.warnings += 1
        print(f"WARN  {text}")

    def fail(self, text: str) -> None:
        self.failures += 1
        print(f"FAIL  {text}")


def judge_reply(label: str, want: str, reply: dict) -> tuple[bool, str]:
    """A reply passes only if it carries the wanted decision AND the event was reported as logged."""
    decision = reply.get("decision") if isinstance(reply.get("decision"), dict) else {}
    got, src = decision.get("decision"), decision.get("source")
    if got == want and reply.get("logged") is True:
        return True, f"{label}: {got} (source {src}), logged"
    return False, f"{label}: expected {want} and logged=true, got {got!r} (source {src!r}), logged={reply.get('logged')!r}"


def judge_log(verified: object, count: int, expected: int) -> tuple[bool, str]:
    """The stored log passes only if the hash chain verifies AND exactly the expected number of events is there."""
    if verified is True and count == expected:
        return True, f"event log: {count} events stored, hash chain verifies"
    return False, f"event log: count={count} (expected {expected}), chain verified={verified!r}"


def check_python_packages(r: Report) -> None:
    missing = [m for m in ("scipy", "numpy", "scapy") if importlib.util.find_spec(m) is None]
    if missing:
        r.fail(f"Python packages missing: {', '.join(missing)} (pip install -r requirements.txt)")
    else:
        r.ok("Python packages: scipy, numpy, scapy")
    if importlib.util.find_spec("reportlab") is None:
        r.warn("reportlab not installed: the PDF report export will be unavailable (CSV and JSON work)")
    else:
        r.ok("reportlab installed (PDF export available)")


def find_dashboard() -> Path | None:
    exe = "voltguard_dashboard.exe" if sys.platform == "win32" else "voltguard_dashboard"
    for sub in ("", "Release", "Debug"):
        p = ROOT / "build" / "dashboard" / sub / exe
        if p.is_file():
            return p
    return None


def _exchange(proc: subprocess.Popen, request: dict) -> dict:
    """Send one request line and read one reply line (the caller's subprocess timeout guards a hang)."""
    proc.stdin.write((json.dumps(request) + "\n").encode())
    proc.stdin.flush()
    line = proc.stdout.readline()
    if not line:
        raise RuntimeError("the worker closed its output")
    return json.loads(line)


def end_to_end(r: Report, parser_cli: Path, engine: Path) -> None:
    from event_logging.event_store import EventStore
    with tempfile.TemporaryDirectory() as tmp:
        db = Path(tmp) / "preflight.db"
        cmd = [sys.executable, "-m", "voltguard.worker", "--log-dir", tmp, "--event-db", str(db),
               "--parser-cli", str(parser_cli), "--decision-engine", str(engine)]
        proc = None
        try:
            import threading
            proc = subprocess.Popen(cmd, cwd=ROOT, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
            watchdog = threading.Timer(READY_TIMEOUT_S + 3 * REPLY_TIMEOUT_S, proc.kill)
            watchdog.start()
            try:
                ready = json.loads(proc.stdout.readline() or b"{}")
                if ready.get("type") != "ready":
                    r.fail(f"worker did not start: {str(ready)[:200]}")
                    return
                r.ok("worker started")
                expected = [("safe write", SAFE, "ALLOW"), ("unsafe write", UNSAFE, "BLOCK"), ("malformed frame", MALFORMED, "REJECT")]
                for i, (label, frame, want) in enumerate(expected):
                    reply = _exchange(proc, {"op": "process", "command_id": f"PF-{i}", "frame_hex": frame, "source": "preflight"})
                    passed, text = judge_reply(label, want, reply)
                    (r.ok if passed else r.fail)(text)
            finally:
                watchdog.cancel()
        except Exception as exc:                       # noqa: BLE001 - report, never crash the check
            r.fail(f"end-to-end run failed: {type(exc).__name__}: {str(exc)[:200]}")
            return
        finally:
            if proc is not None:
                try:
                    proc.stdin.close()
                except OSError:
                    pass
                try:
                    proc.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    proc.kill()
        try:
            store = EventStore(db)
            try:
                ok, detail = store.verify()[:2]
                count = store.count()
            finally:
                store.close()
            passed, text = judge_log(ok, count, len(expected))
            (r.ok if passed else r.fail)(text if passed else f"{text} {detail}")
        except Exception as exc:                       # noqa: BLE001
            r.fail(f"event log could not be read back: {type(exc).__name__}: {str(exc)[:200]}")


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--no-dashboard", action="store_true", help="do not require the built dashboard (command-line demo only)")
    args = ap.parse_args(argv)
    r = Report()
    print("VoltGuard pre-demo check (simulated traffic only; nothing is sent to any device)")

    try:
        from voltguard.config import load_safety_config
        load_safety_config(ROOT / "config" / "safety_limits.json")
        r.ok("safety configuration loads")
    except Exception as exc:                           # noqa: BLE001
        r.fail(f"safety configuration: {type(exc).__name__}: {str(exc)[:200]}")

    check_python_packages(r)

    from voltguard.decision_bridge import find_decision_engine
    from voltguard.pipeline import find_parser_cli
    parser_cli, engine = find_parser_cli(), find_decision_engine()
    if parser_cli is None:
        r.fail("C++ parser not built (cmake -S . -B build && cmake --build build)")
    else:
        r.ok(f"parser: {parser_cli.relative_to(ROOT) if parser_cli.is_relative_to(ROOT) else parser_cli}")
    if engine is None:
        r.fail("Rust decision engine not built (cargo build --release --manifest-path decision_engine/Cargo.toml); without it every command is REJECTED")
    else:
        r.ok(f"decision engine: {Path(engine).relative_to(ROOT) if Path(engine).is_relative_to(ROOT) else engine}")
    dash = find_dashboard()
    if dash is not None:
        r.ok(f"dashboard: {dash.relative_to(ROOT)}")
    elif args.no_dashboard:
        r.warn("dashboard not built (allowed by --no-dashboard)")
    else:
        r.fail("dashboard not built (needs Qt 6; see docs/installation.md), or pass --no-dashboard")

    if parser_cli is not None and engine is not None:
        end_to_end(r, Path(parser_cli), Path(engine))
    else:
        r.fail("end-to-end check skipped because a component is missing")

    print(f"\n{'READY' if r.failures == 0 else 'NOT READY'}: {r.failures} failure(s), {r.warnings} warning(s)")
    return 0 if r.failures == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
