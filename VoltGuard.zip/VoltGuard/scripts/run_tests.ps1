# Runs every available VoltGuard test suite. UNTESTED on Windows as of Phase 1.
$ErrorActionPreference = "Stop"
Set-Location (Split-Path -Parent $PSScriptRoot)
$failed = @()

Write-Host "== Python (pytest) =="
python -m pytest
if ($LASTEXITCODE -ne 0) { $failed += "pytest" }

Write-Host "== C++ (CMake/CTest) =="
cmake -S . -B build
if ($LASTEXITCODE -eq 0) { cmake --build build --config Release }
if ($LASTEXITCODE -eq 0) { ctest --test-dir build -C Release --output-on-failure }
if ($LASTEXITCODE -ne 0) { $failed += "cpp" }

Write-Host "== Rust (cargo test) =="
cargo test --manifest-path decision_engine\Cargo.toml
if ($LASTEXITCODE -ne 0) { $failed += "rust" }

if ($failed.Count -gt 0) { Write-Host "FAILED: $($failed -join ', ')" -ForegroundColor Red; exit 1 }
Write-Host "All test suites passed." -ForegroundColor Green
