#!/usr/bin/env bash
# Start the VoltGuard dashboard for a demo: pre-flight check first, then a FRESH event database so the
# Event log tab starts empty. Simulated traffic only. Extra arguments go to the dashboard.
#   scripts/demo.sh                      # needs a display
#   QT_QPA_PLATFORM=offscreen scripts/demo.sh --screenshot-dir /tmp/shots   # headless
set -euo pipefail
cd "$(dirname "$0")/.."
PY="${PYTHON:-python3}"
"$PY" scripts/preflight.py || { echo "Pre-flight check failed: not starting the demo." >&2; exit 1; }
mkdir -p results/demo
DB="results/demo/events_$(date -u +%Y%m%d_%H%M%S).db"
echo "Starting the dashboard with a fresh event database: $DB"
exec ./build/dashboard/voltguard_dashboard --event-db "$DB" --python "$PY" "$@"
