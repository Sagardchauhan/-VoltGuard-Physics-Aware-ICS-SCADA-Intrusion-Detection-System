"""Writes tests/fixtures/pipeline_results.jsonl: the REAL pipeline result for every traffic-generator scenario.

Each line: {"scenario", "intent", "result": <PipelineResult dict>}. The Rust decision engine tests read it and
compare each decision with the scenario's designed intent (NORMAL/BOUNDARY_SAFE/READ_ONLY -> ALLOW,
UNSAFE -> BLOCK, everything else -> REJECT), so the expectation comes from the scenario design and the physics
tests, not from the engine's own output. Requires the built parser CLI (cmake --build build).
Usage: python scripts/generate_decision_fixture.py [--check]   (--check fails if the file is out of date)
"""

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from traffic_generator.generate_traffic import generate_scenarios  # noqa: E402
from voltguard.config import load_safety_config  # noqa: E402
from voltguard.pipeline import Pipeline, find_parser_cli  # noqa: E402

OUT = ROOT / "tests" / "fixtures" / "pipeline_results.jsonl"


def build() -> str:
    cli = find_parser_cli()
    if cli is None:
        raise SystemExit("parser CLI not built: run `cmake -S . -B build && cmake --build build` first")
    pipeline = Pipeline(load_safety_config(ROOT / "config" / "safety_limits.json"), parser_argv=[str(cli)])
    lines = []
    try:
        for i, row in enumerate(generate_scenarios()):
            result = pipeline.process_frame(f"FX-{i:03d}", bytes.fromhex(row["frame_hex"])).to_dict()
            result.pop("timings_ms")  # timings vary from run to run; they are irrelevant to decisions
            lines.append(json.dumps({"scenario": row["scenario"], "intent": row["intent"], "result": result}, sort_keys=True))
    finally:
        pipeline.close()
    return "\n".join(lines) + "\n"


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--check", action="store_true")
    args = ap.parse_args()
    text = build()
    if args.check:
        if not OUT.is_file() or OUT.read_text(encoding="utf-8") != text:
            print("tests/fixtures/pipeline_results.jsonl is out of date: run scripts/generate_decision_fixture.py")
            return 1
        print("fixture is up to date")
        return 0
    OUT.write_text(text, encoding="utf-8")
    print(f"wrote {len(text.splitlines())} results to {OUT}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
