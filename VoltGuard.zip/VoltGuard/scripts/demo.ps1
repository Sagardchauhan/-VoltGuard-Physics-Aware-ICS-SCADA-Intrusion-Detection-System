# Start the VoltGuard dashboard for a demo (pre-flight check, then a fresh event database).
# UNTESTED on Windows: written to mirror scripts/demo.sh. Simulated traffic only.
$ErrorActionPreference = "Stop"
Set-Location (Split-Path -Parent $PSScriptRoot)
python scripts\preflight.py
if ($LASTEXITCODE -ne 0) { Write-Host "Pre-flight check failed: not starting the demo." -ForegroundColor Red; exit 1 }
New-Item -ItemType Directory -Force results\demo | Out-Null
$db = "results\demo\events_$((Get-Date).ToUniversalTime().ToString('yyyyMMdd_HHmmss')).db"
Write-Host "Starting the dashboard with a fresh event database: $db"
$exe = Get-ChildItem -Path build\dashboard -Recurse -Filter voltguard_dashboard.exe | Select-Object -First 1
if (-not $exe) { Write-Host "Dashboard executable not found under build\dashboard" -ForegroundColor Red; exit 1 }
& $exe.FullName --event-db $db @args
