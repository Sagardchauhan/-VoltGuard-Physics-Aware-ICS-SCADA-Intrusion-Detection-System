// One processed command as shown by the dashboard, built from a (validated) worker "result" message.
// Everything here is a SIMULATED prediction; the dashboard never shows or implies sensor data.
#pragma once

#include <QDateTime>
#include <QJsonObject>
#include <QString>
#include <QStringList>

namespace voltguard {

struct CommandRecord {
    enum class Severity { Ok, Violation, Rejected, Failure };

    QString commandId;
    QDateTime timestampUtc;
    QString source;      // scenario name or "manual"
    QString frameHex;
    QString stage;       // SIMULATED | PARSE_REJECTED | COMPONENT_FAILURE

    bool hasParsed = false;
    int functionCode = -1;
    int registerAddress = -1;
    QString parsedSummary;

    bool hasSimulation = false;
    QString simStatus;   // SUCCESS | INVALID_INPUT | ERROR | TIMEOUT
    bool hasPrediction = false;
    double pressure = 0.0;
    double flow = 0.0;
    QString pressureUnit;
    QString flowUnit;
    double minPressure = 0.0;
    double maxPressure = 0.0;
    QStringList violations;  // human-readable, e.g. "PRESSURE_HIGH: predicted 145 > limit 100"
    QStringList violationTypes;
    QString simError;

    QString errorCode;
    QString error;
    double parseMs = 0.0;
    double simulateMs = 0.0;
    double totalMs = 0.0;

    // Decision from the decision engine (or REJECT with source fail_closed when no decision could be obtained).
    QString decision;          // ALLOW | BLOCK | REJECT (never empty in a valid record)
    QString decisionReason;
    QString decisionSource;    // engine | fail_closed
    QString decisionErrorCode; // set when decisionSource == fail_closed

    int logged = -1;     // event log: 1 stored, 0 NOT stored (failure), -1 logging switched off / unknown

    Severity severity() const;
    QString safetyStatus() const;   // short status text, always labelled as simulated where it is a prediction
    QString decisionText() const;   // the decision exactly as received, e.g. "BLOCK (engine)"
    QString detailsText() const;

    // Strict validation of a worker "result" message; on failure returns false and sets *error.
    static bool fromJson(const QJsonObject& message, CommandRecord* out, QString* error);
    // Record for a request that produced no usable result (worker failure, timeout, invalid reply).
    static CommandRecord failure(const QString& commandId, const QString& source, const QString& frameHex,
                                 const QString& code, const QString& message);
};

}  // namespace voltguard
