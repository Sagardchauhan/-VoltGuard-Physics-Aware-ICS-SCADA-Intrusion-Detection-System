// Alerts raised by the dashboard. Pure display logic: an alert never changes a decision and nothing here
// acts on a device. All numbers in alert text are SIMULATED predictions.
#pragma once

#include <QDateTime>
#include <QList>
#include <QObject>
#include <QString>

#include "commandrecord.h"

namespace voltguard {

struct Alert {
    enum class Level { Info, Warning, Critical };
    Level level = Level::Info;
    QDateTime timeUtc;
    QString commandId;   // empty for system alerts
    QString code;        // stable identifier, e.g. LIMIT_VIOLATION_BLOCKED
    QString message;

    static QString levelText(Level level);
};

// Alerts that one processed command raises (empty for an ordinary ALLOW). A command can raise several.
QList<Alert> alertsForRecord(const CommandRecord& record);

// Bounded, newest-last list of alerts with counts per level.
class AlertLog : public QObject {
    Q_OBJECT
public:
    static constexpr int kMaxAlerts = 200;

    explicit AlertLog(QObject* parent = nullptr) : QObject(parent) {}
    void add(const Alert& alert);
    void addSystem(Alert::Level level, const QString& code, const QString& message);
    void addAll(const QList<Alert>& alerts);
    void clear();
    int size() const { return m_alerts.size(); }
    const Alert& at(int index) const { return m_alerts.at(index); }
    int count(Alert::Level level) const;          // alerts currently held
    int droppedCount() const { return m_dropped; }  // alerts discarded because the list was full

signals:
    void changed();

private:
    QList<Alert> m_alerts;
    int m_dropped = 0;
};

}  // namespace voltguard
