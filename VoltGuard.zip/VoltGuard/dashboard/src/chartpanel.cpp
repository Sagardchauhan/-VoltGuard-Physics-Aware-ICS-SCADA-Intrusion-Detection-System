#include "chartpanel.h"

#include <QChart>
#include <QChartView>
#include <QLineSeries>
#include <QPen>
#include <QScatterSeries>
#include <QValueAxis>
#include <QVBoxLayout>
#include <algorithm>

#include "theme.h"

namespace voltguard {

namespace {

struct ChartParts {
    QChartView* view;
    QLineSeries* line;
    QScatterSeries* allow;
    QScatterSeries* block;
    QScatterSeries* other;
    QLineSeries* minLine;
    QLineSeries* maxLine;
    QValueAxis* x;
    QValueAxis* y;
};

QScatterSeries* marker(const QString& name, const QColor& color) {
    auto* s = new QScatterSeries;
    s->setName(name);
    s->setColor(color);
    s->setBorderColor(color);
    s->setMarkerSize(9.0);
    return s;
}

QLineSeries* limitSeries(const QString& name) {
    auto* s = new QLineSeries;
    s->setName(name);
    QPen pen(QColor(theme::kViolation));
    pen.setStyle(Qt::DashLine);
    pen.setWidth(2);
    s->setPen(pen);
    return s;
}

ChartParts makeChart(const QString& title, const QString& objectName, QWidget* parent) {
    ChartParts c{};
    auto* chart = new QChart;
    chart->setTitle(title);
    chart->setTitleBrush(QColor(theme::kText));
    chart->setBackgroundBrush(QColor(theme::kPanel));
    chart->legend()->setLabelColor(QColor(theme::kText));
    chart->legend()->setAlignment(Qt::AlignBottom);
    c.line = new QLineSeries;
    c.line->setName(QStringLiteral("simulated prediction"));
    c.line->setColor(QColor(theme::kMuted));
    c.allow = marker(QStringLiteral("ALLOW"), QColor(theme::kOk));
    c.block = marker(QStringLiteral("BLOCK"), QColor(theme::kFailure));
    c.other = marker(QStringLiteral("REJECT"), QColor(theme::kRejected));
    c.minLine = limitSeries(QStringLiteral("configured minimum"));
    c.maxLine = limitSeries(QStringLiteral("configured maximum"));
    c.x = new QValueAxis;
    c.x->setTitleText(QStringLiteral("plotted command (order, not time)"));
    c.x->setLabelFormat(QStringLiteral("%d"));
    c.x->setLabelsColor(QColor(theme::kText));
    c.x->setTitleBrush(QColor(theme::kText));
    c.y = new QValueAxis;
    c.y->setLabelsColor(QColor(theme::kText));
    c.y->setTitleBrush(QColor(theme::kText));
    chart->addAxis(c.x, Qt::AlignBottom);
    chart->addAxis(c.y, Qt::AlignLeft);
    for (QAbstractSeries* s : QList<QAbstractSeries*>{c.minLine, c.maxLine, c.line, c.allow, c.block, c.other}) {
        chart->addSeries(s);
        s->attachAxis(c.x);
        s->attachAxis(c.y);
    }
    c.view = new QChartView(chart, parent);
    c.view->setObjectName(objectName);
    c.view->setRenderHint(QPainter::Antialiasing);
    c.view->setMinimumHeight(180);
    return c;
}

QList<QPointF> toList(const QList<QPointF>& pts) { return pts; }

}  // namespace

ChartPanel::ChartPanel(QWidget* parent) : QWidget(parent) {
    auto* layout = new QVBoxLayout(this);
    layout->setContentsMargins(0, 0, 0, 0);
    const ChartParts p = makeChart(QStringLiteral("Predicted pressure (SIMULATED)"), QStringLiteral("pressureChart"), this);
    const ChartParts f = makeChart(QStringLiteral("Predicted flow (SIMULATED)"), QStringLiteral("flowChart"), this);
    m_pressureView = p.view; m_pressureLine = p.line; m_pressureAllow = p.allow; m_pressureBlock = p.block; m_pressureOther = p.other;
    m_pressureMin = p.minLine; m_pressureMax = p.maxLine; m_pressureX = p.x; m_pressureY = p.y;
    m_flowView = f.view; m_flowLine = f.line; m_flowAllow = f.allow; m_flowBlock = f.block; m_flowOther = f.other;
    m_flowMin = f.minLine; m_flowMax = f.maxLine; m_flowX = f.x; m_flowY = f.y;
    layout->addWidget(m_pressureView);
    layout->addWidget(m_flowView);
    m_pressureY->setTitleText(QStringLiteral("pressure"));
    m_flowY->setTitleText(QStringLiteral("flow"));
    rebuild();
}

void ChartPanel::setLimits(double pressureMin, double pressureMax, const QString& pressureUnit,
                           double flowMin, double flowMax, const QString& flowUnit) {
    m_hasLimits = true;
    m_pMin = pressureMin; m_pMax = pressureMax; m_fMin = flowMin; m_fMax = flowMax;
    m_pUnit = pressureUnit; m_fUnit = flowUnit;
    m_pressureY->setTitleText(QStringLiteral("pressure (%1)").arg(pressureUnit));
    m_flowY->setTitleText(QStringLiteral("flow (%1)").arg(flowUnit));
    rebuild();
}

void ChartPanel::addRecord(const CommandRecord& r) {
    if (!r.hasPrediction) return;   // nothing to plot for rejected or failed commands
    ++m_sequence;
    m_pressure.append(QPointF(m_sequence, r.pressure));
    m_flow.append(QPointF(m_sequence, r.flow));
    m_decisions.append(r.decision);
    while (m_pressure.size() > kMaxPoints) {
        m_pressure.removeFirst();
        m_flow.removeFirst();
        m_decisions.removeFirst();
    }
    rebuild();
}

void ChartPanel::clear() {
    m_pressure.clear();
    m_flow.clear();
    m_decisions.clear();
    m_sequence = 0;
    rebuild();
}

int ChartPanel::allowedPointCount() const { return m_decisions.count(QStringLiteral("ALLOW")); }
int ChartPanel::blockedPointCount() const { return m_decisions.count(QStringLiteral("BLOCK")); }

QList<QPointF> ChartPanel::pressureLimitLine(bool upper) const { return toList((upper ? m_pressureMax : m_pressureMin)->points()); }
QList<QPointF> ChartPanel::flowLimitLine(bool upper) const { return toList((upper ? m_flowMax : m_flowMin)->points()); }
double ChartPanel::pressureAxisMin() const { return m_pressureY->min(); }
double ChartPanel::pressureAxisMax() const { return m_pressureY->max(); }
double ChartPanel::flowAxisMin() const { return m_flowY->min(); }
double ChartPanel::flowAxisMax() const { return m_flowY->max(); }

void ChartPanel::rebuild() {
    struct Target {
        const QList<QPointF>* pts; QLineSeries* line; QScatterSeries* allow; QScatterSeries* block; QScatterSeries* other;
        QLineSeries* minLine; QLineSeries* maxLine; QValueAxis* x; QValueAxis* y; double lo, hi;
    };
    const Target targets[2] = {
        {&m_pressure, m_pressureLine, m_pressureAllow, m_pressureBlock, m_pressureOther, m_pressureMin, m_pressureMax, m_pressureX, m_pressureY, m_pMin, m_pMax},
        {&m_flow, m_flowLine, m_flowAllow, m_flowBlock, m_flowOther, m_flowMin, m_flowMax, m_flowX, m_flowY, m_fMin, m_fMax}};
    for (const Target& t : targets) {
        QList<QPointF> allow, block, other;
        for (int i = 0; i < t.pts->size(); ++i) {
            const QString& d = m_decisions.at(i);
            (d == QLatin1String("ALLOW") ? allow : d == QLatin1String("BLOCK") ? block : other).append(t.pts->at(i));
        }
        t.line->replace(*t.pts);
        t.allow->replace(allow);
        t.block->replace(block);
        t.other->replace(other);

        const double x0 = t.pts->isEmpty() ? 0.0 : t.pts->first().x();
        const double x1 = t.pts->isEmpty() ? 1.0 : std::max(t.pts->last().x(), x0 + 1.0);
        if (m_hasLimits) {
            t.minLine->replace(QList<QPointF>{{x0, t.lo}, {x1, t.lo}});
            t.maxLine->replace(QList<QPointF>{{x0, t.hi}, {x1, t.hi}});
        } else {
            t.minLine->clear();
            t.maxLine->clear();
        }
        // The vertical range always includes every plotted value AND both limits, so an out-of-limit
        // prediction is visibly beyond the limit line instead of being clipped.
        double lo = m_hasLimits ? t.lo : 0.0, hi = m_hasLimits ? t.hi : 1.0;
        for (const QPointF& p : *t.pts) {
            lo = std::min(lo, p.y());
            hi = std::max(hi, p.y());
        }
        const double pad = std::max((hi - lo) * 0.08, 1e-6);
        t.x->setRange(x0, x1);
        t.y->setRange(lo - pad, hi + pad);
    }
}

}  // namespace voltguard
