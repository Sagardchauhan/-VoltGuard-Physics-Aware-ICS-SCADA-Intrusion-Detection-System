// VoltGuard dashboard entry point.
//   voltguard_dashboard [--python PATH] [--project-root DIR] [--parser-cli PATH] [--config PATH]
//                       [--screenshot-dir DIR]
// With --screenshot-dir the application runs every test scenario, saves one PNG per tab and exits
// (0 on success, 1 on failure or after 60 s without completing).
#include <QApplication>
#include <QCommandLineParser>
#include <QDir>
#include <QFileInfo>
#include <QTextStream>
#include <QTimer>

#include "mainwindow.h"
#include "theme.h"
#include "trafficmodel.h"

using namespace voltguard;

namespace {

QString findProjectRoot(const QString& hint) {
    if (!hint.isEmpty()) return QDir(hint).absolutePath();
    QDir dir(QCoreApplication::applicationDirPath());
    for (int i = 0; i < 8; ++i) {
        if (QFileInfo::exists(dir.filePath(QStringLiteral("config/safety_limits.json")))) return dir.absolutePath();
        if (!dir.cdUp()) break;
    }
    return QDir::currentPath();
}

QString findParserCli(const QString& appDir) {
#ifdef Q_OS_WIN
    const QString exe = QStringLiteral("voltguard_parser_cli.exe");
#else
    const QString exe = QStringLiteral("voltguard_parser_cli");
#endif
    const QStringList candidates = {QStringLiteral("../packet_interceptor/") + exe, QStringLiteral("../packet_interceptor/Release/") + exe,
                                    QStringLiteral("../../packet_interceptor/Release/") + exe, QStringLiteral("../packet_interceptor/Debug/") + exe,
                                    QStringLiteral("../../packet_interceptor/Debug/") + exe};
    for (const QString& rel : candidates) {
        const QString path = QDir(appDir).absoluteFilePath(rel);
        if (QFileInfo(path).isFile()) return QDir::cleanPath(path);
    }
    return {};
}

}  // namespace

int main(int argc, char** argv) {
    QApplication app(argc, argv);
    QCoreApplication::setApplicationName(QStringLiteral("VoltGuard"));
    theme::applyDarkTheme(app);

    QCommandLineParser cli;
    cli.setApplicationDescription(QStringLiteral("VoltGuard - Physics-Aware Industrial Network Security (simulation prototype)"));
    cli.addHelpOption();
#ifdef Q_OS_WIN
    const QString defaultPython = QStringLiteral("python");
#else
    const QString defaultPython = QStringLiteral("python3");
#endif
    QCommandLineOption optPython(QStringLiteral("python"), QStringLiteral("Python interpreter for the worker."), QStringLiteral("path"), defaultPython);
    QCommandLineOption optRoot(QStringLiteral("project-root"), QStringLiteral("VoltGuard project folder."), QStringLiteral("dir"));
    QCommandLineOption optParser(QStringLiteral("parser-cli"), QStringLiteral("Path to voltguard_parser_cli."), QStringLiteral("path"));
    QCommandLineOption optConfig(QStringLiteral("config"), QStringLiteral("Path to safety_limits.json."), QStringLiteral("path"));
    QCommandLineOption optShots(QStringLiteral("screenshot-dir"), QStringLiteral("Run all scenarios, save screenshots here and exit."), QStringLiteral("dir"));
    QCommandLineOption optEventDb(QStringLiteral("event-db"), QStringLiteral("Event database file (default: logs/events.db). Use a new file for a clean demo."), QStringLiteral("path"));
    cli.addOptions({optPython, optRoot, optParser, optConfig, optShots, optEventDb});
    cli.process(app);

    const QString root = findProjectRoot(cli.value(optRoot));
    QString parser = cli.value(optParser);
    if (parser.isEmpty()) parser = findParserCli(QCoreApplication::applicationDirPath());

    WorkerLaunch launch;
    launch.program = cli.value(optPython);
    launch.workingDirectory = root;
    launch.arguments = {QStringLiteral("-m"), QStringLiteral("voltguard.worker")};
    if (!parser.isEmpty()) launch.arguments << QStringLiteral("--parser-cli") << parser;
    if (cli.isSet(optConfig)) launch.arguments << QStringLiteral("--config") << cli.value(optConfig);
    if (cli.isSet(optEventDb)) launch.arguments << QStringLiteral("--event-db") << cli.value(optEventDb);

    MainWindow window;
    window.show();
    window.startWorker(launch);

    if (cli.isSet(optShots)) {
        const QString dir = cli.value(optShots);
        int expected = -1;
        auto* watchdog = new QTimer(&app);
        watchdog->setSingleShot(true);
        QObject::connect(watchdog, &QTimer::timeout, &app, [&app]() {
            QTextStream(stderr) << "screenshot mode: timed out after 60 s\n";
            app.exit(1);
        });
        watchdog->start(60000);

        QObject::connect(window.worker(), &WorkerClient::stateChanged, &app, [&app](WorkerClient::State s, const QString& d) {
            if (s == WorkerClient::State::Failed) {
                QTextStream(stderr) << "screenshot mode: worker failed: " << d << "\n";
                app.exit(1);
            }
        });
        QObject::connect(window.worker(), &WorkerClient::scenariosReceived, &app, [&]() {
            expected = window.scenarioCount();
            QMetaObject::invokeMethod(&window, "onRunAll");
        });
        QObject::connect(window.model(), &TrafficModel::countsChanged, &app, [&]() {
            if (expected > 0 && window.model()->counts().total >= expected) {
                expected = -1;  // only once
                // Load the stored events first so the Event log tab shows real data, then capture.
                auto capture = [&]() {
                    QTimer::singleShot(300, &app, [&]() {
                        const int saved = window.captureScreenshots(dir);
                        QTextStream(stdout) << "saved " << saved << " screenshot(s) to " << dir << "\n";
                        app.exit(saved == 5 ? 0 : 1);
                    });
                };
                QMetaObject::Connection* conn = new QMetaObject::Connection;
                *conn = QObject::connect(window.worker(), &WorkerClient::eventsReceived, &app, [conn, capture]() {
                    QObject::disconnect(*conn);
                    delete conn;
                    capture();
                });
                if (!window.worker()->requestEvents(200)) {
                    QObject::disconnect(*conn);
                    delete conn;
                    capture();  // event log unavailable: capture anyway (the tab then shows no stored rows)
                }
            }
        });
    }
    return app.exec();
}
