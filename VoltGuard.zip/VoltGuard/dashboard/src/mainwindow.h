// VoltGuard main window: dashboard, traffic monitor with command details, event log and configuration view.
// All processing happens in the worker process; this class only sends requests and displays results,
// so the GUI thread never waits for the parser or the simulation.
#pragma once

#include <QHash>
#include <QMainWindow>
#include <QStringList>

#include "alerts.h"
#include "commandrecord.h"
#include "workerclient.h"

class QComboBox;
class QGroupBox;
class QLabel;
class QLineEdit;
class QPlainTextEdit;
class QPushButton;
class QTabWidget;
class QTableView;
class QTableWidget;
class QListWidget;

namespace voltguard {

class TrafficModel;
class ChartPanel;

struct WorkerLaunch {
    QString program;
    QStringList arguments;
    QString workingDirectory;
};

class MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit MainWindow(QWidget* parent = nullptr);
    ~MainWindow() override;

    void startWorker(const WorkerLaunch& launch);
    WorkerClient* worker() { return m_client; }
    TrafficModel* model() { return m_model; }
    int scenarioCount() const;
    ChartPanel* charts() { return m_charts; }
    AlertLog* alerts() { return m_alerts; }

    // Validates the hex text locally, then sends it to the worker. Returns false (with a visible message)
    // if the input is invalid or the worker is not ready.
    bool submitFrame(const QString& source, const QString& frameHex);

    // Saves one PNG per tab into `directory`; returns the number of files written.
    int captureScreenshots(const QString& directory);

    // Asks the worker to export the stored event log (format "csv", "json" or "pdf"). False (with a visible message)
    // if the format is unknown, the path is empty or another log request is running. The worker refuses to
    // overwrite an existing file unless `overwrite` is true.
    bool exportEvents(const QString& format, const QString& path, bool overwrite = false);

private slots:
    void onWorkerState(WorkerClient::State state, const QString& detail);
    void onWorkerReady(const QJsonObject& info);
    void onScenarios(const QJsonArray& scenarios);
    void onResult(const QJsonObject& message);
    void onRequestFailed(const QString& commandId, const QString& reason);
    void onProtocolError(const QString& message);
    void onRunAll();
    void onSendScenario();
    void onSendHex();
    void onClear();
    void onRestart();
    void onLoadEvents();
    void onVerifyLog();
    void onEventsReceived(const QJsonObject& reply);
    void onLogVerified(bool ok, const QString& message);
    void onExportClicked(const QString& format);
    void onExportFinished(const QJsonObject& reply);
    void onSelectionChanged();
    void refreshDashboard();

private:
    struct Pending {
        QString source;
        QString frameHex;
    };

    void buildUi();
    QWidget* buildDashboardTab();
    QWidget* buildTrafficTab();
    QWidget* buildEventLogTab();
    QWidget* buildConfigTab();
    QWidget* buildGraphsTab();
    void refreshAlertList();
    void raiseSystemAlert(Alert::Level level, const QString& code, const QString& message);
    void setControlsEnabled(bool ready);
    void setInputMessage(const QString& text, bool error);
    void logEvent(const QString& level, const QString& message);
    void addRecord(const CommandRecord& record);
    void refreshStatusBar();
    void selectFirstViolationRow();

    WorkerClient* m_client = nullptr;
    TrafficModel* m_model = nullptr;
    WorkerLaunch m_launch;
    QHash<QString, Pending> m_pending;
    int m_nextId = 0;
    bool m_parserAvailable = false;
    QString m_parserPath;
    QString m_configPath;
    QJsonObject m_config;
    CommandRecord m_latest;
    bool m_hasLatest = false;
    bool m_eventLogOk = false;
    bool m_decisionOk = false;
    QString m_decisionText = QStringLiteral("-");
    QString m_eventLogText = QStringLiteral("-");

    QTabWidget* m_tabs = nullptr;
    QLabel* m_banner = nullptr;
    QLabel* m_inputMessage = nullptr;
    QLabel* m_statusLabel = nullptr;
    QPushButton* m_runAll = nullptr;
    QPushButton* m_sendScenario = nullptr;
    QPushButton* m_sendHex = nullptr;
    QPushButton* m_clear = nullptr;
    QPushButton* m_restart = nullptr;
    QComboBox* m_scenarioCombo = nullptr;
    QLineEdit* m_hexInput = nullptr;
    QLabel* m_appStatus = nullptr;
    QLabel* m_countTotal = nullptr;
    QLabel* m_countWithin = nullptr;
    QLabel* m_countViolation = nullptr;
    QLabel* m_countRejected = nullptr;
    QLabel* m_countFailure = nullptr;
    QLabel* m_countAllowed = nullptr;
    QLabel* m_countBlocked = nullptr;
    QLabel* m_countRejectDecision = nullptr;
    QLabel* m_latestDecision = nullptr;
    QLabel* m_latestStatus = nullptr;
    QLabel* m_latestDetail = nullptr;
    QTableView* m_table = nullptr;
    QPlainTextEdit* m_details = nullptr;
    QPlainTextEdit* m_eventLog = nullptr;
    QTableWidget* m_storedTable = nullptr;
    QPushButton* m_loadEvents = nullptr;
    QPushButton* m_verifyLog = nullptr;
    QLabel* m_logStatus = nullptr;
    QPushButton* m_exportCsv = nullptr;
    QPushButton* m_exportJson = nullptr;
    QPushButton* m_exportPdf = nullptr;
    QLabel* m_exportStatus = nullptr;
    bool m_exportPending = false;
    ChartPanel* m_charts = nullptr;
    AlertLog* m_alerts = nullptr;
    QListWidget* m_alertList = nullptr;
    QLabel* m_alertSummary = nullptr;
    QLabel* m_alertSummaryDash = nullptr;
    QTableWidget* m_configTable = nullptr;
    QLabel* m_configInfo = nullptr;
};

}  // namespace voltguard
