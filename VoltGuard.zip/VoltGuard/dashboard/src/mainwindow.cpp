#include "mainwindow.h"

#include <QApplication>
#include <QComboBox>
#include <QDateTime>
#include <QDir>
#include <QFileDialog>
#include <QGridLayout>
#include <QGroupBox>
#include <QHBoxLayout>
#include <QHeaderView>
#include <QJsonArray>
#include <QLabel>
#include <QListWidget>
#include <QLineEdit>
#include <QPlainTextEdit>
#include <QPushButton>
#include <QRegularExpression>
#include <QSplitter>
#include <QStatusBar>
#include <QTabWidget>
#include <QTableView>
#include <QTableWidget>
#include <QVBoxLayout>

#include "chartpanel.h"
#include "theme.h"
#include "trafficmodel.h"

namespace voltguard {

namespace {

constexpr int kMaxFrameHexChars = 4000;  // same limit as the worker (2000 bytes)

QString colorStyle(const QColor& c, int pointSize = 0, bool bold = false) {
    QString s = QStringLiteral("color: %1;").arg(theme::colorName(c));
    if (pointSize > 0) s += QStringLiteral(" font-size: %1pt;").arg(pointSize);
    if (bold) s += QStringLiteral(" font-weight: bold;");
    return s;
}

QLabel* makeCountLabel(const QString& objectName) {
    auto* l = new QLabel(QStringLiteral("0"));
    l->setObjectName(objectName);
    l->setStyleSheet(colorStyle(QColor(0xd8, 0xde, 0xe6), 22, true));
    l->setAlignment(Qt::AlignCenter);
    return l;
}

}  // namespace

MainWindow::MainWindow(QWidget* parent) : QMainWindow(parent) {
    setWindowTitle(QStringLiteral("VoltGuard - Physics-Aware Industrial Network Security"));
    resize(1280, 800);
    m_client = new WorkerClient(this);
    m_model = new TrafficModel(this);
    buildUi();

    connect(m_client, &WorkerClient::stateChanged, this, &MainWindow::onWorkerState);
    connect(m_client, &WorkerClient::ready, this, &MainWindow::onWorkerReady);
    connect(m_client, &WorkerClient::scenariosReceived, this, &MainWindow::onScenarios);
    connect(m_client, &WorkerClient::eventsReceived, this, &MainWindow::onEventsReceived);
    connect(m_client, &WorkerClient::logVerified, this, &MainWindow::onLogVerified);
    connect(m_client, &WorkerClient::resultReceived, this, &MainWindow::onResult);
    connect(m_client, &WorkerClient::requestFailed, this, &MainWindow::onRequestFailed);
    connect(m_client, &WorkerClient::protocolError, this, &MainWindow::onProtocolError);
    connect(m_model, &TrafficModel::countsChanged, this, &MainWindow::refreshDashboard);

    setControlsEnabled(false);
    refreshDashboard();
    refreshStatusBar();
    logEvent(QStringLiteral("INFO"), QStringLiteral("Application started. Simulation prototype: no live industrial equipment is connected."));
}

MainWindow::~MainWindow() {
    // Stop the worker while this object is still fully alive: stop() reports pending requests through signals,
    // and those must not reach a partly destroyed window.
    m_client->disconnect(this);
    m_client->stop();
}

// ---------------------------------------------------------------------------- UI construction

void MainWindow::buildUi() {
    auto* central = new QWidget(this);
    auto* root = new QVBoxLayout(central);

    m_banner = new QLabel(QStringLiteral(
        "SIMULATION PROTOTYPE - every value shown is a SIMULATED prediction, not a sensor measurement. "
        "ALLOW / BLOCK / REJECT are policy decisions about simulated predictions; nothing is forwarded to any device and no industrial equipment is connected."));
    m_banner->setObjectName(QStringLiteral("bannerLabel"));
    m_banner->setWordWrap(true);
    m_banner->setStyleSheet(QStringLiteral("background: #3a2f12; color: #f5c542; padding: 6px; border: 1px solid #6b5a1e;"));
    root->addWidget(m_banner);

    auto* controls = new QHBoxLayout;
    m_runAll = new QPushButton(QStringLiteral("Run all scenarios"));
    m_runAll->setObjectName(QStringLiteral("runAllButton"));
    m_scenarioCombo = new QComboBox;
    m_scenarioCombo->setObjectName(QStringLiteral("scenarioCombo"));
    m_scenarioCombo->setMinimumWidth(260);
    m_sendScenario = new QPushButton(QStringLiteral("Send scenario"));
    m_sendScenario->setObjectName(QStringLiteral("sendScenarioButton"));
    m_hexInput = new QLineEdit;
    m_hexInput->setObjectName(QStringLiteral("hexInput"));
    m_hexInput->setPlaceholderText(QStringLiteral("Modbus/TCP frame as hex, e.g. 00010000000601060064003c"));
    m_sendHex = new QPushButton(QStringLiteral("Send frame"));
    m_sendHex->setObjectName(QStringLiteral("sendHexButton"));
    m_clear = new QPushButton(QStringLiteral("Clear"));
    m_clear->setObjectName(QStringLiteral("clearButton"));
    m_restart = new QPushButton(QStringLiteral("Restart worker"));
    m_restart->setObjectName(QStringLiteral("restartButton"));
    controls->addWidget(m_runAll);
    controls->addWidget(m_scenarioCombo);
    controls->addWidget(m_sendScenario);
    controls->addWidget(m_hexInput, 1);
    controls->addWidget(m_sendHex);
    controls->addWidget(m_clear);
    controls->addWidget(m_restart);
    root->addLayout(controls);

    m_inputMessage = new QLabel;
    m_inputMessage->setObjectName(QStringLiteral("inputMessageLabel"));
    m_inputMessage->setWordWrap(true);
    root->addWidget(m_inputMessage);

    m_tabs = new QTabWidget;
    m_tabs->setObjectName(QStringLiteral("tabs"));
    m_tabs->addTab(buildDashboardTab(), QStringLiteral("Dashboard"));
    m_tabs->addTab(buildTrafficTab(), QStringLiteral("Traffic"));
    m_tabs->addTab(buildGraphsTab(), QStringLiteral("Graphs and alerts"));
    m_tabs->addTab(buildEventLogTab(), QStringLiteral("Event log"));
    m_tabs->addTab(buildConfigTab(), QStringLiteral("Configuration"));
    root->addWidget(m_tabs, 1);
    setCentralWidget(central);

    m_statusLabel = new QLabel;
    m_statusLabel->setObjectName(QStringLiteral("statusBarLabel"));
    statusBar()->addWidget(m_statusLabel, 1);

    refreshAlertList();
    connect(m_runAll, &QPushButton::clicked, this, &MainWindow::onRunAll);
    connect(m_sendScenario, &QPushButton::clicked, this, &MainWindow::onSendScenario);
    connect(m_sendHex, &QPushButton::clicked, this, &MainWindow::onSendHex);
    connect(m_hexInput, &QLineEdit::returnPressed, this, &MainWindow::onSendHex);
    connect(m_clear, &QPushButton::clicked, this, &MainWindow::onClear);
    connect(m_restart, &QPushButton::clicked, this, &MainWindow::onRestart);
}

QWidget* MainWindow::buildDashboardTab() {
    auto* page = new QWidget;
    auto* grid = new QGridLayout(page);

    auto* statusBox = new QGroupBox(QStringLiteral("Application status"));
    auto* statusLayout = new QVBoxLayout(statusBox);
    m_appStatus = new QLabel;
    m_appStatus->setObjectName(QStringLiteral("appStatusLabel"));
    m_appStatus->setTextInteractionFlags(Qt::TextSelectableByMouse);
    statusLayout->addWidget(m_appStatus);
    grid->addWidget(statusBox, 0, 0);

    auto* countsBox = new QGroupBox(QStringLiteral("Commands since last clear"));
    auto* cl = new QGridLayout(countsBox);
    m_countTotal = makeCountLabel(QStringLiteral("countTotal"));
    m_countWithin = makeCountLabel(QStringLiteral("countWithin"));
    m_countViolation = makeCountLabel(QStringLiteral("countViolation"));
    m_countRejected = makeCountLabel(QStringLiteral("countRejected"));
    m_countFailure = makeCountLabel(QStringLiteral("countFailure"));
    m_countWithin->setStyleSheet(colorStyle(theme::kOk, 22, true));
    m_countViolation->setStyleSheet(colorStyle(theme::kViolation, 22, true));
    m_countRejected->setStyleSheet(colorStyle(theme::kRejected, 22, true));
    m_countFailure->setStyleSheet(colorStyle(theme::kFailure, 22, true));
    m_countAllowed = makeCountLabel(QStringLiteral("countAllowed"));
    m_countBlocked = makeCountLabel(QStringLiteral("countBlocked"));
    m_countRejectDecision = makeCountLabel(QStringLiteral("countRejectDecision"));
    m_countAllowed->setStyleSheet(colorStyle(theme::kOk, 22, true));
    m_countBlocked->setStyleSheet(colorStyle(theme::kFailure, 22, true));
    m_countRejectDecision->setStyleSheet(colorStyle(theme::kRejected, 22, true));
    const QStringList captions = {QStringLiteral("Total"), QStringLiteral("Within limits (simulated)"),
                                  QStringLiteral("Limit violations (simulated)"), QStringLiteral("Rejected"),
                                  QStringLiteral("Component failures")};
    QLabel* counts[] = {m_countTotal, m_countWithin, m_countViolation, m_countRejected, m_countFailure};
    for (int i = 0; i < 5; ++i) {
        cl->addWidget(counts[i], 0, i);
        auto* cap = new QLabel(captions.at(i));
        cap->setAlignment(Qt::AlignCenter);
        cap->setWordWrap(true);
        cap->setStyleSheet(colorStyle(theme::kMuted));
        cl->addWidget(cap, 1, i);
    }
    cl->addWidget(m_countAllowed, 2, 0);
    cl->addWidget(m_countBlocked, 2, 1);
    cl->addWidget(m_countRejectDecision, 2, 2);
    const QStringList decisionCaptions = {QStringLiteral("Decisions: ALLOW"), QStringLiteral("Decisions: BLOCK"), QStringLiteral("Decisions: REJECT")};
    for (int i = 0; i < 3; ++i) {
        auto* cap = new QLabel(decisionCaptions.at(i));
        cap->setAlignment(Qt::AlignCenter);
        cap->setStyleSheet(colorStyle(theme::kMuted));
        cl->addWidget(cap, 3, i);
    }
    grid->addWidget(countsBox, 0, 1);

    auto* latestBox = new QGroupBox(QStringLiteral("Latest command"));
    auto* ll = new QVBoxLayout(latestBox);
    m_latestDecision = new QLabel;
    m_latestDecision->setObjectName(QStringLiteral("latestDecisionLabel"));
    m_latestDecision->setStyleSheet(colorStyle(theme::kMuted, 26, true));
    ll->addWidget(m_latestDecision);
    m_latestStatus = new QLabel(QStringLiteral("No commands processed yet"));
    m_latestStatus->setObjectName(QStringLiteral("latestStatusLabel"));
    m_latestStatus->setStyleSheet(colorStyle(theme::kMuted, 20, true));
    m_latestDetail = new QLabel;
    m_latestDetail->setObjectName(QStringLiteral("latestDetailLabel"));
    m_latestDetail->setWordWrap(true);
    ll->addWidget(m_latestStatus);
    ll->addWidget(m_latestDetail);
    ll->addStretch(1);
    grid->addWidget(latestBox, 1, 0, 1, 2);
    m_alertSummaryDash = new QLabel;
    m_alertSummaryDash->setObjectName(QStringLiteral("alertSummaryDashLabel"));
    grid->addWidget(m_alertSummaryDash, 2, 0, 1, 2);
    grid->setRowStretch(1, 1);
    grid->setColumnStretch(0, 1);
    grid->setColumnStretch(1, 2);
    return page;
}

QWidget* MainWindow::buildTrafficTab() {
    auto* split = new QSplitter(Qt::Horizontal);
    m_table = new QTableView;
    m_table->setObjectName(QStringLiteral("trafficTable"));
    m_table->setModel(m_model);
    m_table->setSelectionBehavior(QAbstractItemView::SelectRows);
    m_table->setSelectionMode(QAbstractItemView::SingleSelection);
    m_table->setEditTriggers(QAbstractItemView::NoEditTriggers);
    m_table->setAlternatingRowColors(true);
    m_table->verticalHeader()->hide();
    m_table->horizontalHeader()->setStretchLastSection(false);
    m_table->horizontalHeader()->setSectionResizeMode(TrafficModel::ColParsed, QHeaderView::Stretch);
    m_table->setColumnWidth(TrafficModel::ColTime, 85);
    m_table->setColumnWidth(TrafficModel::ColCommandId, 95);
    m_table->setColumnWidth(TrafficModel::ColSource, 135);
    m_table->setColumnWidth(TrafficModel::ColParsed, 170);
    m_table->setColumnWidth(TrafficModel::ColStage, 120);
    m_table->setColumnWidth(TrafficModel::ColPressure, 130);
    m_table->setColumnWidth(TrafficModel::ColSafety, 150);
    m_table->setColumnWidth(TrafficModel::ColDecision, 90);
    connect(m_table->selectionModel(), &QItemSelectionModel::currentRowChanged, this, &MainWindow::onSelectionChanged);

    m_details = new QPlainTextEdit;
    m_details->setObjectName(QStringLiteral("detailsView"));
    m_details->setReadOnly(true);
    m_details->setLineWrapMode(QPlainTextEdit::WidgetWidth);
    m_details->setPlainText(QStringLiteral("Select a command to see its details."));
    QFont mono(QStringLiteral("monospace"));
    mono.setStyleHint(QFont::Monospace);
    m_details->setFont(mono);

    split->addWidget(m_table);
    split->addWidget(m_details);
    split->setStretchFactor(0, 3);
    split->setStretchFactor(1, 2);
    split->setSizes({960, 320});
    return split;
}

QWidget* MainWindow::buildEventLogTab() {
    auto* page = new QWidget;
    auto* layout = new QVBoxLayout(page);
    auto* bar = new QHBoxLayout;
    m_loadEvents = new QPushButton(QStringLiteral("Load stored events (newest 200)"));
    m_loadEvents->setObjectName(QStringLiteral("loadEventsButton"));
    m_verifyLog = new QPushButton(QStringLiteral("Verify log integrity"));
    m_verifyLog->setObjectName(QStringLiteral("verifyLogButton"));
    m_logStatus = new QLabel(QStringLiteral("The stored event log is persistent (SQLite) and is NOT cleared by the Clear button."));
    m_logStatus->setObjectName(QStringLiteral("logStatusLabel"));
    m_logStatus->setWordWrap(true);
    m_exportCsv = new QPushButton(QStringLiteral("Export CSV"));
    m_exportCsv->setObjectName(QStringLiteral("exportCsvButton"));
    m_exportJson = new QPushButton(QStringLiteral("Export JSON"));
    m_exportJson->setObjectName(QStringLiteral("exportJsonButton"));
    m_exportPdf = new QPushButton(QStringLiteral("Export PDF report"));
    m_exportPdf->setObjectName(QStringLiteral("exportPdfButton"));
    m_exportPdf->setToolTip(QStringLiteral("Needs the optional Python package reportlab (see requirements-optional.txt)"));
    m_exportStatus = new QLabel;
    m_exportStatus->setObjectName(QStringLiteral("exportStatusLabel"));
    m_exportStatus->setWordWrap(true);
    m_exportStatus->setTextInteractionFlags(Qt::TextSelectableByMouse);
    bar->addWidget(m_loadEvents);
    bar->addWidget(m_verifyLog);
    bar->addWidget(m_logStatus, 1);
    layout->addLayout(bar);
    auto* exportBar = new QHBoxLayout;
    exportBar->addWidget(m_exportCsv);
    exportBar->addWidget(m_exportJson);
    exportBar->addWidget(m_exportPdf);
    exportBar->addWidget(m_exportStatus, 1);
    layout->addLayout(exportBar);

    m_storedTable = new QTableWidget(0, 7);
    m_storedTable->setObjectName(QStringLiteral("storedEventsTable"));
    m_storedTable->setHorizontalHeaderLabels({QStringLiteral("#"), QStringLiteral("Time (UTC)"), QStringLiteral("Command ID"),
                                              QStringLiteral("Source"), QStringLiteral("Stage"), QStringLiteral("Severity"),
                                              QStringLiteral("Pressure (simulated)")});
    m_storedTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    m_storedTable->setSelectionBehavior(QAbstractItemView::SelectRows);
    m_storedTable->verticalHeader()->hide();
    m_storedTable->horizontalHeader()->setStretchLastSection(true);
    m_storedTable->setColumnWidth(0, 50);
    m_storedTable->setColumnWidth(1, 235);
    m_storedTable->setColumnWidth(2, 90);
    m_storedTable->setColumnWidth(3, 240);
    m_storedTable->setColumnWidth(4, 150);
    m_storedTable->setColumnWidth(5, 170);

    auto* split = new QSplitter(Qt::Vertical);
    split->addWidget(m_storedTable);
    m_eventLog = new QPlainTextEdit;
    m_eventLog->setObjectName(QStringLiteral("eventLog"));
    m_eventLog->setReadOnly(true);
    m_eventLog->setMaximumBlockCount(2000);
    QFont mono(QStringLiteral("monospace"));
    mono.setStyleHint(QFont::Monospace);
    m_eventLog->setFont(mono);
    split->addWidget(m_eventLog);
    split->setSizes({300, 300});
    layout->addWidget(split, 1);
    connect(m_loadEvents, &QPushButton::clicked, this, &MainWindow::onLoadEvents);
    connect(m_verifyLog, &QPushButton::clicked, this, &MainWindow::onVerifyLog);
    connect(m_exportCsv, &QPushButton::clicked, this, [this]() { onExportClicked(QStringLiteral("csv")); });
    connect(m_exportJson, &QPushButton::clicked, this, [this]() { onExportClicked(QStringLiteral("json")); });
    connect(m_exportPdf, &QPushButton::clicked, this, [this]() { onExportClicked(QStringLiteral("pdf")); });
    connect(m_client, &WorkerClient::exportFinished, this, &MainWindow::onExportFinished);
    return page;
}

QWidget* MainWindow::buildConfigTab() {
    auto* page = new QWidget;
    auto* l = new QVBoxLayout(page);
    m_configInfo = new QLabel(QStringLiteral("Waiting for the worker to report the safety configuration..."));
    m_configInfo->setObjectName(QStringLiteral("configInfoLabel"));
    m_configInfo->setWordWrap(true);
    l->addWidget(m_configInfo);
    m_configTable = new QTableWidget(0, 4);
    m_configTable->setObjectName(QStringLiteral("configTable"));
    m_configTable->setHorizontalHeaderLabels({QStringLiteral("Quantity"), QStringLiteral("Minimum"),
                                              QStringLiteral("Maximum"), QStringLiteral("Unit")});
    m_configTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    m_configTable->horizontalHeader()->setStretchLastSection(true);
    m_configTable->verticalHeader()->hide();
    l->addWidget(m_configTable, 1);
    auto* note = new QLabel(QStringLiteral(
        "Read-only view of config/safety_limits.json. These are EXAMPLE simulated limits for a mock pipeline, "
        "not real industrial limits. Editing limits from the dashboard is not implemented yet."));
    note->setWordWrap(true);
    note->setStyleSheet(colorStyle(theme::kMuted));
    l->addWidget(note);
    return page;
}

// ---------------------------------------------------------------------------- worker lifecycle

void MainWindow::startWorker(const WorkerLaunch& launch) {
    m_launch = launch;
    m_parserAvailable = false;
    m_eventLogOk = false;
    m_eventLogText = QStringLiteral("-");
    m_decisionOk = false;
    m_decisionText = QStringLiteral("-");
    logEvent(QStringLiteral("INFO"), QStringLiteral("Starting worker: %1 %2").arg(launch.program, launch.arguments.join(QLatin1Char(' '))));
    m_client->start(launch.program, launch.arguments, launch.workingDirectory);
}

void MainWindow::onRestart() {
    if (m_launch.program.isEmpty()) return;
    logEvent(QStringLiteral("INFO"), QStringLiteral("Restarting worker"));
    setInputMessage(QString(), false);
    startWorker(m_launch);
}

void MainWindow::onWorkerState(WorkerClient::State state, const QString& detail) {
    const QString level = state == WorkerClient::State::Failed ? QStringLiteral("ERROR") : QStringLiteral("INFO");
    logEvent(level, QStringLiteral("Worker %1: %2").arg(WorkerClient::stateText(state), detail));
    if (state == WorkerClient::State::Failed && m_exportPending) {
        m_exportPending = false;
        m_exportStatus->setText(QStringLiteral("Export FAILED: the worker stopped before finishing. The file may not exist."));
        m_exportStatus->setStyleSheet(colorStyle(theme::kFailure, 0, true));
    }
    if (state == WorkerClient::State::Failed) raiseSystemAlert(Alert::Level::Critical, QStringLiteral("WORKER_FAILED"), QStringLiteral("Worker failed: %1 (commands fail closed)").arg(detail));
    setControlsEnabled(state == WorkerClient::State::Ready);
    refreshStatusBar();
    refreshDashboard();
}

void MainWindow::onWorkerReady(const QJsonObject& info) {
    m_parserAvailable = info.value(QLatin1String("parser_available")).toBool(false);
    m_parserPath = info.value(QLatin1String("parser_path")).toString();
    m_configPath = info.value(QLatin1String("config_path")).toString();
    m_config = info.value(QLatin1String("config")).toObject();
    {
        const QJsonObject pl = m_config.value(QLatin1String("pressure")).toObject(), fl = m_config.value(QLatin1String("flow")).toObject();
        if (pl.value(QLatin1String("min")).isDouble() && pl.value(QLatin1String("max")).isDouble() &&
            fl.value(QLatin1String("min")).isDouble() && fl.value(QLatin1String("max")).isDouble())
            m_charts->setLimits(pl.value(QLatin1String("min")).toDouble(), pl.value(QLatin1String("max")).toDouble(), pl.value(QLatin1String("unit")).toString(),
                                fl.value(QLatin1String("min")).toDouble(), fl.value(QLatin1String("max")).toDouble(), fl.value(QLatin1String("unit")).toString());
    }
    const QJsonObject el = info.value(QLatin1String("event_log")).toObject();
    m_eventLogOk = el.value(QLatin1String("ok")).toBool(false);
    if (m_eventLogOk) m_eventLogText = QStringLiteral("%1 (recording)").arg(el.value(QLatin1String("path")).toString());
    else if (!el.value(QLatin1String("enabled")).toBool(true)) m_eventLogText = QStringLiteral("switched off - nothing is recorded");
    else m_eventLogText = QStringLiteral("NOT AVAILABLE - nothing is recorded: %1").arg(el.value(QLatin1String("error")).toString().left(200));
    if (!m_eventLogOk) logEvent(QStringLiteral("ERROR"), QStringLiteral("Event log: %1").arg(m_eventLogText));
    const QJsonObject de = info.value(QLatin1String("decision_engine")).toObject();
    m_decisionOk = de.value(QLatin1String("available")).toBool(false);
    m_decisionText = m_decisionOk ? de.value(QLatin1String("path")).toString()
                                  : QStringLiteral("NOT AVAILABLE - every command is REJECTED (fail closed): %1").arg(de.value(QLatin1String("error")).toString().left(200));
    if (!m_decisionOk) {
        logEvent(QStringLiteral("ERROR"), QStringLiteral("Decision engine: %1").arg(m_decisionText));
        raiseSystemAlert(Alert::Level::Critical, QStringLiteral("DECISION_ENGINE_UNAVAILABLE"), QStringLiteral("Decision engine unavailable: every command will be REJECTED (fail closed)"));
    }
    if (!m_eventLogOk) raiseSystemAlert(m_eventLogText.startsWith(QLatin1String("switched off")) ? Alert::Level::Warning : Alert::Level::Critical, QStringLiteral("EVENT_LOG_UNAVAILABLE"), QStringLiteral("Event log: %1").arg(m_eventLogText));
    if (!m_parserAvailable) raiseSystemAlert(Alert::Level::Critical, QStringLiteral("PARSER_UNAVAILABLE"), QStringLiteral("C++ parser not found: every command will fail closed"));

    m_configTable->setRowCount(0);
    for (const QString& key : {QStringLiteral("pressure"), QStringLiteral("flow"), QStringLiteral("pump_speed"), QStringLiteral("valve_position")}) {
        const QJsonObject lim = m_config.value(key).toObject();
        if (lim.isEmpty()) continue;
        const int row = m_configTable->rowCount();
        m_configTable->insertRow(row);
        m_configTable->setItem(row, 0, new QTableWidgetItem(key));
        m_configTable->setItem(row, 1, new QTableWidgetItem(QString::number(lim.value(QLatin1String("min")).toDouble(), 'g', 10)));
        m_configTable->setItem(row, 2, new QTableWidgetItem(QString::number(lim.value(QLatin1String("max")).toDouble(), 'g', 10)));
        m_configTable->setItem(row, 3, new QTableWidgetItem(lim.value(QLatin1String("unit")).toString()));
    }
    const QJsonObject to = m_config.value(QLatin1String("timeouts_ms")).toObject();
    m_configInfo->setText(QStringLiteral("File: %1\nComponent timeouts (ms): parser %2, simulation %3, decision %4\n%5")
                              .arg(m_configPath)
                              .arg(to.value(QLatin1String("parser")).toInt())
                              .arg(to.value(QLatin1String("simulation")).toInt())
                              .arg(to.value(QLatin1String("decision")).toInt())
                              .arg(m_config.value(QLatin1String("description")).toString()));
    if (!m_parserAvailable) {
        logEvent(QStringLiteral("ERROR"), QStringLiteral("The C++ parser executable was not found: commands will fail closed. Build it with: cmake -S . -B build && cmake --build build"));
    }
    m_client->requestScenarios();
    refreshStatusBar();
    refreshDashboard();
}

void MainWindow::onScenarios(const QJsonArray& scenarios) {
    m_scenarioCombo->clear();
    for (const QJsonValue& v : scenarios) {
        const QJsonObject o = v.toObject();
        const QString name = o.value(QLatin1String("name")).toString();
        const QString hex = o.value(QLatin1String("frame_hex")).toString();
        if (name.isEmpty() || o.value(QLatin1String("frame_hex")).isUndefined()) continue;
        m_scenarioCombo->addItem(name, hex);
        m_scenarioCombo->setItemData(m_scenarioCombo->count() - 1, o.value(QLatin1String("description")).toString(), Qt::ToolTipRole);
    }
    logEvent(QStringLiteral("INFO"), QStringLiteral("%1 test scenario(s) loaded").arg(m_scenarioCombo->count()));
    setControlsEnabled(m_client->isReady());
}

int MainWindow::scenarioCount() const { return m_scenarioCombo->count(); }

void MainWindow::setControlsEnabled(bool ready) {
    const bool haveScenarios = ready && m_scenarioCombo->count() > 0;
    m_runAll->setEnabled(haveScenarios);
    m_scenarioCombo->setEnabled(haveScenarios);
    m_sendScenario->setEnabled(haveScenarios);
    m_sendHex->setEnabled(ready);
    m_hexInput->setEnabled(ready);
    m_restart->setEnabled(!m_launch.program.isEmpty());
    const bool canQuery = ready && m_eventLogOk && !m_client->queryPending();
    m_loadEvents->setEnabled(canQuery);
    m_verifyLog->setEnabled(canQuery);
    m_exportCsv->setEnabled(canQuery);
    m_exportJson->setEnabled(canQuery);
    m_exportPdf->setEnabled(canQuery);
}

// ---------------------------------------------------------------------------- sending

bool MainWindow::submitFrame(const QString& source, const QString& frameHexRaw) {
    QString hex = frameHexRaw;
    hex.remove(QRegularExpression(QStringLiteral("\\s")));
    static const QRegularExpression hexOnly(QStringLiteral("^[0-9a-fA-F]*$"));

    if (hex.size() > kMaxFrameHexChars) {
        const QString msg = QStringLiteral("Frame is too long (%1 hex digits; the maximum is %2).").arg(hex.size()).arg(kMaxFrameHexChars);
        setInputMessage(msg, true);
        logEvent(QStringLiteral("WARN"), msg);
        return false;
    }
    if (hex.size() % 2 != 0 || !hexOnly.match(hex).hasMatch()) {
        const QString msg = QStringLiteral("Frame must be an even number of hexadecimal digits (0-9, a-f). Nothing was sent.");
        setInputMessage(msg, true);
        logEvent(QStringLiteral("WARN"), msg);
        return false;
    }
    if (!m_client->isReady()) {
        const QString msg = QStringLiteral("The worker is not ready (%1), so nothing was sent.").arg(WorkerClient::stateText(m_client->state()));
        setInputMessage(msg, true);
        logEvent(QStringLiteral("WARN"), msg);
        return false;
    }

    const QString id = QStringLiteral("UI-%1").arg(++m_nextId, 4, 10, QLatin1Char('0'));
    m_pending.insert(id, Pending{source, hex});
    if (!m_client->sendProcess(id, hex, source)) {
        m_pending.remove(id);
        addRecord(CommandRecord::failure(id, source, hex, QStringLiteral("SEND_FAILED"), QStringLiteral("the request could not be sent to the worker")));
        return false;
    }
    setInputMessage(QString(), false);
    return true;
}

void MainWindow::onRunAll() {
    for (int i = 0; i < m_scenarioCombo->count(); ++i) {
        if (!submitFrame(m_scenarioCombo->itemText(i), m_scenarioCombo->itemData(i).toString())) break;
    }
}

void MainWindow::onSendScenario() {
    const int i = m_scenarioCombo->currentIndex();
    if (i >= 0) submitFrame(m_scenarioCombo->itemText(i), m_scenarioCombo->itemData(i).toString());
}

void MainWindow::onSendHex() {
    if (submitFrame(QStringLiteral("manual"), m_hexInput->text())) m_hexInput->clear();
}

void MainWindow::onClear() {
    m_model->clear();
    m_charts->clear();
    m_alerts->clear();
    m_details->setPlainText(QStringLiteral("Select a command to see its details."));
    m_hasLatest = false;
    refreshDashboard();
    logEvent(QStringLiteral("INFO"), QStringLiteral("Traffic table, graphs and alerts cleared (the event log is kept)"));
}

void MainWindow::setInputMessage(const QString& text, bool error) {
    m_inputMessage->setText(text);
    m_inputMessage->setStyleSheet(error ? colorStyle(theme::kFailure) : colorStyle(theme::kMuted));
}

// ---------------------------------------------------------------------------- receiving

void MainWindow::onResult(const QJsonObject& message) {
    const QString id = message.value(QLatin1String("command_id")).toString();
    const Pending pending = m_pending.take(id);

    CommandRecord record;
    QString error;
    if (!CommandRecord::fromJson(message, &record, &error)) {
        addRecord(CommandRecord::failure(id, pending.source, pending.frameHex, QStringLiteral("INVALID_WORKER_REPLY"),
                                         QStringLiteral("the worker's reply was rejected: %1").arg(error)));
        return;
    }
    record.source = pending.source.isEmpty() ? QStringLiteral("unknown") : pending.source;
    record.frameHex = pending.frameHex;
    addRecord(record);
}

void MainWindow::onRequestFailed(const QString& commandId, const QString& reason) {
    const Pending pending = m_pending.take(commandId);
    addRecord(CommandRecord::failure(commandId, pending.source, pending.frameHex, QStringLiteral("WORKER_FAILURE"), reason));
}

void MainWindow::onProtocolError(const QString& message) {
    logEvent(QStringLiteral("WARN"), QStringLiteral("Worker protocol: %1").arg(message));
}

void MainWindow::addRecord(const CommandRecord& record) {
    m_model->append(record);
    m_charts->addRecord(record);
    m_alerts->addAll(alertsForRecord(record));
    m_latest = record;
    m_hasLatest = true;
    m_table->scrollToBottom();

    QString level = QStringLiteral("INFO");
    switch (record.severity()) {
        case CommandRecord::Severity::Ok: break;
        case CommandRecord::Severity::Violation:
        case CommandRecord::Severity::Rejected: level = QStringLiteral("WARN"); break;
        case CommandRecord::Severity::Failure: level = QStringLiteral("ERROR"); break;
    }
    QString line = QStringLiteral("%1 [%2] %3: %4 -> %5").arg(record.commandId, record.source, record.stage, record.safetyStatus(), record.decisionText());
    if (!record.violations.isEmpty()) line += QStringLiteral(" - ") + record.violationTypes.join(QStringLiteral(", "));
    if (!record.error.isEmpty()) line += QStringLiteral(" - %1: %2").arg(record.errorCode, record.error);
    if (record.logged == 0) {
        line += QStringLiteral(" - NOT STORED in the event log");
        level = QStringLiteral("ERROR");
    }
    if (!record.simError.isEmpty()) line += QStringLiteral(" - ") + record.simError;
    logEvent(level, line);
    refreshDashboard();
}

void MainWindow::onSelectionChanged() {
    const QModelIndex idx = m_table->currentIndex();
    if (!idx.isValid()) return;
    m_details->setPlainText(m_model->recordAt(idx.row()).detailsText());
}

// ---------------------------------------------------------------------------- stored event log

void MainWindow::onLoadEvents() {
    m_logStatus->setStyleSheet(QString());
    if (m_client->requestEvents(200)) {
        m_logStatus->setText(QStringLiteral("Loading stored events..."));
        setControlsEnabled(true);
    }
}

void MainWindow::onVerifyLog() {
    m_logStatus->setStyleSheet(QString());
    if (m_client->requestLogVerification()) {
        m_logStatus->setText(QStringLiteral("Verifying the hash chain..."));
        setControlsEnabled(true);
    }
}

void MainWindow::onEventsReceived(const QJsonObject& reply) {
    const QJsonArray events = reply.value(QLatin1String("events")).toArray();
    m_storedTable->setRowCount(0);
    for (const QJsonValue& v : events) {
        const QJsonObject e = v.toObject();
        const int row = m_storedTable->rowCount();
        m_storedTable->insertRow(row);
        const QJsonValue p = e.value(QLatin1String("predicted_pressure"));
        const QStringList cells = {QString::number(e.value(QLatin1String("id")).toInt()),
                                   e.value(QLatin1String("timestamp_utc")).toString().left(40),
                                   e.value(QLatin1String("command_id")).toString().left(64),
                                   e.value(QLatin1String("source")).toString().left(120),
                                   e.value(QLatin1String("stage")).toString().left(40),
                                   e.value(QLatin1String("severity")).toString().left(40),
                                   p.isDouble() ? QString::number(p.toDouble(), 'f', 2) + QStringLiteral(" kPa") : QStringLiteral("-")};
        for (int c = 0; c < cells.size(); ++c) m_storedTable->setItem(row, c, new QTableWidgetItem(cells.at(c)));
    }
    m_logStatus->setText(QStringLiteral("Showing %1 of %2 stored event(s), newest first. All values are SIMULATED.")
                             .arg(events.size()).arg(reply.value(QLatin1String("total")).toInt()));
    setControlsEnabled(m_client->isReady());
}

bool MainWindow::exportEvents(const QString& format, const QString& path, bool overwrite) {
    auto refuse = [&](const QString& why) {
        m_exportStatus->setText(why);
        m_exportStatus->setStyleSheet(colorStyle(theme::kFailure, 0, true));
        return false;
    };
    if (format != QLatin1String("csv") && format != QLatin1String("json") && format != QLatin1String("pdf"))
        return refuse(QStringLiteral("Unknown export format."));
    if (path.trimmed().isEmpty() || path.size() > 4096) return refuse(QStringLiteral("Choose a file name for the export."));
    if (!m_client->isReady() || !m_eventLogOk) return refuse(QStringLiteral("The event log is not available, so there is nothing to export."));
    if (!m_client->requestExport(format, path, overwrite)) return refuse(QStringLiteral("Another event log request is still running; try again in a moment."));
    m_exportPending = true;
    m_exportStatus->setText(QStringLiteral("Exporting %1 ...").arg(format.toUpper()));
    m_exportStatus->setStyleSheet(QString());
    setControlsEnabled(m_client->isReady());
    return true;
}

void MainWindow::onExportClicked(const QString& format) {
    const QString stamp = QDateTime::currentDateTimeUtc().toString(QStringLiteral("yyyyMMdd_HHmmss"));
    const QString filter = format == QLatin1String("csv") ? QStringLiteral("CSV files (*.csv)")
                         : format == QLatin1String("json") ? QStringLiteral("JSON files (*.json)") : QStringLiteral("PDF files (*.pdf)");
    // The dialog itself asks before replacing an existing file; only then is overwriting allowed.
    const QString path = QFileDialog::getSaveFileName(this, QStringLiteral("Export the event log (simulated data)"),
                                                      QStringLiteral("voltguard_events_%1.%2").arg(stamp, format), filter);
    if (path.isEmpty()) return;
    exportEvents(format, path, QFileInfo::exists(path));
}

void MainWindow::onExportFinished(const QJsonObject& reply) {
    m_exportPending = false;
    setControlsEnabled(m_client->isReady());
    const bool ok = reply.value(QLatin1String("ok")).toBool(false) && reply.value(QLatin1String("ok")).isBool();
    if (!ok) {
        const QString why = reply.value(QLatin1String("error")).toString(QStringLiteral("the worker gave no reason")).left(300);
        m_exportStatus->setText(QStringLiteral("Export FAILED: %1").arg(why));
        m_exportStatus->setStyleSheet(colorStyle(theme::kFailure, 0, true));
        logEvent(QStringLiteral("ERROR"), QStringLiteral("Event log export failed: %1").arg(why));
        raiseSystemAlert(Alert::Level::Warning, QStringLiteral("EXPORT_FAILED"), QStringLiteral("Event log export failed: %1").arg(why));
        return;
    }
    const QString path = reply.value(QLatin1String("path")).toString().left(500);
    const int rows = reply.value(QLatin1String("rows")).toInt(-1), total = reply.value(QLatin1String("total")).toInt(-1);
    const bool truncated = reply.value(QLatin1String("truncated")).toBool(false);
    const bool verified = reply.value(QLatin1String("verified")).toBool(false);
    const QString message = reply.value(QLatin1String("message")).toString().left(300);
    QString text = QStringLiteral("Exported %1 of %2 event(s) to %3.").arg(rows).arg(total).arg(path);
    if (truncated) text += QStringLiteral(" TRUNCATED: the file does not contain every event.");
    text += verified ? QStringLiteral(" Integrity check passed (tamper-evidence only).")
                     : QStringLiteral(" INTEGRITY CHECK FAILED: %1. The file is labelled accordingly.").arg(message);
    m_exportStatus->setText(text);
    m_exportStatus->setStyleSheet(verified && !truncated ? QString() : colorStyle(verified ? theme::kRejected : theme::kFailure, 0, true));
    logEvent(verified ? QStringLiteral("INFO") : QStringLiteral("ERROR"), text);
    if (!verified)
        raiseSystemAlert(Alert::Level::Critical, QStringLiteral("LOG_INTEGRITY_FAILED"), QStringLiteral("Event log integrity check FAILED during export: %1").arg(message));
}

void MainWindow::onLogVerified(bool ok, const QString& message) {
    m_logStatus->setText(ok ? QStringLiteral("Integrity check passed: %1. (Tamper-evidence only: see docs/event_logging.md.)").arg(message)
                            : QStringLiteral("INTEGRITY CHECK FAILED: %1").arg(message));
    m_logStatus->setStyleSheet(ok ? QString() : colorStyle(theme::kFailure, 0, true));
    logEvent(ok ? QStringLiteral("INFO") : QStringLiteral("ERROR"), QStringLiteral("Event log verification: %1").arg(message));
    if (!ok) raiseSystemAlert(Alert::Level::Critical, QStringLiteral("LOG_INTEGRITY_FAILED"), QStringLiteral("Event log integrity check FAILED: %1").arg(message));
    setControlsEnabled(m_client->isReady());
}

// ---------------------------------------------------------------------------- display refresh

void MainWindow::logEvent(const QString& level, const QString& message) {
    m_eventLog->appendPlainText(QStringLiteral("%1 UTC  %2  %3")
                                    .arg(QDateTime::currentDateTimeUtc().toString(QStringLiteral("yyyy-MM-dd HH:mm:ss.zzz")),
                                         level.leftJustified(5), message.left(900)));
}

void MainWindow::refreshStatusBar() {
    m_statusLabel->setText(QStringLiteral("Worker: %1   |   Parser: %2   |   Decision engine: %3   |   All values SIMULATED")
                               .arg(WorkerClient::stateText(m_client->state()),
                                    m_parserAvailable ? QStringLiteral("available") : QStringLiteral("not available"),
                                    m_decisionOk ? QStringLiteral("available") : QStringLiteral("NOT AVAILABLE (all REJECT)")));
}

void MainWindow::refreshDashboard() {
    const Counts c = m_model->counts();
    m_countTotal->setText(QString::number(c.total));
    m_countWithin->setText(QString::number(c.withinLimits));
    m_countViolation->setText(QString::number(c.violations));
    m_countRejected->setText(QString::number(c.rejected));
    m_countFailure->setText(QString::number(c.failures));
    m_countAllowed->setText(QString::number(c.allowed));
    m_countBlocked->setText(QString::number(c.blocked));
    m_countRejectDecision->setText(QString::number(c.rejectedDecisions));

    const WorkerClient::State st = m_client->state();
    QStringList lines;
    lines << QStringLiteral("Worker:           %1%2").arg(WorkerClient::stateText(st),
                                                         m_client->detail().isEmpty() || st == WorkerClient::State::Ready ? QString() : QStringLiteral(" (%1)").arg(m_client->detail()))
          << QStringLiteral("C++ parser:       %1").arg(m_parserAvailable ? m_parserPath : QStringLiteral("NOT FOUND - commands fail closed"))
          << QStringLiteral("Safety config:    %1").arg(m_configPath.isEmpty() ? QStringLiteral("-") : m_configPath)
          << QStringLiteral("Event log:        %1").arg(m_eventLogText)
          << QStringLiteral("Decision engine:  %1").arg(m_decisionText)
          << QStringLiteral("Pending requests: %1").arg(m_client->pendingCount())
          << QStringLiteral("Qt version:       %1").arg(QString::fromLatin1(qVersion()));
    m_appStatus->setText(lines.join(QLatin1Char('\n')));
    QFont mono(QStringLiteral("monospace"));
    mono.setStyleHint(QFont::Monospace);
    m_appStatus->setFont(mono);

    if (!m_hasLatest) {
        m_latestStatus->setText(QStringLiteral("No commands processed yet"));
        m_latestStatus->setStyleSheet(colorStyle(theme::kMuted, 20, true));
        m_latestDecision->clear();
        m_latestDetail->clear();
        return;
    }
    QColor color = theme::kMuted;
    switch (m_latest.severity()) {
        case CommandRecord::Severity::Ok: color = theme::kOk; break;
        case CommandRecord::Severity::Violation: color = theme::kViolation; break;
        case CommandRecord::Severity::Rejected: color = theme::kRejected; break;
        case CommandRecord::Severity::Failure: color = theme::kFailure; break;
    }
    m_latestDecision->setText(QStringLiteral("DECISION: %1").arg(m_latest.decisionText()));
    m_latestDecision->setStyleSheet(colorStyle(m_latest.decision == QLatin1String("ALLOW") ? theme::kOk
                                               : m_latest.decision == QLatin1String("BLOCK") ? theme::kFailure : theme::kRejected, 26, true));
    m_latestStatus->setText(m_latest.safetyStatus());
    m_latestStatus->setStyleSheet(colorStyle(color, 20, true));
    QString detail = QStringLiteral("%1 (%2)\n").arg(m_latest.commandId, m_latest.source);
    if (m_latest.hasPrediction) {
        detail += QStringLiteral("Predicted pressure: %1 %2 (simulated) - configured limits %3 .. %4 %2\nPredicted flow: %5 %6 (simulated)\n")
                      .arg(QString::number(m_latest.pressure, 'f', 2), m_latest.pressureUnit,
                           QString::number(m_latest.minPressure, 'g', 10), QString::number(m_latest.maxPressure, 'g', 10),
                           QString::number(m_latest.flow, 'f', 2), m_latest.flowUnit);
        if (!m_latest.violations.isEmpty()) detail += QStringLiteral("Violations: %1\n").arg(m_latest.violations.join(QStringLiteral("; ")));
    }
    if (!m_latest.error.isEmpty()) detail += QStringLiteral("%1: %2\n").arg(m_latest.errorCode, m_latest.error);
    if (!m_latest.simError.isEmpty()) detail += m_latest.simError + QLatin1Char('\n');
    detail += QStringLiteral("Reason: %1").arg(m_latest.decisionReason);
    m_latestDetail->setText(detail);
}

// ---------------------------------------------------------------------------- screenshots

void MainWindow::selectFirstViolationRow() {
    for (int r = 0; r < m_model->rowCount(); ++r) {
        if (m_model->recordAt(r).severity() == CommandRecord::Severity::Violation) {
            m_table->selectRow(r);
            m_table->setCurrentIndex(m_model->index(r, 0));
            return;
        }
    }
}

QWidget* MainWindow::buildGraphsTab() {
    auto* page = new QWidget;
    auto* layout = new QHBoxLayout(page);
    m_charts = new ChartPanel;
    m_charts->setObjectName(QStringLiteral("chartPanel"));
    layout->addWidget(m_charts, 3);

    auto* box = new QGroupBox(QStringLiteral("Alerts (display only)"));
    auto* bl = new QVBoxLayout(box);
    m_alerts = new AlertLog(this);
    m_alertSummary = new QLabel;
    m_alertSummary->setObjectName(QStringLiteral("alertSummaryLabel"));
    m_alertList = new QListWidget;
    m_alertList->setObjectName(QStringLiteral("alertList"));
    m_alertList->setWordWrap(true);
    auto* note = new QLabel(QStringLiteral("Alerts describe SIMULATED results and system problems. Clearing them does not change any decision or the event log."));
    note->setWordWrap(true);
    note->setStyleSheet(colorStyle(theme::kMuted));
    bl->addWidget(m_alertSummary);
    bl->addWidget(m_alertList, 1);
    bl->addWidget(note);
    layout->addWidget(box, 2);
    connect(m_alerts, &AlertLog::changed, this, &MainWindow::refreshAlertList);
    return page;
}

void MainWindow::raiseSystemAlert(Alert::Level level, const QString& code, const QString& message) {
    m_alerts->addSystem(level, code, message);
}

void MainWindow::refreshAlertList() {
    m_alertList->clear();
    // newest first
    for (int i = m_alerts->size() - 1; i >= 0; --i) {
        const Alert& a = m_alerts->at(i);
        QString text = QStringLiteral("%1  %2  %3%4").arg(a.timeUtc.toString(QStringLiteral("HH:mm:ss")), Alert::levelText(a.level),
                                                          a.commandId.isEmpty() ? QString() : a.commandId + QStringLiteral(": "), a.message);
        auto* item = new QListWidgetItem(text);
        item->setForeground(a.level == Alert::Level::Critical ? theme::kFailure : a.level == Alert::Level::Warning ? theme::kRejected : theme::kMuted);
        item->setToolTip(a.code);
        m_alertList->addItem(item);
    }
    const int crit = m_alerts->count(Alert::Level::Critical), warn = m_alerts->count(Alert::Level::Warning);
    QString summary = QStringLiteral("Alerts: %1 critical, %2 warning").arg(crit).arg(warn);
    if (m_alerts->droppedCount() > 0) summary += QStringLiteral(" (%1 older alerts dropped)").arg(m_alerts->droppedCount());
    m_alertSummary->setText(summary);
    m_alertSummary->setStyleSheet(crit > 0 ? colorStyle(theme::kFailure, 0, true) : warn > 0 ? colorStyle(theme::kRejected, 0, true) : colorStyle(theme::kMuted));
    if (m_alertSummaryDash) {
        m_alertSummaryDash->setText(summary);
        m_alertSummaryDash->setStyleSheet(m_alertSummary->styleSheet());
    }
}

int MainWindow::captureScreenshots(const QString& directory) {
    QDir dir(directory);
    if (!dir.mkpath(QStringLiteral("."))) return 0;
    if (!isVisible()) show();
    const char* names[] = {"1_dashboard.png", "2_traffic_and_details.png", "3_graphs_and_alerts.png", "4_event_log.png", "5_configuration.png"};
    const int previous = m_tabs->currentIndex();
    int saved = 0;
    for (int i = 0; i < m_tabs->count() && i < 5; ++i) {
        m_tabs->setCurrentIndex(i);
        if (i == 1) selectFirstViolationRow();
        QApplication::processEvents();
        if (grab().save(dir.filePath(QLatin1String(names[i])))) ++saved;
    }
    m_tabs->setCurrentIndex(previous);
    return saved;
}

}  // namespace voltguard
