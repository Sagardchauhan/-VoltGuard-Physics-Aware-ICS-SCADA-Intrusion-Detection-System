#include "alerts.h"

namespace voltguard {

QString Alert::levelText(Level level) {
    switch (level) {
        case Level::Critical: return QStringLiteral("CRITICAL");
        case Level::Warning: return QStringLiteral("WARNING");
        case Level::Info: break;
    }
    return QStringLiteral("INFO");
}

QList<Alert> alertsForRecord(const CommandRecord& r) {
    QList<Alert> out;
    auto make = [&](Alert::Level level, const QString& code, const QString& message) {
        Alert a;
        a.level = level;
        a.timeUtc = r.timestampUtc.isValid() ? r.timestampUtc : QDateTime::currentDateTimeUtc();
        a.commandId = r.commandId;
        a.code = code;
        a.message = message;
        out << a;
    };

    if (r.decisionSource == QLatin1String("fail_closed")) {
        // Something could not be done, so the command was refused: always worth the operator's attention.
        make(Alert::Level::Critical, r.decisionErrorCode.isEmpty() ? QStringLiteral("FAIL_CLOSED") : r.decisionErrorCode,
             QStringLiteral("Fail closed: command REJECTED because %1").arg(r.decisionReason));
    } else if (r.decision == QLatin1String("BLOCK")) {
        QString what = r.violations.isEmpty() ? r.decisionReason : r.violations.join(QStringLiteral("; "));
        make(Alert::Level::Critical, QStringLiteral("LIMIT_VIOLATION_BLOCKED"),
             QStringLiteral("Command BLOCKED: simulated prediction outside the configured limits (%1)").arg(what));
    } else if (r.severity() == CommandRecord::Severity::Failure) {
        make(Alert::Level::Critical, r.errorCode.isEmpty() ? QStringLiteral("COMPONENT_FAILURE") : r.errorCode,
             QStringLiteral("Component failure: %1").arg(r.error.isEmpty() ? r.simError : r.error));
    } else if (r.decision == QLatin1String("REJECT")) {
        make(Alert::Level::Warning, r.errorCode.isEmpty() ? QStringLiteral("COMMAND_REJECTED") : r.errorCode,
             QStringLiteral("Command REJECTED: %1").arg(r.decisionReason));
    }
    if (r.logged == 0)
        make(Alert::Level::Warning, QStringLiteral("EVENT_NOT_STORED"), QStringLiteral("This command was NOT stored in the event log"));
    return out;
}

void AlertLog::add(const Alert& alert) {
    m_alerts.append(alert);
    while (m_alerts.size() > kMaxAlerts) {
        m_alerts.removeFirst();
        ++m_dropped;
    }
    emit changed();
}

void AlertLog::addSystem(Alert::Level level, const QString& code, const QString& message) {
    Alert a;
    a.level = level;
    a.timeUtc = QDateTime::currentDateTimeUtc();
    a.code = code;
    a.message = message;
    add(a);
}

void AlertLog::addAll(const QList<Alert>& alerts) {
    for (const Alert& a : alerts) add(a);
}

void AlertLog::clear() {
    m_alerts.clear();
    m_dropped = 0;
    emit changed();
}

int AlertLog::count(Alert::Level level) const {
    int n = 0;
    for (const Alert& a : m_alerts)
        if (a.level == level) ++n;
    return n;
}

}  // namespace voltguard
