#include "trafficmodel.h"

#include <QBrush>

#include "theme.h"

namespace voltguard {

namespace {

QColor colorFor(CommandRecord::Severity s) {
    switch (s) {
        case CommandRecord::Severity::Ok: return theme::kOk;
        case CommandRecord::Severity::Violation: return theme::kViolation;
        case CommandRecord::Severity::Rejected: return theme::kRejected;
        case CommandRecord::Severity::Failure: return theme::kFailure;
    }
    return theme::kMuted;
}

}  // namespace

TrafficModel::TrafficModel(QObject* parent) : QAbstractTableModel(parent) {}

int TrafficModel::rowCount(const QModelIndex& parent) const { return parent.isValid() ? 0 : m_rows.size(); }
int TrafficModel::columnCount(const QModelIndex& parent) const { return parent.isValid() ? 0 : ColCount; }

QVariant TrafficModel::headerData(int section, Qt::Orientation orientation, int role) const {
    if (orientation != Qt::Horizontal || role != Qt::DisplayRole) return {};
    switch (section) {
        case ColTime: return QStringLiteral("Time (UTC)");
        case ColCommandId: return QStringLiteral("Command ID");
        case ColSource: return QStringLiteral("Source");
        case ColParsed: return QStringLiteral("Parsed command");
        case ColStage: return QStringLiteral("Stage");
        case ColPressure: return QStringLiteral("Pressure (simulated)");
        case ColSafety: return QStringLiteral("Safety status");
        case ColDecision: return QStringLiteral("Decision");
    }
    return {};
}

QVariant TrafficModel::data(const QModelIndex& index, int role) const {
    if (!index.isValid() || index.row() < 0 || index.row() >= m_rows.size()) return {};
    const CommandRecord& r = m_rows.at(index.row());
    const int col = index.column();

    if (role == Qt::DisplayRole) {
        switch (col) {
            case ColTime: return r.timestampUtc.toString(QStringLiteral("HH:mm:ss.zzz"));
            case ColCommandId: return r.commandId;
            case ColSource: return r.source;
            case ColParsed: return r.hasParsed ? r.parsedSummary : QStringLiteral("-");
            case ColStage: return r.stage;
            case ColPressure:
                return r.hasPrediction ? QStringLiteral("%1 %2").arg(QString::number(r.pressure, 'f', 2), r.pressureUnit) : QStringLiteral("-");
            case ColSafety: return r.safetyStatus();
            case ColDecision: return r.decision.isEmpty() ? QStringLiteral("-") : r.decision;
        }
    } else if (role == Qt::ForegroundRole && (col == ColSafety || col == ColStage)) {
        return QBrush(colorFor(r.severity()));
    } else if (role == Qt::ForegroundRole && col == ColDecision) {
        return QBrush(r.decision == QLatin1String("ALLOW") ? theme::kOk : r.decision == QLatin1String("BLOCK") ? theme::kFailure : theme::kRejected);
    } else if (role == Qt::ToolTipRole) {
        if (col == ColDecision) return QStringLiteral("%1\n%2").arg(r.decisionText(), r.decisionReason);
        if (col == ColSafety && !r.violations.isEmpty()) return r.violations.join(QLatin1Char('\n'));
        if (col == ColStage && !r.error.isEmpty()) return QStringLiteral("%1: %2").arg(r.errorCode, r.error);
    } else if (role == Qt::TextAlignmentRole && col == ColPressure) {
        return int(Qt::AlignRight | Qt::AlignVCenter);
    }
    return {};
}

void TrafficModel::append(const CommandRecord& record) {
    if (m_rows.size() >= kMaxRows) {
        beginRemoveRows(QModelIndex(), 0, 0);
        m_rows.remove(0);
        endRemoveRows();
    }
    beginInsertRows(QModelIndex(), m_rows.size(), m_rows.size());
    m_rows.append(record);
    endInsertRows();

    ++m_counts.total;
    switch (record.severity()) {
        case CommandRecord::Severity::Ok: ++m_counts.withinLimits; break;
        case CommandRecord::Severity::Violation: ++m_counts.violations; break;
        case CommandRecord::Severity::Rejected: ++m_counts.rejected; break;
        case CommandRecord::Severity::Failure: ++m_counts.failures; break;
    }
    if (record.decision == QLatin1String("ALLOW")) ++m_counts.allowed;
    else if (record.decision == QLatin1String("BLOCK")) ++m_counts.blocked;
    else ++m_counts.rejectedDecisions;  // REJECT, and anything unexpected, counts as not allowed
    emit countsChanged();
}

void TrafficModel::clear() {
    beginResetModel();
    m_rows.clear();
    m_counts = Counts();
    endResetModel();
    emit countsChanged();
}

}  // namespace voltguard
