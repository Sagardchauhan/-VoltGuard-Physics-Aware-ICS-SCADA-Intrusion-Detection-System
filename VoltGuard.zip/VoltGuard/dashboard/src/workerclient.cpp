#include "workerclient.h"

#include <QJsonDocument>
#include <QJsonParseError>

namespace voltguard {

WorkerClient::WorkerClient(QObject* parent) : QObject(parent) {
    m_startTimer.setSingleShot(true);
    m_queryTimer.setSingleShot(true);
    connect(&m_queryTimer, &QTimer::timeout, this, [this]() { fail(QStringLiteral("no answer to an event log request within %1 ms").arg(m_queryTimer.interval())); });
    connect(&m_startTimer, &QTimer::timeout, this, &WorkerClient::onStartTimeout);
    connect(&m_proc, &QProcess::readyReadStandardOutput, this, &WorkerClient::onStdout);
    connect(&m_proc, &QProcess::readyReadStandardError, this, &WorkerClient::onStderr);
    connect(&m_proc, QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished), this, &WorkerClient::onFinished);
    connect(&m_proc, &QProcess::errorOccurred, this, &WorkerClient::onProcessError);
}

WorkerClient::~WorkerClient() { stop(); }

QString WorkerClient::stateText(State s) {
    switch (s) {
        case State::Stopped: return QStringLiteral("Stopped");
        case State::Starting: return QStringLiteral("Starting");
        case State::Ready: return QStringLiteral("Ready");
        case State::Failed: return QStringLiteral("Failed");
    }
    return QStringLiteral("Unknown");
}

void WorkerClient::setState(State s, const QString& detail) {
    m_state = s;
    m_detail = detail;
    emit stateChanged(s, detail);
}

void WorkerClient::start(const QString& program, const QStringList& arguments, const QString& workingDirectory) {
    stop();
    m_buffer.clear();
    m_stderrTail.clear();
    m_stopping = false;
    m_proc.setProgram(program);
    m_proc.setArguments(arguments);
    m_proc.setWorkingDirectory(workingDirectory);
    setState(State::Starting, QStringLiteral("starting worker"));
    m_startTimer.start(m_startTimeoutMs);
    m_proc.start();  // failure to start is reported through errorOccurred
}

void WorkerClient::stop() {
    m_stopping = true;
    m_startTimer.stop();
    m_queryTimer.stop();
    if (m_proc.state() != QProcess::NotRunning) {
        if (m_state == State::Ready) {
            QJsonObject bye;
            bye.insert(QStringLiteral("op"), QStringLiteral("shutdown"));
            writeLine(bye);
        }
        if (!m_proc.waitForFinished(1500)) {
            m_proc.kill();
            m_proc.waitForFinished(2000);
        }
    }
    clearPending(QStringLiteral("worker stopped"));
    if (m_state != State::Stopped) setState(State::Stopped, QStringLiteral("worker stopped"));
}

void WorkerClient::clearPending(const QString& reason) {
    const QList<QString> ids = m_pending.keys();
    for (const QString& id : ids) {
        QTimer* t = m_pending.take(id);
        t->stop();
        t->deleteLater();
        emit requestFailed(id, reason);
    }
}

void WorkerClient::fail(const QString& reason) {
    if (m_state == State::Failed || m_stopping) return;
    m_startTimer.stop();
    m_queryTimer.stop();
    setState(State::Failed, reason);
    if (m_proc.state() != QProcess::NotRunning) {
        m_proc.kill();  // finished() fires later and is ignored because the state is already Failed
    }
    clearPending(reason);
}

void WorkerClient::onStartTimeout() {
    if (m_state == State::Starting) fail(QStringLiteral("worker did not become ready in time"));
}

void WorkerClient::onProcessError(QProcess::ProcessError error) {
    if (error == QProcess::FailedToStart) {
        fail(QStringLiteral("cannot start worker program '%1': %2").arg(m_proc.program(), m_proc.errorString()));
    }
}

void WorkerClient::onFinished(int exitCode, QProcess::ExitStatus) {
    if (m_stopping || m_state == State::Failed || m_state == State::Stopped) return;
    QString reason = QStringLiteral("worker exited unexpectedly (exit code %1)").arg(exitCode);
    const QString tail = QString::fromUtf8(m_stderrTail).trimmed();
    if (!tail.isEmpty()) reason += QStringLiteral(": ") + tail.right(300);
    fail(reason);
}

void WorkerClient::onStderr() {
    m_stderrTail.append(m_proc.readAllStandardError());
    if (m_stderrTail.size() > 2048) m_stderrTail = m_stderrTail.right(2048);
}

void WorkerClient::onStdout() {
    m_buffer.append(m_proc.readAllStandardOutput());
    for (;;) {
        const int nl = m_buffer.indexOf('\n');
        if (nl < 0) break;
        const QByteArray line = m_buffer.left(nl);
        m_buffer.remove(0, nl + 1);
        if (line.size() > kMaxLineBytes) {
            emit protocolError(QStringLiteral("worker output line too long"));
            fail(QStringLiteral("worker sent an oversized line"));
            return;
        }
        handleLine(line);
        if (m_state == State::Failed) return;
    }
    if (m_buffer.size() > kMaxLineBytes) {  // no newline yet, but already too much: do not keep buffering
        m_buffer.clear();
        emit protocolError(QStringLiteral("worker output line too long"));
        fail(QStringLiteral("worker sent an oversized line"));
    }
}

void WorkerClient::handleLine(const QByteArray& line) {
    if (line.trimmed().isEmpty()) return;
    QJsonParseError pe;
    const QJsonDocument doc = QJsonDocument::fromJson(line, &pe);
    if (pe.error != QJsonParseError::NoError || !doc.isObject()) {
        emit protocolError(QStringLiteral("worker sent a line that is not a JSON object"));
        return;
    }
    const QJsonObject o = doc.object();
    const QString type = o.value(QLatin1String("type")).toString();

    if (type == QLatin1String("ready")) {
        m_startTimer.stop();
        setState(State::Ready, QStringLiteral("worker ready"));
        emit ready(o);
    } else if (type == QLatin1String("fatal")) {
        fail(o.value(QLatin1String("error")).toString(QStringLiteral("worker reported a fatal error")));
    } else if (type == QLatin1String("scenarios")) {
        emit scenariosReceived(o.value(QLatin1String("scenarios")).toArray());
    } else if (type == QLatin1String("export")) {
        m_queryTimer.stop();
        m_queryKind = QueryKind::None;
        emit exportFinished(o);
    } else if (type == QLatin1String("events")) {
        m_queryTimer.stop();
        emit eventsReceived(o);
    } else if (type == QLatin1String("log_verification")) {
        m_queryTimer.stop();
        emit logVerified(o.value(QLatin1String("ok")).toBool(false), o.value(QLatin1String("message")).toString().left(300));
    } else if (type == QLatin1String("result")) {
        const QString id = o.value(QLatin1String("command_id")).toString();
        if (!m_pending.contains(id)) {
            emit protocolError(QStringLiteral("worker sent a result for a command that is not pending"));
            return;
        }
        QTimer* t = m_pending.take(id);
        t->stop();
        t->deleteLater();
        emit resultReceived(o);
    } else if (type == QLatin1String("error")) {
        const QString id = o.value(QLatin1String("command_id")).toString();
        const QString message = o.value(QLatin1String("error")).toString(QStringLiteral("worker reported an error"));
        if (!id.isEmpty() && m_pending.contains(id)) {
            QTimer* t = m_pending.take(id);
            t->stop();
            t->deleteLater();
            emit requestFailed(id, message);
        } else {
            if (m_queryTimer.isActive()) {  // an error reply to a log query or export
                m_queryTimer.stop();
                if (m_queryKind == QueryKind::Export) {
                    QJsonObject refusal{{QStringLiteral("type"), QStringLiteral("export")}, {QStringLiteral("ok"), false}, {QStringLiteral("error"), message.left(300)}};
                    m_queryKind = QueryKind::None;
                    emit exportFinished(refusal);
                } else {
                    emit logVerified(false, message.left(300));
                }
            }
            emit protocolError(message);
        }
    } else {
        emit protocolError(QStringLiteral("worker sent a message of unknown type"));
    }
}

bool WorkerClient::writeLine(const QJsonObject& object) {
    QByteArray bytes = QJsonDocument(object).toJson(QJsonDocument::Compact);
    bytes.append('\n');
    return m_proc.write(bytes) == bytes.size();
}

void WorkerClient::requestScenarios() {
    if (m_state != State::Ready) return;
    QJsonObject req;
    req.insert(QStringLiteral("op"), QStringLiteral("scenarios"));
    if (!writeLine(req)) fail(QStringLiteral("cannot write to the worker"));
}

bool WorkerClient::sendProcess(const QString& commandId, const QString& frameHex, const QString& source) {
    if (m_state != State::Ready || m_pending.contains(commandId)) return false;
    QJsonObject req;
    req.insert(QStringLiteral("op"), QStringLiteral("process"));
    req.insert(QStringLiteral("command_id"), commandId);
    req.insert(QStringLiteral("frame_hex"), frameHex);
    if (!source.isEmpty()) req.insert(QStringLiteral("source"), source.left(120));
    if (!writeLine(req)) {
        fail(QStringLiteral("cannot write to the worker"));
        return false;
    }
    auto* timer = new QTimer(this);
    timer->setSingleShot(true);
    connect(timer, &QTimer::timeout, this, [this, commandId]() {
        fail(QStringLiteral("no answer for %1 within %2 ms").arg(commandId).arg(m_requestTimeoutMs));
    });
    timer->start(m_requestTimeoutMs);
    m_pending.insert(commandId, timer);
    return true;
}

bool WorkerClient::startQuery(const QJsonObject& request, QueryKind kind, int timeoutMs) {
    if (m_state != State::Ready || m_queryTimer.isActive()) return false;
    if (!writeLine(request)) {
        fail(QStringLiteral("cannot write to the worker"));
        return false;
    }
    m_queryKind = kind;
    m_queryTimer.start(timeoutMs);
    return true;
}

bool WorkerClient::requestEvents(int limit) {
    QJsonObject req;
    req.insert(QStringLiteral("op"), QStringLiteral("events"));
    req.insert(QStringLiteral("limit"), qBound(1, limit, 1000));
    return startQuery(req, QueryKind::Events, m_requestTimeoutMs);
}

bool WorkerClient::requestLogVerification() {
    QJsonObject req;
    req.insert(QStringLiteral("op"), QStringLiteral("verify_log"));
    return startQuery(req, QueryKind::Verify, m_requestTimeoutMs);
}

bool WorkerClient::requestExport(const QString& format, const QString& path, bool overwrite) {
    QJsonObject req;
    req.insert(QStringLiteral("op"), QStringLiteral("export"));
    req.insert(QStringLiteral("format"), format);
    req.insert(QStringLiteral("path"), path);
    req.insert(QStringLiteral("overwrite"), overwrite);
    return startQuery(req, QueryKind::Export, m_requestTimeoutMs * 6);   // writing a large log (or a PDF) takes longer than a query
}

}  // namespace voltguard
