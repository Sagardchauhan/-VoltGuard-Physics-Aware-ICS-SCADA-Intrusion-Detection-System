// Graphs of the SIMULATED predicted pressure and flow of processed commands, with the configured limits.
// Only commands that produced a prediction are plotted (a rejected or failed command has no value to plot).
// The x axis is the order of the plotted commands, not time. Nothing here is sensor data.
#pragma once

#include <QList>
#include <QPointF>
#include <QWidget>

#include "commandrecord.h"

class QChartView;
class QLineSeries;
class QScatterSeries;
class QValueAxis;

namespace voltguard {

class ChartPanel : public QWidget {
    Q_OBJECT
public:
    static constexpr int kMaxPoints = 200;

    explicit ChartPanel(QWidget* parent = nullptr);

    // Limits come from the worker's configuration message; until they are set no limit lines are drawn.
    void setLimits(double pressureMin, double pressureMax, const QString& pressureUnit,
                   double flowMin, double flowMax, const QString& flowUnit);
    void addRecord(const CommandRecord& record);
    void clear();

    // Read access for tests and for the status text.
    int pointCount() const { return m_pressure.size(); }
    int allowedPointCount() const;
    int blockedPointCount() const;
    bool hasLimits() const { return m_hasLimits; }
    QList<QPointF> pressurePoints() const { return m_pressure; }
    QList<QPointF> flowPoints() const { return m_flow; }
    QList<QPointF> pressureLimitLine(bool upper) const;
    QList<QPointF> flowLimitLine(bool upper) const;
    double pressureAxisMin() const;
    double pressureAxisMax() const;
    double flowAxisMin() const;
    double flowAxisMax() const;

private:
    void rebuild();

    QChartView* m_pressureView = nullptr;
    QChartView* m_flowView = nullptr;
    QLineSeries* m_pressureLine = nullptr;
    QLineSeries* m_flowLine = nullptr;
    QScatterSeries* m_pressureAllow = nullptr;
    QScatterSeries* m_pressureBlock = nullptr;
    QScatterSeries* m_pressureOther = nullptr;
    QScatterSeries* m_flowAllow = nullptr;
    QScatterSeries* m_flowBlock = nullptr;
    QScatterSeries* m_flowOther = nullptr;
    QLineSeries* m_pressureMin = nullptr;
    QLineSeries* m_pressureMax = nullptr;
    QLineSeries* m_flowMin = nullptr;
    QLineSeries* m_flowMax = nullptr;
    QValueAxis* m_pressureX = nullptr;
    QValueAxis* m_pressureY = nullptr;
    QValueAxis* m_flowX = nullptr;
    QValueAxis* m_flowY = nullptr;

    QList<QPointF> m_pressure;
    QList<QPointF> m_flow;
    QList<QString> m_decisions;  // decision of each plotted command, parallel to the point lists
    int m_sequence = 0;          // number of commands plotted since the last clear (not bounded by kMaxPoints)
    bool m_hasLimits = false;
    double m_pMin = 0, m_pMax = 0, m_fMin = 0, m_fMax = 0;
    QString m_pUnit, m_fUnit;
};

}  // namespace voltguard
