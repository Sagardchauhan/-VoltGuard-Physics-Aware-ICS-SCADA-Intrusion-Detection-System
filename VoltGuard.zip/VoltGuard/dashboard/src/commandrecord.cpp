#include "commandrecord.h"

#include <QJsonArray>
#include <QJsonValue>
#include <cmath>

namespace voltguard {

namespace {

const QStringList kStages = {"SIMULATED", "PARSE_REJECTED", "COMPONENT_FAILURE"};
const QStringList kSimStatuses = {"SUCCESS", "INVALID_INPUT", "ERROR", "TIMEOUT"};
constexpr int kMaxText = 600;

bool getNumber(const QJsonObject& o, const char* key, double* out) {
    const QJsonValue v = o.value(QLatin1String(key));
    if (!v.isDouble()) return false;
    const double d = v.toDouble();
    if (!std::isfinite(d)) return false;
    *out = d;
    return true;
}

bool getInt(const QJsonObject& o, const char* key, int* out) {
    double d = 0.0;
    if (!getNumber(o, key, &d) || d != std::floor(d) || std::fabs(d) > 1e9) return false;
    *out = static_cast<int>(d);
    return true;
}

bool getString(const QJsonObject& o, const char* key, QString* out) {
    const QJsonValue v = o.value(QLatin1String(key));
    if (!v.isString()) return false;
    *out = v.toString().left(kMaxText);
    return true;
}

QString num(double d) { return QString::number(d, 'g', 10); }

}  // namespace

CommandRecord::Severity CommandRecord::severity() const {
    if (stage == QLatin1String("COMPONENT_FAILURE")) return Severity::Failure;
    if (stage == QLatin1String("PARSE_REJECTED")) return Severity::Rejected;
    if (simStatus == QLatin1String("SUCCESS")) return violations.isEmpty() ? Severity::Ok : Severity::Violation;
    if (simStatus == QLatin1String("INVALID_INPUT")) return Severity::Rejected;
    return Severity::Failure;  // simulation ERROR / TIMEOUT
}

QString CommandRecord::safetyStatus() const {
    if (stage == QLatin1String("COMPONENT_FAILURE")) return QStringLiteral("COMPONENT FAILURE");
    if (stage == QLatin1String("PARSE_REJECTED")) return QStringLiteral("REJECTED BY PARSER");
    if (simStatus == QLatin1String("SUCCESS")) {
        return violations.isEmpty() ? QStringLiteral("WITHIN LIMITS (simulated)")
                                    : QStringLiteral("LIMIT VIOLATION (simulated)");
    }
    return QStringLiteral("SIMULATION ") + simStatus;
}

QString CommandRecord::decisionText() const {
    if (decision.isEmpty()) return QStringLiteral("none");
    return QStringLiteral("%1 (%2)").arg(decision, decisionSource);
}

QString CommandRecord::detailsText() const {
    QStringList l;
    l << QStringLiteral("Command ID:   %1").arg(commandId)
      << QStringLiteral("Time (UTC):   %1").arg(timestampUtc.toString(QStringLiteral("yyyy-MM-dd HH:mm:ss.zzz")))
      << QStringLiteral("Source:       %1").arg(source.isEmpty() ? QStringLiteral("-") : source)
      << QStringLiteral("Stage:        %1").arg(stage)
      << QStringLiteral("Frame (hex):  %1").arg(frameHex.isEmpty() ? QStringLiteral("(empty)") : frameHex)
      << QString();

    l << QStringLiteral("--- Parsed command ---");
    l << (hasParsed ? parsedSummary : QStringLiteral("(none: the frame was not parsed)")) << QString();

    l << QStringLiteral("--- Simulation (SIMULATED values, not sensor measurements) ---");
    if (!hasSimulation) {
        l << QStringLiteral("(not simulated)");
    } else {
        l << QStringLiteral("Status:              %1").arg(simStatus);
        if (hasPrediction) {
            l << QStringLiteral("Predicted pressure:   %1 %2").arg(num(pressure), pressureUnit)
              << QStringLiteral("Pressure limits:      %1 .. %2 %3 (configured)").arg(num(minPressure), num(maxPressure), pressureUnit)
              << QStringLiteral("Predicted flow:       %1 %2").arg(num(flow), flowUnit)
              << QStringLiteral("Limit violations:     %1").arg(violations.isEmpty() ? QStringLiteral("none") : violations.join(QStringLiteral("; ")));
        } else {
            l << QStringLiteral("Simulation error:     %1").arg(simError);
        }
    }
    l << QString();

    l << QStringLiteral("--- Safety status ---") << safetyStatus() << QString();
    l << QStringLiteral("--- Decision ---") << decisionText()
      << QStringLiteral("Reason: %1").arg(decisionReason.isEmpty() ? QStringLiteral("-") : decisionReason);
    if (!decisionErrorCode.isEmpty()) l << QStringLiteral("Failure code: %1").arg(decisionErrorCode);
    l << QStringLiteral("(Nothing is forwarded to any device. ALLOW means the policy would forward the command.)") << QString();
    if (!error.isEmpty() || !errorCode.isEmpty()) {
        l << QStringLiteral("--- Error ---") << QStringLiteral("%1: %2").arg(errorCode, error) << QString();
    }
    l << QStringLiteral("--- Event log ---")
      << (logged == 1 ? QStringLiteral("stored") : logged == 0 ? QStringLiteral("NOT STORED (event log failure)") : QStringLiteral("not logged (event log off or unknown)"))
      << QString();
    l << QStringLiteral("--- Timing ---")
      << QStringLiteral("parse %1 ms, simulate %2 ms, total %3 ms").arg(num(parseMs), num(simulateMs), num(totalMs));
    return l.join(QLatin1Char('\n'));
}

CommandRecord CommandRecord::failure(const QString& commandId, const QString& source, const QString& frameHex,
                                     const QString& code, const QString& message) {
    CommandRecord r;
    r.commandId = commandId;
    r.timestampUtc = QDateTime::currentDateTimeUtc();
    r.source = source;
    r.frameHex = frameHex;
    r.stage = QStringLiteral("COMPONENT_FAILURE");
    r.decision = QStringLiteral("REJECT");                    // no result means no allow: fail closed
    r.decisionSource = QStringLiteral("fail_closed");
    r.decisionErrorCode = code;
    r.decisionReason = QStringLiteral("fail closed: no valid result was obtained for this command");
    r.errorCode = code;
    r.error = message.left(kMaxText);
    return r;
}

bool CommandRecord::fromJson(const QJsonObject& o, CommandRecord* out, QString* err) {
    auto fail = [err](const QString& m) {
        if (err) *err = m;
        return false;
    };
    CommandRecord r;

    if (!getString(o, "command_id", &r.commandId) || r.commandId.isEmpty() || r.commandId.size() > 64)
        return fail(QStringLiteral("command_id is missing or invalid"));

    QString ts;
    if (!getString(o, "timestamp_utc", &ts)) return fail(QStringLiteral("timestamp_utc is missing"));
    r.timestampUtc = QDateTime::fromString(ts, Qt::ISODateWithMs);
    if (!r.timestampUtc.isValid()) r.timestampUtc = QDateTime::fromString(ts, Qt::ISODate);
    if (!r.timestampUtc.isValid()) return fail(QStringLiteral("timestamp_utc is not a valid ISO date"));
    r.timestampUtc = r.timestampUtc.toUTC();

    if (!getString(o, "stage", &r.stage) || !kStages.contains(r.stage)) return fail(QStringLiteral("stage is missing or unknown"));

    const QJsonValue timings = o.value(QLatin1String("timings_ms"));
    if (!timings.isObject()) return fail(QStringLiteral("timings_ms is missing"));
    const QJsonObject t = timings.toObject();
    if (!getNumber(t, "parse", &r.parseMs) || !getNumber(t, "simulate", &r.simulateMs) ||
        !getNumber(t, "total", &r.totalMs) || r.parseMs < 0 || r.simulateMs < 0 || r.totalMs < 0)
        return fail(QStringLiteral("timings_ms is invalid"));

    const QJsonValue loggedValue = o.value(QLatin1String("logged"));
    if (loggedValue.isBool()) r.logged = loggedValue.toBool() ? 1 : 0;
    else if (!loggedValue.isNull() && !loggedValue.isUndefined()) return fail(QStringLiteral("logged must be a boolean or null"));

    const QJsonValue parsed = o.value(QLatin1String("parsed_command"));
    const QJsonValue sim = o.value(QLatin1String("simulation"));
    if (parsed.isUndefined() || sim.isUndefined()) return fail(QStringLiteral("parsed_command or simulation is missing"));

    const bool simulated = r.stage == QLatin1String("SIMULATED");
    if (simulated != (parsed.isObject() && sim.isObject()) || (!simulated && (!parsed.isNull() || !sim.isNull())))
        return fail(QStringLiteral("stage does not match the presence of parsed_command and simulation"));

    if (!simulated) {
        if (!getString(o, "error_code", &r.errorCode) || !getString(o, "error", &r.error))
            return fail(QStringLiteral("error_code and error are required for this stage"));
    }

    if (simulated) {
        const QJsonObject p = parsed.toObject();
        r.hasParsed = true;
        int fc = 0, addr = 0;
        if (!getInt(p, "function_code", &fc) || !getInt(p, "register_address", &addr))
            return fail(QStringLiteral("parsed_command lacks function_code or register_address"));
        r.functionCode = fc;
        r.registerAddress = addr;
        if (fc == 6) {
            int v = 0;
            if (!getInt(p, "register_value", &v)) return fail(QStringLiteral("parsed_command lacks register_value"));
            r.parsedSummary = QStringLiteral("FC6 write register %1 = %2").arg(addr).arg(v);
        } else if (fc == 3) {
            int q = 0;
            if (!getInt(p, "quantity", &q)) return fail(QStringLiteral("parsed_command lacks quantity"));
            r.parsedSummary = QStringLiteral("FC3 read %1 register(s) from %2").arg(q).arg(addr);
        } else if (fc == 16) {
            const QJsonValue vals = p.value(QLatin1String("register_values"));
            if (!vals.isArray()) return fail(QStringLiteral("parsed_command lacks register_values"));
            QStringList shown;
            const QJsonArray a = vals.toArray();
            for (int i = 0; i < a.size(); ++i) {
                if (!a.at(i).isDouble()) return fail(QStringLiteral("register_values must be numbers"));
                if (i < 6) shown << QString::number(a.at(i).toInt());
            }
            r.parsedSummary = QStringLiteral("FC16 write %1 register(s) from %2 = [%3%4]")
                                  .arg(a.size()).arg(addr).arg(shown.join(QStringLiteral(", ")),
                                                              a.size() > 6 ? QStringLiteral(", ...") : QString());
        } else {
            return fail(QStringLiteral("parsed_command has an unsupported function_code"));
        }

        const QJsonObject s = sim.toObject();
        r.hasSimulation = true;
        if (!getString(s, "simulation_status", &r.simStatus) || !kSimStatuses.contains(r.simStatus))
            return fail(QStringLiteral("simulation_status is missing or unknown"));
        if (!getNumber(s, "configured_min_pressure", &r.minPressure) || !getNumber(s, "configured_max_pressure", &r.maxPressure) ||
            !getString(s, "pressure_unit", &r.pressureUnit) || r.minPressure >= r.maxPressure)
            return fail(QStringLiteral("simulation lacks valid configured pressure limits"));
        const QJsonValue viol = s.value(QLatin1String("violations"));
        if (!viol.isArray()) return fail(QStringLiteral("simulation.violations must be an array"));

        if (r.simStatus == QLatin1String("SUCCESS")) {
            if (!getNumber(s, "predicted_pressure", &r.pressure) || !getNumber(s, "predicted_flow", &r.flow) ||
                !getString(s, "flow_unit", &r.flowUnit))
                return fail(QStringLiteral("a SUCCESS simulation must carry predicted_pressure, predicted_flow and flow_unit"));
            r.hasPrediction = true;
            for (const QJsonValue& v : viol.toArray()) {
                if (!v.isObject()) return fail(QStringLiteral("a violation must be an object"));
                const QJsonObject vo = v.toObject();
                QString type;
                double limit = 0, predicted = 0;
                if (!getString(vo, "type", &type) || !getNumber(vo, "limit", &limit) || !getNumber(vo, "predicted", &predicted))
                    return fail(QStringLiteral("a violation lacks type, limit or predicted"));
                r.violationTypes << type;
                r.violations << QStringLiteral("%1: predicted %2 vs limit %3").arg(type, num(predicted), num(limit));
            }
        } else {
            if (!viol.toArray().isEmpty()) return fail(QStringLiteral("a failed simulation must not report violations"));
            if (o.value(QLatin1String("simulation")).toObject().contains(QLatin1String("predicted_pressure")))
                return fail(QStringLiteral("a failed simulation must not carry predictions"));
            if (!getString(s, "error", &r.simError) || r.simError.isEmpty())
                return fail(QStringLiteral("a failed simulation must carry an error message"));
        }
    }

    // ---- decision (required, strictly validated, and consistent with the result it belongs to)
    const QJsonValue dv = o.value(QLatin1String("decision"));
    if (!dv.isObject()) return fail(QStringLiteral("decision is missing"));
    const QJsonObject d = dv.toObject();
    QString dCommandId, dErrorCode;
    if (!getString(d, "command_id", &dCommandId) || dCommandId != r.commandId)
        return fail(QStringLiteral("decision belongs to a different command"));
    if (!getString(d, "decision", &r.decision) || !QStringList{"ALLOW", "BLOCK", "REJECT"}.contains(r.decision))
        return fail(QStringLiteral("decision is not ALLOW, BLOCK or REJECT"));
    if (!getString(d, "reason", &r.decisionReason) || r.decisionReason.isEmpty() || d.value(QLatin1String("reason")).toString().size() > 512)
        return fail(QStringLiteral("decision reason is missing or too long"));
    if (!getString(d, "source", &r.decisionSource) || !QStringList{"engine", "fail_closed"}.contains(r.decisionSource))
        return fail(QStringLiteral("decision source is missing or unknown"));
    const QJsonValue ec = d.value(QLatin1String("error_code"));
    if (r.decisionSource == QLatin1String("fail_closed")) {
        if (!ec.isString() || ec.toString().isEmpty()) return fail(QStringLiteral("a fail-closed decision must carry an error code"));
        if (r.decision != QLatin1String("REJECT")) return fail(QStringLiteral("a fail-closed decision must be REJECT"));
        r.decisionErrorCode = ec.toString().left(60);
    } else if (!ec.isNull() && !ec.isUndefined()) {
        return fail(QStringLiteral("an engine decision must not carry an error code"));
    }
    // ALLOW and BLOCK only make sense for a successful simulation; anything else is a contradiction.
    if (r.decision != QLatin1String("REJECT") && !(r.stage == QLatin1String("SIMULATED") && r.simStatus == QLatin1String("SUCCESS")))
        return fail(QStringLiteral("%1 for a result that was not a successful simulation").arg(r.decision));

    if (out) *out = r;
    return true;
}

}  // namespace voltguard
