#include "theme.h"

#include <QApplication>
#include <QPalette>
#include <QStyleFactory>

namespace voltguard::theme {

QString colorName(const QColor& c) { return c.name(QColor::HexRgb); }

void applyDarkTheme(QApplication& app) {
    app.setStyle(QStyleFactory::create(QStringLiteral("Fusion")));
    QPalette p;
    const QColor base(0x11, 0x16, 0x1c), panel(0x1a, 0x21, 0x2b), text(0xd8, 0xde, 0xe6), accent(0x3a, 0xa0, 0xff);
    p.setColor(QPalette::Window, base);
    p.setColor(QPalette::WindowText, text);
    p.setColor(QPalette::Base, panel);
    p.setColor(QPalette::AlternateBase, QColor(0x20, 0x29, 0x35));
    p.setColor(QPalette::Text, text);
    p.setColor(QPalette::Button, panel);
    p.setColor(QPalette::ButtonText, text);
    p.setColor(QPalette::ToolTipBase, panel);
    p.setColor(QPalette::ToolTipText, text);
    p.setColor(QPalette::Highlight, accent);
    p.setColor(QPalette::HighlightedText, Qt::black);
    p.setColor(QPalette::PlaceholderText, kMuted);
    p.setColor(QPalette::Disabled, QPalette::Text, kMuted);
    p.setColor(QPalette::Disabled, QPalette::ButtonText, kMuted);
    app.setPalette(p);
    app.setStyleSheet(QStringLiteral(
        "QGroupBox { border: 1px solid #2c3746; border-radius: 4px; margin-top: 10px; padding-top: 8px; }"
        "QGroupBox::title { subcontrol-origin: margin; left: 8px; color: #3aa0ff; }"
        "QTabWidget::pane { border: 1px solid #2c3746; }"
        "QTabBar::tab { background: #1a212b; padding: 6px 14px; border: 1px solid #2c3746; }"
        "QTabBar::tab:selected { background: #243041; color: #3aa0ff; }"
        "QHeaderView::section { background: #20293a; color: #d8dee6; padding: 4px; border: 0; border-right: 1px solid #2c3746; }"
        "QPushButton { padding: 5px 12px; border: 1px solid #2c3746; border-radius: 3px; }"
        "QPushButton:hover { border-color: #3aa0ff; }"
        "QPushButton:disabled { color: #5d6877; }"
        "QPlainTextEdit, QTableView, QTableWidget, QLineEdit, QComboBox { border: 1px solid #2c3746; }"));
}

}  // namespace voltguard::theme
