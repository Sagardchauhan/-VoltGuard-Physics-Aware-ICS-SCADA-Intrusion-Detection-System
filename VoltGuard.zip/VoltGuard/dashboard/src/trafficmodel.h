// Table model for the traffic monitor. Keeps at most kMaxRows rows so memory stays bounded;
// the counters cover everything appended since the last clear().
#pragma once

#include <QAbstractTableModel>
#include <QVector>

#include "commandrecord.h"

namespace voltguard {

struct Counts {
    int total = 0;
    int withinLimits = 0;
    int violations = 0;
    int rejected = 0;   // parser rejections and invalid-input simulations
    int failures = 0;   // component failures and simulation errors/timeouts
    int allowed = 0;    // decisions
    int blocked = 0;
    int rejectedDecisions = 0;
};

class TrafficModel : public QAbstractTableModel {
    Q_OBJECT
public:
    enum Column { ColTime, ColCommandId, ColSource, ColParsed, ColStage, ColPressure, ColSafety, ColDecision, ColCount };
    static constexpr int kMaxRows = 5000;

    explicit TrafficModel(QObject* parent = nullptr);

    int rowCount(const QModelIndex& parent = QModelIndex()) const override;
    int columnCount(const QModelIndex& parent = QModelIndex()) const override;
    QVariant data(const QModelIndex& index, int role = Qt::DisplayRole) const override;
    QVariant headerData(int section, Qt::Orientation orientation, int role = Qt::DisplayRole) const override;

    void append(const CommandRecord& record);
    void clear();
    const CommandRecord& recordAt(int row) const { return m_rows.at(row); }
    Counts counts() const { return m_counts; }

signals:
    void countsChanged();

private:
    QVector<CommandRecord> m_rows;
    Counts m_counts;
};

}  // namespace voltguard
