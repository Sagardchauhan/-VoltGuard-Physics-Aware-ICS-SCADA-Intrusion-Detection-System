// Asynchronous client for the Python worker (voltguard.worker), speaking JSON lines over a QProcess.
//
// Nothing here blocks the GUI thread except stop(), which waits briefly at shutdown. Every request has a
// watchdog; a hung, crashed or garbled worker moves the client to State::Failed, every pending request is
// reported through requestFailed(), and nothing is ever reported as processed that was not.
// The worker is started from a program path and an argument list (QProcess, no shell).
#pragma once

#include <QHash>
#include <QJsonArray>
#include <QJsonObject>
#include <QObject>
#include <QProcess>
#include <QStringList>
#include <QTimer>

namespace voltguard {

class WorkerClient : public QObject {
    Q_OBJECT
public:
    enum class State { Stopped, Starting, Ready, Failed };
    Q_ENUM(State)

    static constexpr int kMaxLineBytes = 2 * 1024 * 1024;  // a worker line longer than this is a protocol failure

    explicit WorkerClient(QObject* parent = nullptr);
    ~WorkerClient() override;

    void start(const QString& program, const QStringList& arguments, const QString& workingDirectory);
    void stop();

    State state() const { return m_state; }
    bool isReady() const { return m_state == State::Ready; }
    QString detail() const { return m_detail; }
    static QString stateText(State s);
    int pendingCount() const { return static_cast<int>(m_pending.size()); }

    void setRequestTimeoutMs(int ms) { m_requestTimeoutMs = ms; }
    void setStartTimeoutMs(int ms) { m_startTimeoutMs = ms; }

    void requestScenarios();
    // False (and nothing sent) if the worker is not ready or the id is already pending.
    bool sendProcess(const QString& commandId, const QString& frameHex, const QString& source = QString());
    // One log query at a time (events or verification). Both are covered by the request watchdog.
    bool requestEvents(int limit);
    bool requestLogVerification();
    // Asks the worker to write the stored events to `path` (format csv|json|pdf). The worker refuses to overwrite an
    // existing file unless `overwrite` is true. The answer arrives through exportFinished (ok=false on refusal).
    bool requestExport(const QString& format, const QString& path, bool overwrite);
    bool queryPending() const { return m_queryTimer.isActive(); }

signals:
    void stateChanged(WorkerClient::State state, const QString& detail);
    void ready(const QJsonObject& info);
    void scenariosReceived(const QJsonArray& scenarios);
    void eventsReceived(const QJsonObject& reply);
    void logVerified(bool ok, const QString& message);
    void exportFinished(const QJsonObject& reply);
    void resultReceived(const QJsonObject& result);
    void requestFailed(const QString& commandId, const QString& reason);
    void protocolError(const QString& message);

private slots:
    void onStdout();
    void onStderr();
    void onFinished(int exitCode, QProcess::ExitStatus status);
    void onProcessError(QProcess::ProcessError error);
    void onStartTimeout();

private:
    void setState(State s, const QString& detail);
    void fail(const QString& reason);
    void handleLine(const QByteArray& line);
    bool writeLine(const QJsonObject& object);
    void clearPending(const QString& reason);
    enum class QueryKind { None, Events, Verify, Export };
    bool startQuery(const QJsonObject& request, QueryKind kind, int timeoutMs);
    QueryKind m_queryKind = QueryKind::None;

    QProcess m_proc;
    QByteArray m_buffer;
    QByteArray m_stderrTail;
    State m_state = State::Stopped;
    QString m_detail;
    bool m_stopping = false;
    int m_requestTimeoutMs = 10000;
    int m_startTimeoutMs = 30000;
    QTimer m_startTimer;
    QTimer m_queryTimer;
    QHash<QString, QTimer*> m_pending;
};

}  // namespace voltguard
