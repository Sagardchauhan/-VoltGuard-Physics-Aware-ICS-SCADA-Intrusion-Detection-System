// Dark industrial colour scheme shared by the widgets.
#pragma once

#include <QColor>

class QApplication;

namespace voltguard::theme {

inline const QColor kOk(0x3e, 0xcf, 0x8e);
inline const QColor kViolation(0xff, 0x8a, 0x3d);
inline const QColor kRejected(0xf5, 0xc5, 0x42);
inline const QColor kFailure(0xff, 0x5c, 0x5c);
inline const QColor kMuted(0x8a, 0x96, 0xa6);
inline const QColor kText(0xd8, 0xde, 0xe6);
inline const QColor kPanel(0x1a, 0x21, 0x2b);

QString colorName(const QColor& c);
void applyDarkTheme(QApplication& app);

}  // namespace voltguard::theme
