# Qt 6 desktop dashboard. Included from the top-level CMakeLists only when Qt 6 (Widgets, Test) was found.
set(CMAKE_AUTOMOC ON)

add_library(voltguard_dashboard_core STATIC
  src/commandrecord.cpp
  src/trafficmodel.cpp
  src/workerclient.cpp
  src/mainwindow.cpp
  src/theme.cpp
  src/alerts.cpp
  src/chartpanel.cpp)
target_include_directories(voltguard_dashboard_core PUBLIC src)
target_link_libraries(voltguard_dashboard_core PUBLIC Qt6::Widgets Qt6::Charts)

add_executable(voltguard_dashboard src/main.cpp)
target_link_libraries(voltguard_dashboard PRIVATE voltguard_dashboard_core)
set_target_properties(voltguard_dashboard PROPERTIES WIN32_EXECUTABLE ON)

add_executable(dashboard_tests tests/dashboard_tests.cpp)
target_link_libraries(dashboard_tests PRIVATE voltguard_dashboard_core Qt6::Test)

foreach(target voltguard_dashboard_core voltguard_dashboard dashboard_tests)
  if(MSVC)
    target_compile_options(${target} PRIVATE /W4)
  else()
    target_compile_options(${target} PRIVATE -Wall -Wextra -Wpedantic)
  endif()
  if(VOLTGUARD_SANITIZE AND NOT MSVC)
    target_compile_options(${target} PRIVATE -fsanitize=address,undefined -fno-omit-frame-pointer)
    target_link_options(${target} PRIVATE -fsanitize=address,undefined)
  endif()
endforeach()

# The tests start the real Python worker, so they need a Python interpreter, the project root and the parser CLI.
find_package(Python3 COMPONENTS Interpreter)
if(Python3_FOUND)
  add_test(NAME dashboard_tests COMMAND dashboard_tests)
  set_tests_properties(dashboard_tests PROPERTIES
    TIMEOUT 300
    ENVIRONMENT "QT_QPA_PLATFORM=offscreen;VOLTGUARD_ROOT=${CMAKE_SOURCE_DIR};VOLTGUARD_PYTHON=${Python3_EXECUTABLE};VOLTGUARD_PARSER_CLI=$<TARGET_FILE:voltguard_parser_cli>;VOLTGUARD_FAKE_WORKER=${CMAKE_SOURCE_DIR}/tests/fixtures/fake_worker.py;VOLTGUARD_FAKE_ENGINE=${CMAKE_SOURCE_DIR}/tests/fixtures/fake_engine.py")
else()
  message(WARNING "Python 3 not found: the dashboard tests are not registered with ctest")
endif()
