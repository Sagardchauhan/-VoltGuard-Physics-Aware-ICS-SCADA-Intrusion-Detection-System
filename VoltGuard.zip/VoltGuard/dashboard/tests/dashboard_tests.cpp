// QtTest suite for the VoltGuard dashboard (run with QT_QPA_PLATFORM=offscreen).
// Environment (set by CMake/ctest): VOLTGUARD_ROOT, VOLTGUARD_PYTHON, VOLTGUARD_PARSER_CLI, VOLTGUARD_FAKE_WORKER.
// Tests that need the real worker use the real C++ parser and Python pipeline; failure-injection tests use
// tests/fixtures/fake_worker.py. A missing environment variable FAILS the suite instead of skipping.
#include <QApplication>
#include <QElapsedTimer>
#include <QJsonArray>
#include <QJsonDocument>
#include <QLabel>
#include <QLineEdit>
#include <QListWidget>
#include <QPlainTextEdit>
#include <QPushButton>
#include <QSignalSpy>
#include <QTimer>
#include <QTableView>
#include <QTableWidget>
#include <QTemporaryDir>
#include <QtTest>

#include "alerts.h"
#include "chartpanel.h"
#include "commandrecord.h"
#include "mainwindow.h"
#include "trafficmodel.h"
#include "workerclient.h"

using namespace voltguard;

namespace {

QString env(const char* name) { return qEnvironmentVariable(name); }

WorkerLaunch realLaunch(const QString& logDir, const QStringList& extra = {}) {
    static int counter = 0;
    WorkerLaunch l;
    l.program = env("VOLTGUARD_PYTHON");
    l.workingDirectory = env("VOLTGUARD_ROOT");
    l.arguments = {"-m", "voltguard.worker", "--parser-cli", env("VOLTGUARD_PARSER_CLI"), "--log-dir", logDir,
                   "--event-db", QString("%1/events_%2.db").arg(logDir).arg(++counter)};   // a fresh event database per launch
    l.arguments += extra;
    return l;
}

WorkerLaunch fakeLaunch(const QString& mode) {
    WorkerLaunch l;
    l.program = env("VOLTGUARD_PYTHON");
    l.workingDirectory = env("VOLTGUARD_ROOT");
    l.arguments = {env("VOLTGUARD_FAKE_WORKER"), mode};
    return l;
}

QJsonObject decisionObj(const QString& id, const QString& decision, const QString& reason = "policy reason",
                        const QString& source = "engine", const QJsonValue& errorCode = QJsonValue::Null) {
    return QJsonObject{{"command_id", id}, {"decision", decision}, {"reason", reason}, {"source", source}, {"error_code", errorCode}};
}

// A complete, valid worker "result" message for a SIMULATED command.
QJsonObject validResult(const QString& id = "T-1") {
    QJsonObject parsed{{"function_code", 6}, {"register_address", 100}, {"register_value", 60}};
    QJsonObject sim{{"simulation_status", "SUCCESS"}, {"configured_min_pressure", 20.0}, {"configured_max_pressure", 100.0},
                    {"pressure_unit", "kPa"}, {"flow_unit", "L/s"}, {"predicted_pressure", 55.5}, {"predicted_flow", 20.0},
                    {"violations", QJsonArray()}};
    return QJsonObject{{"type", "result"}, {"command_id", id}, {"timestamp_utc", "2026-10-31T09:00:00.123+00:00"},
                       {"stage", "SIMULATED"}, {"parsed_command", parsed}, {"simulation", sim},
                       {"decision", decisionObj(id, "ALLOW")},
                       {"timings_ms", QJsonObject{{"parse", 1.0}, {"simulate", 2.0}, {"total", 3.5}}}};
}

QJsonObject rejectedResult(const QString& id = "T-2") {
    return QJsonObject{{"type", "result"}, {"command_id", id}, {"timestamp_utc", "2026-10-31T09:00:00.123+00:00"},
                       {"stage", "PARSE_REJECTED"}, {"parsed_command", QJsonValue::Null}, {"simulation", QJsonValue::Null},
                       {"error_code", "BAD_LENGTH"}, {"error", "length field mismatch"},
                       {"decision", decisionObj(id, "REJECT")},
                       {"timings_ms", QJsonObject{{"parse", 1.0}, {"simulate", 0.0}, {"total", 1.5}}}};
}

CommandRecord recordWith(CommandRecord::Severity wanted) {
    CommandRecord r;
    QString err;
    switch (wanted) {
        case CommandRecord::Severity::Ok:
            CommandRecord::fromJson(validResult(), &r, &err);
            break;
        case CommandRecord::Severity::Violation: {
            QJsonObject m = validResult();
            QJsonObject sim = m["simulation"].toObject();
            sim["violations"] = QJsonArray{QJsonObject{{"type", "PRESSURE_HIGH"}, {"limit", 100.0}, {"predicted", 145.0}}};
            m["simulation"] = sim;
            m["decision"] = decisionObj("T-1", "BLOCK");
            CommandRecord::fromJson(m, &r, &err);
            break;
        }
        case CommandRecord::Severity::Rejected:
            CommandRecord::fromJson(rejectedResult(), &r, &err);
            break;
        case CommandRecord::Severity::Failure:
            r = CommandRecord::failure("F-1", "x", "00", "WORKER_FAILURE", "boom");
            break;
    }
    return r;
}

// A record with a chosen prediction and decision (BLOCK carries a PRESSURE_HIGH violation).
CommandRecord predicted(const QString& id, double pressure, double flow, const QString& decision) {
    QJsonObject m = validResult(id);
    QJsonObject sim = m["simulation"].toObject();
    sim["predicted_pressure"] = pressure;
    sim["predicted_flow"] = flow;
    if (decision == "BLOCK") sim["violations"] = QJsonArray{QJsonObject{{"type", "PRESSURE_HIGH"}, {"limit", 100.0}, {"predicted", pressure}}};
    m["simulation"] = sim;
    m["decision"] = decisionObj(id, decision);
    CommandRecord r;
    QString err;
    if (!CommandRecord::fromJson(m, &r, &err)) qFatal("test helper produced an invalid record: %s", qPrintable(err));
    return r;
}

CommandRecord withDecision(QJsonObject m, const QJsonObject& decision) {
    m["decision"] = decision;
    CommandRecord r;
    QString err;
    if (!CommandRecord::fromJson(m, &r, &err)) qFatal("test helper produced an invalid record: %s", qPrintable(err));
    return r;
}

bool hasAlert(AlertLog* log, const QString& code, Alert::Level level) {
    for (int i = 0; i < log->size(); ++i)
        if (log->at(i).code == code && log->at(i).level == level) return true;
    return false;
}

int rowForSource(TrafficModel* m, const QString& source) {
    for (int r = 0; r < m->rowCount(); ++r)
        if (m->recordAt(r).source == source) return r;
    return -1;
}

}  // namespace

// ============================================================================ CommandRecord / TrafficModel

class RecordModelTests : public QObject {
    Q_OBJECT
private slots:
    void validSimulatedResultIsParsed() {
        CommandRecord r;
        QString err;
        QVERIFY2(CommandRecord::fromJson(validResult(), &r, &err), qPrintable(err));
        QCOMPARE(r.commandId, QString("T-1"));
        QCOMPARE(r.stage, QString("SIMULATED"));
        QVERIFY(r.hasPrediction);
        QCOMPARE(r.pressure, 55.5);
        QCOMPARE(r.severity(), CommandRecord::Severity::Ok);
        QCOMPARE(r.safetyStatus(), QString("WITHIN LIMITS (simulated)"));
        QVERIFY(r.parsedSummary.contains("register 100 = 60"));
    }

    void violationIsReported() {
        const CommandRecord r = recordWith(CommandRecord::Severity::Violation);
        QCOMPARE(r.severity(), CommandRecord::Severity::Violation);
        QCOMPARE(r.safetyStatus(), QString("LIMIT VIOLATION (simulated)"));
        QCOMPARE(r.violationTypes, QStringList{"PRESSURE_HIGH"});
    }

    void parseRejectionIsNotASafetyVerdict() {
        const CommandRecord r = recordWith(CommandRecord::Severity::Rejected);
        QCOMPARE(r.severity(), CommandRecord::Severity::Rejected);
        QCOMPARE(r.safetyStatus(), QString("REJECTED BY PARSER"));
        QVERIFY(!r.hasPrediction);
        QCOMPARE(r.errorCode, QString("BAD_LENGTH"));
    }

    void invalidInputSimulationCountsAsRejected() {
        QJsonObject m = validResult();
        QJsonObject sim{{"simulation_status", "INVALID_INPUT"}, {"configured_min_pressure", 20.0}, {"configured_max_pressure", 100.0},
                        {"pressure_unit", "kPa"}, {"violations", QJsonArray()}, {"error", "pump speed out of range"}};
        m["simulation"] = sim;
        m["decision"] = decisionObj("T-1", "REJECT");
        CommandRecord r;
        QString err;
        QVERIFY2(CommandRecord::fromJson(m, &r, &err), qPrintable(err));
        QVERIFY(!r.hasPrediction);
        QCOMPARE(r.severity(), CommandRecord::Severity::Rejected);
    }

    void simulationErrorCountsAsFailure() {
        for (const char* status : {"ERROR", "TIMEOUT"}) {
            QJsonObject m = validResult();
            QJsonObject sim{{"simulation_status", status}, {"configured_min_pressure", 20.0}, {"configured_max_pressure", 100.0},
                            {"pressure_unit", "kPa"}, {"violations", QJsonArray()}, {"error", "solver failed"}};
            m["simulation"] = sim;
            m["decision"] = decisionObj("T-1", "REJECT");
            CommandRecord r;
            QString err;
            QVERIFY2(CommandRecord::fromJson(m, &r, &err), qPrintable(err));
            QCOMPARE(r.severity(), CommandRecord::Severity::Failure);
            QVERIFY(r.safetyStatus().startsWith("SIMULATION "));
        }
    }

    void malformedResultsAreRejected_data() {
        QTest::addColumn<QString>("what");
        for (const char* k : {"command_id", "timestamp_utc", "stage", "timings_ms", "parsed_command", "simulation", "decision"})
            QTest::newRow(qPrintable(QString("missing_") + k)) << QString("missing:") + k;
        QTest::newRow("empty_command_id") << "id:";
        QTest::newRow("long_command_id") << "id:" + QString(65, 'a');
        QTest::newRow("unknown_stage") << "stage:BLOCKED";
        QTest::newRow("bad_timestamp") << "ts:not a date";
        QTest::newRow("negative_timing") << "timing:-1";
        QTest::newRow("stage_without_simulation") << "stage:PARSE_REJECTED";
        QTest::newRow("success_without_pressure") << "nopressure";
        QTest::newRow("success_without_flow") << "noflow";
        QTest::newRow("inverted_limits") << "limits";
        QTest::newRow("unknown_sim_status") << "simstatus:MAYBE";
        QTest::newRow("unsupported_function_code") << "fc:8";
        QTest::newRow("violation_missing_limit") << "violnolimit";
        QTest::newRow("failed_sim_with_prediction") << "failedwithpred";
        QTest::newRow("failed_sim_with_violation") << "failedwithviol";
        QTest::newRow("nan_like_string_pressure") << "pressurestring";
        QTest::newRow("logged_is_a_string") << "loggedstr";
        QTest::newRow("decision_for_other_command") << "decid";
        QTest::newRow("decision_unknown_value") << "decunknown";
        QTest::newRow("decision_lowercase") << "declower";
        QTest::newRow("decision_reason_empty") << "decreasonempty";
        QTest::newRow("decision_reason_too_long") << "decreasonlong";
        QTest::newRow("decision_source_unknown") << "decsource";
        QTest::newRow("fail_closed_allow") << "fcallow";
        QTest::newRow("fail_closed_block") << "fcblock";
        QTest::newRow("fail_closed_without_code") << "fcnocode";
        QTest::newRow("engine_with_error_code") << "engerr";
        QTest::newRow("decision_not_an_object") << "decstring";
        QTest::newRow("allow_for_parse_rejected") << "allowrejected";
        QTest::newRow("block_for_invalid_input") << "blockinvalid";
        QTest::newRow("allow_for_simulation_error") << "allowsimerror";
        QTest::newRow("rejected_but_has_parsed_command") << "rejwithparsed";
        QTest::newRow("rejected_but_has_simulation") << "rejwithsim";
        QTest::newRow("simulated_but_simulation_null") << "simnull";
    }
    void malformedResultsAreRejected() {
        QFETCH(QString, what);
        QJsonObject m = validResult();
        QJsonObject sim = m["simulation"].toObject();
        if (what.startsWith("missing:")) m.remove(what.mid(8));
        else if (what.startsWith("id:")) m["command_id"] = what.mid(3);
        else if (what.startsWith("stage:")) m["stage"] = what.mid(6);
        else if (what.startsWith("ts:")) m["timestamp_utc"] = what.mid(3);
        else if (what.startsWith("timing:")) m["timings_ms"] = QJsonObject{{"parse", what.mid(7).toDouble()}, {"simulate", 0.0}, {"total", 1.0}};
        else if (what == "nopressure") { sim.remove("predicted_pressure"); m["simulation"] = sim; }
        else if (what == "noflow") { sim.remove("predicted_flow"); m["simulation"] = sim; }
        else if (what == "limits") { sim["configured_min_pressure"] = 100.0; sim["configured_max_pressure"] = 20.0; m["simulation"] = sim; }
        else if (what.startsWith("simstatus:")) { sim["simulation_status"] = what.mid(10); m["simulation"] = sim; }
        else if (what == "fc:8") { m["parsed_command"] = QJsonObject{{"function_code", 8}, {"register_address", 1}}; }
        else if (what == "violnolimit") { sim["violations"] = QJsonArray{QJsonObject{{"type", "PRESSURE_HIGH"}, {"predicted", 1.0}}}; m["simulation"] = sim; }
        else if (what == "failedwithpred") { sim["simulation_status"] = "ERROR"; sim["error"] = "x"; m["simulation"] = sim; }  // still has predicted_pressure
        else if (what == "failedwithviol") {
            sim.remove("predicted_pressure"); sim.remove("predicted_flow");
            sim["simulation_status"] = "ERROR"; sim["error"] = "x";
            sim["violations"] = QJsonArray{QJsonObject{{"type", "PRESSURE_HIGH"}, {"limit", 1.0}, {"predicted", 2.0}}};
            m["simulation"] = sim;
        }
        else if (what == "loggedstr") { m["logged"] = "yes"; }
        else if (what == "decid") { m["decision"] = decisionObj("OTHER", "ALLOW"); }
        else if (what == "decunknown") { m["decision"] = decisionObj("T-1", "MAYBE"); }
        else if (what == "declower") { m["decision"] = decisionObj("T-1", "allow"); }
        else if (what == "decreasonempty") { m["decision"] = decisionObj("T-1", "ALLOW", ""); }
        else if (what == "decreasonlong") { m["decision"] = decisionObj("T-1", "ALLOW", QString(513, 'r')); }
        else if (what == "decsource") { m["decision"] = decisionObj("T-1", "ALLOW", "r", "nobody"); }
        else if (what == "fcallow") { m["decision"] = decisionObj("T-1", "ALLOW", "r", "fail_closed", "CODE"); }
        else if (what == "fcblock") { m["decision"] = decisionObj("T-1", "BLOCK", "r", "fail_closed", "CODE"); }
        else if (what == "fcnocode") { m["decision"] = decisionObj("T-1", "REJECT", "r", "fail_closed"); }
        else if (what == "engerr") { m["decision"] = decisionObj("T-1", "REJECT", "r", "engine", "CODE"); }
        else if (what == "decstring") { m["decision"] = "ALLOW"; }
        else if (what == "allowrejected") { m = rejectedResult("T-1"); m["decision"] = decisionObj("T-1", "ALLOW"); }
        else if (what == "blockinvalid") { sim["simulation_status"] = "INVALID_INPUT"; sim.remove("predicted_pressure"); sim.remove("predicted_flow"); sim["error"] = "x"; m["simulation"] = sim; m["decision"] = decisionObj("T-1", "BLOCK"); }
        else if (what == "allowsimerror") { sim["simulation_status"] = "ERROR"; sim.remove("predicted_pressure"); sim.remove("predicted_flow"); sim["error"] = "x"; m["simulation"] = sim; }
        else if (what == "rejwithparsed") { m = rejectedResult(); m["parsed_command"] = validResult()["parsed_command"]; }
        else if (what == "rejwithsim") { m = rejectedResult(); m["simulation"] = validResult()["simulation"]; }
        else if (what == "simnull") { m["simulation"] = QJsonValue::Null; }
        else if (what == "pressurestring") { sim["predicted_pressure"] = "55.5"; m["simulation"] = sim; }
        CommandRecord r;
        QString err;
        QVERIFY2(!CommandRecord::fromJson(m, &r, &err), qPrintable("accepted: " + what));
        QVERIFY(!err.isEmpty());
    }

    void parserRejectedMessageMustCarryErrorFields() {
        QJsonObject m = rejectedResult();
        m.remove("error_code");
        CommandRecord r;
        QString err;
        QVERIFY(!CommandRecord::fromJson(m, &r, &err));
    }

    void loggedFlagIsParsedAndShown() {
        QJsonObject m = validResult();
        CommandRecord r;
        QString err;
        QVERIFY(CommandRecord::fromJson(m, &r, &err));
        QCOMPARE(r.logged, -1);                                   // absent
        m["logged"] = true;
        QVERIFY(CommandRecord::fromJson(m, &r, &err));
        QCOMPARE(r.logged, 1);
        QVERIFY(r.detailsText().contains("stored"));
        QVERIFY(!r.detailsText().contains("NOT STORED"));
        m["logged"] = false;
        QVERIFY(CommandRecord::fromJson(m, &r, &err));
        QCOMPARE(r.logged, 0);
        QVERIFY(r.detailsText().contains("NOT STORED"));
        m["logged"] = QJsonValue::Null;
        QVERIFY(CommandRecord::fromJson(m, &r, &err));
        QCOMPARE(r.logged, -1);
    }

    void decisionIsShownExactlyAsReceived() {
        CommandRecord r;
        QString err;
        QVERIFY2(CommandRecord::fromJson(validResult(), &r, &err), qPrintable(err));
        QCOMPARE(r.decision, QString("ALLOW"));
        QCOMPARE(r.decisionText(), QString("ALLOW (engine)"));
        QVERIFY(r.detailsText().contains("Reason: policy reason"));
        QVERIFY(r.detailsText().contains("Nothing is forwarded"));
        const CommandRecord blocked = recordWith(CommandRecord::Severity::Violation);
        QCOMPARE(blocked.decisionText(), QString("BLOCK (engine)"));
        QCOMPARE(recordWith(CommandRecord::Severity::Rejected).decision, QString("REJECT"));
    }

    void aFailureRecordIsAlwaysARejectNeverAnAllow() {
        const CommandRecord r = CommandRecord::failure("F-9", "src", "00", "WORKER_FAILURE", "x");
        QCOMPARE(r.decision, QString("REJECT"));
        QCOMPARE(r.decisionSource, QString("fail_closed"));
        QCOMPARE(r.decisionErrorCode, QString("WORKER_FAILURE"));
        QVERIFY(r.detailsText().contains("REJECT (fail_closed)"));
        QVERIFY(!r.detailsText().contains("ALLOW ("));
    }

    void aFailClosedRejectIsAccepted() {
        QJsonObject m = validResult();
        m["decision"] = decisionObj("T-1", "REJECT", "fail closed: engine timeout", "fail_closed", "DECISION_TIMEOUT");
        CommandRecord r;
        QString err;
        QVERIFY2(CommandRecord::fromJson(m, &r, &err), qPrintable(err));
        QCOMPARE(r.decisionErrorCode, QString("DECISION_TIMEOUT"));
        QVERIFY(r.detailsText().contains("Failure code: DECISION_TIMEOUT"));
    }

    void detailsLabelPredictionsAsSimulated() {
        QVERIFY(recordWith(CommandRecord::Severity::Ok).detailsText().contains("SIMULATED"));
    }

    void failureFactoryMakesAFailureRecord() {
        const CommandRecord r = CommandRecord::failure("X-1", "src", "0102", "WORKER_FAILURE", QString(5000, 'z'));
        QCOMPARE(r.severity(), CommandRecord::Severity::Failure);
        QCOMPARE(r.safetyStatus(), QString("COMPONENT FAILURE"));
        QVERIFY(r.error.size() <= 600);
        QVERIFY(!r.hasPrediction);
    }

    void modelCountsEverySeverityOnce() {
        TrafficModel m;
        QSignalSpy spy(&m, &TrafficModel::countsChanged);
        m.append(recordWith(CommandRecord::Severity::Ok));
        m.append(recordWith(CommandRecord::Severity::Ok));
        m.append(recordWith(CommandRecord::Severity::Violation));
        m.append(recordWith(CommandRecord::Severity::Rejected));
        m.append(recordWith(CommandRecord::Severity::Failure));
        const Counts c = m.counts();
        QCOMPARE(c.total, 5);
        QCOMPARE(c.withinLimits, 2);
        QCOMPARE(c.violations, 1);
        QCOMPARE(c.rejected, 1);
        QCOMPARE(c.failures, 1);
        QCOMPARE(spy.count(), 5);
        QCOMPARE(m.rowCount(), 5);
    }

    void modelClearResetsRowsAndCounts() {
        TrafficModel m;
        m.append(recordWith(CommandRecord::Severity::Violation));
        QSignalSpy spy(&m, &TrafficModel::countsChanged);
        m.clear();
        QCOMPARE(m.rowCount(), 0);
        QCOMPARE(m.counts().total, 0);
        QCOMPARE(m.counts().violations, 0);
        QCOMPARE(spy.count(), 1);
    }

    void modelRowsAreBoundedButCountersAreNot() {
        TrafficModel m;
        const CommandRecord r = recordWith(CommandRecord::Severity::Ok);
        for (int i = 0; i < TrafficModel::kMaxRows + 25; ++i) m.append(r);
        QCOMPARE(m.rowCount(), TrafficModel::kMaxRows);
        QCOMPARE(m.counts().total, TrafficModel::kMaxRows + 25);
    }

    void modelShowsTheDecisionAndCountsEachKind() {
        TrafficModel m;
        for (auto s : {CommandRecord::Severity::Ok, CommandRecord::Severity::Violation, CommandRecord::Severity::Rejected,
                       CommandRecord::Severity::Failure, CommandRecord::Severity::Ok})
            m.append(recordWith(s));
        const QStringList shown = {"ALLOW", "BLOCK", "REJECT", "REJECT", "ALLOW"};
        for (int row = 0; row < m.rowCount(); ++row)
            QCOMPARE(m.data(m.index(row, TrafficModel::ColDecision)).toString(), shown.at(row));
        const Counts c = m.counts();
        QCOMPARE(c.allowed, 2);
        QCOMPARE(c.blocked, 1);
        QCOMPARE(c.rejectedDecisions, 2);
        QCOMPARE(c.allowed + c.blocked + c.rejectedDecisions, c.total);
        QVERIFY(m.headerData(TrafficModel::ColPressure, Qt::Horizontal).toString().contains("simulated"));
        QVERIFY(m.data(m.index(0, TrafficModel::ColDecision), Qt::ToolTipRole).toString().contains("policy reason"));
        m.clear();
        QCOMPARE(m.counts().allowed, 0);
    }

    void modelIgnoresOutOfRangeIndexes() {
        TrafficModel m;
        QVERIFY(!m.data(m.index(0, 0)).isValid());
        m.append(recordWith(CommandRecord::Severity::Ok));
        QVERIFY(!m.data(m.index(5, 0)).isValid());
    }
};

// ============================================================================ WorkerClient with fake workers

class ChartAlertTests : public QObject {
    Q_OBJECT
private slots:
    void anOrdinaryAllowRaisesNoAlert() {
        QVERIFY(alertsForRecord(predicted("A-1", 55.5, 20.0, "ALLOW")).isEmpty());
    }

    void aBlockIsCriticalAndNamesTheSimulatedViolation() {
        const QList<Alert> a = alertsForRecord(predicted("A-2", 145.0, 30.0, "BLOCK"));
        QCOMPARE(a.size(), 1);
        QCOMPARE(a[0].level, Alert::Level::Critical);
        QCOMPARE(a[0].code, QString("LIMIT_VIOLATION_BLOCKED"));
        QCOMPARE(a[0].commandId, QString("A-2"));
        QVERIFY(a[0].message.contains("BLOCKED") && a[0].message.contains("simulated") && a[0].message.contains("PRESSURE_HIGH"));
    }

    void aFailClosedRejectIsCriticalWithItsCode() {
        const CommandRecord r = withDecision(validResult("A-3"), decisionObj("A-3", "REJECT", "engine timed out", "fail_closed", "DECISION_TIMEOUT"));
        const QList<Alert> a = alertsForRecord(r);
        QCOMPARE(a.size(), 1);
        QCOMPARE(a[0].level, Alert::Level::Critical);
        QCOMPARE(a[0].code, QString("DECISION_TIMEOUT"));
        QVERIFY(a[0].message.contains("Fail closed"));
    }

    void aWorkerFailureRecordIsCritical() {
        const QList<Alert> a = alertsForRecord(CommandRecord::failure("A-4", "x", "00", "WORKER_FAILURE", "boom"));
        QCOMPARE(a.size(), 1);
        QCOMPARE(a[0].level, Alert::Level::Critical);
        QCOMPARE(a[0].code, QString("WORKER_FAILURE"));
    }

    void aParserRejectionIsOnlyAWarning() {
        CommandRecord r;
        QString err;
        QVERIFY2(CommandRecord::fromJson(rejectedResult("A-5"), &r, &err), qPrintable(err));
        const QList<Alert> a = alertsForRecord(r);
        QCOMPARE(a.size(), 1);
        QCOMPARE(a[0].level, Alert::Level::Warning);
        QCOMPARE(a[0].code, QString("BAD_LENGTH"));
    }

    void anUnstoredEventAddsAWarningToWhateverElseHappened() {
        CommandRecord allow = predicted("A-6", 55.5, 20.0, "ALLOW");
        allow.logged = 0;
        QList<Alert> a = alertsForRecord(allow);
        QCOMPARE(a.size(), 1);
        QCOMPARE(a[0].code, QString("EVENT_NOT_STORED"));
        QCOMPARE(a[0].level, Alert::Level::Warning);
        CommandRecord block = predicted("A-7", 145.0, 30.0, "BLOCK");
        block.logged = 0;
        QCOMPARE(alertsForRecord(block).size(), 2);
        allow.logged = 1;
        QVERIFY(alertsForRecord(allow).isEmpty());
        allow.logged = -1;
        QVERIFY(alertsForRecord(allow).isEmpty());   // logging deliberately off is not an alert
    }

    void theAlertLogIsBoundedCountsLevelsAndClears() {
        AlertLog log;
        QSignalSpy spy(&log, &AlertLog::changed);
        for (int i = 0; i < 250; ++i) log.addSystem(i % 2 ? Alert::Level::Critical : Alert::Level::Warning, "C", QString("m%1").arg(i));
        QCOMPARE(log.size(), AlertLog::kMaxAlerts);
        QCOMPARE(log.droppedCount(), 50);
        QCOMPARE(log.at(0).message, QString("m50"));            // oldest dropped first
        QCOMPARE(log.at(log.size() - 1).message, QString("m249"));
        QCOMPARE(log.count(Alert::Level::Critical) + log.count(Alert::Level::Warning), 200);
        QCOMPARE(spy.count(), 250);
        log.clear();
        QCOMPARE(log.size(), 0);
        QCOMPARE(log.droppedCount(), 0);
        QCOMPARE(log.count(Alert::Level::Critical), 0);
    }

    void limitLinesAppearOnlyOnceTheLimitsAreKnownAndMatchTheConfiguration() {
        ChartPanel c;
        QVERIFY(!c.hasLimits());
        QVERIFY(c.pressureLimitLine(true).isEmpty() && c.flowLimitLine(false).isEmpty());
        c.setLimits(20.0, 100.0, "kPa", 5.0, 50.0, "L/s");
        QVERIFY(c.hasLimits());
        for (const QPointF& p : c.pressureLimitLine(false)) QCOMPARE(p.y(), 20.0);
        for (const QPointF& p : c.pressureLimitLine(true)) QCOMPARE(p.y(), 100.0);
        for (const QPointF& p : c.flowLimitLine(false)) QCOMPARE(p.y(), 5.0);
        for (const QPointF& p : c.flowLimitLine(true)) QCOMPARE(p.y(), 50.0);
        QVERIFY(c.pressureLimitLine(true).size() == 2);
    }

    void onlyCommandsWithAPredictionArePlotted() {
        ChartPanel c;
        c.setLimits(20.0, 100.0, "kPa", 5.0, 50.0, "L/s");
        c.addRecord(predicted("C-1", 55.5, 20.0, "ALLOW"));
        CommandRecord rejected;
        QString err;
        QVERIFY(CommandRecord::fromJson(rejectedResult("C-2"), &rejected, &err));
        c.addRecord(rejected);
        c.addRecord(CommandRecord::failure("C-3", "x", "00", "WORKER_FAILURE", "boom"));
        c.addRecord(predicted("C-4", 145.0, 60.0, "BLOCK"));
        QCOMPARE(c.pointCount(), 2);
        QCOMPARE(c.allowedPointCount(), 1);
        QCOMPARE(c.blockedPointCount(), 1);
        QCOMPARE(c.pressurePoints().at(0), QPointF(1, 55.5));
        QCOMPARE(c.pressurePoints().at(1), QPointF(2, 145.0));
        QCOMPARE(c.flowPoints().at(1), QPointF(2, 60.0));
    }

    void theAxisAlwaysShowsAnOutOfLimitValueBeyondItsLimitLine() {
        ChartPanel c;
        c.setLimits(20.0, 100.0, "kPa", 5.0, 50.0, "L/s");
        QVERIFY(c.pressureAxisMin() < 20.0 && c.pressureAxisMax() > 100.0);   // limits visible even with no data
        c.addRecord(predicted("C-5", 145.0, 60.0, "BLOCK"));
        QVERIFY(c.pressureAxisMax() > 145.0);
        QVERIFY(c.flowAxisMax() > 60.0);
        c.addRecord(predicted("C-6", 3.0, 1.0, "BLOCK"));
        QVERIFY(c.pressureAxisMin() < 3.0 && c.flowAxisMin() < 1.0);
    }

    void thePlotIsBoundedAndTheSequenceKeepsCounting() {
        ChartPanel c;
        c.setLimits(20.0, 100.0, "kPa", 5.0, 50.0, "L/s");
        for (int i = 1; i <= 250; ++i) c.addRecord(predicted(QString("N-%1").arg(i), 50.0, 20.0, "ALLOW"));
        QCOMPARE(c.pointCount(), ChartPanel::kMaxPoints);
        QCOMPARE(c.pressurePoints().first().x(), 51.0);
        QCOMPARE(c.pressurePoints().last().x(), 250.0);
        QCOMPARE(c.allowedPointCount(), ChartPanel::kMaxPoints);
        // the limit lines span exactly the plotted range
        QCOMPARE(c.pressureLimitLine(true).first().x(), 51.0);
        QCOMPARE(c.pressureLimitLine(true).last().x(), 250.0);
        c.clear();
        QCOMPARE(c.pointCount(), 0);
        c.addRecord(predicted("N-x", 50.0, 20.0, "ALLOW"));
        QCOMPARE(c.pressurePoints().first().x(), 1.0);
        QVERIFY(c.hasLimits());                       // clearing keeps the configured limits
    }
};

class WorkerClientTests : public QObject {
    Q_OBJECT
private:
    static bool waitFor(const std::function<bool()>& cond, int ms = 8000) {
        QElapsedTimer t;
        t.start();
        while (!cond() && t.elapsed() < ms) QTest::qWait(20);
        return cond();
    }
    static void startFake(WorkerClient& c, const QString& mode) {
        const WorkerLaunch l = fakeLaunch(mode);
        c.start(l.program, l.arguments, l.workingDirectory);
    }
private slots:
    void environmentIsConfigured() {
        for (const char* v : {"VOLTGUARD_ROOT", "VOLTGUARD_PYTHON", "VOLTGUARD_PARSER_CLI", "VOLTGUARD_FAKE_WORKER"})
            QVERIFY2(!env(v).isEmpty(), v);
        QVERIFY(QFileInfo(env("VOLTGUARD_PARSER_CLI")).isFile());
        QVERIFY(QFileInfo(env("VOLTGUARD_FAKE_WORKER")).isFile());
    }

    void sendBeforeReadyIsRefused() {
        WorkerClient c;
        QCOMPARE(c.state(), WorkerClient::State::Stopped);
        QVERIFY(!c.sendProcess("A-1", "00"));
        QCOMPARE(c.pendingCount(), 0);
    }

    void unstartableProgramFailsClosed() {
        WorkerClient c;
        c.start("/nonexistent/definitely-not-a-program", {}, QDir::tempPath());
        QVERIFY(waitFor([&] { return c.state() == WorkerClient::State::Failed; }));
        QVERIFY(!c.sendProcess("A-1", "00"));
    }

    void fatalMessageFailsTheClient() {
        WorkerClient c;
        startFake(c, "fatal");
        QVERIFY(waitFor([&] { return c.state() == WorkerClient::State::Failed; }));
        QVERIFY(c.detail().contains("fake fatal error"));
    }

    void silentWorkerTimesOutAtStart() {
        WorkerClient c;
        c.setStartTimeoutMs(300);
        startFake(c, "silent");
        QVERIFY(waitFor([&] { return c.state() == WorkerClient::State::Failed; }));
        QVERIFY(c.detail().contains("ready"));
    }

    void hangingWorkerTimesOutAndPendingFails() {
        WorkerClient c;
        c.setRequestTimeoutMs(300);
        QSignalSpy failed(&c, &WorkerClient::requestFailed);
        startFake(c, "hang");
        QVERIFY(waitFor([&] { return c.isReady(); }));
        QVERIFY(c.sendProcess("H-1", "00"));
        QVERIFY(c.sendProcess("H-2", "00"));
        QCOMPARE(c.pendingCount(), 2);
        QVERIFY(waitFor([&] { return c.state() == WorkerClient::State::Failed; }));
        QCOMPARE(failed.count(), 2);
        QCOMPARE(c.pendingCount(), 0);
        QVERIFY(!c.sendProcess("H-3", "00"));  // fail closed: nothing is sent to a failed worker
    }

    void crashingWorkerFailsPending() {
        WorkerClient c;
        QSignalSpy failed(&c, &WorkerClient::requestFailed);
        startFake(c, "crash");
        QVERIFY(waitFor([&] { return c.isReady(); }));
        QVERIFY(c.sendProcess("C-1", "00"));
        QVERIFY(waitFor([&] { return c.state() == WorkerClient::State::Failed; }));
        QCOMPARE(failed.count(), 1);
        QCOMPARE(failed.at(0).at(0).toString(), QString("C-1"));
        QVERIFY(c.detail().contains("exit"));
    }

    void duplicatePendingIdIsRefused() {
        WorkerClient c;
        c.setRequestTimeoutMs(5000);
        startFake(c, "hang");
        QVERIFY(waitFor([&] { return c.isReady(); }));
        QVERIFY(c.sendProcess("D-1", "00"));
        QVERIFY(!c.sendProcess("D-1", "00"));
        QCOMPARE(c.pendingCount(), 1);
    }

    void garbageAndUnexpectedIdAreProtocolErrors() {
        WorkerClient c;
        c.setRequestTimeoutMs(500);
        QSignalSpy proto(&c, &WorkerClient::protocolError);
        QSignalSpy results(&c, &WorkerClient::resultReceived);
        startFake(c, "garbage");
        QVERIFY(waitFor([&] { return c.isReady(); }));
        QVERIFY(c.sendProcess("G-1", "00"));
        QVERIFY(waitFor([&] { return proto.count() >= 2; }));
        QCOMPARE(results.count(), 0);       // a result for an id nobody asked for is never delivered
        QCOMPARE(c.pendingCount(), 1);      // G-1 is still unanswered ...
        QVERIFY(waitFor([&] { return c.state() == WorkerClient::State::Failed; }));  // ... so it times out
    }

    void workerErrorReplyFailsOnlyThatRequest() {
        WorkerClient c;
        QSignalSpy failed(&c, &WorkerClient::requestFailed);
        startFake(c, "error");
        QVERIFY(waitFor([&] { return c.isReady(); }));
        QVERIFY(c.sendProcess("E-1", "00"));
        QVERIFY(waitFor([&] { return failed.count() == 1; }));
        QCOMPARE(failed.at(0).at(1).toString(), QString("fake worker error"));
        QVERIFY(c.isReady());  // the worker itself is still usable
    }

    void oversizedLineFailsTheWorker() {
        WorkerClient c;
        c.setRequestTimeoutMs(20000);
        startFake(c, "oversize");
        QVERIFY(waitFor([&] { return c.isReady(); }));
        QSignalSpy failed(&c, &WorkerClient::requestFailed);
        QVERIFY(c.sendProcess("O-1", "00"));
        QVERIFY(waitFor([&] { return c.state() == WorkerClient::State::Failed; }, 15000));
        QCOMPARE(failed.count(), 1);
        QVERIFY(c.detail().contains("oversized"));
    }

    void scenariosAreDelivered() {
        WorkerClient c;
        QSignalSpy sc(&c, &WorkerClient::scenariosReceived);
        startFake(c, "twoscen");
        QVERIFY(waitFor([&] { return c.isReady(); }));
        c.requestScenarios();
        QVERIFY(waitFor([&] { return sc.count() == 1; }));
        QCOMPARE(sc.at(0).at(0).toJsonArray().size(), 2);
    }

    void stopReportsPendingAndStopsTheProcess() {
        WorkerClient c;
        QSignalSpy failed(&c, &WorkerClient::requestFailed);
        startFake(c, "hang");
        QVERIFY(waitFor([&] { return c.isReady(); }));
        QVERIFY(c.sendProcess("S-1", "00"));
        c.stop();
        QCOMPARE(c.state(), WorkerClient::State::Stopped);
        QCOMPARE(failed.count(), 1);
        QCOMPARE(c.pendingCount(), 0);
    }

    void logQueriesTimeOutAgainstAHungWorker() {
        WorkerClient c;
        c.setRequestTimeoutMs(300);
        startFake(c, "hang");
        QVERIFY(waitFor([&] { return c.isReady(); }));
        QVERIFY(c.requestEvents(10));
        QVERIFY(c.queryPending());
        QVERIFY(!c.requestLogVerification());            // one query at a time
        QVERIFY(waitFor([&] { return c.state() == WorkerClient::State::Failed; }));
        QVERIFY(!c.queryPending());
        QVERIFY(!c.requestEvents(10));                    // nothing is sent to a failed worker
    }

    void anErrorReplyToAnExportBecomesAnOkFalseExportReplyNotAFailure() {
        WorkerClient c;
        startFake(c, "logerr");
        QVERIFY(waitFor([&] { return c.isReady(); }));
        QSignalSpy spy(&c, &WorkerClient::exportFinished);
        QSignalSpy verified(&c, &WorkerClient::logVerified);
        QVERIFY(c.requestExport("csv", "/tmp/x.csv", false));
        QVERIFY(c.queryPending());
        QVERIFY(waitFor([&] { return spy.count() == 1; }));
        const QJsonObject reply = spy.at(0).at(0).toJsonObject();
        QCOMPARE(reply.value("ok").toBool(true), false);
        QCOMPARE(reply.value("error").toString(), QString("fake export refusal"));
        QCOMPARE(verified.count(), 0);                       // not mistaken for a log verification
        QVERIFY(!c.queryPending());
        QVERIFY(c.isReady());
    }

    void anExportThatIsNeverAnsweredFailsTheWorkerAfterSixTimesTheRequestTimeout() {
        WorkerClient c;
        c.setRequestTimeoutMs(100);
        startFake(c, "logok");
        QVERIFY(waitFor([&] { return c.isReady(); }));
        QElapsedTimer t;
        t.start();
        QVERIFY(c.requestExport("csv", "/tmp/x.csv", false));
        QVERIFY(!c.requestEvents(5));                        // one log request at a time
        QVERIFY(waitFor([&] { return c.state() == WorkerClient::State::Failed; }));
        QVERIFY2(t.elapsed() >= 500, qPrintable(QString::number(t.elapsed())));
    }

    void workerFailureClearsAPendingLogQuery() {
        WorkerClient c;
        startFake(c, "crash");
        QVERIFY(waitFor([&] { return c.isReady(); }));
        QVERIFY(c.requestEvents(10));                    // the fake never answers queries
        QVERIFY(c.queryPending());
        QVERIFY(c.sendProcess("Q-1", "00"));             // ... and exits on the first process request
        QVERIFY(waitFor([&] { return c.state() == WorkerClient::State::Failed; }));
        QVERIFY(!c.queryPending());
    }

    void realWorkerServesStoredEventsAndVerification() {
        QTemporaryDir logs;
        WorkerClient c;
        QSignalSpy ev(&c, &WorkerClient::eventsReceived);
        QSignalSpy ver(&c, &WorkerClient::logVerified);
        QSignalSpy res(&c, &WorkerClient::resultReceived);
        const WorkerLaunch l = realLaunch(logs.path());
        c.start(l.program, l.arguments, l.workingDirectory);
        QVERIFY(waitFor([&] { return c.isReady(); }, 30000));
        QVERIFY(c.sendProcess("L-1", "00010000000601060064003c", "my_source"));
        QVERIFY(waitFor([&] { return res.count() == 1; }));
        QVERIFY(res.at(0).at(0).toJsonObject().value("logged").toBool());
        QVERIFY(c.requestEvents(5));
        QVERIFY(waitFor([&] { return ev.count() == 1; }));
        const QJsonArray events = ev.at(0).at(0).toJsonObject().value("events").toArray();
        QCOMPARE(events.size(), 1);
        QCOMPARE(events.at(0).toObject().value("source").toString(), QString("my_source"));
        QVERIFY(c.requestLogVerification());
        QVERIFY(waitFor([&] { return ver.count() == 1; }));
        QVERIFY(ver.at(0).at(0).toBool());
    }

    void realWorkerStartsAndAnswers() {
        QTemporaryDir logs;
        WorkerClient c;
        QSignalSpy ready(&c, &WorkerClient::ready);
        QSignalSpy res(&c, &WorkerClient::resultReceived);
        const WorkerLaunch l = realLaunch(logs.path());
        c.start(l.program, l.arguments, l.workingDirectory);
        QVERIFY(waitFor([&] { return c.isReady(); }, 30000));
        QCOMPARE(ready.count(), 1);
        const QJsonObject info = ready.at(0).at(0).toJsonObject();
        QVERIFY(info.value("parser_available").toBool());
        QVERIFY(info.value("decision_engine").toObject().value("available").toBool());
        QVERIFY(c.sendProcess("R-1", "00010000000601060064003c"));
        QVERIFY(waitFor([&] { return res.count() == 1; }));
        CommandRecord r;
        QString err;
        QVERIFY2(CommandRecord::fromJson(res.at(0).at(0).toJsonObject(), &r, &err), qPrintable(err));
        QCOMPARE(r.commandId, QString("R-1"));
        QCOMPARE(r.severity(), CommandRecord::Severity::Ok);
    }
};

// ============================================================================ MainWindow with the real worker

class MainWindowTests : public QObject {
    Q_OBJECT
private:
    QTemporaryDir m_logs;
    static bool waitFor(const std::function<bool()>& cond, int ms = 20000) {
        QElapsedTimer t;
        t.start();
        while (!cond() && t.elapsed() < ms) QTest::qWait(20);
        return cond();
    }
    bool startReal(MainWindow& w) {
        w.startWorker(realLaunch(m_logs.path()));
        return waitFor([&] { return w.worker()->isReady() && w.scenarioCount() > 0; }, 30000);
    }
    static QPushButton* button(MainWindow& w, const char* name) { return w.findChild<QPushButton*>(name); }
    static QLabel* label(MainWindow& w, const char* name) { return w.findChild<QLabel*>(name); }

private slots:
    void initTestCase() { QVERIFY(m_logs.isValid()); }

    void controlsAreDisabledUntilTheWorkerIsReady() {
        MainWindow w;
        QVERIFY(!button(w, "runAllButton")->isEnabled());
        QVERIFY(!button(w, "sendHexButton")->isEnabled());
        QVERIFY(!w.findChild<QLineEdit*>("hexInput")->isEnabled());
        QVERIFY(!w.submitFrame("manual", "00"));  // refused, and visibly so
        QVERIFY(label(w, "inputMessageLabel")->text().contains("not ready"));
        QCOMPARE(w.model()->rowCount(), 0);
    }

    void bannerAndStatusStateTheLimitations() {
        MainWindow w;
        const QString banner = label(w, "bannerLabel")->text();
        QVERIFY(banner.contains("SIMULAT"));
        QVERIFY(banner.contains("nothing is forwarded to any device"));
        QVERIFY(label(w, "statusBarLabel")->text().contains("Decision engine:"));
    }

    void runAllScenariosClassifiesEveryResult() {
        MainWindow w;
        QVERIFY(startReal(w));
        QCOMPARE(w.scenarioCount(), 27);
        QTest::mouseClick(button(w, "runAllButton"), Qt::LeftButton);
        QVERIFY2(waitFor([&] { return w.model()->counts().total == 27; }), "not all 27 scenarios were answered");

        const Counts c = w.model()->counts();
        // Expected values come from the scenario definitions (intent labels), not from the application output.
        QCOMPARE(c.withinLimits, 6);   // 3 normal + boundary + read-only + write-multiple
        QCOMPARE(c.violations, 5);     // 5 UNSAFE scenarios
        QCOMPARE(c.rejected, 16);      // 2 invalid-value + 2 unsupported + 12 malformed
        QCOMPARE(c.failures, 0);
        QCOMPARE(w.worker()->pendingCount(), 0);

        auto sev = [&](const QString& src) { return w.model()->recordAt(rowForSource(w.model(), src)).severity(); };
        QCOMPARE(sev("normal_pump_60"), CommandRecord::Severity::Ok);
        QCOMPARE(sev("unsafe_pump_100"), CommandRecord::Severity::Violation);
        QCOMPARE(sev("unsafe_valve_closed"), CommandRecord::Severity::Violation);
        QCOMPARE(sev("out_of_range_pump_250"), CommandRecord::Severity::Rejected);
        QCOMPARE(sev("unsupported_fc05_write_coil"), CommandRecord::Severity::Rejected);
        QCOMPARE(sev("malformed_truncated_pdu"), CommandRecord::Severity::Rejected);

        QCOMPARE(label(w, "countTotal")->text(), QString("27"));
        QCOMPARE(label(w, "countViolation")->text(), QString("5"));
        QCOMPARE(label(w, "countRejected")->text(), QString("16"));
        QCOMPARE(c.allowed, 6);
        QCOMPARE(c.blocked, 5);
        QCOMPARE(c.rejectedDecisions, 16);
        QCOMPARE(label(w, "countAllowed")->text(), QString("6"));
        QCOMPARE(label(w, "countBlocked")->text(), QString("5"));
        QCOMPARE(label(w, "countRejectDecision")->text(), QString("16"));
        QVERIFY(label(w, "latestDecisionLabel")->text().startsWith("DECISION: REJECT"));
        QVERIFY(label(w, "latestStatusLabel")->text() != "No commands processed yet");
    }

    void everyCommandShowsTheDecisionItsDesignIntends() {
        MainWindow w;
        QVERIFY(startReal(w));
        QTest::mouseClick(button(w, "runAllButton"), Qt::LeftButton);
        QVERIFY(waitFor([&] { return w.model()->counts().total == 27; }));
        for (int r = 0; r < w.model()->rowCount(); ++r) {
            const CommandRecord& rec = w.model()->recordAt(r);
            // Expectation from the scenario names (the designed intent), not from the application's output.
            const bool allowed = rec.source.startsWith("normal_") || rec.source.startsWith("boundary_") ||
                                 rec.source == "read_pump_registers" || rec.source == "write_multiple_pump_valve";
            const QString want = allowed ? "ALLOW" : rec.source.startsWith("unsafe_") ? "BLOCK" : "REJECT";
            QCOMPARE(w.model()->data(w.model()->index(r, TrafficModel::ColDecision)).toString(), want);
            QVERIFY2(rec.decisionSource == "engine" && rec.decisionErrorCode.isEmpty(), qPrintable(rec.source));
            QVERIFY(!rec.decisionReason.isEmpty());
            if (rec.decision == "ALLOW") QCOMPARE(rec.severity(), CommandRecord::Severity::Ok);        // never ALLOW a failed/rejected result
        }
        QVERIFY(w.findChild<QPlainTextEdit*>("eventLog")->toPlainText().contains("UI-0001"));
        QVERIFY(w.findChild<QPlainTextEdit*>("eventLog")->toPlainText().contains("-> BLOCK (engine)"));
        QVERIFY(label(w, "appStatusLabel")->text().contains("voltguard_decision_engine"));
    }

    void graphsAndAlertsFollowTheRealScenarioResults() {
        MainWindow w;
        QVERIFY(startReal(w));
        // the plotted limits come from the worker's configuration message
        QVERIFY(w.charts()->hasLimits());
        QCOMPARE(w.charts()->pressureLimitLine(false).first().y(), 20.0);
        QCOMPARE(w.charts()->pressureLimitLine(true).first().y(), 100.0);
        QCOMPARE(w.charts()->flowLimitLine(true).first().y(), 50.0);
        QCOMPARE(label(w, "alertSummaryLabel")->text(), QString("Alerts: 0 critical, 0 warning"));
        QTest::mouseClick(button(w, "runAllButton"), Qt::LeftButton);
        QVERIFY(waitFor([&] { return w.model()->counts().total == 27; }));
        // designed outcome: 6 ALLOW + 5 BLOCK have a prediction; the 16 REJECTs have none
        QCOMPARE(w.charts()->pointCount(), 11);
        QCOMPARE(w.charts()->allowedPointCount(), 6);
        QCOMPARE(w.charts()->blockedPointCount(), 5);
        for (const QPointF& p : w.charts()->pressurePoints()) QVERIFY(p.y() >= w.charts()->pressureAxisMin() && p.y() <= w.charts()->pressureAxisMax());
        QCOMPARE(w.alerts()->count(Alert::Level::Critical), 5);      // the five BLOCKs
        QCOMPARE(w.alerts()->count(Alert::Level::Warning), 16);      // the sixteen REJECTs
        QCOMPARE(label(w, "alertSummaryLabel")->text(), QString("Alerts: 5 critical, 16 warning"));
        QCOMPARE(label(w, "alertSummaryDashLabel")->text(), QString("Alerts: 5 critical, 16 warning"));
        auto* list = w.findChild<QListWidget*>("alertList");
        QCOMPARE(list->count(), 21);
        QVERIFY(list->item(0)->text().contains("CRITICAL") || list->item(0)->text().contains("WARNING"));
        // Clear empties the table, the graphs and the alerts (and nothing else)
        QTest::mouseClick(button(w, "clearButton"), Qt::LeftButton);
        QCOMPARE(w.charts()->pointCount(), 0);
        QCOMPARE(w.alerts()->size(), 0);
        QCOMPARE(list->count(), 0);
        QVERIFY(w.charts()->hasLimits());
    }

    void withoutADecisionEngineTheSystemRaisesAlertsAndNothingIsPlottedAsAllowed() {
        MainWindow w;
        w.startWorker(realLaunch(m_logs.path(), {"--decision-engine", "/nonexistent/voltguard_decision_engine"}));
        QVERIFY(waitFor([&] { return w.worker()->isReady() && w.scenarioCount() > 0; }, 30000));
        QVERIFY(hasAlert(w.alerts(), "DECISION_ENGINE_UNAVAILABLE", Alert::Level::Critical));   // raised before any command
        QTest::mouseClick(button(w, "runAllButton"), Qt::LeftButton);
        QVERIFY(waitFor([&] { return w.model()->counts().total == 27; }));
        QCOMPARE(w.charts()->allowedPointCount(), 0);
        QCOMPARE(w.charts()->blockedPointCount(), 0);
        QCOMPARE(w.charts()->pointCount(), 11);                      // predictions still plotted, but as REJECT
        QCOMPARE(w.alerts()->count(Alert::Level::Critical), 28);     // 1 system alert + 27 fail-closed rejects
        QVERIFY(label(w, "alertSummaryLabel")->text().startsWith("Alerts: 28 critical"));
    }

    void withoutADecisionEngineEveryCommandIsRejected() {
        MainWindow w;
        w.startWorker(realLaunch(m_logs.path(), {"--decision-engine", "/nonexistent/voltguard_decision_engine"}));
        QVERIFY(waitFor([&] { return w.worker()->isReady() && w.scenarioCount() > 0; }, 30000));
        QVERIFY(label(w, "appStatusLabel")->text().contains("NOT AVAILABLE"));
        QVERIFY(label(w, "statusBarLabel")->text().contains("NOT AVAILABLE (all REJECT)"));
        QVERIFY(w.findChild<QPlainTextEdit*>("eventLog")->toPlainText().contains("Decision engine: NOT AVAILABLE"));
        QTest::mouseClick(button(w, "runAllButton"), Qt::LeftButton);
        QVERIFY(waitFor([&] { return w.model()->counts().total == 27; }));
        QCOMPARE(w.model()->counts().allowed, 0);
        QCOMPARE(w.model()->counts().blocked, 0);
        QCOMPARE(w.model()->counts().rejectedDecisions, 27);
        for (int r = 0; r < 27; ++r) {
            QCOMPARE(w.model()->recordAt(r).decisionSource, QString("fail_closed"));
            QCOMPARE(w.model()->recordAt(r).decisionErrorCode, QString("DECISION_ENGINE_UNAVAILABLE"));
        }
    }

    void aHungDecisionEngineNeverProducesAnAllow() {
        QTemporaryDir dir;
        const QString py = env("VOLTGUARD_PYTHON"), fake = env("VOLTGUARD_FAKE_ENGINE");
        QVERIFY(!fake.isEmpty());
#ifdef Q_OS_WIN
        QFile wrapper(dir.filePath("fake_engine.cmd"));
        const QByteArray body = QString("@\"%1\" \"%2\" %*\r\n").arg(py, fake).toLocal8Bit();
#else
        QFile wrapper(dir.filePath("fake_engine.sh"));
        const QByteArray body = QString("#!/bin/sh\nexec \"%1\" \"%2\" \"$@\"\n").arg(py, fake).toLocal8Bit();
#endif
        QVERIFY(wrapper.open(QIODevice::WriteOnly));
        wrapper.write(body);
        wrapper.close();
        wrapper.setPermissions(QFile::ReadOwner | QFile::WriteOwner | QFile::ExeOwner);
        qputenv("VOLTGUARD_FAKE_ENGINE_MODE", "hang");
        MainWindow w;
        w.startWorker(realLaunch(m_logs.path(), {"--decision-engine", wrapper.fileName()}));
        QVERIFY(waitFor([&] { return w.worker()->isReady() && w.scenarioCount() > 0; }, 30000));
        QTest::mouseClick(button(w, "runAllButton"), Qt::LeftButton);
        const bool done = waitFor([&] { return w.model()->counts().total == 27; }, 60000);
        qunsetenv("VOLTGUARD_FAKE_ENGINE_MODE");
        QVERIFY(done);
        QCOMPARE(w.model()->counts().allowed, 0);
        QCOMPARE(w.model()->counts().blocked, 0);
        for (int r = 0; r < 27; ++r) {
            QCOMPARE(w.model()->recordAt(r).decision, QString("REJECT"));
            QCOMPARE(w.model()->recordAt(r).decisionErrorCode, QString("DECISION_TIMEOUT"));
        }
    }

    void invalidHexIsRefusedBeforeSending_data() {
        QTest::addColumn<QString>("text");
        QTest::newRow("odd_length") << "abc";
        QTest::newRow("non_hex") << "zz00";
        QTest::newRow("hex_prefix") << "0x0001";
        QTest::newRow("shell_metacharacters") << "00; rm -rf /";
        QTest::newRow("too_long") << QString(4002, 'a');
    }
    void invalidHexIsRefusedBeforeSending() {
        QFETCH(QString, text);
        MainWindow w;
        QVERIFY(startReal(w));
        QVERIFY(!w.submitFrame("manual", text));
        QCOMPARE(w.model()->rowCount(), 0);
        QCOMPARE(w.worker()->pendingCount(), 0);
        QVERIFY(!label(w, "inputMessageLabel")->text().isEmpty());
    }

    void manualFrameWithWhitespaceIsAccepted() {
        MainWindow w;
        QVERIFY(startReal(w));
        auto* input = w.findChild<QLineEdit*>("hexInput");
        input->setText("00 01 00 00 00 06 01 06 00 64 00 3c");
        QTest::mouseClick(button(w, "sendHexButton"), Qt::LeftButton);
        QVERIFY(waitFor([&] { return w.model()->counts().total == 1; }));
        QCOMPARE(w.model()->recordAt(0).source, QString("manual"));
        QCOMPARE(w.model()->recordAt(0).severity(), CommandRecord::Severity::Ok);
        QVERIFY(input->text().isEmpty());  // cleared after a successful send
    }

    void clearEmptiesTableAndCounters() {
        MainWindow w;
        QVERIFY(startReal(w));
        QVERIFY(w.submitFrame("manual", "00010000000601060064003c"));
        QVERIFY(waitFor([&] { return w.model()->counts().total == 1; }));
        QTest::mouseClick(button(w, "clearButton"), Qt::LeftButton);
        QCOMPARE(w.model()->rowCount(), 0);
        QCOMPARE(label(w, "countTotal")->text(), QString("0"));
        QCOMPARE(label(w, "latestStatusLabel")->text(), QString("No commands processed yet"));
    }

    void selectingARowShowsItsDetails() {
        MainWindow w;
        QVERIFY(startReal(w));
        QVERIFY(w.submitFrame("manual", "000700000006010600640064"));  // pump 100 %: violation
        QVERIFY(waitFor([&] { return w.model()->counts().total == 1; }));
        auto* table = w.findChild<QTableView*>("trafficTable");
        table->setCurrentIndex(w.model()->index(0, 0));
        const QString details = w.findChild<QPlainTextEdit*>("detailsView")->toPlainText();
        QVERIFY(details.contains("LIMIT VIOLATION (simulated)"));
        QVERIFY(details.contains("SIMULATED"));
        QVERIFY(details.contains("Predicted pressure"));
        QVERIFY(details.contains("BLOCK (engine)"));
    }

    void screenshotsAreWrittenForEveryTab() {
        MainWindow w;
        QVERIFY(startReal(w));
        QTest::mouseClick(button(w, "runAllButton"), Qt::LeftButton);
        QVERIFY(waitFor([&] { return w.model()->counts().total == 27; }));
        QTemporaryDir out;
        QCOMPARE(w.captureScreenshots(out.path()), 5);
        const QStringList files = QDir(out.path()).entryList({"*.png"});
        QCOMPARE(files.size(), 5);
        for (const QString& f : files) {
            QImage img(QDir(out.path()).filePath(f));
            QVERIFY2(!img.isNull() && img.width() > 400 && img.height() > 300, qPrintable(f));
        }
    }

    void storedEventsCanBeLoadedAndVerified() {
        MainWindow w;
        QVERIFY(startReal(w));
        QVERIFY(w.submitFrame("normal_pump_60", "00010000000601060064003c"));
        QVERIFY(w.submitFrame("unsafe_pump_100", "000700000006010600640064"));
        QVERIFY(w.submitFrame("malformed_x", "0001"));
        QVERIFY(waitFor([&] { return w.model()->counts().total == 3; }));
        for (int r = 0; r < 3; ++r) QCOMPARE(w.model()->recordAt(r).logged, 1);
        QVERIFY(w.findChild<QLabel*>("appStatusLabel")->text().contains("recording"));

        auto* table = w.findChild<QTableWidget*>("storedEventsTable");
        QCOMPARE(table->rowCount(), 0);                       // nothing is loaded until asked for
        QTest::mouseClick(button(w, "loadEventsButton"), Qt::LeftButton);
        QVERIFY(waitFor([&] { return table->rowCount() == 3; }));
        QCOMPARE(table->item(0, 3)->text(), QString("malformed_x"));       // newest first
        QCOMPARE(table->item(0, 5)->text(), QString("REJECTED"));
        QCOMPARE(table->item(1, 3)->text(), QString("unsafe_pump_100"));
        QCOMPARE(table->item(1, 5)->text(), QString("LIMIT_VIOLATION"));
        QCOMPARE(table->item(2, 5)->text(), QString("WITHIN_LIMITS"));

        QTest::mouseClick(button(w, "clearButton"), Qt::LeftButton);        // Clear does not touch the stored log
        QCOMPARE(w.model()->rowCount(), 0);
        QTest::mouseClick(button(w, "verifyLogButton"), Qt::LeftButton);
        QVERIFY(waitFor([&] { return label(w, "logStatusLabel")->text().contains("passed"); }));
        QTest::mouseClick(button(w, "loadEventsButton"), Qt::LeftButton);
        QVERIFY(waitFor([&] { return label(w, "logStatusLabel")->text().contains("3 of 3"); }));
    }

    // Starts the real worker with its own event database, processes three commands (ALLOW, BLOCK, parser REJECT).
    void startWithThreeLoggedCommands(MainWindow& w, const QString& db) {
        w.startWorker(realLaunch(m_logs.path(), {"--event-db", db}));
        QVERIFY(waitFor([&] { return w.worker()->isReady() && w.scenarioCount() > 0; }, 30000));
        QVERIFY(w.submitFrame("a", "00010000000601060064003c"));
        QVERIFY(w.submitFrame("b", "000700000006010600640064"));
        QVERIFY(w.submitFrame("c", "0001"));
        QVERIFY(waitFor([&] { return w.model()->counts().total == 3; }));
    }

    static bool statusStarts(MainWindow& w, const QString& prefix) { return label(w, "exportStatusLabel")->text().startsWith(prefix); }

    void exportsTheStoredLogAsCsvJsonAndPdfAndNeverOverwritesByDefault() {
        QTemporaryDir out, dbDir;
        MainWindow w;
        startWithThreeLoggedCommands(w, dbDir.filePath("e.db"));
        QVERIFY(button(w, "exportCsvButton")->isEnabled());

        const QString csv = out.filePath("events.csv");
        QVERIFY(w.exportEvents("csv", csv));
        QVERIFY(!button(w, "exportCsvButton")->isEnabled());                       // one log request at a time
        QVERIFY(waitFor([&] { return !statusStarts(w, "Exporting"); }));
        QVERIFY2(statusStarts(w, "Exported 3 of 3 event(s)"), qPrintable(label(w, "exportStatusLabel")->text()));
        QVERIFY(label(w, "exportStatusLabel")->text().contains("Integrity check passed"));
        QVERIFY(button(w, "exportCsvButton")->isEnabled());
        QFile f(csv);
        QVERIFY(f.open(QIODevice::ReadOnly));
        const QString csvText = QString::fromUtf8(f.readAll());
        f.close();
        QCOMPARE(csvText.split('\n', Qt::SkipEmptyParts).size(), 4);                // header + 3 rows
        QVERIFY(csvText.contains("BLOCK") && csvText.contains("ALLOW") && csvText.contains("REJECT"));

        // the same name again, without permission to overwrite: refused, file unchanged
        QVERIFY(w.exportEvents("csv", csv));
        QVERIFY(waitFor([&] { return !statusStarts(w, "Exporting"); }));
        QVERIFY(statusStarts(w, "Export FAILED"));
        QVERIFY(label(w, "exportStatusLabel")->text().contains("already exists"));
        QVERIFY(f.open(QIODevice::ReadOnly));
        QCOMPARE(QString::fromUtf8(f.readAll()), csvText);
        f.close();
        QVERIFY(hasAlert(w.alerts(), "EXPORT_FAILED", Alert::Level::Warning));

        // ... and with permission it is replaced
        QVERIFY(w.exportEvents("csv", csv, true));
        QVERIFY(waitFor([&] { return !statusStarts(w, "Exporting"); }));
        QVERIFY(statusStarts(w, "Exported 3 of 3"));

        const QString json = out.filePath("events.json");
        QVERIFY(w.exportEvents("json", json));
        QVERIFY(waitFor([&] { return !statusStarts(w, "Exporting"); }));
        QVERIFY(statusStarts(w, "Exported 3 of 3"));
        f.setFileName(json);
        QVERIFY(f.open(QIODevice::ReadOnly));
        const QJsonObject doc = QJsonDocument::fromJson(f.readAll()).object();
        f.close();
        QCOMPARE(doc.value("rows_exported").toInt(), 3);
        QVERIFY(doc.value("integrity").toObject().value("verified").toBool());
        QVERIFY(doc.value("notice").toString().contains("SIMULATED"));

        const QString pdf = out.filePath("events.pdf");
        QVERIFY(w.exportEvents("pdf", pdf));
        QVERIFY(waitFor([&] { return !statusStarts(w, "Exporting"); }, 40000));
        if (label(w, "exportStatusLabel")->text().contains("reportlab")) QSKIP("reportlab is not installed: the optional PDF export was NOT tested");
        QVERIFY2(statusStarts(w, "Exported 3 of 3"), qPrintable(label(w, "exportStatusLabel")->text()));
        f.setFileName(pdf);
        QVERIFY(f.open(QIODevice::ReadOnly));
        QVERIFY(f.read(4) == "%PDF");
    }

    void badExportRequestsAreRefusedBeforeAnythingIsSent() {
        QTemporaryDir out, dbDir;
        MainWindow w;
        startWithThreeLoggedCommands(w, dbDir.filePath("e.db"));
        QVERIFY(!w.exportEvents("exe", out.filePath("x.exe")));
        QVERIFY(label(w, "exportStatusLabel")->text().contains("Unknown export format"));
        QVERIFY(!w.exportEvents("csv", "   "));
        QVERIFY(label(w, "exportStatusLabel")->text().contains("Choose a file name"));
        QVERIFY(!w.exportEvents("csv", QString(5000, 'a')));
        QVERIFY(!w.worker()->queryPending());
        // an extension that does not match the format is refused by the worker, and nothing is written
        QVERIFY(w.exportEvents("csv", out.filePath("events.txt")));
        QVERIFY(waitFor([&] { return !statusStarts(w, "Exporting"); }));
        QVERIFY(statusStarts(w, "Export FAILED") && label(w, "exportStatusLabel")->text().contains("must end in"));
        QVERIFY(QDir(out.path()).entryList(QDir::Files).isEmpty());
        // a folder that does not exist
        QVERIFY(w.exportEvents("csv", out.filePath("nodir/events.csv")));
        QVERIFY(waitFor([&] { return !statusStarts(w, "Exporting"); }));
        QVERIFY(statusStarts(w, "Export FAILED") && label(w, "exportStatusLabel")->text().contains("does not exist"));
    }

    void withoutAnEventLogThereIsNothingToExport() {
        MainWindow w;
        w.startWorker(realLaunch(m_logs.path(), {"--no-event-log"}));
        QVERIFY(waitFor([&] { return w.worker()->isReady() && w.scenarioCount() > 0; }, 30000));
        QVERIFY(!button(w, "exportCsvButton")->isEnabled() && !button(w, "exportJsonButton")->isEnabled() && !button(w, "exportPdfButton")->isEnabled());
        QVERIFY(!w.exportEvents("csv", QDir::temp().filePath("never_written.csv")));
        QVERIFY(label(w, "exportStatusLabel")->text().contains("not available"));
        QVERIFY(!QFileInfo::exists(QDir::temp().filePath("never_written.csv")));
    }

    void anExportOfATamperedLogIsLabelledAndRaisesACriticalAlert() {
        QTemporaryDir out, dbDir;
        const QString db = dbDir.filePath("tamper.db");
        MainWindow w;
        startWithThreeLoggedCommands(w, db);
        QProcess edit;
        edit.start(env("VOLTGUARD_PYTHON"), {"-c", "import sqlite3,sys; d=sqlite3.connect(sys.argv[1]); "
                                                   "d.execute(\"UPDATE events SET severity='WITHIN_LIMITS' WHERE id=2\"); d.commit()", db});
        QVERIFY(edit.waitForFinished(15000));
        QCOMPARE(edit.exitCode(), 0);
        QVERIFY(w.exportEvents("json", out.filePath("t.json")));
        QVERIFY(waitFor([&] { return !statusStarts(w, "Exporting"); }));
        const QString text = label(w, "exportStatusLabel")->text();
        QVERIFY2(text.startsWith("Exported 3 of 3") && text.contains("INTEGRITY CHECK FAILED") && text.contains("row 2"), qPrintable(text));
        QVERIFY(!text.contains("passed"));
        QVERIFY(hasAlert(w.alerts(), "LOG_INTEGRITY_FAILED", Alert::Level::Critical));
        QVERIFY(QFileInfo::exists(out.filePath("t.json")));             // the evidence is still exported, labelled
    }

    void aWorkerThatNeverAnswersAnExportEndsInAVisibleFailure() {
        MainWindow w;
        w.startWorker(fakeLaunch("logok"));
        QVERIFY(waitFor([&] { return w.worker()->isReady() && w.scenarioCount() > 0; }));
        w.worker()->setRequestTimeoutMs(100);                            // exports get six times this
        QVERIFY(w.exportEvents("csv", QDir::temp().filePath("hung_export.csv")));
        QVERIFY(statusStarts(w, "Exporting"));
        QVERIFY(waitFor([&] { return w.worker()->state() == WorkerClient::State::Failed; }));
        QVERIFY(statusStarts(w, "Export FAILED"));
        QVERIFY(label(w, "exportStatusLabel")->text().contains("worker stopped"));
        QVERIFY(!QFileInfo::exists(QDir::temp().filePath("hung_export.csv")));
    }

    void aTamperedLogFailsVerificationVisibly() {
        QTemporaryDir dir;
        const QString db = dir.filePath("tamper.db");
        MainWindow w;
        w.startWorker(realLaunch(m_logs.path(), {"--event-db", db}));          // the later --event-db wins
        QVERIFY(waitFor([&] { return w.worker()->isReady() && w.scenarioCount() > 0; }, 30000));
        QVERIFY(w.submitFrame("a", "00010000000601060064003c"));
        QVERIFY(w.submitFrame("b", "000700000006010600640064"));
        QVERIFY(waitFor([&] { return w.model()->counts().total == 2; }));

        QProcess edit;      // modify a stored row behind the application's back
        edit.start(env("VOLTGUARD_PYTHON"), {"-c", "import sqlite3,sys; d=sqlite3.connect(sys.argv[1]); "
                                                   "d.execute(\"UPDATE events SET severity='WITHIN_LIMITS' WHERE id=2\"); d.commit()", db});
        QVERIFY(edit.waitForFinished(15000));
        QCOMPARE(edit.exitCode(), 0);

        QTest::mouseClick(button(w, "verifyLogButton"), Qt::LeftButton);
        QVERIFY(waitFor([&] { return label(w, "logStatusLabel")->text().contains("FAILED"); }));
        QVERIFY(label(w, "logStatusLabel")->text().contains("row 2"));
        QVERIFY(!label(w, "logStatusLabel")->text().contains("passed"));
        QVERIFY(w.findChild<QPlainTextEdit*>("eventLog")->toPlainText().contains("ERROR"));
    }

    void unusableEventLogIsReportedNotHidden() {
        QTemporaryDir dir;
        QFile blocker(dir.filePath("file"));
        QVERIFY(blocker.open(QIODevice::WriteOnly));
        blocker.close();
        MainWindow w;
        WorkerLaunch l = realLaunch(m_logs.path(), {"--event-db", dir.filePath("file/events.db")});   // later --event-db wins
        w.startWorker(l);
        QVERIFY(waitFor([&] { return w.worker()->isReady() && w.scenarioCount() > 0; }, 30000));
        QVERIFY(label(w, "appStatusLabel")->text().contains("NOT AVAILABLE"));
        QVERIFY(!button(w, "loadEventsButton")->isEnabled());
        QVERIFY(!button(w, "verifyLogButton")->isEnabled());
        QVERIFY(w.submitFrame("manual", "00010000000601060064003c"));
        QVERIFY(waitFor([&] { return w.model()->counts().total == 1; }));
        QCOMPARE(w.model()->recordAt(0).logged, 0);                        // processed, but visibly not stored
        QCOMPARE(w.model()->recordAt(0).severity(), CommandRecord::Severity::Ok);          // the simulation itself was fine ...
        QCOMPARE(w.model()->recordAt(0).decision, QString("REJECT"));                      // ... but "no audit trail, no allow"
        QCOMPARE(w.model()->recordAt(0).decisionErrorCode, QString("EVENT_LOG_UNAVAILABLE"));
        const QString log = w.findChild<QPlainTextEdit*>("eventLog")->toPlainText();
        QVERIFY(log.contains("NOT STORED"));
        QVERIFY(log.contains("Event log: NOT AVAILABLE"));
    }

    void configurationTabShowsTheConfiguredLimits() {
        MainWindow w;
        QVERIFY(startReal(w));
        auto* table = w.findChild<QTableWidget*>("configTable");
        QCOMPARE(table->rowCount(), 4);
        QCOMPARE(table->item(0, 0)->text(), QString("pressure"));
        QCOMPARE(table->item(0, 1)->text(), QString("20"));
        QCOMPARE(table->item(0, 2)->text(), QString("100"));
        QCOMPARE(table->item(0, 3)->text(), QString("kPa"));
        QVERIFY(label(w, "configInfoLabel")->text().contains("safety_limits.json"));
    }

    // ---- failure handling with injected faulty workers
    void workerErrorRepliesAreShownAsFailuresAndRestartRecovers() {
        MainWindow w;
        w.startWorker(fakeLaunch("twoscen"));
        QVERIFY(waitFor([&] { return w.worker()->isReady() && w.scenarioCount() == 2; }));
        w.worker()->setRequestTimeoutMs(300);
        QTest::mouseClick(button(w, "runAllButton"), Qt::LeftButton);
        QVERIFY(waitFor([&] { return w.model()->counts().total == 2; }));
        QCOMPARE(w.model()->counts().failures, 2);
        QCOMPARE(w.model()->counts().withinLimits, 0);
        QCOMPARE(w.model()->recordAt(0).errorCode, QString("WORKER_FAILURE"));
        QCOMPARE(w.model()->recordAt(0).safetyStatus(), QString("COMPONENT FAILURE"));
        QCOMPARE(w.model()->recordAt(0).source, QString("fake_one"));

        // Restart re-launches the same (fake) worker; swap to the real one to prove recovery.
        w.startWorker(realLaunch(m_logs.path()));
        QVERIFY(waitFor([&] { return w.worker()->isReady() && w.scenarioCount() == 27; }, 30000));
        QVERIFY(w.submitFrame("after_restart", "00010000000601060064003c"));
        QVERIFY(waitFor([&] { return w.model()->counts().total == 3; }));
        QCOMPARE(w.model()->recordAt(2).severity(), CommandRecord::Severity::Ok);
    }

    void crashedWorkerDisablesControlsAndShowsFailure() {
        MainWindow w;
        w.startWorker(fakeLaunch("crash"));
        QVERIFY(waitFor([&] { return w.worker()->isReady(); }));
        QVERIFY(w.submitFrame("manual", "00"));
        QVERIFY(waitFor([&] { return w.worker()->state() == WorkerClient::State::Failed; }));
        QVERIFY(waitFor([&] { return w.model()->counts().total == 1; }));
        QCOMPARE(w.model()->counts().failures, 1);
        QCOMPARE(w.model()->recordAt(0).decision, QString("REJECT"));              // no result from the worker is never an allow
        QCOMPARE(w.model()->counts().allowed, 0);
        QVERIFY(hasAlert(w.alerts(), "WORKER_FAILED", Alert::Level::Critical));
        QVERIFY(hasAlert(w.alerts(), "WORKER_FAILURE", Alert::Level::Critical));
        QVERIFY(!button(w, "sendHexButton")->isEnabled());
        QVERIFY(!w.submitFrame("manual", "00"));
        QVERIFY(label(w, "statusBarLabel")->text().contains("Failed"));
    }

    void invalidWorkerReplyIsAFailureNotAResult() {
        MainWindow w;
        w.startWorker(fakeLaunch("badresult"));
        QVERIFY(waitFor([&] { return w.worker()->isReady(); }));
        QVERIFY(w.submitFrame("manual", "00"));
        QVERIFY(waitFor([&] { return w.model()->counts().total == 1; }));
        QCOMPARE(w.model()->counts().failures, 1);
        QCOMPARE(w.model()->counts().withinLimits, 0);
        QCOMPARE(w.model()->recordAt(0).errorCode, QString("INVALID_WORKER_REPLY"));
    }

    // Responsiveness: while a request is in flight (the worker never answers), the GUI event loop must keep
    // running. A 10 ms ticker measures the longest gap between ticks; a blocked GUI thread would show a long gap.
    void eventLoopStaysResponsiveWhileAWorkerRequestIsPending() {
        MainWindow w;
        w.startWorker(fakeLaunch("hang"));
        QVERIFY(waitFor([&] { return w.worker()->isReady(); }));
        w.worker()->setRequestTimeoutMs(800);
        QElapsedTimer sinceLast;
        sinceLast.start();
        qint64 maxGapMs = 0;
        int ticks = 0;
        QTimer ticker;
        ticker.setInterval(10);
        connect(&ticker, &QTimer::timeout, &w, [&] {
            maxGapMs = qMax(maxGapMs, sinceLast.elapsed());
            sinceLast.restart();
            ++ticks;
        });
        ticker.start();
        QVERIFY(w.submitFrame("manual", "00"));
        QCOMPARE(w.worker()->pendingCount(), 1);
        QVERIFY(waitFor([&] { return w.model()->counts().total == 1; }));  // ends by the 800 ms watchdog
        ticker.stop();
        QVERIFY2(ticks >= 30, qPrintable(QString("only %1 ticks in ~800 ms").arg(ticks)));
        QVERIFY2(maxGapMs < 400, qPrintable(QString("event loop stalled for %1 ms").arg(maxGapMs)));
        QCOMPARE(w.model()->counts().failures, 1);
    }

    void missingWorkerProgramShowsFailedState() {
        MainWindow w;
        WorkerLaunch l;
        l.program = "/nonexistent/python";
        l.workingDirectory = QDir::tempPath();
        w.startWorker(l);
        QVERIFY(waitFor([&] { return w.worker()->state() == WorkerClient::State::Failed; }));
        QVERIFY(label(w, "appStatusLabel")->text().contains("Failed"));
        QVERIFY(!button(w, "runAllButton")->isEnabled());
        QVERIFY(button(w, "restartButton")->isEnabled());
    }
};

// ============================================================================ runner

// VOLTGUARD_TEST_CLASSES (comma separated class names) restricts the run, e.g. for quick mutation checks.
// The report generator and ctest never set it, so the full suite is what they run.
int main(int argc, char** argv) {
    QApplication app(argc, argv);
    const QStringList only = qEnvironmentVariable("VOLTGUARD_TEST_CLASSES").split(',', Qt::SkipEmptyParts);
    auto wanted = [&](const char* name) { return only.isEmpty() || only.contains(QLatin1String(name)); };
    int status = 0;
    if (wanted("RecordModelTests")) { RecordModelTests t; status |= QTest::qExec(&t, argc, argv); }
    if (wanted("ChartAlertTests")) { ChartAlertTests t; status |= QTest::qExec(&t, argc, argv); }
    if (wanted("WorkerClientTests")) { WorkerClientTests t; status |= QTest::qExec(&t, argc, argv); }
    if (wanted("MainWindowTests")) { MainWindowTests t; status |= QTest::qExec(&t, argc, argv); }
    return status;
}

#include "dashboard_tests.moc"
