"""Persistent, structured event log (Phase 9): one SQLite row per processed command.

Design rules
  * Every value reaches SQLite through bound parameters; nothing is ever concatenated into SQL.
  * Text coming from packets or components is length-capped and stored as data only.
  * Rows are chained: row_hash = SHA-256(previous row_hash + canonical record). `verify()` detects edited,
    deleted or reordered rows in the middle of the log. This is TAMPER-EVIDENCE only: someone who can write
    the database file can recompute the whole chain, truncate the tail, or delete the file. It is not an
    access control and not a substitute for shipping logs elsewhere.
  * A logging failure never changes a processing result. `record()` returns False (and remembers the error)
    instead of raising, so the caller can show "not logged" rather than silently losing the event.
  * The log grows without bound (no pruning yet): see docs/event_logging.md.
"""

from __future__ import annotations

import hashlib
import json
import sqlite3
import threading
from pathlib import Path
from typing import Any

SCHEMA_VERSION = 2   # v2 (Phase 11): decision columns and a per-row hash_version; v1 databases are migrated on open
GENESIS = "0" * 64
MAX_TEXT = 600
MAX_FRAME_HEX = 4000
MAX_JSON = 20000
MAX_QUERY_LIMIT = 1000

SEVERITIES = ("WITHIN_LIMITS", "LIMIT_VIOLATION", "REJECTED", "SIMULATION_FAILURE", "COMPONENT_FAILURE")
STAGES = ("SIMULATED", "PARSE_REJECTED", "COMPONENT_FAILURE")

_SCHEMA = """
CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp_utc TEXT NOT NULL,
    command_id TEXT,
    source TEXT NOT NULL,
    stage TEXT NOT NULL,
    severity TEXT NOT NULL,
    sim_status TEXT,
    function_code INTEGER,
    register_address INTEGER,
    predicted_pressure REAL,
    predicted_flow REAL,
    violations TEXT NOT NULL,
    error_code TEXT,
    error TEXT,
    frame_hex TEXT NOT NULL,
    parsed_json TEXT,
    simulation_json TEXT,
    timings_json TEXT NOT NULL,
    decision TEXT,
    decision_reason TEXT,
    decision_source TEXT,
    hash_version INTEGER NOT NULL DEFAULT 2,
    prev_hash TEXT NOT NULL,
    row_hash TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_events_severity ON events(severity);
CREATE INDEX IF NOT EXISTS idx_events_command ON events(command_id);
"""

_HASHED_V1 = ("timestamp_utc", "command_id", "source", "stage", "severity", "sim_status", "function_code",
              "register_address", "predicted_pressure", "predicted_flow", "violations", "error_code", "error",
              "frame_hex", "parsed_json", "simulation_json", "timings_json")
_HASHED = _HASHED_V1 + ("decision", "decision_reason", "decision_source")      # fields covered by the hash of v2 rows
_FIELDS_BY_HASH_VERSION = {1: _HASHED_V1, 2: _HASHED}
DECISION_VALUES = ("ALLOW", "BLOCK", "REJECT")
DECISION_SOURCES = ("engine", "fail_closed")


class EventStoreError(Exception):
    """The event database cannot be opened or has an unexpected format."""


def classify(result: dict[str, Any]) -> str:
    """Severity of a pipeline result. This is NOT an allow/block decision (Phase 10)."""
    stage = result.get("stage")
    if stage == "COMPONENT_FAILURE":
        return "COMPONENT_FAILURE"
    if stage == "PARSE_REJECTED":
        return "REJECTED"
    sim = result.get("simulation")
    if stage != "SIMULATED" or not isinstance(sim, dict):
        return "COMPONENT_FAILURE"  # unknown shape: fail closed
    status = sim.get("simulation_status")
    if status == "SUCCESS":
        return "LIMIT_VIOLATION" if sim.get("violations") else "WITHIN_LIMITS"
    if status == "INVALID_INPUT":
        return "REJECTED"
    return "SIMULATION_FAILURE"


def _cap(value: Any, limit: int) -> str | None:
    if value is None:
        return None
    text = value if isinstance(value, str) else str(value)
    return "".join(c if c.isprintable() else "?" for c in text)[:limit]


def _json(value: Any) -> str | None:
    if value is None:
        return None
    text = json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)
    if len(text) > MAX_JSON:
        return json.dumps({"truncated": True, "original_length": len(text)})
    return text


def _num(value: Any) -> float | None:
    return float(value) if isinstance(value, (int, float)) and not isinstance(value, bool) and value == value else None


def _int(value: Any) -> int | None:
    return value if isinstance(value, int) and not isinstance(value, bool) else None


def build_row(result: dict[str, Any], source: str, frame_hex: str, timestamp_utc: str,
              decision: dict[str, Any] | None = None) -> dict[str, Any]:
    """Flatten a pipeline result (and the final decision, if any) into the stored columns (everything length-capped)."""
    decision = decision if isinstance(decision, dict) else {}
    parsed = result.get("parsed_command") if isinstance(result.get("parsed_command"), dict) else None
    sim = result.get("simulation") if isinstance(result.get("simulation"), dict) else None
    violations = []
    if sim and isinstance(sim.get("violations"), list):
        violations = [{"type": _cap(v.get("type"), 40), "limit": _num(v.get("limit")), "predicted": _num(v.get("predicted"))}
                      for v in sim["violations"] if isinstance(v, dict)]
    return {
        "timestamp_utc": _cap(timestamp_utc, 40) or "",
        "command_id": _cap(result.get("command_id"), 64),
        "source": _cap(source, 120) or "unknown",
        "stage": result.get("stage") if result.get("stage") in STAGES else "COMPONENT_FAILURE",
        "severity": classify(result),
        "sim_status": _cap(sim.get("simulation_status"), 20) if sim else None,
        "function_code": _int(parsed.get("function_code")) if parsed else None,
        "register_address": _int(parsed.get("register_address")) if parsed else None,
        "predicted_pressure": _num(sim.get("predicted_pressure")) if sim else None,
        "predicted_flow": _num(sim.get("predicted_flow")) if sim else None,
        "violations": json.dumps(violations, sort_keys=True, separators=(",", ":"), allow_nan=False),
        "error_code": _cap(result.get("error_code"), 60),
        "error": _cap(result.get("error"), MAX_TEXT),
        "frame_hex": _cap(frame_hex, MAX_FRAME_HEX) or "",
        "parsed_json": _json(parsed),
        "simulation_json": _json(sim),
        "timings_json": _json(result.get("timings_ms") if isinstance(result.get("timings_ms"), dict) else {}) or "{}",
        "decision": decision.get("decision") if decision.get("decision") in DECISION_VALUES else None,
        "decision_reason": _cap(decision.get("reason"), MAX_TEXT) if decision else None,
        "decision_source": decision.get("source") if decision.get("source") in DECISION_SOURCES else None,
    }


def _hash(prev: str, row: dict[str, Any], hash_version: int = 2) -> str:
    payload = json.dumps([row[k] for k in _FIELDS_BY_HASH_VERSION[hash_version]], separators=(",", ":"), allow_nan=False)
    return hashlib.sha256((prev + payload).encode("utf-8")).hexdigest()


class EventStore:
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.last_error: str | None = None
        self._lock = threading.Lock()
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self._db = sqlite3.connect(str(self.path), timeout=5.0, check_same_thread=False)
            self._db.executescript(_SCHEMA)
            row = self._db.execute("SELECT value FROM meta WHERE key='schema_version'").fetchone()
            if row is None:
                self._db.execute("INSERT INTO meta(key, value) VALUES('schema_version', ?)", (str(SCHEMA_VERSION),))
                self._db.commit()
            elif row[0] == "1":
                self._migrate_v1()
            elif row[0] != str(SCHEMA_VERSION):
                raise EventStoreError(f"unsupported event database schema version {row[0]!r}")
            last = self._db.execute("SELECT row_hash FROM events ORDER BY id DESC LIMIT 1").fetchone()
            self._last_hash = last[0] if last else GENESIS
        except (sqlite3.Error, OSError) as exc:
            raise EventStoreError(f"cannot open event database {self.path}: {exc}") from exc

    def _migrate_v1(self) -> None:
        """v1 -> v2: add the decision columns. Old rows keep hash_version 1, so their hashes stay valid."""
        have = {r[1] for r in self._db.execute("PRAGMA table_info(events)")}
        with self._db:
            for column, ddl in (("decision", "TEXT"), ("decision_reason", "TEXT"), ("decision_source", "TEXT"),
                                ("hash_version", "INTEGER NOT NULL DEFAULT 1")):
                if column not in have:
                    self._db.execute(f"ALTER TABLE events ADD COLUMN {column} {ddl}")   # constants only
            self._db.execute("UPDATE meta SET value=? WHERE key='schema_version'", (str(SCHEMA_VERSION),))

    def close(self) -> None:
        with self._lock:
            try:
                self._db.close()
            except sqlite3.Error:
                pass

    def record(self, result: dict[str, Any], source: str, frame_hex: str, timestamp_utc: str,
               decision: dict[str, Any] | None = None) -> bool:
        """Append one event. Never raises: returns False and sets last_error if the event could not be stored."""
        try:
            row = build_row(result, source, frame_hex, timestamp_utc, decision)
            with self._lock:
                digest = _hash(self._last_hash, row)
                cols = list(_HASHED) + ["hash_version", "prev_hash", "row_hash"]
                self._db.execute(
                    f"INSERT INTO events ({', '.join(cols)}) VALUES ({', '.join('?' * len(cols))})",  # column names are constants
                    [row[k] for k in _HASHED] + [SCHEMA_VERSION, self._last_hash, digest])
                self._db.commit()
                self._last_hash = digest
            self.last_error = None
            return True
        except Exception as exc:  # noqa: BLE001 - logging must never break processing
            self.last_error = f"{type(exc).__name__}: {exc}"[:300]
            return False

    def count(self) -> int:
        with self._lock:
            return self._db.execute("SELECT COUNT(*) FROM events").fetchone()[0]

    def query(self, limit: int = 100, severity: str | None = None, command_id: str | None = None) -> list[dict[str, Any]]:
        """Newest-first rows. Filters are bound parameters; unknown severities raise ValueError."""
        if not isinstance(limit, int) or isinstance(limit, bool) or limit < 1:
            raise ValueError("limit must be a positive integer")
        limit = min(limit, MAX_QUERY_LIMIT)
        if severity is not None and severity not in SEVERITIES:
            raise ValueError(f"unknown severity {severity!r}")
        sql, args = "SELECT * FROM events", []
        where = []
        if severity is not None:
            where.append("severity = ?")
            args.append(severity)
        if command_id is not None:
            where.append("command_id = ?")
            args.append(command_id)
        if where:
            sql += " WHERE " + " AND ".join(where)  # fixed fragments only
        sql += " ORDER BY id DESC LIMIT ?"
        args.append(limit)
        with self._lock:
            cur = self._db.execute(sql, args)
            names = [d[0] for d in cur.description]
            return [dict(zip(names, r)) for r in cur.fetchall()]

    def export_rows(self, max_rows: int, severity: str | None = None) -> tuple[list[dict[str, Any]], int]:
        """Oldest-first rows for export (at most `max_rows`) and the number of rows that matched the filter."""
        if not isinstance(max_rows, int) or isinstance(max_rows, bool) or max_rows < 1:
            raise ValueError("max_rows must be a positive integer")
        if severity is not None and severity not in SEVERITIES:
            raise ValueError(f"unknown severity {severity!r}")
        where, args = ("WHERE severity = ?", [severity]) if severity is not None else ("", [])
        with self._lock:
            total = self._db.execute(f"SELECT COUNT(*) FROM events {where}", args).fetchone()[0]    # fixed fragments only
            cur = self._db.execute(f"SELECT * FROM events {where} ORDER BY id LIMIT ?", args + [max_rows])
            names = [d[0] for d in cur.description]
            return [dict(zip(names, r)) for r in cur.fetchall()], total

    def verify(self) -> tuple[bool, str]:
        """Recompute the whole chain. Returns (ok, message naming the first bad row if any)."""
        with self._lock:
            prev = GENESIS
            n = 0
            for r in self._db.execute(f"SELECT id, {', '.join(_HASHED)}, hash_version, prev_hash, row_hash FROM events ORDER BY id"):
                rid, values, version, stored_prev, stored_hash = r[0], r[1:1 + len(_HASHED)], r[-3], r[-2], r[-1]
                row = dict(zip(_HASHED, values))
                if version not in _FIELDS_BY_HASH_VERSION:
                    return False, f"row {rid}: unknown hash version {version!r}"
                if version == 1 and any(row[k] is not None for k in _HASHED[len(_HASHED_V1):]):
                    return False, f"row {rid}: decision fields on a pre-decision (v1) row are not covered by its hash"
                if stored_prev != prev:
                    return False, f"row {rid}: chain broken (a previous row was removed or changed)"
                if _hash(prev, row, version) != stored_hash:
                    return False, f"row {rid}: contents do not match their hash"
                prev = stored_hash
                n += 1
            return True, f"{n} row(s) verified"


class UnavailableStore:
    """Stands in for an event database that could not be opened, so failures are reported instead of hidden."""

    def __init__(self, reason: str):
        self.last_error = reason

    def record(self, *_args: Any, **_kw: Any) -> bool:
        return False

    def count(self) -> int:
        return 0

    def query(self, *_args: Any, **_kw: Any) -> list[dict[str, Any]]:
        raise EventStoreError(self.last_error or "event log unavailable")

    def export_rows(self, *_args: Any, **_kw: Any) -> tuple[list[dict[str, Any]], int]:
        raise EventStoreError(self.last_error or "event log unavailable")

    def verify(self) -> tuple[bool, str]:
        return False, self.last_error or "event log unavailable"

    def close(self) -> None:
        pass
