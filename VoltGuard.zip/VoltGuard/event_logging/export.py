"""Export of the stored event log to CSV or JSON, plus an optional PDF report.

Everything exported is a SIMULATED result or a decision about one; the files say so. Safety properties:
  * The hash chain is verified first and the outcome is reported (and written into JSON/PDF). A failed check
    does NOT stop the export (the operator may want the evidence), it is labelled loudly instead.
  * CSV cells that a spreadsheet would execute as a formula (leading = + - @ tab CR) are prefixed with an
    apostrophe, so hostile text stored in the log cannot become a formula when the file is opened.
  * Files are written to a temporary name in the target folder, flushed to disk and then moved into place.
    Without `overwrite=True` an existing file is never replaced (the move is atomic and fails if the
    name is taken). A failure leaves no partial file behind.
  * The target path comes from the caller, never from logged data; the folder must already exist; the file
    extension must match the format; symbolic links and directories are refused.
  * At most MAX_EXPORT_ROWS rows are exported; truncation is reported, never silent.
"""

from __future__ import annotations

import argparse
import csv
import datetime
import json
import os
import sys
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

if __name__ == "__main__" and __package__ in (None, ""):
    # Started as a plain file (for example with an editor's Run button) instead of `python -m ...`: Python then puts
    # this file's own folder on sys.path, so the project packages cannot be found. Use the project root instead.
    sys.path[0:1] = [str(Path(__file__).resolve().parent.parent)]

from event_logging.event_store import SEVERITIES, EventStore, EventStoreError

MAX_EXPORT_ROWS = 100_000
FORMATS = {"csv": ".csv", "json": ".json", "pdf": ".pdf"}
EXPORT_COLUMNS = ("id", "timestamp_utc", "command_id", "source", "stage", "severity", "sim_status", "function_code",
                  "register_address", "predicted_pressure", "predicted_flow", "violations", "error_code", "error",
                  "decision", "decision_reason", "decision_source", "frame_hex", "row_hash")
NOTICE = ("SIMULATED data from the VoltGuard prototype: predicted values come from an invented model and decisions are "
          "policy outcomes about simulated commands. Nothing was forwarded to any device.")
INTEGRITY_NOTE = "The hash chain gives tamper-evidence only (tail truncation and full recomputation are not detected)."
_FORMULA_STARTS = ("=", "+", "-", "@", "\t", "\r")


class ExportError(Exception):
    """The export was refused or failed; no file was left behind."""


class ReportUnavailable(ExportError):
    """The optional PDF library (reportlab) is not installed."""


@dataclass(frozen=True)
class ExportResult:
    path: Path
    format: str
    rows: int
    total_matching: int
    truncated: bool
    verified: bool
    verify_message: str


def neutralise_cell(value: Any) -> Any:
    """Numbers and None pass through; text a spreadsheet could execute gets a leading apostrophe."""
    if isinstance(value, str) and value.startswith(_FORMULA_STARTS):
        return "'" + value
    return value


def check_target(path: Path | str, fmt: str, overwrite: bool) -> Path:
    if fmt not in FORMATS:
        raise ExportError(f"unknown export format {fmt!r} (use csv, json or pdf)")
    target = Path(path)
    if target.suffix.lower() != FORMATS[fmt]:
        raise ExportError(f"the file name must end in {FORMATS[fmt]} for the {fmt} format")
    parent = target.parent if str(target.parent) else Path(".")
    if not parent.is_dir():
        raise ExportError(f"the folder {parent} does not exist")
    if target.is_symlink():
        raise ExportError("the target is a symbolic link; refusing to write through it")
    if target.is_dir():
        raise ExportError("the target is a folder")
    if target.exists() and not overwrite:
        raise ExportError(f"{target.name} already exists (nothing was changed; choose another name or allow overwriting)")
    return target


def _write_atomically(target: Path, write: Callable[[Any], None], binary: bool, overwrite: bool) -> None:
    fd, tmp_name = tempfile.mkstemp(prefix=".voltguard-export-", suffix=".tmp", dir=str(target.parent))
    tmp = Path(tmp_name)
    try:
        with os.fdopen(fd, "wb" if binary else "w", **({} if binary else {"encoding": "utf-8", "newline": ""})) as handle:
            write(handle)
            handle.flush()
            os.fsync(handle.fileno())
        if overwrite:
            os.replace(tmp, target)
        else:
            os.link(tmp, target)       # fails if the name appeared in the meantime: never replaces
            tmp.unlink()
    except FileExistsError:
        raise ExportError(f"{target.name} already exists (nothing was changed)") from None
    except OSError as exc:
        raise ExportError(f"cannot write {target}: {exc}") from exc
    finally:
        try:
            tmp.unlink()
        except FileNotFoundError:
            pass
        except OSError:
            pass


def _clean_rows(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [{k: r.get(k) for k in EXPORT_COLUMNS} for r in rows]


def export_events(store: EventStore, path: Path | str, fmt: str, *, severity: str | None = None, overwrite: bool = False,
                  max_rows: int = MAX_EXPORT_ROWS, safety_config: Any = None) -> ExportResult:
    """Export the stored events (oldest first) to `path` in `fmt` ('csv', 'json' or 'pdf')."""
    if severity is not None and severity not in SEVERITIES:
        raise ExportError(f"unknown severity {severity!r}")
    target = check_target(path, fmt, overwrite)
    try:
        verified, verify_message = store.verify()
        rows, total = store.export_rows(max_rows, severity)
    except (EventStoreError, ValueError) as exc:
        raise ExportError(f"cannot read the event log: {exc}") from exc
    clean = _clean_rows(rows)
    truncated = total > len(clean)
    exported_at = datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds")

    if fmt == "csv":
        def write_csv(handle: Any) -> None:
            writer = csv.writer(handle)
            writer.writerow(EXPORT_COLUMNS)
            for row in clean:
                writer.writerow([neutralise_cell(row[c]) for c in EXPORT_COLUMNS])
        _write_atomically(target, write_csv, False, overwrite)
    elif fmt == "json":
        document = {"format_version": 1, "notice": NOTICE, "exported_at_utc": exported_at,
                    "integrity": {"verified": verified, "message": verify_message, "note": INTEGRITY_NOTE},
                    "filter": {"severity": severity}, "total_matching_rows": total, "rows_exported": len(clean),
                    "truncated": truncated, "events": clean}

        def write_json(handle: Any) -> None:
            json.dump(document, handle, indent=2, allow_nan=False)
            handle.write("\n")
        _write_atomically(target, write_json, False, overwrite)
    else:
        from event_logging.report_pdf import build_pdf_bytes
        pdf = build_pdf_bytes(clean, total=total, truncated=truncated, verified=verified, verify_message=verify_message,
                              exported_at=exported_at, severity=severity, safety_config=safety_config)
        _write_atomically(target, lambda handle: handle.write(pdf), True, overwrite)
    return ExportResult(target, fmt, len(clean), total, truncated, verified, verify_message)


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Export the VoltGuard event log (simulated data) to CSV, JSON or PDF.")
    ap.add_argument("--db", type=Path, required=True, help="event database (must exist)")
    ap.add_argument("--format", choices=sorted(FORMATS), required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--severity", choices=SEVERITIES)
    ap.add_argument("--max-rows", type=int, default=MAX_EXPORT_ROWS)
    ap.add_argument("--config", type=Path, default=None, help="safety_limits.json to print in the PDF (default: the shipped one)")
    ap.add_argument("--force", action="store_true", help="overwrite an existing output file")
    args = ap.parse_args(argv)
    if args.max_rows < 1:
        ap.error("--max-rows must be positive")
    if not args.db.is_file():
        print(f"error: {args.db} does not exist (an export never creates a database)", file=sys.stderr)
        return 2
    config = None
    if args.format == "pdf":
        from voltguard.config import ConfigError, load_safety_config
        try:
            config = load_safety_config(args.config or Path(__file__).resolve().parent.parent / "config" / "safety_limits.json")
        except ConfigError as exc:
            print(f"error: invalid safety configuration: {exc}", file=sys.stderr)
            return 2
    try:
        store = EventStore(args.db)
    except EventStoreError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    try:
        result = export_events(store, args.out, args.format, severity=args.severity, overwrite=args.force,
                               max_rows=args.max_rows, safety_config=config)
    except ReportUnavailable as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 3
    except ExportError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    finally:
        store.close()
    print(f"wrote {result.rows} of {result.total_matching} row(s) to {result.path}"
          + (" (TRUNCATED)" if result.truncated else ""))
    print(f"integrity: {'verified' if result.verified else 'FAILED'} - {result.verify_message}")
    return 0 if result.verified else 4


if __name__ == "__main__":
    sys.exit(main())
