"""Optional PDF report of the stored events (needs the reportlab package; see requirements-optional.txt).

The report states plainly that all values are simulated, shows the integrity check result, summary counts,
the configured limits and a table of the newest events. All text from the log is escaped before layout and
truncated; a hostile string is printed as text, never interpreted as markup.
"""

from __future__ import annotations

import io
from collections import Counter
from typing import Any
from xml.sax.saxutils import escape

MAX_TABLE_ROWS = 200
CELL_CHARS = 60


def _cell(value: Any, limit: int = CELL_CHARS) -> str:
    text = "" if value is None else str(value)
    text = "".join(c if c.isprintable() else "?" for c in text)
    return escape(text[:limit] + ("..." if len(text) > limit else ""))


def build_pdf_bytes(rows: list[dict[str, Any]], *, total: int, truncated: bool, verified: bool, verify_message: str,
                    exported_at: str, severity: str | None, safety_config: Any) -> bytes:
    try:
        from reportlab.lib import colors
        from reportlab.lib.pagesizes import A4, landscape
        from reportlab.lib.styles import getSampleStyleSheet
        from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle
    except ImportError:
        from event_logging.export import ReportUnavailable
        raise ReportUnavailable("the PDF report needs the optional reportlab package (pip install reportlab)") from None
    from event_logging.export import INTEGRITY_NOTE, NOTICE

    styles = getSampleStyleSheet()
    small = styles["BodyText"].clone("small", fontSize=8, leading=10)
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=landscape(A4), title="VoltGuard event report", author="VoltGuard prototype",
                            leftMargin=24, rightMargin=24, topMargin=24, bottomMargin=24)
    story: list[Any] = [Paragraph("VoltGuard event report", styles["Title"]),
                        Paragraph(escape(NOTICE), styles["BodyText"]), Spacer(1, 8),
                        Paragraph(f"Generated {_cell(exported_at)} UTC. Filter: severity = {_cell(severity or 'all')}. "
                                  f"Rows in this report: {len(rows)} of {total} matching"
                                  + (" (<b>TRUNCATED</b>)" if truncated else "") + ".", styles["BodyText"])]
    status = "VERIFIED" if verified else "FAILED"
    colour = "darkgreen" if verified else "red"
    story += [Paragraph(f"Event log integrity check: <font color='{colour}'><b>{status}</b></font> - {_cell(verify_message, 200)}", styles["BodyText"]),
              Paragraph(escape(INTEGRITY_NOTE), small), Spacer(1, 10)]

    def table(data: list[list[str]], widths: list[float] | None = None) -> Table:
        t = Table(data, colWidths=widths, repeatRows=1)
        t.setStyle(TableStyle([("FONTSIZE", (0, 0), (-1, -1), 7), ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey),
                               ("GRID", (0, 0), (-1, -1), 0.25, colors.grey), ("VALIGN", (0, 0), (-1, -1), "TOP")]))
        return t

    decisions = Counter(r.get("decision") or "(none: logged before decisions existed)" for r in rows)
    severities = Counter(r.get("severity") for r in rows)
    story.append(Paragraph("Summary of the exported rows", styles["Heading2"]))
    story.append(table([["Decision", "Count"]] + [[_cell(k), str(v)] for k, v in sorted(decisions.items())], [260, 60]))
    story.append(Spacer(1, 6))
    story.append(table([["Simulation severity", "Count"]] + [[_cell(k), str(v)] for k, v in sorted(severities.items(), key=lambda kv: str(kv[0]))], [260, 60]))

    if safety_config is not None:
        story += [Spacer(1, 10), Paragraph("Configured limits (example values, not real plant limits)", styles["Heading2"])]
        limits = [["Quantity", "Minimum", "Maximum", "Unit"]]
        for name in ("pressure", "flow", "pump_speed", "valve_position"):
            lim = getattr(safety_config, name)
            limits.append([name, _cell(lim.minimum), _cell(lim.maximum), _cell(lim.unit)])
        story.append(table(limits, [140, 70, 70, 60]))

    story += [Spacer(1, 10), Paragraph(f"Events (oldest first; the first {MAX_TABLE_ROWS} of the exported rows)", styles["Heading2"])]
    header = ["id", "time (UTC)", "command", "source", "severity", "pressure", "flow", "decision", "reason"]
    body = [[_cell(r.get("id")), _cell(r.get("timestamp_utc"), 26), _cell(r.get("command_id"), 24), _cell(r.get("source"), 28),
             _cell(r.get("severity")), _cell(r.get("predicted_pressure")), _cell(r.get("predicted_flow")),
             _cell(r.get("decision")), _cell(r.get("decision_reason"), 80)] for r in rows[:MAX_TABLE_ROWS]]
    story.append(table([header] + [[Paragraph(c, small) for c in line] for line in body] if body else [header],
                       [30, 90, 80, 90, 80, 45, 40, 50, 260]))
    story += [Spacer(1, 10), Paragraph("Limitations: values are predictions of an invented steady-state model; the limits are examples; "
                                       "the log is tamper-evident, not tamper-proof; this report is not a compliance or audit document.", small)]
    doc.build(story)
    return buffer.getvalue()
