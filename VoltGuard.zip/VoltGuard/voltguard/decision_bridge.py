"""Bridge to the Rust decision engine (Phase 11).

    pipeline result (dict) -> voltguard_decision_engine (controlled subprocess, JSON lines) -> final decision

Fail-closed rules:
  * Every failure (engine missing, timeout, crash, bad JSON, schema violation, wrong command id, an
    answer that contradicts the pipeline result) becomes REJECT with source "fail_closed". A failure is
    NEVER turned into ALLOW, and no exception reaches the caller of Decider.decide().
  * ALLOW and BLOCK are only accepted for stage SIMULATED with simulation status SUCCESS.
  * Second opinion: an ALLOW for a write is vetoed (REJECT) if this module's own limit check (Python, using
    the loaded configuration) finds the predicted pressure or flow outside the limits. Two independent
    implementations in two languages must both be satisfied for a write to be allowed.
  * After any engine failure the child is killed and restarted on the next request.
  * The engine receives only the JSON of the pipeline result; its answer is validated by
    voltguard.schemas.DecisionResult before it is used. The child is started from a fixed argument list
    (shell=False).

The final decision is a dict: DecisionResult fields plus
  "source": "engine" | "fail_closed" and "error_code": null | CODE   (CODE names the failure).
"""

from __future__ import annotations

import json
import logging
import os
import queue
import subprocess
import sys
import threading
from pathlib import Path
from typing import Any, Sequence

from physics_engine.safety_limits import evaluate_limits
from voltguard.config import SafetyConfig
from voltguard.schemas import FC_READ_HOLDING, DecisionResult, SchemaError

ROOT = Path(__file__).resolve().parent.parent
MAX_REQUEST_BYTES = 64 * 1024
MAX_RESPONSE_BYTES = 16 * 1024
KILL_WAIT_S = 5.0
SOURCE_ENGINE = "engine"
SOURCE_FAIL_CLOSED = "fail_closed"

log = logging.getLogger("voltguard.decision")


class DecisionError(Exception):
    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code
        self.message = message


def find_decision_engine() -> Path | None:
    """$VOLTGUARD_DECISION_ENGINE, then decision_engine/target/{release,debug}."""
    env = os.environ.get("VOLTGUARD_DECISION_ENGINE")
    candidates = [Path(env)] if env else []
    exe = "voltguard_decision_engine.exe" if sys.platform == "win32" else "voltguard_decision_engine"
    for sub in ("release", "debug"):
        candidates.append(ROOT / "decision_engine" / "target" / sub / exe)
    return next((c for c in candidates if c.is_file()), None)


class EngineProcess:
    """One long-lived engine child. Thread-safe (requests are serialised)."""

    def __init__(self, argv: Sequence[str]) -> None:
        self._argv = [str(a) for a in argv]
        self._proc: subprocess.Popen | None = None
        self._lines: queue.Queue | None = None
        self._lock = threading.Lock()
        self.starts = 0

    def _start(self) -> None:
        try:
            proc = subprocess.Popen(self._argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                    stderr=subprocess.DEVNULL, shell=False)
        except (OSError, ValueError) as exc:
            raise DecisionError("DECISION_ENGINE_UNAVAILABLE", f"cannot start decision engine: {type(exc).__name__}") from exc
        lines: queue.Queue = queue.Queue()
        threading.Thread(target=self._reader, args=(proc, lines), daemon=True).start()
        self._proc, self._lines = proc, lines
        self.starts += 1

    @staticmethod
    def _reader(proc: subprocess.Popen, lines: queue.Queue) -> None:
        try:
            while True:
                line = proc.stdout.readline(MAX_RESPONSE_BYTES + 1)
                if not line:
                    break
                lines.put(line)
                if len(line) > MAX_RESPONSE_BYTES:
                    break
        except (OSError, ValueError):
            pass
        finally:
            lines.put(None)

    def start(self) -> None:
        """Start eagerly (so the first request does not pay for process start-up). Raises DecisionError."""
        with self._lock:
            if self._proc is None or self._proc.poll() is not None:
                self._stop_locked()
                self._start()

    def stop(self) -> None:
        with self._lock:
            self._stop_locked()

    def _stop_locked(self) -> None:
        proc, self._proc, self._lines = self._proc, None, None
        if proc is None:
            return
        try:
            proc.kill()
        except OSError:
            pass
        try:
            proc.wait(timeout=KILL_WAIT_S)
        except subprocess.TimeoutExpired:
            log.error("decision engine pid %s did not exit after kill", proc.pid)
        for stream in (proc.stdin, proc.stdout):
            try:
                if stream:
                    stream.close()
            except OSError:
                pass

    def request(self, request_line: bytes, timeout_s: float) -> bytes:
        """One line in, one raw line out. Raises DecisionError."""
        with self._lock:
            if self._proc is None or self._proc.poll() is not None or (self._lines is not None and not self._lines.empty()):
                self._stop_locked()
                self._start()
            assert self._proc is not None and self._lines is not None
            try:
                self._proc.stdin.write(request_line + b"\n")
                self._proc.stdin.flush()
            except (OSError, ValueError) as exc:
                self._stop_locked()
                raise DecisionError("DECISION_ENGINE_CRASHED", f"cannot write to decision engine: {type(exc).__name__}") from exc
            try:
                raw = self._lines.get(timeout=timeout_s)
            except queue.Empty:
                self._stop_locked()
                raise DecisionError("DECISION_TIMEOUT", f"decision engine did not answer within {timeout_s * 1000:.0f} ms") from None
            if raw is None:
                self._stop_locked()
                raise DecisionError("DECISION_ENGINE_CRASHED", "decision engine exited without answering")
            if len(raw) > MAX_RESPONSE_BYTES:
                self._stop_locked()
                raise DecisionError("DECISION_BAD_OUTPUT", "decision engine reply too long")
            return raw


def fail_closed_decision(command_id: str | None, code: str, message: str) -> dict[str, Any]:
    text = "".join(c if c.isprintable() else "?" for c in message)[:300]
    return {"command_id": command_id, "decision": "REJECT", "source": SOURCE_FAIL_CLOSED, "error_code": code,
            "reason": f"fail closed: {text}"[:512]}


class Decider:
    """Turns a pipeline result into the final decision. `decide` never raises and never returns ALLOW on failure."""

    def __init__(self, config: SafetyConfig, argv: Sequence[str] | None, timeout_s: float | None = None) -> None:
        self._config = config
        # The configured decision timeout is the default; `timeout_s` exists so tests can use other values.
        self._timeout_s = timeout_s if timeout_s is not None else config.timeouts_ms["decision"] / 1000.0
        self._engine = EngineProcess(argv) if argv else None
        self.available = False
        self.unavailable_reason: str | None = None if argv else "decision engine executable not found (build it: cargo build --manifest-path decision_engine/Cargo.toml)"
        if self._engine is not None:
            try:
                self._engine.start()
                self.available = True
            except DecisionError as exc:
                self.unavailable_reason = exc.message

    def close(self) -> None:
        if self._engine is not None:
            self._engine.stop()

    def decide(self, result: dict[str, Any]) -> dict[str, Any]:
        command_id = result.get("command_id") if isinstance(result, dict) else None
        valid_id = command_id if isinstance(command_id, str) and command_id.isascii() and 0 < len(command_id) <= 64 else None
        try:
            return self._decide(result)
        except DecisionError as exc:
            log.error("command %s: %s: %s", valid_id, exc.code, exc.message)
            return fail_closed_decision(valid_id, exc.code, exc.message)
        except Exception as exc:  # noqa: BLE001 - nothing may escape, and nothing may become ALLOW
            log.exception("unexpected error in the decision bridge")
            return fail_closed_decision(valid_id, "DECISION_INTERNAL_ERROR", type(exc).__name__)

    def _decide(self, result: dict[str, Any]) -> dict[str, Any]:
        if self._engine is None:
            raise DecisionError("DECISION_ENGINE_UNAVAILABLE", self.unavailable_reason or "decision engine unavailable")
        command_id = result.get("command_id")
        if not isinstance(command_id, str):
            raise DecisionError("DECISION_BAD_INPUT", "pipeline result has no command id")
        try:
            line = json.dumps(result, separators=(",", ":"), allow_nan=False).encode("utf-8")
        except (TypeError, ValueError):
            raise DecisionError("DECISION_BAD_INPUT", "pipeline result cannot be serialised") from None
        if len(line) > MAX_REQUEST_BYTES or b"\n" in line:
            raise DecisionError("DECISION_BAD_INPUT", "pipeline result too large")

        raw = self._engine.request(line, self._timeout_s)
        try:
            reply = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError, RecursionError):
            self._engine.stop()
            raise DecisionError("DECISION_BAD_OUTPUT", "decision engine reply is not valid JSON") from None
        if isinstance(reply, dict) and reply.get("type") == "error":
            raise DecisionError("DECISION_ENGINE_ERROR", f"engine could not decide: {str(reply.get('error'))[:120]}")
        try:
            decision = DecisionResult.from_dict(reply)
        except SchemaError as exc:
            self._engine.stop()
            raise DecisionError("DECISION_BAD_OUTPUT", f"decision engine reply violates the contract: {exc}") from None
        if decision.command_id != command_id:
            self._engine.stop()
            raise DecisionError("DECISION_ID_MISMATCH", "decision engine answered for a different command id")
        self._check_consistency(decision, result)
        out = decision.to_dict()
        out["source"] = SOURCE_ENGINE
        out["error_code"] = None
        return out

    def _check_consistency(self, decision: DecisionResult, result: dict[str, Any]) -> None:
        if decision.decision == "REJECT":
            return
        sim = result.get("simulation")
        if result.get("stage") != "SIMULATED" or not isinstance(sim, dict) or sim.get("simulation_status") != "SUCCESS":
            raise DecisionError("DECISION_INCONSISTENT", f"engine said {decision.decision} for a result that was not a successful simulation")
        if decision.decision != "ALLOW":
            return
        parsed = result.get("parsed_command")
        if isinstance(parsed, dict) and parsed.get("function_code") == FC_READ_HOLDING:
            return  # reads are allowed regardless of the predicted state (docs/decision_policy.md)
        pressure, flow = sim.get("predicted_pressure"), sim.get("predicted_flow")
        numbers = [x for x in (pressure, flow) if isinstance(x, (int, float)) and not isinstance(x, bool) and x == x]
        if len(numbers) != 2 or evaluate_limits(float(pressure), float(flow), self._config):
            raise DecisionError("DECISION_INCONSISTENT", "second check vetoed the ALLOW: predicted values are missing or outside the limits")
