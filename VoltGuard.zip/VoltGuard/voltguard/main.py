"""VoltGuard application entry point: startup, configuration check and component status only.

Run:  python -m voltguard.main [--config PATH] [--log-dir PATH]
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

if __name__ == "__main__" and __package__ in (None, ""):
    # Started as a plain file (for example with an editor's Run button) instead of `python -m ...`: Python then puts
    # this file's own folder on sys.path, so the project packages cannot be found. Use the project root instead.
    sys.path[0:1] = [str(Path(__file__).resolve().parent.parent)]

from voltguard import __version__
from voltguard.app_logging import setup_logger
from voltguard.config import ConfigError, load_safety_config

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_CONFIG = PROJECT_ROOT / "config" / "safety_limits.json"
DEFAULT_LOG_DIR = PROJECT_ROOT / "logs"

# Honest per-component status. Update as phases are completed.
COMPONENT_STATUS = {
    "configuration": "implemented (Phase 1)",
    "application logger": "implemented (Phase 1)",
    "message schemas": "implemented (Phase 2)",
    "traffic generator": "implemented (Phase 3)",
    "C++ packet parser": "implemented (Phase 4)",
    "physics engine": "implemented (Phase 5)",
    "parser-to-simulation bridge": "implemented (Phase 7)",
    "Decision engine": "implemented (Phase 10), connected through voltguard.decision_bridge in the worker (Phase 11; fail closed)",
    "Event log": "implemented (Phase 9): SQLite, hash-chained, written by the dashboard worker",
    "Qt dashboard": "implemented (Phase 8): voltguard_dashboard, built by CMake when Qt 6 is installed",
}


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="voltguard", description="VoltGuard - Physics-Aware Industrial Network Security")
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG, help="path to safety_limits.json")
    parser.add_argument("--log-dir", type=Path, default=DEFAULT_LOG_DIR, help="directory for log files")
    parser.add_argument("--version", action="version", version=f"VoltGuard {__version__}")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_arg_parser().parse_args(argv)
    logger = setup_logger(log_dir=args.log_dir)
    logger.info("VoltGuard %s starting (simulation prototype; no live industrial equipment)", __version__)

    try:
        config = load_safety_config(args.config)
    except ConfigError as exc:
        # Fail closed: without a valid safety configuration nothing may be allowed.
        logger.error("Safety configuration invalid, refusing to start: %s", exc)
        return 2

    logger.info(
        "Configuration loaded: pressure %.1f..%.1f %s, flow %.1f..%.1f %s",
        config.pressure.minimum, config.pressure.maximum, config.pressure.unit,
        config.flow.minimum, config.flow.maximum, config.flow.unit,
    )
    for component, status in COMPONENT_STATUS.items():
        logger.info("Component %-22s %s", component, status)
    logger.info("Traffic can be generated, parsed and simulated end to end; decisions need the built Rust engine (cargo build --manifest-path decision_engine/Cargo.toml); without it every command is REJECTED.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
