"""Parser-to-simulation pipeline (Phase 7).

    frame bytes -> C++ parser (controlled subprocess) -> ParsedCommand -> physics simulation -> PipelineResult

Integration method: the C++ parser runs as a long-lived child process speaking the line protocol
documented in integration/interfaces.md (one request line in, one JSON line out). The child is started
from a fixed argument list (never a shell) and receives only a validated command id and hex digits.

Fail-closed rules:
  * Every failure (parser missing, timeout, crash, wrong id, bad JSON, schema violation, simulator
    timeout) becomes a recorded result with an error; nothing is ever treated as "safe" here.
  * No exception from a component reaches the caller of process_frame().
  * After any parser failure the child is killed and restarted lazily on the next request, so one bad
    exchange cannot desynchronise later ones.
  * This module makes no allow/block decision (Phase 10/11) and never changes the pipeline settings.

Limitation: a simulation that exceeds its timeout cannot be forcibly stopped (Python threads cannot
be killed); it is abandoned in a daemon thread and reported as TIMEOUT.
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import queue
import subprocess
import sys
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Sequence

if __name__ == "__main__" and __package__ in (None, ""):
    # Started as a plain file (for example with an editor's Run button) instead of `python -m ...`: Python then puts
    # this file's own folder on sys.path, so the project packages cannot be found. Use the project root instead.
    sys.path[0:1] = [str(Path(__file__).resolve().parent.parent)]

from physics_engine.pipeline_model import DEFAULT_MODEL, PipelineModel, solve_operating_point
from physics_engine.simulator import DEFAULT_STATE, PipelineState, simulate_command
from voltguard.app_logging import setup_logger
from voltguard.config import ConfigError, SafetyConfig, load_safety_config
from voltguard.schemas import COMMAND_ID_PATTERN, ParsedCommand, SchemaError, SimulationResult

ROOT = Path(__file__).resolve().parent.parent

STAGE_SIMULATED = "SIMULATED"                    # parsed and a SimulationResult exists (its status may still be a failure)
STAGE_PARSE_REJECTED = "PARSE_REJECTED"          # the parser rejected the frame; the simulator was never called
STAGE_COMPONENT_FAILURE = "COMPONENT_FAILURE"    # a component failed; no usable result
STAGES = (STAGE_SIMULATED, STAGE_PARSE_REJECTED, STAGE_COMPONENT_FAILURE)

MAX_FRAME_BYTES = 1000            # larger frames are rejected here; the parser's own limit is 260
MAX_RESPONSE_BYTES = 16 * 1024    # a parser reply line longer than this is treated as a failure
MAX_TEXT = 200
KILL_WAIT_S = 5.0

log = logging.getLogger("voltguard.pipeline")


class ComponentError(Exception):
    """A component failed. `code` is a stable machine-readable reason."""

    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code
        self.message = message


def find_parser_cli() -> Path | None:
    """Locate the compiled parser: $VOLTGUARD_PARSER_CLI, then the usual CMake build folders."""
    env = os.environ.get("VOLTGUARD_PARSER_CLI")
    candidates = [Path(env)] if env else []
    exe = "voltguard_parser_cli.exe" if sys.platform == "win32" else "voltguard_parser_cli"
    for sub in ("", "Release", "Debug"):
        candidates.append(ROOT / "build" / "packet_interceptor" / sub / exe)
    return next((c for c in candidates if c.is_file()), None)


# --------------------------------------------------------------------------- parser subprocess

class ParserProcess:
    """One long-lived parser child. Thread-safe (requests are serialised)."""

    def __init__(self, argv: Sequence[str]) -> None:
        self._argv = [str(a) for a in argv]
        self._proc: subprocess.Popen | None = None
        self._lines: queue.Queue | None = None
        self._lock = threading.Lock()
        self.starts = 0

    @property
    def pid(self) -> int | None:
        return self._proc.pid if self._proc is not None else None

    def _start(self) -> None:
        try:
            proc = subprocess.Popen(self._argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                    stderr=subprocess.DEVNULL, shell=False)
        except (OSError, ValueError) as exc:
            raise ComponentError("PARSER_UNAVAILABLE", f"cannot start parser: {type(exc).__name__}") from exc
        lines: queue.Queue = queue.Queue()
        threading.Thread(target=self._reader, args=(proc, lines), daemon=True).start()
        self._proc, self._lines = proc, lines
        self.starts += 1

    @staticmethod
    def _reader(proc: subprocess.Popen, lines: queue.Queue) -> None:
        try:
            while True:
                line = proc.stdout.readline(MAX_RESPONSE_BYTES + 1)
                if not line:
                    break
                lines.put(line)
                if len(line) > MAX_RESPONSE_BYTES:
                    break
        except (OSError, ValueError):
            pass
        finally:
            lines.put(None)  # end-of-stream marker

    def stop(self) -> None:
        with self._lock:
            self._stop_locked()

    def _stop_locked(self) -> None:
        proc, self._proc, self._lines = self._proc, None, None
        if proc is None:
            return
        try:
            proc.kill()
        except OSError:
            pass
        try:
            proc.wait(timeout=KILL_WAIT_S)
        except subprocess.TimeoutExpired:
            log.error("parser pid %s did not exit after kill", proc.pid)
        for stream in (proc.stdin, proc.stdout):
            try:
                if stream:
                    stream.close()
            except OSError:
                pass

    def request(self, command_id: str, frame_hex: str, timeout_s: float) -> dict[str, Any]:
        """Send one frame and return the validated reply object. Raises ComponentError on any problem."""
        with self._lock:
            # Unsolicited output or a dead child means the exchange can no longer be trusted: restart.
            if self._proc is None or self._proc.poll() is not None or (self._lines is not None and not self._lines.empty()):
                self._stop_locked()
                self._start()
            assert self._proc is not None and self._lines is not None
            try:
                self._proc.stdin.write(f"{command_id} {frame_hex}\n".encode("ascii"))
                self._proc.stdin.flush()
            except (OSError, ValueError) as exc:
                self._stop_locked()
                raise ComponentError("PARSER_CRASHED", f"cannot write to parser: {type(exc).__name__}") from exc

            try:
                raw = self._lines.get(timeout=timeout_s)
            except queue.Empty:
                self._stop_locked()
                raise ComponentError("PARSER_TIMEOUT", f"parser did not answer within {timeout_s * 1000:.0f} ms") from None
            if raw is None:
                self._stop_locked()
                raise ComponentError("PARSER_CRASHED", "parser exited without answering")
            try:
                return self._validate_reply(raw, command_id)
            except ComponentError:
                self._stop_locked()
                raise

    @staticmethod
    def _validate_reply(raw: bytes, command_id: str) -> dict[str, Any]:
        if len(raw) > MAX_RESPONSE_BYTES:
            raise ComponentError("PARSER_BAD_OUTPUT", "parser reply too long")
        try:
            reply = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError, RecursionError):
            raise ComponentError("PARSER_BAD_OUTPUT", "parser reply is not valid JSON") from None
        if not isinstance(reply, dict):
            raise ComponentError("PARSER_BAD_OUTPUT", "parser reply is not a JSON object")
        if reply.get("command_id") != command_id:
            raise ComponentError("PARSER_ID_MISMATCH", "parser reply belongs to a different command id")
        status = reply.get("status")
        if status == "OK":
            if not isinstance(reply.get("command"), dict):
                raise ComponentError("PARSER_BAD_OUTPUT", "OK reply without a command object")
        elif status == "REJECTED":
            if not isinstance(reply.get("error_code"), str) or not isinstance(reply.get("error"), str):
                raise ComponentError("PARSER_BAD_OUTPUT", "REJECTED reply without error_code/error text")
        else:
            raise ComponentError("PARSER_BAD_OUTPUT", "parser reply has an unknown status")
        return reply


# --------------------------------------------------------------------------- results

@dataclass(frozen=True)
class PipelineResult:
    command_id: str | None
    stage: str
    parsed_command: ParsedCommand | None = None
    simulation: SimulationResult | None = None
    error_code: str | None = None
    error: str | None = None
    parse_ms: float = 0.0
    simulate_ms: float = 0.0
    total_ms: float = 0.0

    def to_dict(self) -> dict[str, Any]:
        return {
            "command_id": self.command_id, "stage": self.stage,
            "parsed_command": self.parsed_command.to_dict() if self.parsed_command else None,
            "simulation": self.simulation.to_dict() if self.simulation else None,
            "error_code": self.error_code, "error": self.error,
            "timings_ms": {"parse": round(self.parse_ms, 3), "simulate": round(self.simulate_ms, 3),
                           "total": round(self.total_ms, 3)},
        }


def _short(text: str) -> str:
    cleaned = "".join(c if c.isprintable() else "?" for c in text)
    return cleaned[:MAX_TEXT]


def _simulate_with_timeout(command: ParsedCommand, config: SafetyConfig, state: PipelineState, model: PipelineModel,
                           solver: Callable, timeout_s: float) -> SimulationResult:
    holder: dict[str, SimulationResult] = {}

    def work() -> None:
        holder["r"] = simulate_command(command, config, state, model, solver)

    thread = threading.Thread(target=work, daemon=True)
    thread.start()
    thread.join(timeout_s)
    if "r" in holder:
        return holder["r"]
    return SimulationResult(
        command_id=command.command_id, simulation_status="TIMEOUT", pressure_unit=config.pressure.unit,
        configured_min_pressure=config.pressure.minimum, configured_max_pressure=config.pressure.maximum,
        violations=(), error=f"simulation did not finish within {timeout_s * 1000:.0f} ms")


class Pipeline:
    """frame -> parser -> simulator. Never raises for bad frames or failed components."""

    def __init__(self, config: SafetyConfig, parser_argv: Sequence[str] | None = None,
                 state: PipelineState = DEFAULT_STATE, model: PipelineModel = DEFAULT_MODEL,
                 solver: Callable = solve_operating_point, parser_timeout_ms: int | None = None,
                 simulation_timeout_ms: int | None = None) -> None:
        if parser_argv is None:
            cli = find_parser_cli()
            parser_argv = [str(cli)] if cli else ["voltguard_parser_cli-not-built"]
        self.config, self.state, self.model, self.solver = config, state, model, solver
        self.parser = ParserProcess(parser_argv)
        self.parser_timeout_s = (parser_timeout_ms or config.timeouts_ms["parser"]) / 1000.0
        self.simulation_timeout_s = (simulation_timeout_ms or config.timeouts_ms["simulation"]) / 1000.0

    def close(self) -> None:
        self.parser.stop()

    def __enter__(self) -> "Pipeline":
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()

    # ------------------------------------------------------------------
    def process_frame(self, command_id: Any, frame: Any) -> PipelineResult:
        t0 = time.perf_counter()

        def finish(**kw: Any) -> PipelineResult:
            kw.setdefault("total_ms", (time.perf_counter() - t0) * 1000.0)
            result = PipelineResult(**kw)
            if result.stage == STAGE_COMPONENT_FAILURE:
                log.error("command %s: component failure %s: %s", result.command_id, result.error_code, result.error)
            return result

        if not isinstance(command_id, str) or not COMMAND_ID_PATTERN.fullmatch(command_id):
            return finish(command_id=None, stage=STAGE_COMPONENT_FAILURE, error_code="INVALID_COMMAND_ID",
                          error="command id must match [A-Za-z0-9_.-]{1,64}")
        if not isinstance(frame, (bytes, bytearray)):
            return finish(command_id=command_id, stage=STAGE_COMPONENT_FAILURE, error_code="INVALID_FRAME",
                          error="frame must be bytes")
        if len(frame) > MAX_FRAME_BYTES:
            return finish(command_id=command_id, stage=STAGE_PARSE_REJECTED, error_code="FRAME_TOO_LARGE",
                          error="frame too large")

        # ---- stage 1: parser
        t_parse = time.perf_counter()
        try:
            reply = self.parser.request(command_id, bytes(frame).hex(), self.parser_timeout_s)
        except ComponentError as exc:
            return finish(command_id=command_id, stage=STAGE_COMPONENT_FAILURE, error_code=exc.code,
                          error=exc.message, parse_ms=(time.perf_counter() - t_parse) * 1000.0)
        except Exception as exc:  # noqa: BLE001 - nothing may escape: fail closed
            self.parser.stop()
            return finish(command_id=command_id, stage=STAGE_COMPONENT_FAILURE, error_code="PARSER_ERROR",
                          error=f"unexpected parser bridge error: {type(exc).__name__}",
                          parse_ms=(time.perf_counter() - t_parse) * 1000.0)
        parse_ms = (time.perf_counter() - t_parse) * 1000.0

        if reply["status"] == "REJECTED":
            return finish(command_id=command_id, stage=STAGE_PARSE_REJECTED, error_code=_short(reply["error_code"]),
                          error=_short(reply["error"]), parse_ms=parse_ms)

        try:
            parsed = ParsedCommand.from_dict(reply["command"])
            if parsed.command_id != command_id:
                raise SchemaError("command_id inside the parsed command does not match the request")
        except SchemaError as exc:
            return finish(command_id=command_id, stage=STAGE_COMPONENT_FAILURE, error_code="PARSER_SCHEMA_ERROR",
                          error=_short(f"parser output violates the ParsedCommand schema: {exc}"), parse_ms=parse_ms)

        # ---- stage 2: physics simulation
        t_sim = time.perf_counter()
        try:
            simulation = _simulate_with_timeout(parsed, self.config, self.state, self.model, self.solver,
                                                self.simulation_timeout_s)
        except Exception as exc:  # noqa: BLE001
            return finish(command_id=command_id, stage=STAGE_COMPONENT_FAILURE, error_code="SIMULATOR_ERROR",
                          error=f"unexpected simulator error: {type(exc).__name__}", parsed_command=parsed,
                          parse_ms=parse_ms, simulate_ms=(time.perf_counter() - t_sim) * 1000.0)
        return finish(command_id=command_id, stage=STAGE_SIMULATED, parsed_command=parsed, simulation=simulation,
                      parse_ms=parse_ms, simulate_ms=(time.perf_counter() - t_sim) * 1000.0)

    def process_many(self, items: Sequence[tuple[Any, Any]]) -> list[PipelineResult]:
        return [self.process_frame(cid, frame) for cid, frame in items]


# --------------------------------------------------------------------------- command line

MAX_INPUT_MESSAGES = 100_000
MAX_INPUT_BYTES = 64 * 1024 * 1024


def load_traffic_file(path: Path) -> list[tuple[str, bytes, str]]:
    """Read a traffic file written by traffic_generator. Returns (command_id, frame, label) triples."""
    try:
        if path.stat().st_size > MAX_INPUT_BYTES:
            raise ValueError("input file too large")
        document = json.loads(path.read_text(encoding="utf-8"))
        messages = document["messages"]
        if document.get("format_version") != 1 or not isinstance(messages, list) or len(messages) > MAX_INPUT_MESSAGES:
            raise ValueError("unsupported traffic file")
        out = []
        for m in messages:
            out.append((m["command_id"], bytes.fromhex(m["frame_hex"]), str(m.get("scenario", ""))))
        return out
    except (OSError, ValueError, KeyError, TypeError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError(f"cannot read traffic file '{path}': {exc}") from exc


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Run mock traffic through the C++ parser and the physics simulation (no decisions yet).")
    ap.add_argument("--input", type=Path, required=True, help="traffic file from traffic_generator")
    ap.add_argument("--config", type=Path, default=ROOT / "config" / "safety_limits.json")
    ap.add_argument("--parser-cli", type=Path, help="path to voltguard_parser_cli (default: auto-detect)")
    ap.add_argument("--output", type=Path, help="write all results as JSON to this file")
    args = ap.parse_args(argv)

    logger = setup_logger("voltguard.pipeline", log_dir=ROOT / "logs", console=False)
    try:
        config = load_safety_config(args.config)
        traffic = load_traffic_file(args.input)
    except (ConfigError, ValueError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    cli = args.parser_cli or find_parser_cli()
    if cli is None or not Path(cli).is_file():
        print("error: parser executable not found; build it with: cmake -S . -B build && cmake --build build", file=sys.stderr)
        return 2

    failures = 0
    results = []
    with Pipeline(config, parser_argv=[str(cli)]) as pipeline:
        for command_id, frame, label in traffic:
            r = pipeline.process_frame(command_id, frame)
            results.append(r)
            failures += r.stage == STAGE_COMPONENT_FAILURE
            if r.stage == STAGE_SIMULATED:
                s = r.simulation
                detail = (f"P={s.predicted_pressure} {s.pressure_unit} Q={s.predicted_flow} {s.flow_unit} violations="
                          f"{','.join(v.type for v in s.violations) or '-'}") if s.simulation_status == "SUCCESS" \
                    else f"{s.simulation_status}: {s.error}"
            else:
                detail = f"{r.error_code}: {r.error}"
            print(f"{r.command_id or '-':10} {label:34} {r.stage:18} {detail}")
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps({"results": [r.to_dict() for r in results]}, indent=2) + "\n", encoding="utf-8")
    logger.info("pipeline run: %d message(s), %d component failure(s)", len(results), failures)
    print(f"{len(results)} message(s) processed, {failures} component failure(s). Simulated values only; no allow/block decision is made by this command (the dashboard worker adds one).")
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
