"""Mock pipeline register map (shared by the traffic generator and, later, the physics engine).

This is an invented map for the simulated water-treatment pipeline; it does not
correspond to any real PLC. Values are stored as plain integers in the register.
"""

PUMP_SPEED_REGISTER = 100       # pump speed, percent of nominal (valid 0..100)
VALVE_POSITION_REGISTER = 101   # valve opening, percent (valid 0..100)

REGISTER_NAMES = {
    PUMP_SPEED_REGISTER: "pump_speed",
    VALVE_POSITION_REGISTER: "valve_position",
}
REGISTER_UNIT = "percent"
MAX_PERCENT = 100
