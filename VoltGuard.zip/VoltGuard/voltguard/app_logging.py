"""Basic application logger (console + rotating file).

Named app_logging (not logging) so it can never shadow the standard library.
Structured per-command event logging is a later phase (Phase 9).
"""

from __future__ import annotations

import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path

LOG_FORMAT = "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
LOG_FILE_NAME = "voltguard.log"
MAX_LOG_BYTES = 1_000_000
BACKUP_COUNT = 3


def setup_logger(name: str = "voltguard", log_dir: str | Path | None = None,
                 level: int = logging.INFO, console: bool = True) -> logging.Logger:
    """Create (or reconfigure) a logger. Safe to call repeatedly: handlers are not duplicated."""
    logger = logging.getLogger(name)
    logger.setLevel(level)
    logger.propagate = False

    # Remove handlers from a previous call so repeated setup does not duplicate output.
    for handler in list(logger.handlers):
        logger.removeHandler(handler)
        handler.close()

    formatter = logging.Formatter(LOG_FORMAT)

    if console:
        stream = logging.StreamHandler()
        stream.setFormatter(formatter)
        logger.addHandler(stream)

    if log_dir is not None:
        directory = Path(log_dir)
        directory.mkdir(parents=True, exist_ok=True)
        file_handler = RotatingFileHandler(
            directory / LOG_FILE_NAME, maxBytes=MAX_LOG_BYTES,
            backupCount=BACKUP_COUNT, encoding="utf-8",
        )
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)

    return logger
