"""VoltGuard: Physics-Aware Industrial Network Security (simulation prototype)."""

__version__ = "0.1.0"
