"""Loading and validation of the VoltGuard safety configuration.

The configuration is untrusted input: every field is type- and range-checked and
any problem raises ConfigError. Callers must treat a ConfigError as "no safe
configuration available" and fail closed.
"""

from __future__ import annotations

import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

MAX_CONFIG_BYTES = 64 * 1024  # a safety config this large is almost certainly wrong
SUPPORTED_SCHEMA_VERSION = 1
REQUIRED_LIMITS = ("pressure", "flow", "pump_speed", "valve_position")
REQUIRED_TIMEOUTS = ("parser", "simulation", "decision")
MAX_TIMEOUT_MS = 60_000


class ConfigError(ValueError):
    """Raised when the configuration file is missing, malformed or unsafe."""


@dataclass(frozen=True)
class Limit:
    """Inclusive [minimum, maximum] range for one physical quantity."""

    minimum: float
    maximum: float
    unit: str

    def contains(self, value: float) -> bool:
        return self.minimum <= value <= self.maximum


@dataclass(frozen=True)
class SafetyConfig:
    schema_version: int
    description: str
    pressure: Limit
    flow: Limit
    pump_speed: Limit
    valve_position: Limit
    timeouts_ms: Mapping[str, int]


def _require_mapping(value: Any, where: str) -> Mapping[str, Any]:
    if not isinstance(value, dict):
        raise ConfigError(f"{where} must be a JSON object")
    return value


def _require_number(value: Any, where: str) -> float:
    # bool is a subclass of int in Python; reject it explicitly.
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ConfigError(f"{where} must be a number")
    number = float(value)
    if not math.isfinite(number):
        raise ConfigError(f"{where} must be finite")
    return number


def _parse_limit(name: str, limits: Mapping[str, Any], units: Mapping[str, Any]) -> Limit:
    if name not in limits:
        raise ConfigError(f"limits.{name} is missing")
    entry = _require_mapping(limits[name], f"limits.{name}")
    for key in ("min", "max"):
        if key not in entry:
            raise ConfigError(f"limits.{name}.{key} is missing")
    minimum = _require_number(entry["min"], f"limits.{name}.min")
    maximum = _require_number(entry["max"], f"limits.{name}.max")
    if minimum >= maximum:
        raise ConfigError(f"limits.{name}: min ({minimum}) must be less than max ({maximum})")
    unit = units.get(name)
    if not isinstance(unit, str) or not unit.strip():
        raise ConfigError(f"units.{name} must be a non-empty string")
    return Limit(minimum=minimum, maximum=maximum, unit=unit)


def parse_safety_config(data: Any) -> SafetyConfig:
    """Validate an already-decoded JSON document and build a SafetyConfig."""
    root = _require_mapping(data, "configuration root")

    version = root.get("schema_version")
    if isinstance(version, bool) or version != SUPPORTED_SCHEMA_VERSION:
        raise ConfigError(f"unsupported schema_version {version!r}; expected {SUPPORTED_SCHEMA_VERSION}")

    units = _require_mapping(root.get("units"), "units")
    limits = _require_mapping(root.get("limits"), "limits")
    limit_values = {name: _parse_limit(name, limits, units) for name in REQUIRED_LIMITS}

    # Pump speed and valve position are percentages; reject physically meaningless ranges.
    for name in ("pump_speed", "valve_position"):
        lim = limit_values[name]
        if lim.minimum < 0.0 or lim.maximum > 100.0:
            raise ConfigError(f"limits.{name} must lie within 0..100 percent")

    timeouts_raw = _require_mapping(root.get("timeouts_ms"), "timeouts_ms")
    timeouts: dict[str, int] = {}
    for name in REQUIRED_TIMEOUTS:
        if name not in timeouts_raw:
            raise ConfigError(f"timeouts_ms.{name} is missing")
        value = timeouts_raw[name]
        if isinstance(value, bool) or not isinstance(value, int):
            raise ConfigError(f"timeouts_ms.{name} must be an integer")
        if not 0 < value <= MAX_TIMEOUT_MS:
            raise ConfigError(f"timeouts_ms.{name} must be between 1 and {MAX_TIMEOUT_MS}")
        timeouts[name] = value

    description = root.get("description", "")
    if not isinstance(description, str):
        raise ConfigError("description must be a string")

    return SafetyConfig(
        schema_version=SUPPORTED_SCHEMA_VERSION,
        description=description,
        pressure=limit_values["pressure"],
        flow=limit_values["flow"],
        pump_speed=limit_values["pump_speed"],
        valve_position=limit_values["valve_position"],
        timeouts_ms=timeouts,
    )


def load_safety_config(path: str | Path) -> SafetyConfig:
    """Read, size-check, decode and validate the safety configuration file."""
    file_path = Path(path)
    try:
        size = file_path.stat().st_size
    except OSError as exc:
        raise ConfigError(f"cannot read configuration '{file_path}': {exc.strerror or exc}") from exc
    if size > MAX_CONFIG_BYTES:
        raise ConfigError(f"configuration '{file_path}' is too large ({size} bytes)")
    try:
        text = file_path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError) as exc:
        raise ConfigError(f"cannot read configuration '{file_path}': {exc}") from exc
    try:
        data = json.loads(text)
    except json.JSONDecodeError as exc:
        raise ConfigError(f"configuration '{file_path}' is not valid JSON: {exc}") from exc
    return parse_safety_config(data)
