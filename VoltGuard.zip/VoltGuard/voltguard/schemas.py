"""Message contracts exchanged between VoltGuard components (Phase 2).

Three messages flow through the pipeline:

    ParsedCommand  (C++ parser)    -> physics engine
    SimulationResult (physics)     -> decision engine
    DecisionResult (decision)      -> logger / dashboard

All incoming data is untrusted. Each ``from_dict`` validates strictly (exact key
sets, exact types, finite numbers, value ranges) and raises SchemaError on any
problem. Callers must treat SchemaError as "no valid message" and fail closed.
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass
from typing import Any, Mapping

PROTOCOL = "Modbus/TCP"
COMMAND_ID_PATTERN = re.compile(r"^[A-Za-z0-9_.-]{1,64}$")
MAX_TEXT_LENGTH = 512

FC_READ_HOLDING = 3
FC_WRITE_SINGLE = 6
FC_WRITE_MULTIPLE = 16
SUPPORTED_FUNCTION_CODES = (FC_READ_HOLDING, FC_WRITE_SINGLE, FC_WRITE_MULTIPLE)

MAX_READ_QUANTITY = 125   # Modbus limit for function 3
MAX_WRITE_QUANTITY = 123  # Modbus limit for function 16

SIMULATION_STATUSES = ("SUCCESS", "INVALID_INPUT", "ERROR", "TIMEOUT")
DECISIONS = ("ALLOW", "BLOCK", "REJECT")
VIOLATION_TYPES = ("PRESSURE_HIGH", "PRESSURE_LOW", "FLOW_HIGH", "FLOW_LOW")


class SchemaError(ValueError):
    """Raised when a message does not conform to its contract."""


# --------------------------------------------------------------------------- helpers

def _mapping(data: Any, where: str) -> Mapping[str, Any]:
    if not isinstance(data, dict):
        raise SchemaError(f"{where} must be a JSON object")
    return data


def _check_keys(data: Mapping[str, Any], required: set[str], optional: set[str], where: str) -> None:
    missing = required - data.keys()
    if missing:
        raise SchemaError(f"{where}: missing field(s) {sorted(missing)}")
    unknown = data.keys() - required - optional
    if unknown:
        raise SchemaError(f"{where}: unknown field(s) {sorted(unknown)}")


def _int(value: Any, where: str, lo: int, hi: int) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise SchemaError(f"{where} must be an integer")
    if not lo <= value <= hi:
        raise SchemaError(f"{where} must be between {lo} and {hi}")
    return value


def _number(value: Any, where: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise SchemaError(f"{where} must be a number")
    number = float(value)
    if not math.isfinite(number):
        raise SchemaError(f"{where} must be finite")
    return number


def _text(value: Any, where: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise SchemaError(f"{where} must be a non-empty string")
    if len(value) > MAX_TEXT_LENGTH:
        raise SchemaError(f"{where} exceeds {MAX_TEXT_LENGTH} characters")
    return value


def _command_id(value: Any) -> str:
    # fullmatch, not match: "$" would otherwise accept a trailing newline.
    if not isinstance(value, str) or not COMMAND_ID_PATTERN.fullmatch(value):
        raise SchemaError("command_id must match [A-Za-z0-9_.-]{1,64}")
    return value


def _choice(value: Any, where: str, allowed: tuple[str, ...]) -> str:
    if not isinstance(value, str) or value not in allowed:
        raise SchemaError(f"{where} must be one of {list(allowed)}")
    return value


# --------------------------------------------------------------------------- ParsedCommand

@dataclass(frozen=True)
class ParsedCommand:
    """A structurally valid Modbus/TCP request as produced by the packet parser.

    Fields not used by the function code are None:
      FC 3  (read holding registers):  register_address, quantity
      FC 6  (write single register):   register_address, register_value
      FC 16 (write multiple registers): register_address, quantity, register_values
    """

    command_id: str
    transaction_id: int
    unit_id: int
    function_code: int
    register_address: int
    register_value: int | None = None
    quantity: int | None = None
    register_values: tuple[int, ...] | None = None
    protocol: str = PROTOCOL

    @classmethod
    def from_dict(cls, data: Any) -> "ParsedCommand":
        d = _mapping(data, "ParsedCommand")
        common = {"command_id", "protocol", "transaction_id", "unit_id", "function_code", "register_address"}
        if "function_code" not in d:
            raise SchemaError("ParsedCommand: missing field(s) ['function_code']")
        fc = _int(d["function_code"], "function_code", 0, 255)
        if fc not in SUPPORTED_FUNCTION_CODES:
            raise SchemaError(f"unsupported function_code {fc}; supported: {list(SUPPORTED_FUNCTION_CODES)}")
        extra = {FC_READ_HOLDING: {"quantity"},
                 FC_WRITE_SINGLE: {"register_value"},
                 FC_WRITE_MULTIPLE: {"quantity", "register_values"}}[fc]
        _check_keys(d, common | extra, set(), "ParsedCommand")

        if d["protocol"] != PROTOCOL:
            raise SchemaError(f"protocol must be '{PROTOCOL}'")
        kwargs: dict[str, Any] = dict(
            command_id=_command_id(d["command_id"]),
            transaction_id=_int(d["transaction_id"], "transaction_id", 0, 0xFFFF),
            unit_id=_int(d["unit_id"], "unit_id", 0, 255),
            function_code=fc,
            register_address=_int(d["register_address"], "register_address", 0, 0xFFFF),
        )
        if fc == FC_WRITE_SINGLE:
            kwargs["register_value"] = _int(d["register_value"], "register_value", 0, 0xFFFF)
        elif fc == FC_READ_HOLDING:
            kwargs["quantity"] = _int(d["quantity"], "quantity", 1, MAX_READ_QUANTITY)
        else:
            qty = _int(d["quantity"], "quantity", 1, MAX_WRITE_QUANTITY)
            values = d["register_values"]
            if not isinstance(values, list) or len(values) != qty:
                raise SchemaError("register_values must be a list whose length equals quantity")
            kwargs["quantity"] = qty
            kwargs["register_values"] = tuple(
                _int(v, f"register_values[{i}]", 0, 0xFFFF) for i, v in enumerate(values))
        if kwargs["register_address"] + kwargs.get("quantity", 1) - 1 > 0xFFFF:
            raise SchemaError("register range exceeds address space (0..65535)")
        return cls(**kwargs)

    def to_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {
            "command_id": self.command_id, "protocol": self.protocol,
            "transaction_id": self.transaction_id, "unit_id": self.unit_id,
            "function_code": self.function_code, "register_address": self.register_address,
        }
        if self.register_value is not None:
            out["register_value"] = self.register_value
        if self.quantity is not None:
            out["quantity"] = self.quantity
        if self.register_values is not None:
            out["register_values"] = list(self.register_values)
        return out


# --------------------------------------------------------------------------- SimulationResult

@dataclass(frozen=True)
class Violation:
    type: str
    limit: float
    predicted: float

    @classmethod
    def from_dict(cls, data: Any) -> "Violation":
        d = _mapping(data, "violation")
        _check_keys(d, {"type", "limit", "predicted"}, set(), "violation")
        vtype = _choice(d["type"], "violation.type", VIOLATION_TYPES)
        limit = _number(d["limit"], "violation.limit")
        predicted = _number(d["predicted"], "violation.predicted")
        # A violation must actually be a violation; contradictory data is rejected.
        if vtype.endswith("_HIGH") and not predicted > limit:
            raise SchemaError(f"{vtype}: predicted {predicted} does not exceed limit {limit}")
        if vtype.endswith("_LOW") and not predicted < limit:
            raise SchemaError(f"{vtype}: predicted {predicted} is not below limit {limit}")
        return cls(vtype, limit, predicted)

    def to_dict(self) -> dict[str, Any]:
        return {"type": self.type, "limit": self.limit, "predicted": self.predicted}


@dataclass(frozen=True)
class SimulationResult:
    """Outcome of the physics simulation for one command.

    SUCCESS requires predicted_pressure and predicted_flow.
    Any other status requires an error message, no predictions and no violations.
    """

    command_id: str
    simulation_status: str
    pressure_unit: str
    configured_min_pressure: float
    configured_max_pressure: float
    violations: tuple[Violation, ...] = ()
    predicted_pressure: float | None = None
    predicted_flow: float | None = None
    flow_unit: str | None = None
    error: str | None = None

    @classmethod
    def from_dict(cls, data: Any) -> "SimulationResult":
        d = _mapping(data, "SimulationResult")
        required = {"command_id", "simulation_status", "pressure_unit",
                    "configured_min_pressure", "configured_max_pressure", "violations"}
        optional = {"predicted_pressure", "predicted_flow", "flow_unit", "error"}
        _check_keys(d, required, optional, "SimulationResult")

        status = _choice(d["simulation_status"], "simulation_status", SIMULATION_STATUSES)
        min_p = _number(d["configured_min_pressure"], "configured_min_pressure")
        max_p = _number(d["configured_max_pressure"], "configured_max_pressure")
        if min_p >= max_p:
            raise SchemaError("configured_min_pressure must be less than configured_max_pressure")
        raw_violations = d["violations"]
        if not isinstance(raw_violations, list):
            raise SchemaError("violations must be a list")
        violations = tuple(Violation.from_dict(v) for v in raw_violations)

        pressure, flow, flow_unit, error = (d.get(k) for k in
                                            ("predicted_pressure", "predicted_flow", "flow_unit", "error"))
        if status == "SUCCESS":
            if pressure is None or flow is None or flow_unit is None:
                raise SchemaError("SUCCESS requires predicted_pressure, predicted_flow and flow_unit")
            if error is not None:
                raise SchemaError("SUCCESS must not carry an error")
            pressure = _number(pressure, "predicted_pressure")
            flow = _number(flow, "predicted_flow")
            flow_unit = _text(flow_unit, "flow_unit")
        else:
            if error is None:
                raise SchemaError(f"{status} requires an error message")
            if pressure is not None or flow is not None or violations:
                raise SchemaError(f"{status} must not carry predictions or violations")
            error = _text(error, "error")
            flow_unit = None if flow_unit is None else _text(flow_unit, "flow_unit")
        return cls(
            command_id=_command_id(d["command_id"]), simulation_status=status,
            pressure_unit=_text(d["pressure_unit"], "pressure_unit"),
            configured_min_pressure=min_p, configured_max_pressure=max_p,
            violations=violations, predicted_pressure=pressure, predicted_flow=flow,
            flow_unit=flow_unit, error=error,
        )

    def to_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {
            "command_id": self.command_id, "simulation_status": self.simulation_status,
            "pressure_unit": self.pressure_unit,
            "configured_min_pressure": self.configured_min_pressure,
            "configured_max_pressure": self.configured_max_pressure,
            "violations": [v.to_dict() for v in self.violations],
        }
        for key in ("predicted_pressure", "predicted_flow", "flow_unit", "error"):
            value = getattr(self, key)
            if value is not None:
                out[key] = value
        return out


# --------------------------------------------------------------------------- DecisionResult

@dataclass(frozen=True)
class DecisionResult:
    """Final allow/block/reject verdict for one command, with an explanation.

    REJECT is used for malformed or unprocessable input; BLOCK for commands whose
    predicted physical effect violates the configured policy.
    """

    command_id: str
    decision: str
    reason: str
    predicted_pressure: float | None = None
    configured_max_pressure: float | None = None

    @classmethod
    def from_dict(cls, data: Any) -> "DecisionResult":
        d = _mapping(data, "DecisionResult")
        _check_keys(d, {"command_id", "decision", "reason"},
                    {"predicted_pressure", "configured_max_pressure"}, "DecisionResult")
        pressure = d.get("predicted_pressure")
        max_p = d.get("configured_max_pressure")
        return cls(
            command_id=_command_id(d["command_id"]),
            decision=_choice(d["decision"], "decision", DECISIONS),
            reason=_text(d["reason"], "reason"),
            predicted_pressure=None if pressure is None else _number(pressure, "predicted_pressure"),
            configured_max_pressure=None if max_p is None else _number(max_p, "configured_max_pressure"),
        )

    def to_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {"command_id": self.command_id, "decision": self.decision,
                               "reason": self.reason}
        if self.predicted_pressure is not None:
            out["predicted_pressure"] = self.predicted_pressure
        if self.configured_max_pressure is not None:
            out["configured_max_pressure"] = self.configured_max_pressure
        return out
