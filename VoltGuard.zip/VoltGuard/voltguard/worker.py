"""Dashboard worker (Phase 8): a JSON-lines front end to the parser-to-simulation pipeline.

The Qt dashboard starts this as a child process (fixed argument list, no shell) and talks to it over
stdin/stdout, so the GUI thread never runs parser or simulation code. One JSON object per line.

Event log (Phase 9): every processed command is stored by event_logging.EventStore; replies carry "logged".
  {"op":"events","limit":N,"severity":S}  ->  {"type":"events","total":n,"events":[...]}   {"op":"verify_log"}  ->  {"type":"log_verification",...}
  {"op":"export","format":"csv|json|pdf","path":P,"severity":S?,"overwrite":bool?}  ->  {"type":"export","ok":bool,...}  (Phase 15)

Requests (stdin)                                   Replies (stdout)
  {"op":"process","command_id":ID,"frame_hex":H}   {"type":"result","timestamp_utc":...,<PipelineResult>}
  {"op":"scenarios"}                               {"type":"scenarios","scenarios":[{name,description,intent,frame_hex}]}
  {"op":"shutdown"}                                (worker exits 0)
  anything invalid                                 {"type":"error","command_id":ID|null,"error":TEXT}
On start the worker prints {"type":"ready",...} (version, configuration, parser availability) or
{"type":"fatal","error":TEXT} and exits 2 if the safety configuration is invalid (fail closed).

stdout carries protocol lines only; diagnostics go to logs/. Results are SIMULATED values: this worker
takes its allow/block/reject decision from the Rust decision engine via voltguard.decision_bridge (Phase 11; fail closed).
"""

from __future__ import annotations

import argparse
import datetime
import json
import logging
import re
import sys
from pathlib import Path
from typing import Any

if __name__ == "__main__" and __package__ in (None, ""):
    # Started as a plain file (for example with an editor's Run button) instead of `python -m ...`: Python then puts
    # this file's own folder on sys.path, so the project packages cannot be found. Use the project root instead.
    sys.path[0:1] = [str(Path(__file__).resolve().parent.parent)]

from voltguard import __version__
from voltguard.app_logging import setup_logger
from event_logging.event_store import EventStore, EventStoreError, SEVERITIES, UnavailableStore
from event_logging.export import ExportError, export_events
from voltguard.decision_bridge import Decider, fail_closed_decision, find_decision_engine
from voltguard.config import ConfigError, SafetyConfig, load_safety_config
from voltguard.pipeline import ROOT, Pipeline, find_parser_cli
from voltguard.schemas import COMMAND_ID_PATTERN
from traffic_generator.generate_traffic import generate_scenarios

MAX_REQUEST_BYTES = 64 * 1024
MAX_FRAME_HEX_CHARS = 4000          # 2000 bytes; the pipeline itself rejects frames over 1000 bytes
HEX_ONLY = re.compile(r"[0-9a-fA-F]*")
NOTICE = ("Values are SIMULATED. ALLOW/BLOCK/REJECT come from the decision engine and mean what the policy says about a "
          "simulated prediction; nothing is forwarded to any device.")


def config_to_dict(config: SafetyConfig) -> dict[str, Any]:
    def lim(limit) -> dict[str, Any]:
        return {"min": limit.minimum, "max": limit.maximum, "unit": limit.unit}

    return {"description": config.description, "pressure": lim(config.pressure), "flow": lim(config.flow),
            "pump_speed": lim(config.pump_speed), "valve_position": lim(config.valve_position),
            "timeouts_ms": dict(config.timeouts_ms)}


def _error(message: str, command_id: Any = None) -> dict[str, Any]:
    valid = isinstance(command_id, str) and COMMAND_ID_PATTERN.fullmatch(command_id)
    return {"type": "error", "command_id": command_id if valid else None, "error": message}


EVENT_COLUMNS = ("id", "timestamp_utc", "command_id", "source", "stage", "severity", "sim_status", "function_code",
                  "register_address", "predicted_pressure", "predicted_flow", "violations", "error_code", "error",
                  "decision", "decision_reason", "decision_source")


def handle_request(pipeline: Pipeline, scenarios: list[dict[str, Any]], request: Any,
                   store: EventStore | UnavailableStore | None = None, decider: Decider | None = None) -> dict[str, Any] | None:
    """Reply for one decoded request; None means shut down. `store` (optional) receives one event per command."""
    if not isinstance(request, dict):
        return _error("request must be a JSON object")
    op = request.get("op")
    if op == "shutdown":
        return None
    if op == "scenarios":
        return {"type": "scenarios", "scenarios": scenarios}
    if op == "events":
        if store is None:
            return _error("event log is not available")
        limit, severity = request.get("limit", 100), request.get("severity")
        if not isinstance(limit, int) or isinstance(limit, bool) or limit < 1:
            return _error("limit must be a positive integer")
        if severity is not None and severity not in SEVERITIES:
            return _error("unknown severity")
        try:
            rows = store.query(limit=limit, severity=severity)
        except EventStoreError as exc:
            return _error(f"event log unavailable: {exc}"[:300])
        return {"type": "events", "total": store.count(),
                "events": [{k: r[k] for k in EVENT_COLUMNS} for r in rows]}
    if op == "verify_log":
        if store is None:
            return _error("event log is not available")
        ok, message = store.verify()
        return {"type": "log_verification", "ok": ok, "message": message}
    if op == "export":
        return _export(pipeline, store, request)
    if op != "process":
        return _error("unknown or missing op")

    command_id, frame_hex = request.get("command_id"), request.get("frame_hex")
    if not isinstance(command_id, str) or not COMMAND_ID_PATTERN.fullmatch(command_id):
        return _error("command_id must match [A-Za-z0-9_.-]{1,64}")
    if not isinstance(frame_hex, str):
        return _error("frame_hex must be a string", command_id)
    if len(frame_hex) > MAX_FRAME_HEX_CHARS:
        return _error(f"frame_hex is longer than {MAX_FRAME_HEX_CHARS} characters", command_id)
    if len(frame_hex) % 2 or not HEX_ONLY.fullmatch(frame_hex):
        return _error("frame_hex must be an even number of hexadecimal digits", command_id)

    source = request.get("source", "manual")
    if not isinstance(source, str):
        return _error("source must be a string", command_id)

    result = pipeline.process_frame(command_id, bytes.fromhex(frame_hex))
    timestamp = datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="milliseconds")
    pipeline_result = result.to_dict()
    reply = {"type": "result", "timestamp_utc": timestamp, **pipeline_result}
    decision = decider.decide(pipeline_result) if decider is not None else fail_closed_decision(
        command_id, "DECISION_ENGINE_UNAVAILABLE", "no decision engine is configured")
    reply["decision"] = decision

    # Log before allow: an ALLOW is only released after its event is stored. If the event log is switched
    # off (store is None) nothing is stored; if it is configured but fails, the ALLOW becomes a REJECT.
    logged = _store_event(store, reply, source, frame_hex, timestamp, decision)
    # Only an explicit True counts as stored: False, None-from-a-store, an exception or any other value is "not stored".
    if decision["decision"] == "ALLOW" and store is not None and logged is not True:
        decision = fail_closed_decision(command_id, "EVENT_LOG_UNAVAILABLE",
                                        "the event log could not store this command, so it is not allowed")
        reply["decision"] = decision
        logged = _store_event(store, reply, source, frame_hex, timestamp, decision)    # best effort: record the refusal
    # None = event log switched off; False = the event could NOT be stored (never silently dropped).
    reply["logged"] = logged
    return reply


def _export(pipeline: Pipeline, store: Any, request: dict[str, Any]) -> dict[str, Any]:
    """{"op":"export","format":"csv|json|pdf","path":P,"severity":S?,"overwrite":bool?} -> {"type":"export","ok":...}.

    The path is chosen by the person using the dashboard (never taken from logged data). A refusal or a failure
    is reported with ok=false and leaves no file behind."""
    def refuse(message: str) -> dict[str, Any]:
        return {"type": "export", "ok": False, "error": message[:300]}

    if store is None or not hasattr(store, "export_rows"):
        return refuse("event log is not available")
    fmt, path, severity, overwrite = request.get("format"), request.get("path"), request.get("severity"), request.get("overwrite", False)
    if not isinstance(fmt, str) or not isinstance(path, str) or not path or len(path) > 4096 or "\x00" in path:
        return refuse("format and path must be strings (path at most 4096 characters)")
    if severity is not None and not isinstance(severity, str):
        return refuse("severity must be a string")
    if not isinstance(overwrite, bool):
        return refuse("overwrite must be true or false")
    try:
        result = export_events(store, path, fmt, severity=severity, overwrite=overwrite, safety_config=pipeline.config)
    except ExportError as exc:
        return refuse(str(exc))
    except Exception as exc:  # noqa: BLE001 - the worker must survive and say so
        logging.getLogger("voltguard").exception("export failed")
        return refuse(f"export failed: {type(exc).__name__}")
    return {"type": "export", "ok": True, "path": str(result.path), "format": result.format, "rows": result.rows,
            "total": result.total_matching, "truncated": result.truncated, "verified": result.verified,
            "message": result.verify_message[:300]}


def _store_event(store: Any, reply: dict[str, Any], source: str, frame_hex: str, timestamp: str,
                 decision: dict[str, Any]) -> bool | None:
    """Store one event. None = logging is switched off; True = stored; False = NOT stored (never raises, never other values)."""
    if store is None:
        return None
    try:
        return store.record(reply, source, frame_hex, timestamp, decision) is True
    except Exception:  # noqa: BLE001 - a logging failure must never escape or be mistaken for success
        logging.getLogger("voltguard").exception("event log write raised")
        return False


def _write(obj: dict[str, Any]) -> bool:
    try:
        sys.stdout.write(json.dumps(obj, separators=(",", ":")) + "\n")
        sys.stdout.flush()
        return True
    except (BrokenPipeError, OSError, ValueError):
        return False  # the dashboard went away


def _read_line() -> bytes | None:
    """One request line (without newline); b'' marks an over-long line (rest discarded); None is EOF."""
    stdin = sys.stdin.buffer
    line = stdin.readline(MAX_REQUEST_BYTES + 1)
    if not line:
        return None
    if len(line) > MAX_REQUEST_BYTES and not line.endswith(b"\n"):
        while True:  # discard the remainder of the oversized line
            rest = stdin.readline(MAX_REQUEST_BYTES)
            if not rest or rest.endswith(b"\n"):
                break
        return b""
    return line.rstrip(b"\r\n") or b" "


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="VoltGuard dashboard worker (JSON lines on stdin/stdout)")
    ap.add_argument("--config", type=Path, default=ROOT / "config" / "safety_limits.json")
    ap.add_argument("--parser-cli", type=Path, help="path to voltguard_parser_cli (default: auto-detect)")
    ap.add_argument("--log-dir", type=Path, default=ROOT / "logs")
    ap.add_argument("--event-db", type=Path, default=None, help="event database (default: <log-dir>/events.db)")
    ap.add_argument("--decision-engine", type=Path, default=None, help="path to voltguard_decision_engine (default: auto-detect)")
    ap.add_argument("--no-event-log", action="store_true", help="do not write the event database")
    args = ap.parse_args(argv)
    logger = setup_logger("voltguard.worker", log_dir=args.log_dir, console=False)

    try:
        config = load_safety_config(args.config)
    except ConfigError as exc:
        logger.error("invalid configuration, refusing to start: %s", exc)
        _write({"type": "fatal", "error": f"invalid safety configuration: {exc}"})
        return 2

    cli = args.parser_cli or find_parser_cli()
    parser_available = bool(cli and Path(cli).is_file())
    scenarios = [{"name": r["scenario"], "description": r["description"], "intent": r["intent"],
                  "frame_hex": r["frame_hex"]} for r in generate_scenarios()]
    pipeline = Pipeline(config, parser_argv=[str(cli)] if cli else None)
    engine_path = args.decision_engine or find_decision_engine()
    decider = Decider(config, [str(engine_path), "--config", str(args.config)] if engine_path else None)
    decision_info = {"available": decider.available, "path": str(engine_path) if engine_path else None,
                     "error": None if decider.available else decider.unavailable_reason}
    if not decider.available:
        logger.error("decision engine unavailable, every command will be REJECTED (fail closed): %s", decider.unavailable_reason)
    store: EventStore | UnavailableStore | None = None
    event_log = {"enabled": not args.no_event_log, "path": None, "ok": False, "error": None}
    if not args.no_event_log:
        event_log["path"] = str(args.event_db or args.log_dir / "events.db")
        try:
            store = EventStore(event_log["path"])
            event_log["ok"] = True
        except EventStoreError as exc:  # processing continues, but the dashboard is told that nothing is being logged
            logger.error("event log unavailable: %s", exc)
            event_log["error"] = str(exc)[:300]
            store = UnavailableStore(event_log["error"])
    if not _write({"type": "ready", "version": __version__, "config": config_to_dict(config),
                   "config_path": str(args.config), "parser_available": parser_available,
                   "parser_path": str(cli) if cli else None, "decision_engine": decision_info,
                   "event_log": event_log, "notice": NOTICE}):
        return 0
    logger.info("worker ready (parser available: %s)", parser_available)

    try:
        while True:
            raw = _read_line()
            if raw is None:
                break
            if raw == b"":
                reply: dict[str, Any] | None = _error(f"request longer than {MAX_REQUEST_BYTES} bytes")
            else:
                try:
                    request = json.loads(raw.decode("utf-8"))
                except (UnicodeDecodeError, json.JSONDecodeError, RecursionError):
                    reply = _error("request is not valid JSON")
                else:
                    try:
                        reply = handle_request(pipeline, scenarios, request, store, decider)
                    except Exception as exc:  # noqa: BLE001 - the worker must survive any request
                        logger.exception("unexpected error handling a request")
                        reply = _error(f"internal error: {type(exc).__name__}",
                                       request.get("command_id") if isinstance(request, dict) else None)
            if reply is None:
                break
            if not _write(reply):
                break
    finally:
        pipeline.close()
        decider.close()
        if store is not None:
            store.close()
    logger.info("worker stopped")
    return 0


if __name__ == "__main__":
    sys.exit(main())
