# Failure modes and outcomes (Phase 12)

Everything here concerns SIMULATED traffic. "Tested by" names tests in `tests/test_safety_invariants.py` (SI) or earlier suites. A failure never produces ALLOW.

| Failure | Where handled | Outcome | Tested by |
|---|---|---|---|
| Invalid or missing safety configuration | `voltguard/config.py`, worker, engine | worker prints `fatal`, exit 2; engine exits 2 with no output; nothing is decided | SI corrupt configuration (17 variants), missing file; Rust CLI tests |
| Parser executable missing / hangs / crashes / replies with junk, wrong id, wrong schema, over-long or extra lines | `voltguard/pipeline.py` | stage `COMPONENT_FAILURE` -> REJECT; parser restarted | SI fault matrix; `tests/test_integration.py` |
| Parser rejects a malformed frame | parser | stage `PARSE_REJECTED` -> REJECT | SI fuzz; parser tests |
| Physics solver raises, hangs, returns NaN/inf/negative/string/None | `physics_engine`, pipeline | simulation status ERROR/TIMEOUT/INVALID -> REJECT | SI fault matrix |
| Write outside the limits | engine + Python second check | BLOCK (an engine ALLOW is vetoed to REJECT) | SI sweep; unsafe command vs every faulty engine |
| Decision engine missing / hangs / crashes / replies with junk, wrong id, wrong contract, huge lines, errors | `voltguard/decision_bridge.py` | REJECT with `fail_closed` source and an error code; engine restarted | SI fault matrix; `tests/test_decision_bridge.py` |
| Engine says ALLOW for something that was not a successful simulation, or outside the limits | bridge | REJECT `DECISION_INCONSISTENT` | SI fault matrix, unsafe command test |
| Event log cannot store an event (write fails, store raises, store returns a non-True value) | worker | ALLOW becomes REJECT `EVENT_LOG_UNAVAILABLE`; BLOCK/REJECT unchanged | SI event-log tests |
| Hostile worker input (bad JSON, binary, huge lines, wrong types, hostile source text) | worker | `error` reply, worker keeps running, ids stay matched | SI hostile input; `tests/test_worker.py` |
| stdin closed mid-line | worker | complete requests answered, exit 0 | SI |

## Not covered
- Behaviour on Windows, with MSVC builds, or on real hardware.
- Resource exhaustion (disk full for real, memory pressure); a failing store is simulated.
- Coverage-guided fuzzing; the fuzz is seeded random mutation.
- A bug that the independent oracle shares with the parser (both follow the same reading of the Modbus specification).
- Anything involving real devices: none is ever contacted.
