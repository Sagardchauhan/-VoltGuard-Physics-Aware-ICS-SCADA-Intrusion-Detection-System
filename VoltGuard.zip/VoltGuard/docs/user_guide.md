# User guide: the VoltGuard dashboard

Everything the dashboard shows is a **simulated** prediction or a policy decision about one. Nothing is sent to any device. The yellow banner at the top of every tab says so.

## Starting it

```bash
cmake -S . -B build -G Ninja && cmake --build build
cargo build --release --manifest-path decision_engine/Cargo.toml
./build/dashboard/voltguard_dashboard
```

The dashboard starts the Python worker itself, so run it from a machine with the Python requirements installed (`pip install -r requirements.txt`). Options: `--python PATH`, `--project-root DIR`, `--parser-cli PATH`, `--config PATH`, `--event-db PATH` (a new file gives a clean event log; `scripts/demo.sh` does this for you). If the decision engine is not built, every command is REJECTED; the status bar shows "Decision engine: unavailable" in that case.

The bottom status bar shows the worker state, whether the parser and decision engine are available, and the reminder that all values are simulated.

## Sending commands

The row under the banner is shared by all tabs:

| Control | What it does |
|---|---|
| **Run all scenarios** | Sends the 27 built-in scenarios (6 within limits, 5 limit violations, 16 rejected before simulation) |
| scenario list + **Send scenario** | Sends one named scenario |
| hex box + **Send frame** | Sends a Modbus/TCP frame you type as hex, e.g. `00010000000601060064003c` (write pump speed to 60 %) |
| **Clear** | Clears the on-screen traffic, counters, charts and alerts. It does **not** touch the stored event log |
| **Restart worker** | Restarts the Python worker (and with it the parser and engine processes) |

## Tabs

### Dashboard
![Dashboard tab](screenshots/1_dashboard.png)

Application status (which parser, configuration, event database and decision engine are in use), counters since the last Clear (total, within limits, limit violations, rejected, component failures, and the ALLOW / BLOCK / REJECT counts) and the latest command with its decision and reason.

### Traffic
![Traffic tab](screenshots/2_traffic_and_details.png)

One row per command: time, id, source, parsed command, stage (`SIMULATED`, `PARSE_REJECTED`, `COMPONENT_FAILURE`), simulated pressure, safety status and the decision. Select a row to see the full detail on the right: parsed fields, the simulation, the decision with its reason, whether the event was stored, and timings.

- **ALLOW**: the simulated prediction is inside the example limits and every check passed.
- **BLOCK**: a well-formed write whose predicted effect violates the limits.
- **REJECT**: the command was malformed, unsupported or unprocessable, or a component failed.

BLOCK and REJECT both mean "do not forward". The exact rules are in [decision_policy.md](decision_policy.md).

### Graphs and alerts
![Graphs and alerts tab](screenshots/3_graphs_and_alerts.png)

Predicted pressure and flow of the most recent commands (up to 200) with the configured limit lines and a marker coloured by decision. The x axis is the order of plotted commands, not time. Commands without a simulation (rejected frames) are not plotted. The alert list on the right is **display-only**: it summarises BLOCKs, REJECTs and system problems such as a failed export. The **Clear** button empties it; that changes no decision and no log entry.

### Event log
![Event log tab](screenshots/4_event_log.png)

- **Load stored events** shows the newest 200 events from the persistent SQLite log, newest first.
- **Verify log integrity** checks the hash chain. It detects edits, deletions and reordering of stored rows; it does not detect removal of the newest rows.
- **Export CSV / JSON / PDF report** writes the stored events to a file you choose. Existing files are replaced only after the file dialog's own confirmation. Spreadsheet formulas in text fields are neutralised in CSV. The result line states how many events were written, whether the file is truncated (exports are capped at 100,000 rows) and whether the integrity check passed; a failed check does not stop the export, but the file is labelled accordingly. The PDF report needs the optional `reportlab` package (`pip install -r requirements-optional.txt`); without it the button reports that PDF export is unavailable.

The text area below the table is the live application log for this session.

### Configuration
![Configuration tab](screenshots/5_configuration.png)

A read-only view of `config/safety_limits.json`: the example limits and the component timeouts. To change limits, edit the file and restart the worker; an invalid file stops the worker (fail closed). Editing from the dashboard is not implemented.

## Command line alternatives

```bash
python -m traffic_generator.generate_traffic --output results/traffic.json
python -m voltguard.pipeline --input results/traffic.json          # parse + simulate (no decision)
python -m event_logging.export --db logs/events.db --format json --out results/events.json
```

## Screenshots

The screenshots in `docs/screenshots/` are produced by the application itself in a headless run, from a fresh event database:
`QT_QPA_PLATFORM=offscreen ./build/dashboard/voltguard_dashboard --screenshot-dir docs/screenshots`
They show the Linux / Qt 6.4.2 build; the look on other platforms will differ.
