# Decision policy (Phase 10, integrated in Phase 11)

`decision_engine/` is a deterministic, rule-based Rust program (no machine learning, no network, no files except the configuration it is given). It turns one **pipeline result** (parser output + physics simulation, see `integration/interfaces.md`) into a `DecisionResult`: **ALLOW**, **BLOCK** or **REJECT**.

> **What ALLOW means.** "The simulated prediction for this command is within the *example* limits in `config/safety_limits.json` and every consistency check below passed." The physics model is invented and unvalidated and the limits are illustrative, so ALLOW says nothing about safety on real equipment. This prototype is for simulated traffic only.

## Policy, in order (the first failing rule decides)

| # | Condition | Decision |
|---|---|---|
| 0 | `command_id` missing or not `[A-Za-z0-9_.-]{1,64}` | **no decision** (CLI prints an error line; the id is never echoed) |
| 1 | stage missing or unknown | REJECT |
| 2 | stage `PARSE_REJECTED` or `COMPONENT_FAILURE` (also when a simulation is wrongly attached) | REJECT |
| 3 | stage `SIMULATED` but parsed command or simulation missing / not objects | REJECT |
| 4 | command id missing or different in the parsed command or in the simulation | REJECT |
| 5 | function code not 3, 6 or 16; register address missing or outside 0..65535 | REJECT |
| 6 | write: value missing / not an integer; FC16 quantity not equal to the number of values, no values or more than 123 | REJECT |
| 7 | write: any target register other than 100 (pump speed) or 101 (valve position); any value outside that register's configured limit | REJECT |
| 8 | simulation status not `SUCCESS` (`INVALID_INPUT`, `ERROR`, `TIMEOUT`, missing, unknown) | REJECT |
| 9 | predicted pressure or flow missing, not a number, not finite | REJECT |
| 10 | the pressure limits recorded in the simulation differ from the engine's own configuration (stale or mismatched config) | REJECT |
| 11 | violation list missing / not an array | REJECT |
| 12 | **read (FC 3)** passing 1-11 | ALLOW (see "Design choices") |
| 13 | write: predicted pressure or flow outside the configured limits (the engine re-checks them itself; limits are inclusive) | **BLOCK**, reason names every violated quantity |
| 14 | write: the simulation reported a violation that the engine could not confirm | **BLOCK** (take the cautious side) |
| 15 | write: everything passed | **ALLOW** |

There is exactly one place in the code that constructs an ALLOW (`allow_outcome`); every other path returns REJECT or BLOCK. Unknown extra fields in the input are ignored; they cannot change a decision.

## Design choices you may disagree with

- **Reads are ALLOWED even if the predicted state is already outside the limits.** A read cannot change a setpoint, and operators need to observe a plant that is out of range. Everything else (consistency, status, finite values, configuration match) must still hold. Pinned by a test; change it in `evaluate()` if your policy differs.
- **BLOCK vs REJECT.** BLOCK means "well-formed command whose predicted effect violates the policy". REJECT means "malformed, unsupported, unprocessable or inconsistent input, or a component failed". Both mean "do not forward".
- **The engine does not trust the simulation.** It repeats the limit comparison and the register/value checks. If the simulation says "no violation" but the numbers are outside the limits, the engine BLOCKs. If the simulation reports a violation the engine cannot reproduce, it also BLOCKs.
- **Register map is duplicated** in Rust (`PUMP_SPEED_REGISTER`, `VALVE_POSITION_REGISTER`) on purpose (independent re-check). A test compares it with `voltguard/register_map.py`.
- **Configuration is strict and fail-closed:** schema version 1, finite numbers, `min < max`, pump/valve limits within 0..100, otherwise the CLI prints nothing and exits 2.

## Interface

```
voltguard_decision_engine --config config/safety_limits.json   < pipeline_results.jsonl   > decisions.jsonl
```
One JSON object per line in, one reply line out, in order. A reply is either a DecisionResult (`command_id`, `decision`, `reason` <= 512 printable ASCII characters, and `predicted_pressure` / `configured_max_pressure` when known) or `{"type":"error","error":TEXT}` (invalid JSON, line over 1 MB, unusable command id, internal failure). **A consumer must treat anything other than a valid DecisionResult with `ALLOW` as "do not allow".** Echoed text from the input is limited to a few printable characters and cannot forge another JSON field (tested).

## Integration (Phase 11, `voltguard/decision_bridge.py`)

The dashboard worker sends every pipeline result to the engine through `Decider`. The bridge is the engine's caller and **fails closed**:

| Situation | Final decision |
|---|---|
| engine executable not found / cannot start | REJECT, `DECISION_ENGINE_UNAVAILABLE` |
| engine crashes (restarted for the next request) | REJECT, `DECISION_ENGINE_CRASHED` |
| no reply within `timeouts_ms.decision` (100 ms; enforced by the Python caller, engine killed and restarted) | REJECT, `DECISION_TIMEOUT` |
| reply is not JSON / violates the DecisionResult contract / over-long | REJECT, `DECISION_BAD_OUTPUT` |
| reply is for a different command id | REJECT, `DECISION_ID_MISMATCH` |
| engine error line | REJECT, `DECISION_ENGINE_ERROR` |
| input cannot be serialised, has no command id or is oversized | REJECT, `DECISION_BAD_INPUT` |
| ALLOW or BLOCK for a result that is not stage SIMULATED with status SUCCESS | REJECT, `DECISION_INCONSISTENT` |
| **second opinion**: ALLOW for a write whose predicted pressure/flow is missing or outside the limits (checked again in Python) | REJECT, `DECISION_INCONSISTENT` |
| any other exception | REJECT, `DECISION_INTERNAL_ERROR` |
| the engine's own REJECT or BLOCK | passed through (`source: "engine"`) |

Fail-closed decisions carry `source: "fail_closed"` and an `error_code`; engine decisions carry `source: "engine"` and `error_code: null`.

**Log-before-allow.** If the event log is configured but the row cannot be written, an ALLOW becomes REJECT with `EVENT_LOG_UNAVAILABLE` (an allowed command with no audit trail is refused). BLOCK and REJECT are unaffected. With logging deliberately switched off (`--no-event-log`) an ALLOW stays ALLOW and the reply says `logged: null`.

### Limits of the integration
- **Nothing is forwarded to any device.** ALLOW is a recorded, displayed decision about a simulated command, nothing more.
- Allowed commands are **not applied to the simulated plant state**; every command is evaluated against the default state.
- ALLOW refers to simulated predictions from an invented model against example limits.
- The decision timeout is a wall-clock limit on the caller's wait; it has been tested with a fake hanging engine on Linux only.
- Windows/MSVC and real-display behaviour are untested.

## What is not covered

- No state: each command is judged independently. A sequence of individually allowed writes is not analysed, and the engine does not know the plant's real current state (the simulation assumes the pipeline default state).
- No authentication or authorisation of who sent a command; no protection of the transport.
- Duplicate JSON keys follow "last one wins" in both the Python producer and this engine; the engine does not detect them.
- Latency was measured in Phase 14: see docs/performance.md (target met on an idle machine, missed under CPU stress).
