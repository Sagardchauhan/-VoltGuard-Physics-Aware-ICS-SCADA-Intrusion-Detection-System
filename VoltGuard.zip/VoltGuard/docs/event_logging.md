# Event logging (Phase 9)

Every command the dashboard worker processes is stored as one row in a SQLite database (`logs/events.db` by default; `--event-db PATH` and `--no-event-log` on `python -m voltguard.worker`). Implementation: `event_logging/event_store.py`; tests: `tests/test_event_store.py` and the dashboard tests.

## What is stored

Timestamp (UTC), command id, source (scenario name or `manual`), stage, **severity**, simulation status, function code, register address, predicted pressure/flow (SIMULATED values), violations, error code/text, the frame as hex, the parsed command and simulation result as JSON, and timings.

Severity values: `WITHIN_LIMITS`, `LIMIT_VIOLATION`, `REJECTED` (parser rejection or invalid input), `SIMULATION_FAILURE`, `COMPONENT_FAILURE`. **These describe the simulation outcome. They are not allow/block decisions.** Since Phase 11 (schema version 2) each row also stores `decision` (ALLOW/BLOCK/REJECT), `decision_reason` and `decision_source` (`engine` or `fail_closed`), and these three columns are part of the hash. Rows written before the upgrade keep NULL decisions. A version-1 database is migrated when it is opened (columns added, a per-row `hash_version` recorded so old hashes still verify); `verify()` also fails if a v1 row has decision values (someone adding decisions to old rows).

## Safety properties

- All values reach SQLite through bound parameters; only constant column names are interpolated. Hostile text (`'; DROP TABLE events; --`, control characters) is stored as data and tested.
- Text is length-capped and control characters become `?`; frame hex is capped at 4000 characters, JSON blobs at 20,000 characters (replaced by a marker if larger).
- **Logging never changes a processing result, and a logging failure is never silent.** `record()` does not raise; the worker's reply carries `"logged": true | false | null` (`false` = the event could NOT be stored, `null` = logging switched off). If the database cannot be opened, the worker still starts but reports `event_log.ok = false`; the dashboard shows "NOT AVAILABLE - nothing is recorded" and marks each command "NOT STORED". Decided in Phase 11: **log-before-allow**. If logging is enabled and the write fails, an ALLOW is replaced by REJECT (`EVENT_LOG_UNAVAILABLE`); BLOCK and REJECT stay as they are, and `--no-event-log` leaves ALLOW unchanged with `logged: null`.
- Unknown stages or inconsistent results are stored as `COMPONENT_FAILURE` (fail closed in the classification).
- Schema version is stored in `meta`; an unknown version refuses to open.

## Tamper evidence (and its limits)

Each row stores `prev_hash` and `row_hash = SHA-256(prev_hash + canonical JSON of every stored field)`. `EventStore.verify()` (dashboard button "Verify log integrity", worker op `verify_log`) recomputes the chain and names the first bad row. Tests tamper with each of the hashed columns (including the three decision columns), delete and swap rows, and forge hashes.

This is **tamper-evidence, not tamper-proofing**:
- Someone who can write the database can recompute the whole chain, or delete the file.
- **Removing the newest rows (tail truncation) is not detected** (a test documents this). Detecting it would need the latest hash stored somewhere else (another host, a signed checkpoint).
- There are no signatures or keys. Do not describe this as an audit-grade or compliant log.

## Other limitations

- The log grows without bound; there is no rotation or pruning yet (pruning would also need a chain checkpoint).
- A single worker writes to the database; concurrent writers from several processes are not tested.
- The dashboard's "Clear" button clears only the on-screen table; the stored log is untouched. The dashboard loads at most the newest 200 events (the worker caps queries at 1000).
- Export (Phase 15): see "Export" below.

## Export (Phase 15)

`python -m event_logging.export --db logs/events.db --format csv|json|pdf --out FILE [--severity S] [--max-rows N] [--force]`, or the Export buttons on the dashboard's Event log tab (worker op `export`). Oldest row first; columns: id, timestamp, command id, source, stage, severity, simulation status, function code, register, predicted pressure and flow, violations, error code and text, decision, reason and source, the frame as hex and the row hash.

- The hash chain is verified first. A **failed check does not stop the export** (the evidence is wanted) but is reported (dashboard: red text and a critical alert; CLI: exit code 4; JSON `integrity.verified: false`; PDF "FAILED"). CSV has no metadata block, so the CSV file alone does not show the check result; the CLI/dashboard message does.
- CSV: text cells starting with `=`, `+`, `-`, `@`, tab or CR get a leading apostrophe so a spreadsheet does not run them as formulas; numbers are untouched. The apostrophe is part of the exported text, so a consumer that needs the exact original must strip it.
- Files: written to a temporary file in the target folder, flushed, then linked into place; an existing file is never replaced unless overwriting is requested (the dashboard allows it only after its save dialog asked the user); a failure leaves no partial file; the folder must exist; the extension must match; symbolic links and folders are refused; the path always comes from the user, never from logged data.
- At most 100,000 rows are exported; a larger log is reported as TRUNCATED (in the JSON, the PDF and the dashboard message).
- PDF (optional, needs `reportlab`, see `requirements-optional.txt`): notice that all values are simulated, integrity result, decision and severity counts, the configured limits, the first 200 exported events and a limitations paragraph. Logged text is escaped, so markup in it is printed literally.
- The export is a copy. It does not make the log more trustworthy: the same tamper-evidence limits apply, and a person who can edit the exported file can edit the numbers in it.
