# Performance (Phase 14)

Measured with `python scripts/benchmark.py` (results in `docs/performance_results.json` and, for the stress run, `docs/performance_results_loaded.json`). Simulated traffic only; one machine, one day, one run each. These numbers describe **this machine** (2-CPU virtual machine, Intel Xeon @ 2.10 GHz, Linux, Python 3.13, GCC 13 / Rust release engine). They are not a guarantee for any other machine, and say nothing about Windows.

## What is measured

Per command, with `time.perf_counter`: **parse** (frame to the C++ parser process and back, validated), **simulate** (SciPy prediction in a worker thread), **decide** (Rust engine round trip over pipes plus the Python consistency checks), **log** (one SQLite insert with hash chain, committed), and **handle** (everything the dashboard worker does for one command, which is the sum of the parts plus glue). The last row is the full round trip through the real worker process (JSON over stdin/stdout). 1,500 timed commands per workload after 100 warm-up commands (500 for the worker). Percentiles are nearest-rank.

The target from the project plan is **under 10 ms per command**. I interpret it as: p99 of `handle` is at most 10 ms. That interpretation is mine; the plan does not say which percentile.

## Result 1: idle machine

| Workload | Stage | n | mean | p50 | p95 | p99 | max |
|---|---|---|---|---|---|---|---|
| valid write (ALLOW) | parse | 1500 | 0.151 | 0.143 | 0.217 | 0.283 | 0.854 |
| valid write (ALLOW) | simulate | 1500 | 0.274 | 0.269 | 0.351 | 0.514 | 1.130 |
| valid write (ALLOW) | decide | 1500 | 0.285 | 0.279 | 0.348 | 0.438 | 6.361 |
| valid write (ALLOW) | log | 1500 | 1.470 | 1.387 | 2.032 | 3.489 | 7.576 |
| valid write (ALLOW) | handle | 1500 | 2.270 | 2.193 | 2.942 | 4.386 | 8.273 |
| unsafe write (BLOCK) | parse | 1500 | 0.139 | 0.132 | 0.190 | 0.259 | 2.325 |
| unsafe write (BLOCK) | simulate | 1500 | 0.268 | 0.263 | 0.337 | 0.498 | 2.575 |
| unsafe write (BLOCK) | decide | 1500 | 0.262 | 0.262 | 0.329 | 0.397 | 0.763 |
| unsafe write (BLOCK) | log | 1500 | 1.340 | 1.290 | 1.726 | 2.564 | 6.237 |
| unsafe write (BLOCK) | handle | 1500 | 2.091 | 2.038 | 2.603 | 3.577 | 6.880 |
| malformed frame (REJECT) | parse | 1500 | 0.137 | 0.119 | 0.198 | 0.333 | 5.744 |
| malformed frame (REJECT) | decide | 1500 | 0.197 | 0.186 | 0.266 | 0.350 | 3.240 |
| malformed frame (REJECT) | log | 1500 | 1.274 | 1.225 | 1.692 | 2.815 | 5.105 |
| malformed frame (REJECT) | handle | 1500 | 1.664 | 1.607 | 2.156 | 4.008 | 7.495 |
| all 27 scenarios, cycled | parse | 1500 | 0.130 | 0.116 | 0.194 | 0.261 | 4.593 |
| all 27 scenarios, cycled | simulate | 722 | 0.230 | 0.215 | 0.310 | 0.671 | 2.233 |
| all 27 scenarios, cycled | decide | 1500 | 0.211 | 0.202 | 0.297 | 0.369 | 1.319 |
| all 27 scenarios, cycled | log | 1500 | 1.282 | 1.227 | 1.684 | 2.609 | 5.036 |
| all 27 scenarios, cycled | handle | 1500 | 1.804 | 1.735 | 2.390 | 3.967 | 7.717 |
| real worker process | round trip | 500 | 2.016 | 1.961 | 2.677 | 3.592 | 4.574 |

Worker start to `ready`: 570 ms; first request after `ready`: 5.03 ms (one-off). Times are milliseconds.

- valid write (ALLOW): p99 of `handle` = 4.386 ms against a 10.0 ms target -> **PASS**
- unsafe write (BLOCK): p99 of `handle` = 3.577 ms against a 10.0 ms target -> **PASS**
- malformed frame (REJECT): p99 of `handle` = 4.008 ms against a 10.0 ms target -> **PASS**
- all 27 scenarios, cycled: p99 of `handle` = 3.967 ms against a 10.0 ms target -> **PASS**

## Result 2: stress run (two busy-loop processes on the two CPUs)

| Workload | Stage | n | mean | p50 | p95 | p99 | max |
|---|---|---|---|---|---|---|---|
| valid write (ALLOW) | parse | 1500 | 0.185 | 0.079 | 0.311 | 2.506 | 4.146 |
| valid write (ALLOW) | simulate | 1500 | 2.644 | 2.385 | 5.351 | 6.350 | 9.723 |
| valid write (ALLOW) | decide | 1500 | 0.352 | 0.188 | 0.352 | 3.876 | 7.894 |
| valid write (ALLOW) | log | 1500 | 1.734 | 1.366 | 4.658 | 5.240 | 25.096 |
| valid write (ALLOW) | handle | 1500 | 4.994 | 4.179 | 8.076 | 11.310 | 27.579 |
| unsafe write (BLOCK) | parse | 1500 | 0.158 | 0.086 | 0.140 | 2.285 | 4.059 |
| unsafe write (BLOCK) | simulate | 1500 | 2.595 | 2.336 | 5.816 | 6.451 | 8.860 |
| unsafe write (BLOCK) | decide | 1500 | 0.336 | 0.194 | 0.311 | 3.875 | 11.380 |
| unsafe write (BLOCK) | log | 1500 | 1.819 | 1.429 | 4.708 | 5.405 | 26.464 |
| unsafe write (BLOCK) | handle | 1500 | 4.988 | 4.166 | 8.080 | 10.187 | 40.787 |
| malformed frame (REJECT) | parse | 1500 | 0.182 | 0.070 | 0.115 | 3.724 | 7.412 |
| malformed frame (REJECT) | decide | 1500 | 0.345 | 0.147 | 2.018 | 4.413 | 8.076 |
| malformed frame (REJECT) | log | 1500 | 1.563 | 1.214 | 4.654 | 6.087 | 27.296 |
| malformed frame (REJECT) | handle | 1500 | 2.146 | 1.508 | 5.582 | 6.717 | 28.460 |
| all 27 scenarios, cycled | parse | 1500 | 0.195 | 0.079 | 0.171 | 3.161 | 5.780 |
| all 27 scenarios, cycled | simulate | 722 | 2.603 | 2.307 | 5.768 | 6.310 | 11.331 |
| all 27 scenarios, cycled | decide | 1500 | 0.343 | 0.165 | 1.563 | 4.101 | 7.822 |
| all 27 scenarios, cycled | log | 1500 | 1.696 | 1.326 | 4.697 | 6.474 | 33.937 |
| all 27 scenarios, cycled | handle | 1500 | 3.554 | 3.686 | 7.924 | 9.809 | 35.265 |
| real worker process | round trip | 500 | 3.609 | 3.751 | 7.770 | 9.740 | 12.529 |

Worker start to `ready`: 839 ms; first request after `ready`: 12.98 ms (one-off). Times are milliseconds.
Measured with 2 busy-loop background process(es) on 2 CPU(s).

- valid write (ALLOW): p99 of `handle` = 11.310 ms against a 10.0 ms target -> **FAIL**
- unsafe write (BLOCK): p99 of `handle` = 10.187 ms against a 10.0 ms target -> **FAIL**
- malformed frame (REJECT): p99 of `handle` = 6.717 ms against a 10.0 ms target -> **PASS**
- all 27 scenarios, cycled: p99 of `handle` = 9.809 ms against a 10.0 ms target -> **PASS**

## What the numbers say

- **Idle:** every workload meets the 10 ms target with a wide margin (p99 of `handle` about 3.6 to 4.4 ms, worst single command 8.3 ms). The median command takes about 1.6 to 2.2 ms.
- **The event log dominates.** Committing one SQLite row costs about 1.2 to 1.5 ms (mean), roughly 60 to 70 % of the total. Parser (about 0.14 ms), physics (about 0.25 ms) and decision engine (about 0.2 to 0.3 ms) are each a fraction of a millisecond. The log write is also the part that provides log-before-allow, so it cannot simply be skipped; batching or deferring the commit would trade durability for speed and was not done.
- **Under CPU contention the target is NOT reliably met:** with both CPUs kept busy, p99 of `handle` is 11.3 ms for valid writes and 10.2 ms for unsafe writes (FAIL), 9.8 ms for the 27-scenario mix and 6.7 ms for malformed frames (pass, narrowly). The tail (max 27 to 41 ms) is far above the target. The simulate stage grows about tenfold (0.27 to 2.6 ms mean) because it runs in a Python thread that has to be scheduled; the other stages show occasional 2 to 4 ms stalls.
- **One-off costs:** the worker needs about 0.5 to 0.8 s to start and the first command costs 5 to 13 ms (cold caches); neither is in the percentiles.
- **Timeouts:** the configured timeouts (parser 100 ms, simulation 500 ms, decision 100 ms) are 10 to 25 times the idle worst case, and about 3 to 10 times the worst case under stress, so on this machine they did not fire during the benchmark. A much slower machine could hit the decision timeout, and the result would then be REJECT (fail closed), not a wrong ALLOW.

## Limits of these measurements

- One machine and one short run per condition; no repetition across days, no confidence intervals. The stress run uses a crude load (two busy loops), not a realistic one.
- Sequential, one command at a time. Throughput under concurrent senders and sustained load over hours was **not** measured. Disk behaviour is that of this virtual machine's disk; a slower disk would raise the log cost directly.
- The dashboard's own cost (drawing the table and charts) is not included. The GUI never waits for the worker (tested in Phase 8), but the time from a button click to a painted row was not measured.
- Windows and MSVC builds were not measured.
- The statement "meets the 10 ms target" holds for the idle run on this machine only.
- `scripts/generate_test_report.py` does not re-run the benchmark (it takes minutes and its numbers depend on machine load); `tests/test_benchmark.py` checks only the script's arithmetic and structure, with no speed thresholds.
