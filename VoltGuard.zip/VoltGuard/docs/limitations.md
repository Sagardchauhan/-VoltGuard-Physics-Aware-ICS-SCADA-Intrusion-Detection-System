# Limitations and untested areas

This is the single list of what VoltGuard does not do, what it assumes and what was never run. It is a simulation prototype for study and demonstration.

## Meaning of the results
- **ALLOW is not a safety claim.** It means a SIMULATED prediction, from an invented model, stayed inside EXAMPLE limits and the software's own checks passed. It says nothing about any real plant or device. This is not a certified safety control and must never be connected to live equipment.
- The physics model is a steady-state approximation with invented parameters: no transients, no water hammer, no validation against real hydraulics ([methodology.md](methodology.md)).
- The limits in `config/safety_limits.json` are illustrative.
- Each command is judged on its own. A sequence of individually acceptable writes is not analysed, and the simulation does not track a persistent plant state: allowed commands are not applied to anything.

## Protocol scope
- Only Modbus/TCP function codes 3, 6 and 16 are parsed; everything else is rejected by design. Only registers 100 (pump speed %) and 101 (valve position %) are mapped.
- No authentication or authorisation of the sender and no protection of the transport.
- No packet capture, no live network input. Traffic is generated or typed in.

## Event log and export
- The hash chain is **tamper-evident only**: removal of the newest rows is not detected, and someone who can write the file can rebuild the chain. The log grows without bound. See [event_logging.md](event_logging.md).
- Exports are capped at 100,000 rows (and say so when truncated). PDF export needs the optional `reportlab` package.
- Two worker processes writing one database at the same time are unsupported and untested.

## Performance
- Measured about 2 ms per command on an idle 2-CPU virtual machine (p99 under 4.4 ms), but the 10 ms p99 target was **missed** under CPU stress ([performance.md](performance.md)). Numbers are for that machine only.

## Platform and environment (never tested)
- Windows, PowerShell scripts, MSVC builds and a real display have never been run. The C++ code has been compiled only with GCC 13; the dashboard only with Qt 6.4.2 on Linux and tested on the offscreen platform.
- The process-killing end-to-end tests read `/proc` and are Linux-only.
- No long-running (hours) test, no memory-growth test, no real disk-full test (a failing store is simulated).
- Fuzzing is seeded random mutation, not coverage-guided.
- Test report: Scapy cannot dissect FC16 writes of 101 to 123 registers, so those frames are cross-checked by other means ([test_report.md](test_report.md)).

## Dashboard
- The configuration tab is read-only; limits cannot be edited from the GUI.
- Alerts are display-only and are not persisted separately from the event log.
- Qt Charts is required to build the dashboard; check that the Qt Charts licence (GPLv3 or commercial) fits your use.

## Out of scope by design
No machine learning, no cloud service, no web application, and no connection to real industrial equipment.
