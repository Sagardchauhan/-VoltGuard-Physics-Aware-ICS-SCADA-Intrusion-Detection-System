# Testing

## Run everything and write the report

```bash
python scripts/generate_test_report.py          # builds C++, runs all suites, writes docs/test_report.md
python scripts/generate_test_report.py --no-sanitizer   # skip the ASan/UBSan build (needed on MSVC/Windows)
```

Exit code 0 means every suite passed, no test was skipped and every audit item is covered by passing tests. Windows: `scripts\run_tests.ps1` runs the suites without the report (the report script has only been run on Linux).

## Individual suites

| Suite | Command |
|---|---|
| Python (config, logger, schemas, traffic generator, parser CLI, physics) | `python -m pytest` |
| C++ parser unit tests | `cmake -S . -B build && cmake --build build && ctest --test-dir build --output-on-failure` |
| C++ under AddressSanitizer + UBSan (GCC/Clang) | `cmake -S . -B build-san -DVOLTGUARD_SANITIZE=ON -DCMAKE_BUILD_TYPE=Debug && cmake --build build-san && ./build-san/packet_interceptor/parser_tests` |
| Qt dashboard (headless) | `cmake --build build && ctest --test-dir build -R dashboard --output-on-failure` (or run `build/dashboard/dashboard_tests` with `QT_QPA_PLATFORM=offscreen`, `VOLTGUARD_ROOT`, `VOLTGUARD_PYTHON`, `VOLTGUARD_PARSER_CLI`, `VOLTGUARD_FAKE_WORKER` set) |
| Worker protocol (Python) | `python -m pytest tests/test_worker.py` |
| Event log (Python) | `python -m pytest tests/test_event_store.py` |
| Rust decision engine (unit, integration, CLI, fuzz) | `cargo test --manifest-path decision_engine/Cargo.toml` |
| Rust-vs-Python contract tests | `cargo build --manifest-path decision_engine/Cargo.toml && python -m pytest tests/test_decision_contract.py` (skipped, not passed, if the engine is not built) |

`tests/test_parser.py` runs the compiled `voltguard_parser_cli`; if it is not built those tests are **skipped, not passed**. Set `VOLTGUARD_PARSER_CLI` to use a CLI built elsewhere.

## How the parser is checked

1. Hand-written C++ unit tests (valid frames, boundaries, every function code 0-255, every truncation, every single-byte corruption, 200,000 deterministic random inputs).
2. The Phase 3 fixture: outcome, error text and every parsed field.
3. An independent reference parser written from the Modbus spec, compared on 6,000+ mutated frames.
4. Scapy as a third party: frames Scapy builds must round-trip exactly, and Scapy's dissector must agree with the C++ parser (except function-16 writes of 101-123 registers, which Scapy 2.8.0 cannot dissect).

## How the physics engine is checked

Numeric solver vs closed-form solution (grid and 200,000 random points), monotonic physical trends, boundary and inclusive-limit behaviour, injected solver failures, determinism, and the scenario outcomes pinned in `tests/test_physics.py`. The model is an invented approximation; see `methodology.md`.

## How the dashboard is checked

QtTest suite `dashboard/tests/dashboard_tests.cpp`, run headless. Four groups: (1) data model: strict validation of worker results (including 20+ malformed variants), severity and counters, bounded row count, the decision object validated strictly (a missing, contradictory or fail-closed-ALLOW decision is refused) and the Decision column and counters; (2) the worker client against fault-injecting fake workers (`tests/fixtures/fake_worker.py`: hang, crash, garbage, wrong id, oversized line, fatal, never ready) and the real worker; (3) alert rules and chart behaviour (`ChartAlertTests`: which records raise which alert, bounded alert log, only predictions plotted, limit lines at the configured values, axis always showing out-of-limit values, bounded plot); (4) the main window driven through its buttons against the real C++ parser and Python pipeline (all 27 scenarios classified, hostile hex input refused before sending, restart after failure, the decision tally 6 ALLOW / 5 BLOCK / 16 REJECT, all-REJECT without an engine and with a hung fake engine, screenshots, event-loop responsiveness while a request is pending, graphs and alerts after the 27 scenarios: 11 points, 5 critical and 16 warning alerts, and the system alerts when the engine is missing). Run under AddressSanitizer/UBSan by the report generator. A scratch-copy mutation run is described in the CHANGELOG.

## System safety and failure tests (Phase 12)

`tests/test_safety_invariants.py` checks the whole chain against one invariant: **ALLOW only when every component worked and an independently written oracle agrees** (well-formed frame, FC 3/6/16, writes only to registers 100/101 with values 0..100, predicted state inside the limits). It contains: a seeded mutation fuzz (1,500 mutated frames plus 500 random binary frames; the test fails if the fuzz does not reach ALLOW, BLOCK and REJECT), an exhaustive sweep of every pump/valve value, a fault matrix (13 parser faults x 7 solver faults for the two engines that can ALLOW, reduced sets for the other 12 engine fault modes), event-log failures, 17 corrupt configurations, hostile worker input and a hung-engine latency bound. The catalogue of failure modes and their outcomes is in `docs/failure_modes.md`. Limits: the oracle shares the Modbus specification with the parser, so a misreading of the specification would be shared; the fake parser, engine and solvers are my own fault models; fuzz inputs are random, not coverage-guided.

## What the tests do not show

They show the code does what this project specifies. They do not show that the model matches a real plant, that the parser handles every real-world Modbus device, or that the system is safe for industrial use.

## End-to-end tests (Phase 16)

`tests/test_end_to_end.py` runs the real worker with the real parser and engine as separate processes, including kill -9 of the worker and of its children. Linux only (reads `/proc`). See [integration_testing.md](integration_testing.md).

## Documentation tests (Phase 17)

`tests/test_docs.py` checks that links, screenshots and the commands named in the docs exist. It cannot check that a sentence is true; that was done by hand against the code.

## Demo readiness (Phase 18)

`scripts/preflight.py` is the check to run before a demo; `tests/test_preflight.py` makes components misbehave and requires NOT READY. See [demo_guide.md](demo_guide.md).
