# Architecture

All traffic is simulated. Nothing in VoltGuard opens a network connection to a device, and nothing is forwarded anywhere; the "traffic" is frames built by the generator (or typed into the dashboard) and handed to the parser as bytes.

## Components and processes

```
                       +------------------------------ worker process (Python: voltguard.worker) -------------------------------+
Qt dashboard  <--JSON lines over stdin/stdout-->  handle_request                                                                  |
(C++ / Qt 6)                                      |                                                                               |
                                                  |-- Pipeline --stdin/stdout--> C++ parser (child process)  voltguard_parser_cli |
                                                  |       '-- physics simulation (SciPy) in a worker thread, with timeout         |
                                                  |-- Decider  --stdin/stdout--> Rust decision engine (child process)             |
                                                  '-- EventStore --> SQLite file (hash-chained)                                  |
                                                                                                                                  |
                       +----------------------------------------------------------------------------------------------------------+
```

| Component | Language | Role | Failure handling |
|---|---|---|---|
| Parser (`packet_interceptor/`) | C++17 | Validates the MBAP header and PDU; supports FC 3, 6, 16; everything else is rejected | Any malformed frame is `PARSE_REJECTED`. Unit-tested under ASan/UBSan |
| Pipeline (`voltguard/pipeline.py`) | Python | Runs the parser child, then the simulation, producing one result per command | Timeout, crash, wrong id or junk reply is `COMPONENT_FAILURE`; the child is restarted |
| Physics (`physics_engine/`) | Python + SciPy | Predicts steady-state pressure and flow for pump speed and valve position | Solver errors, NaN/inf, negative values or a timeout give a non-SUCCESS status and no predictions |
| Decision engine (`decision_engine/`) | Rust | Pure rule evaluation: ALLOW / BLOCK / REJECT ([policy](decision_policy.md)) | A single place constructs ALLOW; anything unexpected is REJECT |
| Decision bridge (`voltguard/decision_bridge.py`) | Python | Calls the engine with a timeout, validates its reply, and repeats the limit check itself | Every failure is a REJECT with an error code; the engine is restarted |
| Event store (`event_logging/`) | Python + SQLite | Stores every command and decision in a SHA-256 hash chain; exports CSV/JSON/PDF | A failed write turns an ALLOW into REJECT `EVENT_LOG_UNAVAILABLE` |
| Worker (`voltguard/worker.py`) | Python | Serves the dashboard: `process`, `export`, queries; owns the three pieces above | Bad input gets an `error` reply; the worker keeps running |
| Dashboard (`dashboard/`) | C++ / Qt 6 | Display, graphs, alerts, export. Contains no decision logic | Without a reply in time, the command is shown as failed, never as allowed |

## Data flow for one command

1. The dashboard (or a test) sends `{"op":"process","command_id":...,"frame_hex":...}`.
2. The parser returns a `ParsedCommand` or a rejection reason.
3. For a supported command, the simulation predicts steady-state pressure and flow. A write is applied to a fixed default pipeline state (a register the command does not write keeps its default); a read describes that default state. No state is carried from one command to the next.
4. The decision engine turns the combined result into ALLOW, BLOCK or REJECT. The bridge checks the reply and independently re-checks the limits; if the two disagree, the result is REJECT.
5. **Log before allow:** the event is written to SQLite. Only when the store explicitly confirms the write is an ALLOW released; otherwise it is replaced by REJECT.
6. The reply goes to the dashboard, which shows the decision, adds display-only alerts and plots the prediction.

Message formats for each hop are in [integration/interfaces.md](../integration/interfaces.md); the machine-readable schema is `integration/message_schema.json`.

## Design rules

- **Fail closed.** The only path to ALLOW is a parsed, supported command, a successful simulation inside the limits, an engine ALLOW that passes the Python second check, and a confirmed log write. A missing component is a REJECT, not a skip.
- **Untrusted input everywhere.** Every message is validated for exact keys, types, ranges and finiteness. Packet contents are never used to build a shell command or a file path; child processes are started with `shell=False` and fixed arguments.
- **Independent re-checks.** The engine repeats the register and limit checks instead of trusting the simulation; the bridge repeats the limit check instead of trusting the engine. The register map is deliberately duplicated in Rust and Python, with a test that they match.
- **Bounded time.** Per-component timeouts come from `config/safety_limits.json` (`timeouts_ms`: parser 100, simulation 500, decision 100). A child that exceeds its timeout is killed and restarted; a child found dead before a request is replaced before use.
- **Tamper-evident log, not tamper-proof.** Editing, deleting or reordering a stored row breaks the hash chain, but truncating the end of the log is not detected and anyone with write access to the file can rebuild the chain. See [event_logging.md](event_logging.md).
- **No decision logic in the GUI.** The dashboard cannot allow anything; alerts are display-only and clearing them changes neither a decision nor the log.

## What is deliberately not here

No machine learning, no cloud service, no web application, no network listener, and no connection to real industrial equipment. See [limitations.md](limitations.md).
