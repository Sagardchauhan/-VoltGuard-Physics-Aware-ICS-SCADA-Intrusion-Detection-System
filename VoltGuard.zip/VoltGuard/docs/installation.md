# Installation

Versions listed under "Tested" were verified in the development environment (Ubuntu 24.04, Linux). **Nothing has been run on Windows yet**; the Windows commands below are the standard installation routes and still need to be confirmed on your machine.

| Tool | Tested (Linux) | Needed from |
|---|---|---|
| Python | 3.13.18 | all Python parts |
| pytest / SciPy / NumPy / Scapy | 9.1.1 / 1.18.1 / 2.5.3 / 2.8.0 | all Python parts |
| g++ / CMake / Ninja | 13.3.0 / 3.28.3 / 1.11.1 | C++ parser and dashboard |
| Rust / Cargo | 1.97.0 | Rust decision engine |
| Qt 6 (Widgets, Test, Charts) | 6.4.2 (Ubuntu apt) | Dashboard (Charts: graphs tab) |

## Windows (PowerShell)

```powershell
# Tools (winget). Open a new terminal afterwards so PATH updates.
winget install Python.Python.3.13
winget install Kitware.CMake
winget install Rustlang.Rustup
winget install Git.Git

# C++ compiler: Visual Studio Build Tools with the "Desktop development with C++" workload
winget install Microsoft.VisualStudio.2022.BuildTools --override "--wait --add Microsoft.VisualStudio.Workload.VCTools --includeRecommended"

# Qt 6 (needed from Phase 8): install with the Qt Online Installer from https://www.qt.io/download-qt-installer
# and select the MSVC 2022 64-bit kit plus the Qt Charts module. Then point CMake at it, e.g.
#   cmake -S . -B build -DCMAKE_PREFIX_PATH=C:\Qt\6.x.y\msvc2022_64
# (the Qt version in the path is yours; this project was only built with Qt 6.4.2 on Linux).
```

### Python environment

```powershell
cd VoltGuard
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

Scapy packet *capture* on Windows needs Npcap (https://npcap.com); packet *generation* for the mock traffic does not.

### Build and test

```powershell
python -m pytest
cmake -S . -B build
cmake --build build --config Release
ctest --test-dir build -C Release --output-on-failure
cargo test --manifest-path decision_engine\Cargo.toml
cargo build --release --manifest-path decision_engine\Cargo.toml   # required: without it the dashboard worker REJECTS every command (fail closed)
# or all at once:
.\scripts\run_tests.ps1
```

### Run

```powershell
python -m voltguard.main
```

## Linux

```bash
sudo apt install build-essential cmake ninja-build python3-pip
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
pip install --break-system-packages -r requirements.txt   # or use a venv
```

## Troubleshooting

- `ModuleNotFoundError: voltguard` - fixed for the entry-point files (they now also start from an editor's Run button, tested on Linux only). If it still appears, run commands from the project root (`python -m voltguard.main`); pytest uses `pythonpath = .`.
- `ModuleNotFoundError` for `scipy`, `numpy` or `scapy` - run `pip install -r requirements.txt` with the same Python the editor uses (check the interpreter shown at the bottom right of VS Code).
- The Run button in VS Code starts the active editor tab: if an Output tab (for example "Pip package updater") is active it fails with `No such file or directory`; click the `.py` file first.
- Execution of `.ps1` scripts blocked - run `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`.
- CMake cannot find a compiler on Windows - run from "Developer PowerShell for VS 2022".
- Application exits with code 2 - the safety configuration is missing or invalid; the log states why.

## Linux: Qt and running the dashboard (tested)

```bash
# optional, for the PDF report: pip install -r requirements-optional.txt
sudo apt install qt6-base-dev qt6-base-dev-tools libqt6test6 qt6-charts-dev libgl1-mesa-dev   # Qt 6.4.2 on Ubuntu 24.04
cmake -S . -B build -G Ninja && cmake --build build
./build/dashboard/voltguard_dashboard            # starts the Python worker itself (python3 -m voltguard.worker)
```

If Qt 6 is not found, CMake prints a warning and builds everything else without the dashboard (`-DVOLTGUARD_BUILD_DASHBOARD=OFF` skips it deliberately). Useful options: `--python PATH`, `--project-root DIR`, `--parser-cli PATH`, `--config PATH`, `--event-db PATH`.
Headless run that writes screenshots (also used for `docs/screenshots/`): `QT_QPA_PLATFORM=offscreen ./build/dashboard/voltguard_dashboard --screenshot-dir docs/screenshots`.
The dashboard needs the same Python environment as the rest of the project (`pip install -r requirements.txt`) because it starts `voltguard.worker`.
