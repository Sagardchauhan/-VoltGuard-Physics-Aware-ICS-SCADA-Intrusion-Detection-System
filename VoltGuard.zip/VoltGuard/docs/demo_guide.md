# Demo guide

A 7-minute walkthrough of VoltGuard, a pre-demo checklist, three failure drills and honest answers to likely questions. Everything shown is simulated; say so at the start. The numbers below come from real runs of this repository on the Linux development machine (Qt 6.4.2, offscreen for screenshots); your machine's timings will differ.

## Before the demo (10 minutes ahead)

```bash
cmake -S . -B build -G Ninja && cmake --build build
cargo build --release --manifest-path decision_engine/Cargo.toml
python scripts/preflight.py          # must end with: READY: 0 failure(s)
```

`scripts/preflight.py` checks the configuration, Python packages, the parser, the decision engine and the dashboard, then sends a safe, an unsafe and a malformed command through the real worker into a temporary database (your real log is not touched). Expected: ALLOW, BLOCK, REJECT, all logged, hash chain verifies. If it says NOT READY, fix that before presenting; its messages name the missing piece.

Start the demo with `scripts/demo.sh` (Linux) or `scripts\demo.ps1` (Windows, **untested**). Both run the pre-flight check, refuse to start if it fails, and open the dashboard on a **fresh event database** so the Event log tab starts empty.

Backup plan: if there is no display or the dashboard will not start, open `docs/screenshots/` (all five tabs) and use the command-line steps at the end of each section; `python -m voltguard.pipeline --input results/traffic.json` shows the parser and simulation without the GUI.

## The 7-minute script

| Min | Do | Say / point at | Expected on screen |
|---|---|---|---|
| 0:00 | Show the yellow banner | "Everything here is simulated. No device is connected and nothing is forwarded. ALLOW is a policy decision about a prediction from an invented model." | Banner on every tab |
| 0:45 | Slide or `docs/architecture.md` diagram | Frame -> C++ parser -> physics -> Rust rules -> log -> dashboard. "Anything it cannot verify is not allowed." | |
| 1:30 | **Dashboard** tab, press **Run all scenarios** | 27 built-in scenarios: normal traffic, physically unsafe commands, malformed and unsupported frames | Counters: Total 27, Within limits 6, Limit violations 5, Rejected 16, Component failures 0; Decisions ALLOW 6 / BLOCK 5 / REJECT 16 |
| 2:30 | **Traffic** tab, select `unsafe_pump_100` | "This is a well-formed, legal Modbus write. The parser accepts it. The physics prediction is what stops it." | Pump 100 % -> predicted pressure 102.14 kPa vs limit 100: `BLOCK (engine)`, reason "predicted pressure 102.1429 exceeds maximum 100" |
| 3:15 | Select `unsafe_multi_pump_100_valve_20` | "Two registers in one write: pump to 100 %, valve nearly shut." | Predicted 145 kPa: BLOCK |
| 3:45 | Select a `malformed_*` row, then `unsupported_fc01_read_coils` | "Protocol-level garbage never reaches the physics engine; unsupported function codes are rejected by design." | Stage PARSE_REJECTED, decision REJECT, reason from the parser (e.g. `LENGTH_MISMATCH`, `UNSUPPORTED_FUNCTION_CODE`) |
| 4:15 | Type `00010000000601060064003c` in the hex box, **Send frame** | "A live command: pump speed 60 %." | ALLOW; predicted pressure 39.24 kPa, flow 24.7386 L/s; details say the event was stored |
| 4:45 | **Graphs and alerts** tab | Limit lines, decision-coloured markers; alerts are display-only | Red markers outside the dashed limit lines for BLOCK rows |
| 5:30 | **Event log** tab: Load stored events, **Verify log integrity** | "Every decision is stored in a SQLite hash chain. An ALLOW is only released after the log write is confirmed." | 27 events, integrity verified |
| 6:15 | **Export JSON** | Shows the notice that the data is simulated and the integrity result in the file | "Exported 27 of 27 event(s) ... Integrity check passed (tamper-evidence only)." |
| 6:45 | Close with the limits (below) | Be the first to say what it does not do | |

## Three failure drills (real behaviour, each about 30 seconds)

1. **Fail closed: no decision engine.** Run the worker with a missing engine and send the safe command:
   `... --decision-engine /nonexistent/engine`. Real result: `REJECT`, source `fail_closed`, error code `DECISION_ENGINE_UNAVAILABLE`, still logged. In the dashboard, the same effect appears if the engine was never built: the status bar shows the engine as unavailable and every command is REJECTED.
2. **Tampering is detected.** Export a log, change one stored row in a *copy* of the database, export again:
   `python -m event_logging.export --db copy.db --format json --out out.json` -> `integrity: FAILED - row 2: contents do not match their hash`, exit code 4; the file is still written but labelled `"verified": false`. (Limit: truncating the newest rows is not detected.)
3. **Kill a component.** `python -m pytest tests/test_end_to_end.py -q -k "killed"` kills the parser and engine processes during a burst of commands: no unsafe command is ever ALLOWed and every command is logged (about 15 seconds; Linux only).

## What to say about the limits (say it before they ask)

- The physics is an **invented steady-state model**, not validated hydraulics, and the limits are **examples**. ALLOW therefore says nothing about a real plant.
- Only Modbus function codes 3, 6 and 16 on two registers are understood.
- The event log is tamper-**evident**, not tamper-proof.
- Latency: about 2 ms per command idle (p99 under 4.4 ms), but the 10 ms p99 target **was missed** under CPU stress ([performance.md](performance.md)).
- Tested on Linux, Qt 6.4.2, headless. Windows, MSVC and a real display were never tested. No ML, cloud or web component, by design.

## Likely questions

| Question | Honest answer |
|---|---|
| Does it work on real PLCs? | No, and it must not be connected to any. It only processes simulated frames. |
| Why not just limit-check the register value? | A legal-looking value can have an unsafe *effect*: pump 100 % passes a 0..100 value check but the model predicts 102 kPa. The prediction is what is checked, in addition to the value limits. |
| Is the physics accurate? | No. It is a deliberately simple steady-state model with invented parameters ([methodology.md](methodology.md)); the point of the prototype is the architecture and the fail-closed handling. |
| What if a component crashes? | Every failure becomes REJECT and the component is restarted; the failure-mode table is in [failure_modes.md](failure_modes.md), and the end-to-end tests kill processes to prove it. |
| Why Rust for the decision? | A small, dependency-free rule engine with one place that can produce ALLOW; the Python side repeats the limit check as a second opinion. |
| Can the log be forged? | Someone with write access to the file can rebuild the chain. It detects accidental or casual edits, not a determined attacker. |
| Where is the machine learning? | There is none by design: the decisions are deterministic rules that can be explained and tested. |

## Command-line cheat sheet

```bash
python scripts/preflight.py
python -m traffic_generator.generate_traffic --output results/traffic.json
python -m voltguard.pipeline --input results/traffic.json
python -m event_logging.export --db results/demo/events_<stamp>.db --format csv --out results/events.csv
python scripts/generate_test_report.py        # runs every test suite (several minutes)
```
