# Integration testing (Phase 16)

All traffic is simulated. This page says which test layer covers which path through the system, and what was found.

## The paths

```
traffic generator (JSON) -> worker process -> C++ parser (child) -> physics (SciPy thread)
                                           -> Rust decision engine (child) -> SQLite event log -> export (CSV/JSON/PDF)
Qt dashboard <-> worker (JSON lines over a pipe)
```

| Path | Covered by |
|---|---|
| generator -> parser (all 27 scenarios, parsed fields) | `tests/test_parser.py`, `tests/test_traffic_generator.py` |
| parser -> physics -> pipeline result | `tests/test_integration.py` |
| pipeline result -> decision (contract between Python and Rust) | `tests/test_decision_contract.py`, `decision_engine/tests` |
| worker (all components together) | `tests/test_worker.py`, `tests/test_decision_integration.py` |
| **whole chain as separate processes, to the export** | `tests/test_end_to_end.py` (Phase 16) |
| dashboard <-> worker, real parser and engine | `dashboard/tests/dashboard_tests.cpp` (`MainWindowTests`) |
| failures and hostile input across the chain | `tests/test_safety_invariants.py` (Phase 12) |

## What `tests/test_end_to_end.py` adds

- **Generated scenarios to the export:** the generator CLI writes the 27 scenarios, a real worker process handles each (parser child, simulation, engine child, log), and the exported JSON must agree row by row with the traffic file, the worker replies and the designed intent (6 ALLOW / 5 BLOCK / 16 REJECT).
- **Random stream:** 250 seeded random commands through the whole stack; no ALLOW unless an independently written oracle agrees; the log holds 250 verified rows.
- **CLI chain:** generator CLI -> pipeline CLI -> engine CLI gives the same 6/5/16.
- **Restarts:** two worker sessions on one database continue one verified hash chain.
- **kill -9 of the worker** with a burst of requests in flight (three timings): every ALLOW the client received is already in the log, and the chain still verifies. This is what log-before-allow is for.
- **Killed child processes:** a parser or engine that died while idle is replaced before the next command (no command lost, unsafe command still BLOCKed); both killed at once; and a thread that SIGKILLs both children every 5 ms during alternating safe/unsafe commands (at least 240, and until a fail-closed refusal has been seen): no unsafe ALLOW, every reply matches its request and is logged, fail-closed refusals did occur and the system kept allowing safe commands in between.
- **No orphans:** closing the worker, or killing it with kill -9, leaves no parser or engine process running.

Process-killing tests read `/proc` and run on Linux only (skipped visibly elsewhere).

## Findings

- No defect in the product code was found by these tests. One of my first expectations was wrong: I assumed the first command after killing an idle child would be refused. The code detects a dead child before use and restarts it, so the command is served normally. The test now asserts the real (better) behaviour.

## Not covered

- Windows process handling (`taskkill`, pipe semantics, MSVC builds): untested.
- Two worker processes writing one database at the same time: unsupported and untested.
- Long-running behaviour (hours), memory growth, a full disk, a real display for the dashboard.
- The mutation check shows two things these tests cannot tell apart: closing the children explicitly versus them ending when the pipes close at worker exit (both leave no orphans), and the "restart before use" path versus "restart after the first failure" is only distinguished by the exact BLOCK/ALLOW sequence asserted in the idle-kill test.
