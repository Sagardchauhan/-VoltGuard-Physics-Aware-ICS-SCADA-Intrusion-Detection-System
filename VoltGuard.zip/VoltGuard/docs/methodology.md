# Physics model: methodology, assumptions and limitations

> **This is an invented, simplified steady-state model for a software prototype. It is not a validated fluid-dynamics model, it does not describe any real plant, and its output must never be read as a guarantee of physical safety.** All parameter values and limits are illustrative.

## What the physics engine does

For each command it (1) works out the pump speed and valve position the command would produce, (2) predicts the steady-state pressure and flow with the model below, (3) compares them with the configured limits, and (4) returns a `SimulationResult` (see `integration/interfaces.md`). Code: `physics_engine/` (`pipeline_model.py` model and solver, `safety_limits.py` limit comparison, `simulator.py` command handling).

## Units and valid inputs

| Quantity | Unit | Valid input range | Source of range |
|---|---|---|---|
| Pump speed (register 100) | percent of nominal | 0..100 | `limits.pump_speed` in `config/safety_limits.json` |
| Valve position (register 101) | percent open | 0..100 | `limits.valve_position` |
| Predicted pressure | kPa (gauge) | - | limits in `limits.pressure` (example: 20..100) |
| Predicted flow | L/s | - | limits in `limits.flow` (example: 5..50) |

Values outside the input range, non-numbers, NaN/infinity, booleans, missing values and writes to any register other than 100/101 are **INVALID_INPUT**, not physical violations. A multi-register write with one bad value is rejected as a whole.

## Model

With s = pump speed / 100, v = valve position / 100, Q = flow (L/s), P = pump discharge pressure (kPa):

- Pump curve: `P_pump = P0*s^2 - a*Q^2` (pressure scales with speed squared, as in the pump affinity laws; falls with flow)
- System curve: `P_sys = P_back + (k_pipe + k_valve/v^2)*Q^2` (static back pressure plus quadratic losses; a smaller valve opening raises the loss)
- The operating point is the intersection with Q >= 0. It is found numerically with `scipy.optimize.brentq`, and the tests compare it with the closed form `Q^2 = (P0*s^2 - P_back)/(a + R)`, `R = k_pipe + k_valve/v^2`, `P = P_back + R*Q^2`.
- Valve fully closed, or pump unable to overcome back pressure (`P0*s^2 <= P_back`): `Q = 0` and `P = P0*s^2` (pump dead-head pressure).

| Parameter | Value | Meaning |
|---|---|---|
| P0 | 160.0 kPa | pump dead-head pressure at 100 % speed |
| a | 0.03 kPa/(L/s)^2 | pump curve slope |
| P_back | 10.0 kPa | static back pressure |
| k_pipe | 0.02 kPa/(L/s)^2 | pipe loss coefficient |
| k_valve | 0.01 kPa/(L/s)^2 | valve loss coefficient at full opening |

These numbers were chosen so the example limits give a mix of safe and unsafe commands. They were not fitted to any data.

## Initial conditions and determinism

The simulator is pure: the same command, current settings, limits and model always give the same result (predictions are rounded to 4 decimals). The default current settings are pump 50 %, valve 60 %. A write to one register keeps the other at its current setting. A read (FC3) requests no change and reports the current settings. The simulator never updates the current settings; the pipeline will do that only after an ALLOW decision (Phase 7/11).

## Limit checks

Limits are inclusive: a value exactly equal to a limit is allowed, anything strictly beyond it is reported (`PRESSURE_HIGH`, `PRESSURE_LOW`, `FLOW_HIGH`, `FLOW_LOW`). Example: pump 100 % with valve 100 % predicts a flow of exactly 50.0 L/s, equal to the 50 L/s maximum, so it is allowed.

## Failure handling

Any solver exception, non-finite or negative output, or contract violation becomes `simulation_status = ERROR` with a message and **no predictions and no violations**, so downstream code cannot mistake a failed simulation for a safe one. `TIMEOUT` is reserved for the bridge (Phase 7); a solve takes microseconds.

## Results for the generator scenarios (default settings)

Produced by running the simulator on the Phase 3 scenarios; pinned by `tests/test_physics.py`.

| Scenario | Command | Intent | Pressure kPa | Flow L/s | Violations |
|---|---|---|---|---|---|
| `normal_pump_60` | FC6 reg 100=60 | NORMAL | 39.24 | 24.74 | none |
| `normal_pump_45` | FC6 reg 100=45 | NORMAL | 23.76 | 16.97 | none |
| `normal_valve_70` | FC6 reg 101=70 | NORMAL | 27.22 | 20.64 | none |
| `unsafe_multi_pump_100_valve_20` | FC16 reg 100=[100, 20] | UNSAFE | 145.00 | 22.36 | PRESSURE_HIGH |
| `unsafe_valve_closed` | FC6 reg 101=0 | UNSAFE | 40.00 | 0.00 | FLOW_LOW |
| `unsafe_pump_stop` | FC6 reg 100=0 | UNSAFE | 0.00 | 0.00 | PRESSURE_LOW, FLOW_LOW |
| `unsafe_pump_40_low_pressure` | FC6 reg 100=40 | UNSAFE | 19.58 | 14.16 | PRESSURE_LOW |
| `unsafe_pump_100` | FC6 reg 100=100 | UNSAFE | 102.14 | 43.92 | PRESSURE_HIGH |
| `out_of_range_pump_250` | FC6 reg 100=250 | INVALID_VALUE | - | - | INVALID_INPUT: pump_speed 250 is outside the valid range 0..100 percent |
| `unmapped_register_write` | FC6 reg 102=5 | INVALID_VALUE | - | - | INVALID_INPUT: register 102 is not mapped to a pipeline control |
| `boundary_full_speed_full_open` | FC16 reg 100=[100, 100] | BOUNDARY_SAFE | 85.00 | 50.00 | none |
| `read_pump_registers` | FC3 read 2 reg from 100 | READ_ONLY | 28.43 | 19.64 | none |
| `write_multiple_pump_valve` | FC16 reg 100=[55, 65] | NORMAL | 32.76 | 22.83 | none |

## Known limitations

- Steady state only: no transients, ramp rates, water hammer, pump start-up, cavitation, temperature or compressibility. A command that is safe at steady state could still be harmful while the plant moves between settings.
- One pump, one valve, one lumped pipe. No network topology, tanks, elevation changes or multiple sensors.
- Parameters are invented and unvalidated. Real limits depend on the real plant and must come from its engineers.
- The model predicts from assumed current settings; it is not fed real sensor data. Values are always labelled as simulated.
- Only registers 100 and 101 are mapped. Any other write is rejected as invalid input; that is a deliberate, conservative choice, not a statement about real devices.
- OpenModelica is not used. SciPy was sufficient for the core model; a Modelica model could replace `pipeline_model.py` later behind the same `solve_operating_point` interface.
