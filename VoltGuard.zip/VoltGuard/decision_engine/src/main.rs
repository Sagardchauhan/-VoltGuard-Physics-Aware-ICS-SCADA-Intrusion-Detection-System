//! JSON-lines front end for the decision engine.
//!
//!   voltguard_decision_engine --config config/safety_limits.json  < results.jsonl  > decisions.jsonl
//!
//! One pipeline-result JSON object per input line; one reply line per input line, in order:
//!   * a DecisionResult object (command_id, decision, reason[, predicted_pressure, configured_max_pressure]), or
//!   * {"type":"error","error":TEXT} when no decision is possible (invalid JSON, unusable command id,
//!     over-long line, internal failure). A consumer must treat that as "do not allow".
//! Exit code 2 (and no output) if the configuration is missing or invalid.

use std::io::{BufRead, Read, Write};
use std::panic::{catch_unwind, AssertUnwindSafe};
use voltguard_decision_engine::{decide, Config};

const MAX_LINE_BYTES: u64 = 1024 * 1024;

fn error_line(message: &str) -> String {
    serde_json::json!({"type": "error", "error": message}).to_string()
}

fn main() {
    let mut config_path = String::from("config/safety_limits.json");
    let mut args = std::env::args().skip(1);
    while let Some(a) = args.next() {
        match a.as_str() {
            "--config" => match args.next() {
                Some(p) => config_path = p,
                None => {
                    eprintln!("--config needs a path");
                    std::process::exit(2);
                }
            },
            other => {
                eprintln!("unknown argument: {other}");
                std::process::exit(2);
            }
        }
    }
    let cfg = match std::fs::read_to_string(&config_path).map_err(|e| e.to_string()).and_then(|t| Config::from_json_str(&t).map_err(|e| e.to_string())) {
        Ok(c) => c,
        Err(e) => {
            eprintln!("cannot start: {e}");
            std::process::exit(2);
        }
    };

    let stdin = std::io::stdin();
    let mut input = stdin.lock();
    let stdout = std::io::stdout();
    let mut out = stdout.lock();
    loop {
        let mut buf = Vec::new();
        let n = match (&mut input).take(MAX_LINE_BYTES + 1).read_until(b'\n', &mut buf) {
            Ok(n) => n,
            Err(_) => break,
        };
        if n == 0 {
            break;
        }
        let reply = if buf.len() as u64 > MAX_LINE_BYTES {
            // Over-long line: discard the rest of it, answer with an error.
            if !buf.ends_with(b"\n") {
                let mut sink = Vec::new();
                while let Ok(m) = (&mut input).take(MAX_LINE_BYTES).read_until(b'\n', &mut sink) {
                    if m == 0 || sink.ends_with(b"\n") {
                        break;
                    }
                    sink.clear();
                }
            }
            error_line("input line too long")
        } else {
            match serde_json::from_slice::<serde_json::Value>(&buf) {
                Err(_) => error_line("input is not valid JSON"),
                Ok(value) => match catch_unwind(AssertUnwindSafe(|| decide(&value, &cfg))) {
                    Ok(Ok(decision)) => decision.to_json().to_string(),
                    Ok(Err(_)) => error_line("command_id missing or invalid; no decision possible"),
                    Err(_) => error_line("internal error; no decision possible"),
                },
            }
        };
        if writeln!(out, "{reply}").and_then(|_| out.flush()).is_err() {
            break; // the reader went away
        }
    }
}
