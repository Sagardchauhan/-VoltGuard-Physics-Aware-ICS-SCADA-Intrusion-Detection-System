//! VoltGuard decision engine (Phase 10).
//!
//! A deterministic, rule-based policy that turns one pipeline result (parser + physics simulation, all
//! SIMULATED data) into ALLOW, BLOCK or REJECT. No machine learning, no I/O, no global state.
//!
//! Fail-closed rules (see docs/decision_policy.md):
//! * ALLOW is returned only when every check passes; any missing, mistyped, non-finite, inconsistent or
//!   unexpected input yields REJECT (or BLOCK), never ALLOW.
//! * The engine does not trust the simulation's own violation list: it re-checks the predicted pressure and
//!   flow against its own copy of the limits, and re-validates the written register values.
//! * Nothing from the input is interpreted as code or a command; text echoed into a reason is sanitised.

use serde_json::{json, Map, Value};

pub const MAX_REASON_CHARS: usize = 512;
/// Mirrors voltguard/register_map.py (mock pipeline). Phase 11 adds a cross-check test between the two.
pub const PUMP_SPEED_REGISTER: i64 = 100;
pub const VALVE_POSITION_REGISTER: i64 = 101;
const FC_READ: i64 = 3;
const FC_WRITE_SINGLE: i64 = 6;
const FC_WRITE_MULTIPLE: i64 = 16;
const MAX_WRITE_REGISTERS: usize = 123;

// ------------------------------------------------------------------------------------------ configuration

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Limit {
    pub min: f64,
    pub max: f64,
}

#[derive(Debug, Clone, PartialEq)]
pub struct Config {
    pub pressure: Limit,
    pub flow: Limit,
    pub pump_speed: Limit,
    pub valve_position: Limit,
}

#[derive(Debug, PartialEq)]
pub struct ConfigError(pub String);

impl std::fmt::Display for ConfigError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "invalid safety configuration: {}", self.0)
    }
}

fn limit_from(limits: &Map<String, Value>, name: &str, lo_bound: f64, hi_bound: f64) -> Result<Limit, ConfigError> {
    let err = |m: &str| ConfigError(format!("limits.{name}: {m}"));
    let obj = limits.get(name).and_then(Value::as_object).ok_or_else(|| err("missing or not an object"))?;
    let get = |key: &str| -> Result<f64, ConfigError> {
        let v = obj.get(key).and_then(Value::as_f64).ok_or_else(|| err(&format!("{key} missing or not a number")))?;
        if v.is_finite() { Ok(v) } else { Err(err(&format!("{key} is not finite"))) }
    };
    let (min, max) = (get("min")?, get("max")?);
    if min >= max {
        return Err(err("min must be smaller than max"));
    }
    if min < lo_bound || max > hi_bound {
        return Err(err(&format!("must lie within {lo_bound}..{hi_bound}")));
    }
    Ok(Limit { min, max })
}

impl Config {
    /// Strict parser for config/safety_limits.json (schema_version 1). Any problem is an error: the engine
    /// refuses to run without a valid configuration.
    pub fn from_json_str(text: &str) -> Result<Config, ConfigError> {
        let root: Value = serde_json::from_str(text).map_err(|e| ConfigError(format!("not valid JSON: {e}")))?;
        let root = root.as_object().ok_or_else(|| ConfigError("top level must be an object".into()))?;
        if root.get("schema_version").and_then(Value::as_i64) != Some(1) {
            return Err(ConfigError("schema_version must be 1".into()));
        }
        let limits = root.get("limits").and_then(Value::as_object).ok_or_else(|| ConfigError("limits missing".into()))?;
        Ok(Config {
            pressure: limit_from(limits, "pressure", 0.0, 1.0e9)?,
            flow: limit_from(limits, "flow", 0.0, 1.0e9)?,
            pump_speed: limit_from(limits, "pump_speed", 0.0, 100.0)?,
            valve_position: limit_from(limits, "valve_position", 0.0, 100.0)?,
        })
    }
}

// ------------------------------------------------------------------------------------------ decisions

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Verdict {
    Allow,
    Block,
    Reject,
}

impl Verdict {
    pub fn as_str(self) -> &'static str {
        match self {
            Verdict::Allow => "ALLOW",
            Verdict::Block => "BLOCK",
            Verdict::Reject => "REJECT",
        }
    }
}

#[derive(Debug, Clone, PartialEq)]
pub struct Decision {
    pub command_id: String,
    pub verdict: Verdict,
    pub reason: String,
    pub predicted_pressure: Option<f64>,
    pub configured_max_pressure: Option<f64>,
}

impl Decision {
    /// JSON matching the DecisionResult contract (integration/message_schema.json).
    pub fn to_json(&self) -> Value {
        let mut out = json!({"command_id": self.command_id, "decision": self.verdict.as_str(), "reason": self.reason});
        if let Some(p) = self.predicted_pressure.filter(|p| p.is_finite()) {
            out["predicted_pressure"] = json!(p);
        }
        if let Some(m) = self.configured_max_pressure.filter(|m| m.is_finite()) {
            out["configured_max_pressure"] = json!(m);
        }
        out
    }
}

/// No decision can be made because the command id itself is unusable (it is never echoed back).
#[derive(Debug, PartialEq, Eq)]
pub struct NoCommandId;

pub fn valid_command_id(id: &str) -> bool {
    !id.is_empty() && id.len() <= 64 && id.bytes().all(|b| b.is_ascii_alphanumeric() || b == b'_' || b == b'.' || b == b'-')
}

/// Printable-ASCII, limited-length copy of untrusted text for use inside a reason.
fn clean(text: &str, max: usize) -> String {
    text.chars().take(max).map(|c| if c.is_ascii_graphic() || c == ' ' { c } else { '?' }).collect()
}

fn reason(text: String) -> String {
    clean(&text, MAX_REASON_CHARS)
}

fn finite(v: Option<&Value>) -> Option<f64> {
    v.and_then(Value::as_f64).filter(|x| x.is_finite())
}

fn integer(v: Option<&Value>) -> Option<i64> {
    v.and_then(|x| x.as_i64())
}

struct Outcome {
    verdict: Verdict,
    reason: String,
    pressure: Option<f64>,
    max_pressure: Option<f64>,
}

fn reject(why: impl Into<String>) -> Outcome {
    Outcome { verdict: Verdict::Reject, reason: why.into(), pressure: None, max_pressure: None }
}

/// Decide one pipeline result (the JSON object produced by voltguard.pipeline / voltguard.worker).
pub fn decide(input: &Value, cfg: &Config) -> Result<Decision, NoCommandId> {
    let id = match input.get("command_id").and_then(Value::as_str) {
        Some(s) if valid_command_id(s) => s.to_owned(),
        _ => return Err(NoCommandId),
    };
    let o = evaluate(input, cfg, &id);
    // ALLOW is only reachable through `allow_outcome`; this assertion documents that for every other path.
    Ok(Decision {
        command_id: id,
        verdict: o.verdict,
        reason: reason(o.reason),
        predicted_pressure: o.pressure,
        configured_max_pressure: o.max_pressure,
    })
}

fn evaluate(input: &Value, cfg: &Config, id: &str) -> Outcome {
    let Some(root) = input.as_object() else { return reject("input is not a JSON object") };
    let stage = root.get("stage").and_then(Value::as_str);
    match stage {
        Some("PARSE_REJECTED") => {
            let code = root.get("error_code").and_then(Value::as_str).map(|c| clean(c, 40)).unwrap_or_else(|| "unknown".into());
            return reject(format!("parser rejected the frame ({code})"));
        }
        Some("COMPONENT_FAILURE") => {
            let code = root.get("error_code").and_then(Value::as_str).map(|c| clean(c, 40)).unwrap_or_else(|| "unknown".into());
            return reject(format!("component failure, fail closed ({code})"));
        }
        Some("SIMULATED") => {}
        Some(_) => return reject("unknown pipeline stage"),
        None => return reject("pipeline stage missing"),
    }

    let (Some(parsed), Some(sim)) = (
        root.get("parsed_command").and_then(Value::as_object),
        root.get("simulation").and_then(Value::as_object),
    ) else {
        return reject("SIMULATED result lacks a parsed command or simulation result");
    };

    // The same command id must appear everywhere it is present.
    for (what, obj) in [("parsed command", parsed), ("simulation", sim)] {
        match obj.get("command_id") {
            Some(Value::String(s)) if s == id => {}
            _ => return reject(format!("command id of the {what} is missing or differs")),
        }
    }

    let Some(fc) = integer(parsed.get("function_code")) else { return reject("function code missing") };
    if ![FC_READ, FC_WRITE_SINGLE, FC_WRITE_MULTIPLE].contains(&fc) {
        return reject(format!("unsupported function code {fc}"));
    }
    let Some(start) = integer(parsed.get("register_address")).filter(|a| (0..=65535).contains(a)) else {
        return reject("register address missing or out of range");
    };

    // Writes: independently validate target registers and values.
    let writes: Vec<(i64, i64)> = match fc {
        FC_WRITE_SINGLE => match integer(parsed.get("register_value")) {
            Some(v) => vec![(start, v)],
            None => return reject("register value missing"),
        },
        FC_WRITE_MULTIPLE => {
            let Some(arr) = parsed.get("register_values").and_then(Value::as_array) else {
                return reject("register values missing");
            };
            if arr.is_empty() || arr.len() > MAX_WRITE_REGISTERS {
                return reject("number of written registers is out of range");
            }
            let mut v = Vec::with_capacity(arr.len());
            for (i, item) in arr.iter().enumerate() {
                match item.as_i64() {
                    Some(x) => v.push((start + i as i64, x)),
                    None => return reject("a written register value is not an integer"),
                }
            }
            if integer(parsed.get("quantity")) != Some(arr.len() as i64) {
                return reject("quantity does not match the number of register values");
            }
            v
        }
        _ => Vec::new(),
    };
    for (addr, value) in &writes {
        let limit = match *addr {
            PUMP_SPEED_REGISTER => cfg.pump_speed,
            VALVE_POSITION_REGISTER => cfg.valve_position,
            _ => return reject(format!("write to unmapped register {addr}")),
        };
        if (*value as f64) < limit.min || (*value as f64) > limit.max {
            return reject(format!("written value {value} for register {addr} is outside {}..{}", limit.min, limit.max));
        }
    }

    // The simulation must be a complete, successful, finite result for the same configuration.
    match sim.get("simulation_status").and_then(Value::as_str) {
        Some("SUCCESS") => {}
        Some("INVALID_INPUT") => return reject("simulation rejected the input"),
        Some(other) => return reject(format!("simulation did not succeed ({})", clean(other, 20))),
        None => return reject("simulation status missing"),
    }
    let (Some(pressure), Some(flow)) = (finite(sim.get("predicted_pressure")), finite(sim.get("predicted_flow"))) else {
        return reject("predicted pressure or flow missing or not finite");
    };
    if finite(sim.get("configured_min_pressure")) != Some(cfg.pressure.min)
        || finite(sim.get("configured_max_pressure")) != Some(cfg.pressure.max)
    {
        return reject("simulation was run with different pressure limits than the engine's configuration");
    }
    let Some(reported) = sim.get("violations").and_then(Value::as_array) else {
        return reject("violation list missing");
    };

    // Reads change nothing, so predicted limits do not block them; everything above still had to hold.
    if fc == FC_READ {
        return allow_outcome(format!("read-only command; current predicted pressure {pressure} {}", "kPa"), pressure, cfg);
    }

    let mut violations = Vec::new();
    if pressure > cfg.pressure.max {
        violations.push(format!("predicted pressure {pressure} exceeds maximum {}", cfg.pressure.max));
    } else if pressure < cfg.pressure.min {
        violations.push(format!("predicted pressure {pressure} is below minimum {}", cfg.pressure.min));
    }
    if flow > cfg.flow.max {
        violations.push(format!("predicted flow {flow} exceeds maximum {}", cfg.flow.max));
    } else if flow < cfg.flow.min {
        violations.push(format!("predicted flow {flow} is below minimum {}", cfg.flow.min));
    }
    if !violations.is_empty() {
        return Outcome { verdict: Verdict::Block, reason: violations.join("; "), pressure: Some(pressure), max_pressure: Some(cfg.pressure.max) };
    }
    if !reported.is_empty() {
        // The simulation flagged a violation that this engine cannot confirm: take the cautious side.
        return Outcome {
            verdict: Verdict::Block,
            reason: "simulation reported a limit violation that the engine could not confirm; blocking to be safe".into(),
            pressure: Some(pressure),
            max_pressure: Some(cfg.pressure.max),
        };
    }
    allow_outcome(
        format!("predicted pressure {pressure} kPa and flow {flow} L/s are within the configured limits (simulated)"),
        pressure,
        cfg,
    )
}

/// The only constructor of an ALLOW outcome.
fn allow_outcome(why: String, pressure: f64, cfg: &Config) -> Outcome {
    Outcome { verdict: Verdict::Allow, reason: why, pressure: Some(pressure), max_pressure: Some(cfg.pressure.max) }
}

// ------------------------------------------------------------------------------------------ unit tests
#[cfg(test)]
mod tests {
    use super::*;

    const CONFIG: &str = r#"{"schema_version":1,"limits":{"pressure":{"min":20.0,"max":100.0},"flow":{"min":5.0,"max":50.0},
        "pump_speed":{"min":0.0,"max":100.0},"valve_position":{"min":0.0,"max":100.0}}}"#;

    fn cfg() -> Config {
        Config::from_json_str(CONFIG).unwrap()
    }

    fn write(pressure: f64, flow: f64) -> Value {
        json!({"command_id":"T-1","stage":"SIMULATED",
            "parsed_command":{"command_id":"T-1","function_code":6,"register_address":100,"register_value":60},
            "simulation":{"command_id":"T-1","simulation_status":"SUCCESS","configured_min_pressure":20.0,"configured_max_pressure":100.0,
                "violations":[],"predicted_pressure":pressure,"predicted_flow":flow}})
    }

    fn verdict(v: &Value) -> Verdict {
        decide(v, &cfg()).unwrap().verdict
    }

    #[test]
    fn within_limits_is_allowed() {
        let d = decide(&write(55.0, 20.0), &cfg()).unwrap();
        assert_eq!(d.verdict, Verdict::Allow);
        assert_eq!(d.predicted_pressure, Some(55.0));
        assert_eq!(d.configured_max_pressure, Some(100.0));
        assert!(d.reason.contains("within"));
    }

    #[test]
    fn limits_are_inclusive() {
        for (p, f) in [(20.0, 5.0), (100.0, 50.0), (20.0, 50.0), (100.0, 5.0)] {
            assert_eq!(verdict(&write(p, f)), Verdict::Allow, "{p} {f}");
        }
    }

    #[test]
    fn just_outside_limits_is_blocked() {
        for (p, f) in [(100.0001, 20.0), (19.9999, 20.0), (55.0, 50.0001), (55.0, 4.9999)] {
            assert_eq!(verdict(&write(p, f)), Verdict::Block, "{p} {f}");
        }
    }

    #[test]
    fn block_reason_names_every_violation_and_carries_values() {
        let d = decide(&write(145.0, 3.0), &cfg()).unwrap();
        assert_eq!(d.verdict, Verdict::Block);
        assert!(d.reason.contains("pressure 145") && d.reason.contains("flow 3"));
        assert_eq!(d.predicted_pressure, Some(145.0));
    }

    #[test]
    fn reason_is_never_longer_than_the_contract_allows() {
        let mut v = write(55.0, 20.0);
        v["stage"] = json!("PARSE_REJECTED");
        v["error_code"] = json!("X".repeat(5000));
        let d = decide(&v, &cfg()).unwrap();
        assert!(d.reason.len() <= MAX_REASON_CHARS && !d.reason.is_empty());
    }

    #[test]
    fn reason_helper_truncates_and_sanitises() {
        let long = format!("{}\n\u{1b}é", "a".repeat(2000));
        let r = reason(long);
        assert_eq!(r.chars().count(), MAX_REASON_CHARS);
        let r = reason("x\n\u{1b}[0m\u{0}é".to_string());
        assert_eq!(r, "x??[0m??");
    }

    #[test]
    fn unusable_command_ids_give_no_decision() {
        for bad in [json!(null), json!(5), json!(""), json!("a b"), json!("id\n"), json!("x".repeat(65)), json!("é")] {
            let mut v = write(55.0, 20.0);
            v["command_id"] = bad;
            assert_eq!(decide(&v, &cfg()), Err(NoCommandId));
        }
        assert_eq!(decide(&json!({}), &cfg()), Err(NoCommandId));
        assert_eq!(decide(&json!([1]), &cfg()), Err(NoCommandId));
    }

    #[test]
    fn config_rejects_bad_values() {
        let good: Value = serde_json::from_str(CONFIG).unwrap();
        let mut cases: Vec<Value> = Vec::new();
        for (path, val) in [("/limits/pressure/min", json!(100.0)), ("/limits/pressure/max", json!("x")),
                            ("/limits/flow/min", json!(-1.0)), ("/limits/pump_speed/max", json!(101.0)),
                            ("/schema_version", json!(2)), ("/limits", json!(5)), ("/limits/valve_position", json!(null))] {
            let mut c = good.clone();
            *c.pointer_mut(path).unwrap() = val;
            cases.push(c);
        }
        for c in cases {
            assert!(Config::from_json_str(&c.to_string()).is_err(), "{c}");
        }
        assert!(Config::from_json_str("not json").is_err());
        assert!(Config::from_json_str("[]").is_err());
    }

    #[test]
    fn decision_json_matches_the_contract_keys() {
        let j = decide(&write(145.0, 20.0), &cfg()).unwrap().to_json();
        let mut keys: Vec<_> = j.as_object().unwrap().keys().cloned().collect();
        keys.sort();
        assert_eq!(keys, ["command_id", "configured_max_pressure", "decision", "predicted_pressure", "reason"]);
        assert_eq!(j["decision"], "BLOCK");
    }
}
