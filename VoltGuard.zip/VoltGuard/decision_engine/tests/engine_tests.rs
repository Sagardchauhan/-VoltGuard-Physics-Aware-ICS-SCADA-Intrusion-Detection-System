//! Phase 10 integration tests for the decision engine: real pipeline results, adversarial inputs,
//! the JSON-lines CLI and a deterministic fuzz with an independently written oracle.

use serde_json::{json, Value};
use std::io::Write;
use std::panic::{catch_unwind, AssertUnwindSafe};
use std::path::PathBuf;
use std::process::{Command, Stdio};
use voltguard_decision_engine::{decide, Config, NoCommandId, Verdict};

fn root() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR")).parent().unwrap().to_path_buf()
}

fn real_config() -> Config {
    Config::from_json_str(&std::fs::read_to_string(root().join("config/safety_limits.json")).unwrap()).unwrap()
}

/// (scenario, intent, pipeline result) for all scenarios; the file is generated from the real pipeline.
fn fixture() -> Vec<(String, String, Value)> {
    let text = std::fs::read_to_string(root().join("tests/fixtures/pipeline_results.jsonl")).expect("fixture missing");
    let rows: Vec<_> = text
        .lines()
        .map(|l| {
            let v: Value = serde_json::from_str(l).unwrap();
            (v["scenario"].as_str().unwrap().to_owned(), v["intent"].as_str().unwrap().to_owned(), v["result"].clone())
        })
        .collect();
    assert_eq!(rows.len(), 27, "the fixture must hold every scenario");
    rows
}

/// Designed expectation per scenario intent (from the traffic generator and the physics tests).
fn expected(intent: &str) -> Verdict {
    match intent {
        "NORMAL" | "BOUNDARY_SAFE" | "READ_ONLY" => Verdict::Allow,
        "UNSAFE" => Verdict::Block,
        "INVALID_VALUE" | "UNSUPPORTED" | "MALFORMED" => Verdict::Reject,
        other => panic!("unknown intent {other}"),
    }
}

fn verdict_of(v: &Value) -> Verdict {
    decide(v, &real_config()).expect("command id").verdict
}

// ------------------------------------------------------------------------------------ real pipeline data

#[test]
fn every_scenario_gets_the_decision_its_design_intends() {
    let cfg = real_config();
    for (name, intent, result) in fixture() {
        let d = decide(&result, &cfg).unwrap();
        assert_eq!(d.verdict, expected(&intent), "{name} ({intent}): {}", d.reason);
        assert!(!d.reason.is_empty() && d.reason.len() <= 512, "{name}");
    }
}

#[test]
fn scenario_outcomes_are_not_all_the_same() {
    let v: Vec<Verdict> = fixture().iter().map(|(_, _, r)| verdict_of(r)).collect();
    for want in [Verdict::Allow, Verdict::Block, Verdict::Reject] {
        assert!(v.contains(&want), "{want:?} never produced");
    }
    assert_eq!(v.iter().filter(|x| **x == Verdict::Allow).count(), 6);
    assert_eq!(v.iter().filter(|x| **x == Verdict::Block).count(), 5);
    assert_eq!(v.iter().filter(|x| **x == Verdict::Reject).count(), 16);
}

#[test]
fn block_decisions_carry_the_predicted_pressure_and_the_limit() {
    for (name, intent, result) in fixture().into_iter().filter(|r| r.1 == "UNSAFE") {
        let d = decide(&result, &real_config()).unwrap();
        assert_eq!(d.configured_max_pressure, Some(100.0), "{name} {intent}");
        assert_eq!(d.predicted_pressure, result["simulation"]["predicted_pressure"].as_f64());
    }
}

// ------------------------------------------------------------------------------------ adversarial table

fn base_write() -> Value {
    fixture().into_iter().find(|r| r.0 == "normal_pump_60").unwrap().2
}

fn base_read() -> Value {
    fixture().into_iter().find(|r| r.0 == "read_pump_registers").unwrap().2
}

fn base_multi() -> Value {
    fixture().into_iter().find(|r| r.0 == "write_multiple_pump_valve").unwrap().2
}

fn with(mut v: Value, pointer: &str, new: Value) -> Value {
    *v.pointer_mut(pointer).unwrap_or_else(|| panic!("no {pointer}")) = new;
    v
}

fn without(mut v: Value, pointer: &str) -> Value {
    let (parent, key) = pointer.rsplit_once('/').unwrap();
    v.pointer_mut(parent).unwrap().as_object_mut().unwrap().remove(key).unwrap_or_else(|| panic!("no {pointer}"));
    v
}

#[test]
fn bases_are_allowed_so_the_mutations_below_mean_something() {
    for b in [base_write(), base_read(), base_multi()] {
        assert_eq!(verdict_of(&b), Verdict::Allow);
    }
}

#[test]
fn contradictory_or_malformed_results_are_never_allowed() {
    let big = json!(1u64 << 40);
    let cases: Vec<(&str, Value, Verdict)> = vec![
        ("stage missing", without(base_write(), "/stage"), Verdict::Reject),
        ("stage unknown", with(base_write(), "/stage", json!("DONE")), Verdict::Reject),
        ("stage lowercase", with(base_write(), "/stage", json!("simulated")), Verdict::Reject),
        ("stage not a string", with(base_write(), "/stage", json!(1)), Verdict::Reject),
        ("parse rejected but simulation attached", with(base_write(), "/stage", json!("PARSE_REJECTED")), Verdict::Reject),
        ("component failure but simulation attached", with(base_write(), "/stage", json!("COMPONENT_FAILURE")), Verdict::Reject),
        ("parsed command null", with(base_write(), "/parsed_command", Value::Null), Verdict::Reject),
        ("simulation null", with(base_write(), "/simulation", Value::Null), Verdict::Reject),
        ("parsed command missing", without(base_write(), "/parsed_command"), Verdict::Reject),
        ("parsed id differs", with(base_write(), "/parsed_command/command_id", json!("OTHER")), Verdict::Reject),
        ("parsed id missing", without(base_write(), "/parsed_command/command_id"), Verdict::Reject),
        ("simulation id differs", with(base_write(), "/simulation/command_id", json!("OTHER")), Verdict::Reject),
        ("simulation id missing", without(base_write(), "/simulation/command_id"), Verdict::Reject),
        ("fc 8", with(base_write(), "/parsed_command/function_code", json!(8)), Verdict::Reject),
        ("fc 0", with(base_write(), "/parsed_command/function_code", json!(0)), Verdict::Reject),
        ("fc string", with(base_write(), "/parsed_command/function_code", json!("6")), Verdict::Reject),
        ("fc float", with(base_write(), "/parsed_command/function_code", json!(6.5)), Verdict::Reject),
        ("fc null", with(base_write(), "/parsed_command/function_code", Value::Null), Verdict::Reject),
        ("fc huge", with(base_write(), "/parsed_command/function_code", big.clone()), Verdict::Reject),
        ("fc missing", without(base_write(), "/parsed_command/function_code"), Verdict::Reject),
        ("address missing", without(base_write(), "/parsed_command/register_address"), Verdict::Reject),
        ("address negative", with(base_write(), "/parsed_command/register_address", json!(-1)), Verdict::Reject),
        ("address too large", with(base_write(), "/parsed_command/register_address", json!(70000)), Verdict::Reject),
        ("address string", with(base_write(), "/parsed_command/register_address", json!("100")), Verdict::Reject),
        ("write to register 99", with(base_write(), "/parsed_command/register_address", json!(99)), Verdict::Reject),
        ("write to register 102", with(base_write(), "/parsed_command/register_address", json!(102)), Verdict::Reject),
        ("write to register 65535", with(base_write(), "/parsed_command/register_address", json!(65535)), Verdict::Reject),
        ("value 101", with(base_write(), "/parsed_command/register_value", json!(101)), Verdict::Reject),
        ("value negative", with(base_write(), "/parsed_command/register_value", json!(-1)), Verdict::Reject),
        ("value fractional", with(base_write(), "/parsed_command/register_value", json!(60.5)), Verdict::Reject),
        ("value string", with(base_write(), "/parsed_command/register_value", json!("60")), Verdict::Reject),
        ("value null", with(base_write(), "/parsed_command/register_value", Value::Null), Verdict::Reject),
        ("value missing", without(base_write(), "/parsed_command/register_value"), Verdict::Reject),
        ("value huge", with(base_write(), "/parsed_command/register_value", big), Verdict::Reject),
        ("multi: values missing", without(base_multi(), "/parsed_command/register_values"), Verdict::Reject),
        ("multi: values empty", with(with(base_multi(), "/parsed_command/register_values", json!([])), "/parsed_command/quantity", json!(0)), Verdict::Reject),
        ("multi: quantity mismatch", with(base_multi(), "/parsed_command/quantity", json!(1)), Verdict::Reject),
        ("multi: quantity missing", without(base_multi(), "/parsed_command/quantity"), Verdict::Reject),
        ("multi: spills into register 102", with(base_multi(), "/parsed_command/register_address", json!(101)), Verdict::Reject),
        ("multi: value out of range", with(base_multi(), "/parsed_command/register_values/1", json!(250)), Verdict::Reject),
        ("multi: value not an integer", with(base_multi(), "/parsed_command/register_values/0", json!("55")), Verdict::Reject),
        ("multi: 124 values", with(with(base_multi(), "/parsed_command/register_values", json!(vec![50; 124])), "/parsed_command/quantity", json!(124)), Verdict::Reject),
        ("sim status ERROR", with(base_write(), "/simulation/simulation_status", json!("ERROR")), Verdict::Reject),
        ("sim status TIMEOUT", with(base_write(), "/simulation/simulation_status", json!("TIMEOUT")), Verdict::Reject),
        ("sim status INVALID_INPUT", with(base_write(), "/simulation/simulation_status", json!("INVALID_INPUT")), Verdict::Reject),
        ("sim status lowercase", with(base_write(), "/simulation/simulation_status", json!("success")), Verdict::Reject),
        ("sim status number", with(base_write(), "/simulation/simulation_status", json!(1)), Verdict::Reject),
        ("sim status missing", without(base_write(), "/simulation/simulation_status"), Verdict::Reject),
        ("pressure missing", without(base_write(), "/simulation/predicted_pressure"), Verdict::Reject),
        ("pressure null", with(base_write(), "/simulation/predicted_pressure", Value::Null), Verdict::Reject),
        ("pressure string", with(base_write(), "/simulation/predicted_pressure", json!("55")), Verdict::Reject),
        ("flow missing", without(base_write(), "/simulation/predicted_flow"), Verdict::Reject),
        ("flow bool", with(base_write(), "/simulation/predicted_flow", json!(true)), Verdict::Reject),
        ("limits differ: max", with(base_write(), "/simulation/configured_max_pressure", json!(200.0)), Verdict::Reject),
        ("limits differ: min", with(base_write(), "/simulation/configured_min_pressure", json!(0.0)), Verdict::Reject),
        ("limits missing", without(base_write(), "/simulation/configured_max_pressure"), Verdict::Reject),
        ("violations missing", without(base_write(), "/simulation/violations"), Verdict::Reject),
        ("violations not an array", with(base_write(), "/simulation/violations", json!("none")), Verdict::Reject),
        ("simulation reports a violation the engine cannot confirm", with(base_write(), "/simulation/violations", json!([{"type": "PRESSURE_HIGH", "limit": 100.0, "predicted": 101.0}])), Verdict::Block),
        ("pressure just high", with(base_write(), "/simulation/predicted_pressure", json!(100.5)), Verdict::Block),
        ("pressure low", with(base_write(), "/simulation/predicted_pressure", json!(5.0)), Verdict::Block),
        ("flow high", with(base_write(), "/simulation/predicted_flow", json!(60)), Verdict::Block),
        ("flow low", with(base_write(), "/simulation/predicted_flow", json!(0)), Verdict::Block),
        ("simulation lies: empty violations but pressure is high", with(with(base_write(), "/simulation/predicted_pressure", json!(300.0)), "/simulation/violations", json!([])), Verdict::Block),
        ("read: sim failed", with(base_read(), "/simulation/simulation_status", json!("ERROR")), Verdict::Reject),
        ("read: id differs", with(base_read(), "/parsed_command/command_id", json!("OTHER")), Verdict::Reject),
        ("read: limits differ", with(base_read(), "/simulation/configured_max_pressure", json!(5.0)), Verdict::Reject),
        ("read: pressure missing", without(base_read(), "/simulation/predicted_pressure"), Verdict::Reject),
    ];
    let cfg = real_config();
    for (name, input, want) in cases {
        let got = decide(&input, &cfg).unwrap_or_else(|_| panic!("{name}: no decision"));
        assert_eq!(got.verdict, want, "{name}: {}", got.reason);
        assert!(got.verdict != Verdict::Allow, "{name} was ALLOWED");
    }
}

#[test]
fn reads_are_not_blocked_by_predicted_limits_by_design() {
    // A read changes nothing, so a plant that is already outside its limits can still be observed.
    let read = with(base_read(), "/simulation/predicted_pressure", json!(300.0));
    assert_eq!(verdict_of(&read), Verdict::Allow);
}

#[test]
fn unknown_extra_fields_do_not_change_the_decision() {
    let mut v = base_write();
    v["timestamp_utc"] = json!("2026-11-01T00:00:00Z");
    v["logged"] = json!(true);
    v["note"] = json!({"nested": [1, 2, 3]});
    assert_eq!(verdict_of(&v), Verdict::Allow);
    let blocked = with(v, "/simulation/predicted_pressure", json!(150.0));
    assert_eq!(verdict_of(&blocked), Verdict::Block);
}

#[test]
fn text_from_the_input_is_sanitised_inside_reasons() {
    let mut v = json!({"command_id": "E-1", "stage": "PARSE_REJECTED", "error_code": "BAD\n\u{1b}[31m\"; rm -rf /\u{0}é"});
    let d = decide(&v, &real_config()).unwrap();
    assert!(d.reason.chars().all(|c| c.is_ascii_graphic() || c == ' '), "{:?}", d.reason);
    v["error_code"] = json!(12345);
    assert_eq!(decide(&v, &real_config()).unwrap().verdict, Verdict::Reject);
}

#[test]
fn the_engine_is_deterministic() {
    for (_, _, r) in fixture() {
        assert_eq!(decide(&r, &real_config()), decide(&r, &real_config()));
    }
}

#[test]
fn a_different_configuration_changes_decisions_consistently() {
    let tight = Config::from_json_str(
        r#"{"schema_version":1,"limits":{"pressure":{"min":20.0,"max":100.0},"flow":{"min":5.0,"max":50.0},
        "pump_speed":{"min":0.0,"max":50.0},"valve_position":{"min":0.0,"max":100.0}}}"#,
    )
    .unwrap();
    // pump value 60 is now outside the pump_speed limit: REJECT with the normal fixture, not ALLOW.
    assert_eq!(decide(&base_write(), &tight).unwrap().verdict, Verdict::Reject);
    assert_eq!(decide(&base_write(), &real_config()).unwrap().verdict, Verdict::Allow);
}

#[test]
fn no_command_id_means_no_decision() {
    assert_eq!(decide(&json!({"stage": "SIMULATED"}), &real_config()), Err(NoCommandId));
}

// ------------------------------------------------------------------------------------ the CLI

fn run_cli(config: &str, input: &[u8]) -> (Option<i32>, Vec<String>, String) {
    let mut child = Command::new(env!("CARGO_BIN_EXE_voltguard_decision_engine"))
        .args(["--config", config])
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .unwrap();
    let mut stdin = child.stdin.take().unwrap();
    let data = input.to_vec();
    let writer = std::thread::spawn(move || {
        let _ = stdin.write_all(&data); // the engine may exit early; that is checked by the caller
    });
    let out = child.wait_with_output().unwrap();
    writer.join().unwrap();
    (out.status.code(), String::from_utf8_lossy(&out.stdout).lines().map(str::to_owned).collect(), String::from_utf8_lossy(&out.stderr).into_owned())
}

fn config_path() -> String {
    root().join("config/safety_limits.json").to_string_lossy().into_owned()
}

#[test]
fn cli_decides_every_fixture_line_in_order() {
    let rows = fixture();
    let input: String = rows.iter().map(|r| format!("{}\n", r.2)).collect();
    let (code, lines, _) = run_cli(&config_path(), input.as_bytes());
    assert_eq!(code, Some(0));
    assert_eq!(lines.len(), rows.len());
    for (line, (name, intent, result)) in lines.iter().zip(&rows) {
        let d: Value = serde_json::from_str(line).unwrap();
        assert_eq!(d["command_id"], result["command_id"], "{name}");
        assert_eq!(d["decision"], expected(intent).as_str_for_test(), "{name}");
        assert!(d["reason"].as_str().map_or(false, |r| !r.is_empty() && r.len() <= 512));
    }
}

trait Name {
    fn as_str_for_test(&self) -> &'static str;
}
impl Name for Verdict {
    fn as_str_for_test(&self) -> &'static str {
        self.as_str()
    }
}

#[test]
fn cli_answers_bad_lines_with_errors_and_keeps_going() {
    let good = base_write().to_string();
    let no_id = json!({"stage": "SIMULATED"}).to_string();
    let input = format!("not json\n{good}\n{no_id}\n\n[1,2]\n{{\"command_id\":\"A\\nB\",\"stage\":\"SIMULATED\"}}\n{{\"command_id\":\"T-1\",\"x\":1e999}}\n{good}\n");
    let (code, lines, _) = run_cli(&config_path(), input.as_bytes());
    assert_eq!(code, Some(0));
    assert_eq!(lines.len(), 8, "one reply per input line: {lines:?}");
    let kinds: Vec<String> = lines
        .iter()
        .map(|l| {
            let v: Value = serde_json::from_str(l).unwrap();
            v["decision"].as_str().map(str::to_owned).unwrap_or_else(|| format!("error:{}", v["type"]))
        })
        .collect();
    assert_eq!(kinds[0], "error:\"error\"");
    assert_eq!(kinds[1], "ALLOW");
    assert!(kinds[2].starts_with("error") && kinds[3].starts_with("error") && kinds[4].starts_with("error") && kinds[5].starts_with("error"));
    assert!(kinds[6].starts_with("error"), "a number outside the f64 range must not produce a decision");
    assert_eq!(kinds[7], "ALLOW");
}

#[test]
fn cli_survives_an_overlong_line_and_still_answers_the_next_one() {
    let mut input = vec![b'x'; 3 * 1024 * 1024];
    input.push(b'\n');
    input.extend_from_slice(base_write().to_string().as_bytes());
    input.push(b'\n');
    let (code, lines, _) = run_cli(&config_path(), &input);
    assert_eq!(code, Some(0));
    assert_eq!(lines.len(), 2, "{lines:?}");
    assert!(lines[0].contains("too long"));
    assert!(lines[1].contains("ALLOW"));
}

#[test]
fn cli_handles_a_final_line_without_a_newline() {
    let (_, lines, _) = run_cli(&config_path(), base_write().to_string().as_bytes());
    assert_eq!(lines.len(), 1);
    assert!(lines[0].contains("ALLOW"));
}

#[test]
fn cli_refuses_to_start_without_a_valid_configuration() {
    let dir = std::env::temp_dir().join(format!("vg-decision-{}", std::process::id()));
    std::fs::create_dir_all(&dir).unwrap();
    let bad = dir.join("bad.json");
    std::fs::write(&bad, r#"{"schema_version":1,"limits":{"pressure":{"min":100,"max":20}}}"#).unwrap();
    for path in [bad.to_string_lossy().into_owned(), dir.join("missing.json").to_string_lossy().into_owned()] {
        let (code, lines, stderr) = run_cli(&path, base_write().to_string().as_bytes());
        assert_eq!(code, Some(2), "{path}");
        assert!(lines.is_empty(), "no decision may be printed without a valid configuration");
        assert!(stderr.contains("cannot start"));
    }
    let _ = std::fs::remove_dir_all(&dir);
}

#[test]
fn cli_rejects_unknown_arguments() {
    let status = Command::new(env!("CARGO_BIN_EXE_voltguard_decision_engine")).arg("--nonsense").stdin(Stdio::null()).output().unwrap().status;
    assert_eq!(status.code(), Some(2));
}

// ------------------------------------------------------------------------------------ fuzz

struct XorShift(u64);
impl XorShift {
    fn next(&mut self) -> u64 {
        let mut x = self.0;
        x ^= x << 13;
        x ^= x >> 7;
        x ^= x << 17;
        self.0 = x;
        x
    }
    fn below(&mut self, n: usize) -> usize {
        (self.next() % n as u64) as usize
    }
}

fn junk(rng: &mut XorShift) -> Option<Value> {
    Some(match rng.below(16) {
        0 => Value::Null,
        1 => json!(true),
        2 => json!(false),
        3 => json!(""),
        4 => json!("SUCCESS"),
        5 => json!("SIMULATED"),
        6 => json!(0),
        7 => json!(-1),
        8 => json!(60),
        9 => json!(55.5),
        10 => json!(1e300),
        11 => json!(i64::MAX),
        12 => json!([]),
        13 => json!({}),
        14 => json!([60, 40]),
        _ => return None, // delete
    })
}

fn all_pointers(v: &Value, prefix: String, out: &mut Vec<String>) {
    match v {
        Value::Object(m) => {
            for (k, c) in m {
                let p = format!("{prefix}/{k}");
                out.push(p.clone());
                all_pointers(c, p, out);
            }
        }
        Value::Array(a) => {
            for (i, c) in a.iter().enumerate() {
                let p = format!("{prefix}/{i}");
                out.push(p.clone());
                all_pointers(c, p, out);
            }
        }
        _ => {}
    }
}

/// Independently written NECESSARY conditions for an ALLOW (never used by the engine).
fn allow_is_plausible(v: &Value) -> bool {
    let s = |p: &str| v.pointer(p).and_then(Value::as_str);
    let n = |p: &str| v.pointer(p).and_then(Value::as_f64).filter(|x| x.is_finite());
    let id = match s("/command_id") {
        Some(i) => i,
        None => return false,
    };
    if s("/stage") != Some("SIMULATED") || s("/simulation/simulation_status") != Some("SUCCESS") {
        return false;
    }
    if s("/parsed_command/command_id") != Some(id) || s("/simulation/command_id") != Some(id) {
        return false;
    }
    let fc = v.pointer("/parsed_command/function_code").and_then(Value::as_i64);
    if !matches!(fc, Some(3) | Some(6) | Some(16)) {
        return false;
    }
    if n("/simulation/configured_min_pressure") != Some(20.0) || n("/simulation/configured_max_pressure") != Some(100.0) {
        return false;
    }
    let (Some(p), Some(f)) = (n("/simulation/predicted_pressure"), n("/simulation/predicted_flow")) else { return false };
    if v.pointer("/simulation/violations").map_or(true, |x| !x.is_array()) {
        return false;
    }
    if fc != Some(3) {
        if !(20.0..=100.0).contains(&p) || !(5.0..=50.0).contains(&f) {
            return false;
        }
        if !v.pointer("/simulation/violations").unwrap().as_array().unwrap().is_empty() {
            return false;
        }
        let vals: Vec<i64> = match fc {
            Some(6) => v.pointer("/parsed_command/register_value").and_then(Value::as_i64).into_iter().collect(),
            _ => v.pointer("/parsed_command/register_values").and_then(Value::as_array).map(|a| a.iter().filter_map(Value::as_i64).collect()).unwrap_or_default(),
        };
        if vals.is_empty() || vals.iter().any(|x| !(0..=100).contains(x)) {
            return false;
        }
    }
    true
}

#[test]
fn fuzz_never_panics_and_never_allows_an_implausible_input() {
    let cfg = real_config();
    let bases: Vec<Value> = fixture().into_iter().map(|r| r.2).collect();
    let mut rng = XorShift(0x9E37_79B9_7F4A_7C15);
    let (mut allow, mut block, mut reject, mut nodec) = (0u32, 0u32, 0u32, 0u32);
    for _ in 0..60_000 {
        let mut v = bases[rng.below(bases.len())].clone();
        for _ in 0..1 + rng.below(3) {
            let mut ptrs = Vec::new();
            all_pointers(&v, String::new(), &mut ptrs);
            if ptrs.is_empty() {
                break;
            }
            let p = ptrs[rng.below(ptrs.len())].clone();
            match junk(&mut rng) {
                Some(j) => {
                    if let Some(slot) = v.pointer_mut(&p) {
                        *slot = j;
                    }
                }
                None => {
                    let (parent, key) = p.rsplit_once('/').unwrap();
                    match v.pointer_mut(parent) {
                        Some(Value::Object(m)) => {
                            m.remove(key);
                        }
                        Some(Value::Array(a)) => {
                            if let Ok(i) = key.parse::<usize>() {
                                if i < a.len() {
                                    a.remove(i);
                                }
                            }
                        }
                        _ => {}
                    }
                }
            }
        }
        let r = catch_unwind(AssertUnwindSafe(|| decide(&v, &cfg))).unwrap_or_else(|_| panic!("panic on {v}"));
        match r {
            Err(NoCommandId) => nodec += 1,
            Ok(d) => {
                assert!(!d.reason.is_empty() && d.reason.len() <= 512, "{v}");
                match d.verdict {
                    Verdict::Allow => {
                        allow += 1;
                        assert!(allow_is_plausible(&v), "ALLOW for an implausible input: {v}");
                    }
                    Verdict::Block => block += 1,
                    Verdict::Reject => reject += 1,
                }
            }
        }
    }
    // The fuzz must actually have explored all outcomes, otherwise the assertions above prove little.
    assert!(allow > 1000 && block > 1000 && reject > 1000 && nodec > 100, "allow {allow} block {block} reject {reject} nodec {nodec}");
}
