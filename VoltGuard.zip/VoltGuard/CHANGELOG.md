# Changelog

## [1.0.1] - Direct-run fix (2026-11-11)

### Fixed
- Running an entry-point file directly (for example `voltguard/main.py` with VS Code's Run button) failed with `ModuleNotFoundError: No module named 'voltguard'`, because Python then puts the file's own folder on `sys.path` instead of the project root. Reproduced for six files (`voltguard/main.py`, `pipeline.py`, `worker.py`, `traffic_generator/generate_traffic.py`, `event_logging/export.py`, `physics_engine/simulator.py`); each now fixes `sys.path` when started as a file. `python -m ...` and imports are unchanged.
- Found by a user on Windows; the fix and the new `tests/test_direct_run.py` (8 tests, 6 mutants killed) ran on Linux only.

## [1.0.0] - Final deliverables (2026-11-11)

### Added
- `deliverables/VoltGuard_Report.pdf` (12 pages: design, safety rules, verification results, findings, performance, limitations, timeline) and `deliverables/VoltGuard_Presentation.pptx` (12 slides, speaker notes, native latency chart, real screenshots). Every number in both comes from `docs/test_report.md` and the benchmark JSON files.
- Both were rendered to images and inspected; the first renders had real defects (deck: placeholders not applied and centred titles, malformed arrow shapes; report: a clipped architecture diagram, overlapping chart labels, two near-empty pages), all fixed. One statement in the report draft (a Phase 15 finding) was wrong and was corrected against the record.

### Not changed
- No product code changed in this step. Known limits are unchanged and listed in `docs/limitations.md`.

## [0.18.0] - Phase 18: demo preparation (2026-11-05)

### Added
- `scripts/preflight.py`: pre-demo readiness check (configuration, packages, parser, engine, dashboard, then a safe / unsafe / malformed command through the real worker into a temporary database). Exit 1 on any FAIL; never touches `logs/events.db`.
- `scripts/demo.sh` (tested on Linux) and `scripts/demo.ps1` (**never run**): pre-flight, then the dashboard on a fresh event database.
- Dashboard option `--event-db PATH`.
- `docs/demo_guide.md`: 7-minute script with real expected values, checklist, three failure drills (engine missing, tampered log, killed components), honest limits, likely questions.
- `tests/test_preflight.py` (26 tests). Four audit items.

### Fixed
- **Flaky test found:** `test_children_killed_repeatedly_during_a_burst_never_cause_an_unsafe_allow` failed about 1 run in 13 once the release build of the decision engine existed. No unsafe command was ever allowed; the test's own guard ("at least one fail-closed refusal") failed, because a child killed while idle is replaced before the next command and a refusal needs a kill to land mid-request, which is rarer with a fast engine. The test now sends commands (at least 240, bounded at 4000) until a refusal has been observed and kills every 5 ms. 0 failures in 60 runs afterwards (3 in 40 before). Product code unchanged.
- `scripts/preflight.py` first version would have crashed with a traceback if the worker could not be started; caught by a mutation check, now reported as a FAIL.

### Checked
- Mutation checks on `preflight.py` (12 mutants): all killed after the tests were tightened (4 first survived: three because another failure line hid the effect, one because of the crash above). The end-to-end mutants give the same result as in 0.16.0.
- A release build of the decision engine was built and used for the first time in this phase.

## [0.17.0] - Phase 17: documentation and screenshots (2026-11-05)

### Added
- `docs/user_guide.md` (dashboard walkthrough with the five screenshots), `docs/architecture.md`, `docs/limitations.md` (the single list of limits and untested areas).
- `tests/test_docs.py` (20 tests: relative links and images, screenshots, command/module names, layout paths, safety notice kept, no "planned/skeleton" wording). Two audit items.

### Changed
- README rewritten: it still described the Rust engine as a skeleton and the dashboard as an initial version, and held the whole status in one paragraph. Stale statements fixed in docs/decision_policy.md (performance), docs/installation.md (phase labels), the pipeline CLI message and the `voltguard.main` docstring.
- Dashboard Traffic table: the Decision column was off-screen at the default window size and headers were clipped. Column widths adjusted, header shortened to "Pressure (simulated)", event-log timestamp column widened. Screenshots regenerated from a fresh event database (the previous ones came from a database that had accumulated runs).

### Checked
- Docs tests were mutation-checked in a scratch copy (dead link, missing screenshot, nonexistent module, stale wording: all caught). A first mutant was ineffective (it changed only the link label); it was redone.

## [0.16.0] - Phase 16: full integration testing (2026-11-04)

### Added
- `tests/test_end_to_end.py` (13 tests): generator -> worker process -> parser/engine children -> SQLite -> export, row-by-row agreement; random stream vs the independent oracle; CLI chain; two sessions on one database; kill -9 of the worker during a burst; killed parser/engine (idle, both, and repeatedly during a burst); no orphaned children. Five new audit items. `docs/integration_testing.md`.

### Findings
- No product defect found. One wrong expectation of mine (a child killed while idle is restarted before the next command, so that command is served, not refused) was corrected after the tests failed.
- Mutation checks on the paths these tests protect: commit removal, parser/engine restart-before-use, forced reply id and ignored source were all killed (the two restart mutants only after the idle-kill test was tightened to assert the exact BLOCK/ALLOW/BLOCK sequence). Three survivors are equivalent or covered elsewhere: not closing the children explicitly (they end anyway when the pipes close), and disabling log-before-allow (covered by the Phase 12 tests, not by these).

## [0.15.0] - Phase 15: CSV/JSON export and optional PDF report (2026-11-03)

### Added
- `event_logging/export.py`: CSV and JSON export of the stored events, `python -m event_logging.export` (exit codes: 0 ok, 2 refused, 3 PDF library missing, 4 integrity check failed), and `event_logging/report_pdf.py` (optional PDF report, `requirements-optional.txt`). Integrity check first and reported; CSV formula neutralisation; atomic no-overwrite file writing; refusal of bad targets; truncation reported. `EventStore.export_rows`.
- Worker op `export`; dashboard Export CSV / JSON / PDF buttons with a status line, an alert when an export fails or finds a failed integrity check.
- Tests: 33 Python export tests, 7 dashboard tests (131 in total), 7 new audit items; test runner accepts `VOLTGUARD_TEST_CLASSES` for quick mutation checks.

### Verification notes
- Mutation checks: 28 mutants of the export, PDF and worker code (24 killed at once, 2 after two weak tests were strengthened: a folder test that matched only the file name, and a PDF test that matched only part of a sentence; two are equivalent: the early "file exists" check duplicates the atomic link, and the NUL-byte check duplicates the path checks) and 13 of the dashboard export code (12 killed at once; the client's error-reply routing had no test, one was added and it was killed).
- Not tested: truncation display in the dashboard (needs more than 100,000 rows or a fake worker), PDF appearance in other viewers.

## [0.14.0] - Phase 14: performance measurement (2026-11-03)

### Added
- `scripts/benchmark.py`: per-stage latency (parse, simulate, decide, log, whole `handle`) for four workloads plus the real worker round trip, percentiles, an optional `--background-load N` stress run, JSON output and a PASS/FAIL verdict against `--target-ms` (default 10).
- `docs/performance.md` with the measured results and their limits; `docs/performance_results.json` and `docs/performance_results_loaded.json`.
- `tests/test_benchmark.py` (9 tests): percentile and summary arithmetic, result structure, verdict logic; deliberately no speed thresholds.

### Results (this machine only)
- Idle: p99 of the full per-command path 3.6 to 4.4 ms (target 10 ms: met). Under two busy-loop processes on two CPUs: p99 10.2 and 11.3 ms for the two write workloads (target missed). The SQLite commit is about 65 % of the idle cost.

## [0.13.0] - Phase 13: dashboard graphs and alerts (2026-11-01)

### Added
- "Graphs and alerts" tab (Qt Charts): predicted pressure and flow of the processed commands (SIMULATED), configured minimum/maximum drawn as dashed lines from the worker's configuration, markers coloured by decision (ALLOW / BLOCK / REJECT). The vertical axis always spans every plotted value and both limits, so an out-of-limit prediction is visible beyond its line. At most 200 points; the x axis is the order of plotted commands, not time. Commands without a prediction (parser rejections, failures) are not plotted.
- Alerts (`dashboard/src/alerts.*`): BLOCK and every fail-closed REJECT and component failure are CRITICAL; other REJECTs are WARNING; "event NOT stored" is an extra WARNING; system alerts for a missing decision engine, parser or event log, a failed worker and a failed log integrity check. The list holds 200 alerts (older ones are counted as dropped), is shown newest first, and a summary also appears on the Dashboard tab. Alerts are display only: they change no decision and the Clear button does not touch the event log.
- Screenshots: five tabs (`3_graphs_and_alerts.png` added).
- Tests: 13 chart/alert unit tests and 2 window integration tests (119 dashboard tests in total); 3 new audit items.

### Changed
- Qt Charts is now required to build the dashboard (`qt6-charts-dev` on Ubuntu).

### Verification notes
- Mutation checks on the new code (22 mutants of the alert rules, the chart panel and the main-window hooks): all killed. One mutant was first skipped because my search string did not match; it was re-run and killed.

### Known limitations
- Graphs show simulated predictions of commands, not plant measurements, and have no time axis. Not tested on a real display; rendering was checked only through offscreen screenshots.

## [0.12.0] - Phase 12: safety and failure tests (2026-11-01)

### Added
- `tests/test_safety_invariants.py` (57 tests): independent-oracle fuzz through the real parser, physics and decision engine; exhaustive pump/valve sweep; fault matrix over parser, solver and engine faults; event-log failure tests; 17 corrupt configurations; hostile worker input; bounded latency with a hung engine. `docs/failure_modes.md`.
- Six "System safety" items in the generated report.

### Fixed
- Worker: an ALLOW was released if the event store returned any value other than `False` (for example a junk value), and an exception from the store would have escaped. An ALLOW now needs an explicit `True`; a raising or junk-returning store gives REJECT (`EVENT_LOG_UNAVAILABLE`). The shipped `EventStore` already returned a bool and never raised, so this was a robustness gap, not an observed failure.

### Verification notes
- 9 mutants of the bridge, worker and pipeline were run against the new suite: 8 killed. The survivor (`logged is not True` -> `logged is False`) is equivalent now that `_store_event` normalises the value. A first mutation run had silently lost the configuration tests through an editing mistake of mine (no mutant on that path was killed); this was noticed and the tests restored before the numbers above.

## [0.11.0] - Phase 11: allow/block integration (2026-11-01)

### Added
- `voltguard/decision_bridge.py`: `Decider` runs the Rust engine as a subprocess (fixed argv, no shell, timeout from `timeouts_ms.decision`, command-id check, restart after crash/hang/desync). Every failure becomes REJECT with `source: "fail_closed"` and an error code; ALLOW/BLOCK are accepted only for a SIMULATED + SUCCESS result; a Python second check vetoes an ALLOW whose predicted values are outside the limits.
- Worker: every `result` carries a `decision`; `--decision-engine PATH`; the ready message reports `decision_engine {available, path, error}`. **Log-before-allow:** if event logging is on and the write fails, ALLOW becomes REJECT (`EVENT_LOG_UNAVAILABLE`).
- Event log schema v2: decision, reason and source columns inside the hash chain; v1 databases are migrated on open and still verify.
- Dashboard: Decision column and counters (allowed / blocked / rejected), latest decision, engine status; strict validation of the `decision` object.
- Tests: 37 bridge tests, integration tests through the worker (27 scenarios, faulty fake engine modes, log-before-allow), schema-v2 tests, dashboard decision tests (104 in total).

### Changed
- A dashboard failure row is now a REJECT (fail closed). `COMPONENT_STATUS` and docs updated.

### Known limitations
- Nothing is forwarded to any device; allowed commands are not applied to the simulated plant state. ALLOW refers to simulated predictions against example limits. Windows/MSVC/real display untested.

## [0.10.0] - Phase 10: Rust decision engine (2026-11-01)

### Added
- `decision_engine/` (Rust, `serde_json` only): `decide()` turns one pipeline result into ALLOW / BLOCK / REJECT with a reason (<= 512 printable ASCII chars). Rule-based and deterministic; ALLOW has a single construction point; everything missing, mistyped, non-finite, contradictory or unexpected is REJECT or BLOCK. The engine re-checks the limits (inclusive), the written registers (100 pump, 101 valve) and values, command-id consistency and that the simulation used the same pressure limits. Full table and design choices in `docs/decision_policy.md`.
- JSON-lines CLI (`--config PATH`): one reply per input line; error lines instead of decisions for bad JSON / unusable ids / lines over 1 MB; exit 2 with no output for an invalid configuration; panics are caught and reported as errors.
- Strict configuration loader mirroring `config/safety_limits.json`.
- `tests/fixtures/pipeline_results.jsonl` (real pipeline output for all 27 scenarios) and `scripts/generate_decision_fixture.py [--check]`.
- Tests: 27 Rust tests (unit + integration: real fixtures vs designed intent through library and CLI, 60+ adversarial cases, CLI robustness, 60,000-input deterministic fuzz with an independently written oracle) and 9 Python contract tests (`tests/test_decision_contract.py`: output validated by `DecisionResult.from_dict`, register map equality, fixture freshness). Nine decision-engine audit items in the generated report, which now builds the engine before running pytest.

### Verification notes
- Mutation check on a scratch copy: 32 deliberate defects in `lib.rs`; 30 killed on the first run. Survivors: result-text truncation (unreachable through the public API because echoed text is already capped; a direct unit test of the helper was added) and the 123-register cap (redundant with the unmapped-register rule while only two registers are mapped; kept as defence in depth).
- Results: all 27 scenarios receive the decision their design intends (6 ALLOW, 5 BLOCK, 16 REJECT).

### Not done / limitations
- Not connected to the pipeline or dashboard (Phase 11); the decision timeout is enforced by the caller in Phase 11. Stateless per command. ALLOW refers to simulated predictions against example limits only. Performance not measured (Phase 14).
- Reads are ALLOWED even when the predicted state is outside limits (documented policy choice).

## [0.9.0] - Phase 9: persistent event logging (2026-10-31)

### Added
- `event_logging/event_store.py`: SQLite event store (one row per processed command: time, id, source, stage, severity, simulation status, parsed fields, SIMULATED predictions, violations, errors, frame hex, JSON blobs, timings). Bound parameters only, length-capped text, schema-version check, newest-first filtered queries, SHA-256 hash chain with `verify()`, `UnavailableStore` so a failed log is reported instead of hidden. Documented in `docs/event_logging.md`.
- Worker: logs every command (`--event-db`, `--no-event-log`), replies carry `logged` (true / false / null), new ops `events` and `verify_log`, `event_log` status in the ready message. Processing continues if the log is unusable but is flagged.
- Dashboard: "NOT STORED" shown and escalated for unlogged commands, event-log status line, Event log tab with stored-events table, "Load stored events" and "Verify log integrity" (query watchdog included); the scenario name is stored as the event source.
- Tests: `tests/test_event_store.py` (69 tests) and 8 more dashboard tests (85 in total). Six event-log audit items and one more dashboard item in the generated report.

### Verification notes
- Mutation checks on scratch copies: event store/worker 19 mutants, dashboard 12. Real gaps found and fixed: only some hashed columns were tamper-tested (now all 17), the query-limit clamp, the displayed failure of a failed integrity check, and a pending log query surviving a worker failure. Remaining equivalents: none known.

### Not done / limitations
- Tamper-evidence only: tail truncation and full chain recomputation are not detected; no signatures. Unbounded growth, no rotation. No decision column yet (Phase 10/11). Whether a failed log write should block a future ALLOW is an open Phase 11 decision.

## [0.8.0] - Phase 8: initial native Qt 6 dashboard (2026-10-31)

### Added
- `dashboard/` (C++17, Qt 6 Widgets): main window with Dashboard (status, counters, latest command), Traffic (table + command details), Event log and Configuration (read-only limits) tabs, dark industrial theme, a banner and status bar stating that all values are SIMULATED and that no decision engine exists yet. Controls: run all scenarios, send one scenario, send a manual hex frame, clear, restart worker.
- `voltguard/worker.py`: JSON-lines worker so parsing and simulation run outside the GUI process; protocol documented in `integration/interfaces.md`.
- `WorkerClient` (QProcess, no shell): per-request watchdog, start timeout, line-size cap, id matching; hung, crashed, garbled or oversized workers become a `Failed` state and visible `COMPONENT_FAILURE` rows, never a result.
- `CommandRecord::fromJson`: strict validation of worker results, mirroring the Python contract.
- `dashboard/tests/dashboard_tests.cpp` (QtTest, 77 tests, headless) and `tests/fixtures/fake_worker.py`; `tests/test_worker.py` (32 tests).
- `voltguard_dashboard --screenshot-dir DIR` writes one PNG per tab (docs/screenshots/, offscreen platform).
- Report generator: dashboard suite, dashboard-under-ASan/UBSan suite, six dashboard audit items (`--no-dashboard` to skip).

### Verification notes
- Mutation check of the dashboard in a scratch copy (18 deliberate defects: severity, decision text, strict-validation checks, pending-request handling, watchdog, unknown-id results, oversize guards, input validation, failure display, destructor, row cap, counters). First run: 15 killed, 3 survived. One was a genuine test gap (a message claiming `PARSE_REJECTED` while still carrying a parsed command was only rejected by an unrelated check); 3 test cases added and the mutant is now killed. The other two were the two overlapping oversize-line guards, each redundant alone; removing both is killed.
- Generated report: 77 QtTest cases pass normally and under ASan/UBSan (leak detection off), 415 pytest cases, 3390 C++ parser checks; 23/23 audit items.

### Fixed (found by the new tests)
- Use-after-free at shutdown: `~WorkerClient` reported pending requests to a half-destroyed `MainWindow`. Found when a failing test unwound; `~MainWindow` now disconnects and stops the worker first.
- Traffic table hid the Safety status column behind the details pane; column widths and splitter sizes adjusted.

### Not done / limitations
- No allow/block decision (Phase 10-11); Decision column is always `-`. Limits cannot be edited yet. No graphs/alerts yet (Phase 13).
- Built and tested only with Qt 6.4.2 on Linux, headless; real display, Windows and MSVC untested.

## [0.7.0] - Phase 7: parser-to-simulation integration (2026-10-30)

### Added
- `voltguard/pipeline.py`: `Pipeline.process_frame(command_id, frame)` runs the C++ parser as one long-lived child process (fixed argument list, `shell=False`, one request line in / one JSON line out) and feeds the validated `ParsedCommand` to the physics simulation. Returns a `PipelineResult` (stage `SIMULATED`, `PARSE_REJECTED` or `COMPONENT_FAILURE`, parsed command, simulation result, error code/text, parse/simulate/total timings). Never raises for bad input or failed components.
- Fail-closed handling: parser timeout (from `timeouts_ms.parser`), crash, missing executable, wrong or mismatched command id, non-JSON/oversized/unknown-status replies, schema-violating output and unsolicited extra output all produce a recorded `COMPONENT_FAILURE` with no prediction; the child is killed and restarted on the next request. Simulation timeout (`timeouts_ms.simulation`) and exceptions give a `TIMEOUT`/`ERROR` simulation result.
- Caller-side validation before anything is sent to the child: command id pattern, frame must be bytes, frames over 1000 bytes rejected.
- `python -m voltguard.pipeline --input traffic.json [--output results.json]` runs a traffic file through both stages and prints one line per message (exit 0 / 1 if any component failure / 2 for setup errors).
- `tests/test_integration.py` (53 tests) and `tests/fixtures/fake_parser.py`, a fault-injecting stand-in parser. Five integration audit items added to the generated test report.
- Interface documentation for the pipeline and its error codes in `integration/interfaces.md`.

### Verification notes
- Mutation check on the bridge: 10 of 11 deliberate defects caught; the survivor was one of two overlapping liveness guards (removing both fails 2 tests). A CLI test that never reached exit code 1 was rewritten.

### Not done
- The pipeline does not decide allow/block and never updates the pipeline settings (Phase 10-11). Dashboard responsiveness is untested until Phase 8.

## [0.6.0] - Phase 6: parser and simulation test audit (2026-10-30)

### Added
- Parser tests against a third party: 3,000 random valid frames built by Scapy must round-trip to exactly the fields that went in; Scapy's own Modbus dissector and the C++ parser must decode the same bytes identically (1,300+ frames compared); single-byte-removed/added and corrupted-length variants of 300 valid frames must all be rejected. `tests/test_parser.py` now has 23 tests.
- `scripts/generate_test_report.py`: runs the C++ build and unit tests, the ASan/UBSan build, pytest and cargo, then writes `docs/test_report.md` from the real results and maps each parser/physics audit item from the review plan to the tests that cover it. An item passes only if all its tests exist, ran and passed; skipped tests fail the run. Verified to exit 1 for a deliberately broken parser (9/12 items) and for a missing parser CLI (skips).
- `docs/testing.md`: how to run the tests and read the report.

### Found
- Scapy 2.8.0 cannot dissect function-16 writes of 101..123 registers (returns a raw payload), although the frames are byte-identical to an independent struct-based encoder's. The Scapy cross-check excludes exactly that case (asserted by the test); those frames are covered by the independent reference parser and the round-trip test.
- A test of mine initially failed because of that Scapy limitation, not because of a parser defect; confirmed by comparing bytes before changing the test.

### Not done
- The integration audit (parser-to-simulation schema match, command-id association, timeouts, dashboard responsiveness) waits for the bridge (Phase 7) and the dashboard (Phase 8).

## [0.5.0] - Phase 5: physics engine (2026-10-29)

### Added
- `physics_engine/pipeline_model.py`: steady-state pump curve + valve/pipe system curve, solved with `scipy.optimize.brentq` (closed form kept as a test oracle). `safety_limits.py`: inclusive limit comparison. `simulator.py`: command -> pump/valve settings -> predicted pressure/flow -> `SimulationResult`; also a small CLI (`python -m physics_engine.simulator --pump P --valve V`).
- Fail-closed behaviour: invalid, missing, out-of-range, NaN/inf, unmapped-register and unsupported-function-code inputs give `INVALID_INPUT`; solver exceptions or non-finite/negative outputs give `ERROR`; neither carries predictions or violations. Every result is re-validated against the Phase 2 contract before it is returned.
- `docs/methodology.md`: equations, parameters, units, assumptions, limitations and a results table generated from real simulator output.
- `tests/test_physics.py`: 121 tests (solver vs closed form on a grid, monotonicity, invalid/missing/boundary inputs, solver-failure injection, determinism, purity, scenario outcomes, CLI).

### Changed (corrections found by running the model)
- Phase 3 scenario labels were verified against the model and corrected: `normal_pump_40` predicts 19.58 kPa (below the 20 kPa minimum) and became `unsafe_pump_40_low_pressure`; the single-write "pump 100 + valve closed" scenario never closed the valve and duplicated the pump-100 boundary case, so it became the FC16 scenario `unsafe_multi_pump_100_valve_20`; `boundary_pump_100` became `unsafe_pump_100`. Added `normal_pump_45`, `unmapped_register_write` and `boundary_full_speed_full_open` (flow exactly on the 50 L/s limit). Intent values are now `NORMAL`, `BOUNDARY_SAFE`, `UNSAFE`, `INVALID_VALUE`, `READ_ONLY`, ... (previously `UNSAFE_UNVERIFIED`). Fixture regenerated (27 messages).

### Fixed
- The solver's absolute tolerance was too coarse for a nearly closed valve (1e-9 %): it returned 160.018 kPa, above the 160 kPa pump dead-head. Switched to relative tolerance; a 200,000-point random check now agrees with the closed form to about 1e-13.

### Verification notes
- Mutation check on 10 deliberate defects (inclusive/exclusive limits, unmapped registers allowed, swapped registers, missing range check, wrong pump or valve equation, reads changing state, ...): 9 caught. The survivor (disabling the NaN check on solver output) is masked by the final contract validation, which also rejects NaN/inf.

## [0.4.0] - Phase 4: C++ packet parser (2026-10-29)

### Added
- `packet_interceptor/`: C++17 Modbus/TCP parser (`parser.h/.cpp`) for function codes 3, 6 and 16, with strict validation: 260-byte frame cap (checked first), MBAP header, protocol id, length field, per-function PDU length, quantity limits, FC16 byte count, address-space overflow. Unsupported function codes are rejected before any PDU layout is assumed.
- `wire_format.h/.cpp` and `voltguard_parser_cli`: reads `<command_id> <hex>` lines on stdin and writes one JSON line per request (output matches the Phase 2 ParsedCommand schema). Bounded memory per line, command ids restricted to `[A-Za-z0-9_.-]{1,64}`, untrusted text never echoed. The parser contains no I/O and no security decisions.
- `packet_interceptor/tests/parser_tests.cpp`: 3,390 checks (valid frames, boundaries, every function code 0-255, every truncation, every single-byte corruption of an FC16 frame, 200,000 deterministic random inputs).
- `tests/test_parser.py`: 19 tests running the real CLI against the Phase 3 fixture, validating output with the Phase 2 schema, comparing 6,024 frames against an independent Python reference parser, and hardening checks (garbage, 5 MB lines, shell metacharacters, CRLF).
- CMake option `VOLTGUARD_SANITIZE=ON` for AddressSanitizer + UBSan builds.
- New fixture scenario `malformed_fc3_range_overflow`.

### Removed
- The Phase 1 `toolchain_check` smoke target (superseded by the real tests).

### Verification notes
- Mutation check: deliberately removing the byte-count, length-field, protocol-id or address-range check in a scratch copy made the tests fail in each case. The first run showed the address-range mutant surviving the Python tests (no fixture frame near address 65535), which is why the new scenario was added.

## [0.3.0] - Phase 3: mock Modbus/TCP traffic generator (2026-10-29)

### Added
- `traffic_generator/`: 23 fixed scenarios (normal, aggressive, boundary, out-of-range, read, multi-write, unsupported function codes, 11 malformed frame types) plus a seeded random stream mode.
- Well-formed frames are built with Scapy's Modbus layer and cross-checked in tests against an independent struct-based encoder; malformed frames are hand-written bytes.
- `voltguard/register_map.py`: invented register map for the mock pipeline (100 = pump speed %, 101 = valve position %).
- `tests/fixtures/mock_traffic.json`: committed fixture (with expected parse outcomes) for the Phase 4 C++ parser tests; a test fails if it drifts from the generator.
- 29 new tests. The generator never opens a socket (enforced by a test).

### Note
- Scenario `intent` for well-formed writes (e.g. `UNSAFE_UNVERIFIED`) is the designer's expectation only. It is verified or corrected against the physics model in Phases 5-6.

## [0.2.0] - Phase 2: message schemas (2026-10-28)

### Added
- `voltguard/schemas.py`: strict validators for ParsedCommand, SimulationResult and DecisionResult (exact key sets, types, ranges, finite numbers, cross-field rules such as "a failed simulation carries no predictions").
- `integration/message_schema.json` (language-neutral JSON Schema) and `integration/interfaces.md`.
- 117 new tests, including checks that the JSON Schema enums and fields stay in sync with the Python validators.

### Fixed
- Command IDs used `re.match` with `$`, which accepted a trailing newline (`"id\n"`); now `fullmatch`. Caught by the new tests before any component used it.

## [0.1.0] - Phase 1: project skeleton (2026-10-28)

### Added
- Project structure, `.gitignore`, `pytest.ini`, `requirements.txt`.
- `config/safety_limits.json` with example simulated limits and timeouts.
- `voltguard.config`: validated, fail-closed safety configuration loader.
- `voltguard.app_logging`: console + rotating-file application logger.
- `voltguard.main`: entry point that loads configuration and reports honest component status.
- C++17 CMake configuration with a toolchain smoke test (the parser is Phase 4).
- Rust crate skeleton for the decision engine (logic is Phase 10).
- 40 pytest tests (configuration, logger, entry point).
- `docs/installation.md`, `scripts/run_tests.ps1`.

### Deviations from the recommended layout
- `logging/` is planned as `event_logging/` to avoid shadowing the standard library.
- Directories for later components are created when their phase begins, not as empty placeholders.
